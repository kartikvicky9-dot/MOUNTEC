import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { google } from "googleapis";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable large file uploads for PDFs/Images
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API routes
  app.post("/api/parse-document", async (req, res) => {
    const { fileContent, fileName, mimeType, textDump } = req.body;
    
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error("GEMINI_API_KEY environment variable is not configured on the server.");
      return res.status(500).json({ error: "Gemini API key is not configured on the server. Please add GEMINI_API_KEY to your environment." });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      
      const systemPrompt = `You are an expert financial auditor for Mountec Pte Ltd. Your task is to analyze the provided invoice document, billing data, text, or spreadsheet, and extract all billing entries as structured sales invoice records.
      
      Please follow these formatting rules strictly:
      1. 'invoiceRef': Extract the exact invoice number (e.g. "2024-001", "ME-1234").
      2. 'client': Extract and clean the client company name (e.g., "VINDAR PRIVATE LIMITED", "Sembcorp").
      3. 'projectRef': Extract the project location, contract number, or site details.
      4. 'invoiceDate': Identify the invoice issue date. Format as YYYY-MM-DD.
      5. 'amount': The subtotal base amount (before GST).
      6. 'gst': The GST/tax amount (usually 9% of base amount in Singapore, or as stated).
      7. 'totalAmount': The gross total (amount + gst).
      8. 'paymentDueDate': Identify the due date. Format as YYYY-MM-DD. If not listed, set it to 30 days after the invoiceDate.
      9. 'receivedDate': If there's proof of payment or clear remarks indicating full/partial payment date, specify as YYYY-MM-DD. Otherwise leave empty.
      10. 'receivedAccount': Mention the receiving bank or account if specified (e.g., "OCBC", "UOB"), or leave empty.
      11. 'actualReceivedTotal': The total amount actually paid/received so far. If fully paid, it should equal totalAmount. If unpaid, it is 0.
      12. 'outstandingBalance': The remaining unpaid balance (totalAmount - actualReceivedTotal).
      13. 'status': Must be one of: "Paid", "Overdue", "Cancelled". (Use "Paid" if outstandingBalance <= 0, otherwise "Overdue" if the due date is in the past, or "Overdue" as general default for pending invoices).
      14. Output a JSON array containing these invoice objects. Do not wrap in markdown or anything else outside of the schema.`;

      const invoiceSchema = {
        type: Type.ARRAY,
        description: "List of extracted sales invoices",
        items: {
          type: Type.OBJECT,
          properties: {
            invoiceRef: { type: Type.STRING, description: "Invoice reference/number" },
            client: { type: Type.STRING, description: "Client name" },
            projectRef: { type: Type.STRING, description: "Project reference / site details" },
            invoiceDate: { type: Type.STRING, description: "Invoice date in YYYY-MM-DD format" },
            amount: { type: Type.NUMBER, description: "Base amount before GST" },
            gst: { type: Type.NUMBER, description: "GST amount (usually 9%)" },
            totalAmount: { type: Type.NUMBER, description: "Total gross amount (amount + GST)" },
            paymentDueDate: { type: Type.STRING, description: "Due date in YYYY-MM-DD format" },
            receivedDate: { type: Type.STRING, description: "Received date in YYYY-MM-DD format or empty" },
            receivedAccount: { type: Type.STRING, description: "Received account name or empty" },
            actualReceivedTotal: { type: Type.NUMBER, description: "Actual total received amount" },
            outstandingBalance: { type: Type.NUMBER, description: "Outstanding balance" },
            status: { type: Type.STRING, description: "Must be Paid, Overdue, or Cancelled" }
          },
          required: ["invoiceRef", "client", "invoiceDate", "amount", "totalAmount", "status"]
        }
      };

      let response;
      if (textDump) {
        // Handle text dump (from CSV, Excel, Word, or Google Sheets parsed on client)
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [
            `Please extract the sales invoices from this raw document text:\n\n${textDump}`
          ],
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: invoiceSchema,
          }
        });
      } else if (fileContent && mimeType) {
        // Handle image or PDF directly (multimodal)
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [
            {
              inlineData: {
                data: fileContent,
                mimeType: mimeType
              }
            },
            "Please scan this document and extract all billing sales invoices."
          ],
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: invoiceSchema,
          }
        });
      } else {
        return res.status(400).json({ error: "Missing both fileContent and textDump in request payload." });
      }

      const rawText = response.text || "[]";
      const parsedData = JSON.parse(rawText);
      res.json({ success: true, count: parsedData.length, data: parsedData });

    } catch (err: any) {
      console.error("Gemini scanning error:", err);
      res.status(500).json({ error: err?.message || "Failed to parse document using Gemini" });
    }
  });

  app.get("/api/sheets/:spreadsheetId", async (req, res) => {
    const { spreadsheetId } = req.params;
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: Missing Google OAuth token" });
    }
    const token = authHeader.substring(7);
    
    try {
      const oauth2Client = new google.auth.OAuth2();
      oauth2Client.setCredentials({ access_token: token });

      const sheets = google.sheets({ version: "v4", auth: oauth2Client });
      
      // Retrieve spreadsheet metadata to get the actual name of the first sheet dynamically
      let sheetName = "Sheet1";
      try {
        const meta = await sheets.spreadsheets.get({ spreadsheetId });
        if (meta.data.sheets && meta.data.sheets.length > 0) {
          sheetName = meta.data.sheets[0].properties?.title || "Sheet1";
        }
      } catch (metaErr) {
        console.warn("Could not retrieve spreadsheet metadata, falling back to default range", metaErr);
      }

      const response = await sheets.spreadsheets.values.get({
        spreadsheetId,
        range: `${sheetName}!A1:Z200`,
      });
      res.json(response.data);
    } catch (error: any) {
      console.error("Error fetching Google Sheet:", error);
      res.status(500).json({ error: error?.message || "Failed to fetch sheet" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
