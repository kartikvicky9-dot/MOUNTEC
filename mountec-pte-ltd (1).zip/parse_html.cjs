const fs = require('fs');
const html = fs.readFileSync('data.html', 'utf-8');

// very basic extraction
const rows = html.match(/<tr.*?>(.*?)<\/tr>/g);
const result = [];

if (rows) {
  for (const row of rows) {
    const cells = row.match(/<(td|th).*?>(.*?)<\/(td|th)>/g);
    if (cells) {
      const rowData = cells.map(cell => {
        // remove tags
        let text = cell.replace(/<[^>]+>/g, '').trim();
        // decode html entities if needed
        text = text.replace(/&#39;/g, "'").replace(/&amp;/g, '&');
        return text;
      });
      result.push(rowData);
    }
  }
}

// We only want the rows starting from the header row (S/No, Employee ID, ...)
const headerIndex = result.findIndex(row => row.includes('S/No') || row.includes('Employee ID'));
if (headerIndex !== -1) {
  const finalData = result.slice(headerIndex);
  fs.writeFileSync('src/defaultData.ts', `export const defaultSheetData = ${JSON.stringify(finalData, null, 2)};\n`);
  console.log('Successfully extracted data to src/defaultData.ts');
} else {
  console.log('Could not find header row');
}
