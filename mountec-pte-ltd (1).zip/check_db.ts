import { collection, getDocs } from 'firebase/firestore';
import { db } from './src/lib/firebase';
import fs from 'fs';

try {
  async function main() {
    const querySnapshot = await getDocs(collection(db, 'salesInvoices'));
    let out = `Found ${querySnapshot.size} salesInvoices in Firestore.\n`;
    if (querySnapshot.size > 0) {
      const sample = querySnapshot.docs[0].data();
      out += `Sample doc: ${JSON.stringify(sample)}\n`;
    }
    fs.writeFileSync('./db_output.txt', out, 'utf8');
    console.log(out);
    process.exit(0);
  }

  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
} catch (e) {
  console.error(e);
}
