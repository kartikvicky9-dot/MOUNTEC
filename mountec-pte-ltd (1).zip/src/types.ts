export interface Worker {
  id: string;
  sNo?: string;
  employeeId?: string;
  nameOfWorker?: string;
  nationality?: string;
  dateOfApplication?: string;
  dateOfEmployment?: string;
  wpsPassIssuanceDate?: string;
  dateOfBirth?: string;
  finNo?: string;
  wpsPassNo?: string;
  wpsPassExpiryDate?: string;
  passportNo?: string;
  passportExpiryDate?: string;
  passportIssuingCountry?: string;
  wpsPassStatus?: string;
  bankAccountNo?: string;
  bankName?: string;
  mobileNumber?: string;
  emailId?: string;
  password?: string;
  exitDate?: string;
  workDurationMonth?: string;
  name?: string;
  role?: string;
  status?: string;
  baseSalary?: string;
  overtimeRate?: string;
  designation?: string;
  spreadsheetId?: string;
}

export interface SpreadsheetData {
  range: string;
  majorDimension: string;
  values: string[][];
}

export interface Project {
  id: string;
  sNo: string;
  date: string;
  projectRef: string;
  name: string;
  client: string;
  sum: number;
  actualWork: number;
  actualWorkPercent: number;
  scopeOfWorks?: string;
  status?: string;
  estTopDate?: string;
}

export interface Client {
  id: string;
  sNo: string;
  clientCode: string;
  name: string;
  contactPerson: string;
  contactNumber: string;
  email: string;
  address: string;
  remarks: string;
  createdAt?: number;
}

export interface Quotation {
  id: string;
  date: string;
  referenceNo: string;
  project: string;
  clientName: string;
  sum: number;
  gst: number;
  total: number;
  remarks: string;
}

export interface DeploymentSegment {
  projectRef: string;
  projectName: string;
  timeIn: string;
  timeOut: string;
  breakMinutes: number;
  workingHours: number;
  remarks?: string;
  transportClaim?: number;
}

export interface WorkDeployment {
  id: string;
  sNo?: string;
  employeeId: string;
  employeeName: string;
  projectRef: string;
  projectName: string;
  date: string;
  timeIn: string;
  timeOut: string;
  totalWorkingHours: number;
  shift?: string;
  status?: string;
  remarks?: string;
  createdAt?: number;
  segments?: DeploymentSegment[];
  transportClaim?: number;
}



