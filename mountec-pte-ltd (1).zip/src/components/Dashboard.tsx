import React, { useState } from 'react';
import { 
  Users, 
  ShieldAlert, 
  FileText, 
  Activity, 
  Wallet, 
  Briefcase,
  LogOut,
  Building2,
  Menu,
  X,
  ArrowLeft,
  ZoomIn,
  ZoomOut,
  ListTodo,
  Bell,
  KeyRound,
  Folder,
  ChevronDown,
  ChevronRight,
  Search,
  ClipboardList
} from 'lucide-react';
import { logout, db } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import ExecutiveGovernancePanel from './panels/executive/ExecutiveGovernancePanel';
import OverallFlowChart from './panels/executive/OverallFlowChart';
import HRManagementPanel from './panels/hr/HRManagementPanel';
import MountecLogo from './MountecLogo';
import SafetyPanel from './panels/hseq/SafetyPanel';
import PlaceholderPanel from './panels/support/PlaceholderPanel';
import OperationsManagementPanel from './panels/operations/OperationsManagementPanel';
import FinanceManagementPanel from './panels/finance/FinanceManagementPanel';
import SafetyManagementPanel from './panels/hseq/SafetyManagementPanel';
import SupportManagementPanel from './panels/support/SupportManagementPanel';
import AccessRequestsPanel from './panels/hr/AccessRequestsPanel';
import TasksPanel from './panels/operations/TasksPanel';
import SettingsPanel from './panels/executive/SettingsPanel';
import UserCredentialsPanel from './panels/support/UserCredentialsPanel';
import FinancePanel from './panels/finance/FinancePanel';
import { useAppContext } from '../context/AppContext';
import { Settings } from 'lucide-react';

const navItems = [
  { id: 'flowchart', label: 'OVERALL FLOW CHART', icon: Activity, component: OverallFlowChart },
  { id: 'executive', label: '1. EXECUTIVE & GOVERNANCE', icon: Folder, component: ExecutiveGovernancePanel },
  { id: 'hr', label: '2. HUMAN CAPITAL MANAGEMENT', icon: Users, component: HRManagementPanel },
  { id: 'ops', label: '3. OPERATIONS & DELIVERY', icon: Briefcase, component: OperationsManagementPanel },
  { id: 'accounts', label: '4. FINANCE & ACCOUNTING', icon: Wallet, component: FinanceManagementPanel },
  { id: 'safety', label: '5. SAFETY', icon: ShieldAlert, component: SafetyPanel },
  { id: 'general', label: '6. SUPPORT & GENERAL', icon: Folder, component: SupportManagementPanel },
  { id: 'settings', label: 'SETTINGS', icon: Settings, component: SettingsPanel },
];

export default function Dashboard({ isDay }: { isDay: boolean }) {
  const { isViewOnly, isUserAdmin, isMasterAdmin, userRole, accessiblePanels, accessStatus, requestAccess, preferences, user } = useAppContext();
  const [activeTab, setActiveTab] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  
  const [selectedSafetyFolderId, setSelectedSafetyFolderId] = useState('5.1.1.1');
  const [safetyExpanded, setSafetyExpanded] = useState(true);
  const [subSafetyExpanded, setSubSafetyExpanded] = useState(true);
  const [subSubSafetyExpanded, setSubSubSafetyExpanded] = useState(true);
  
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [requestName, setRequestName] = useState('');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');

  React.useEffect(() => {
    if (user?.email) {
      setRequestName(user.email);
    }
  }, [user]);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [pendingTasksCount, setPendingTasksCount] = useState(0);
  const [showTaskNotification, setShowTaskNotification] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  React.useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isPublicUrl = window.location.hostname.includes('ais-pre-') || window.location.hostname.includes('shared');
  
  const visibleNavItems = navItems.filter(item => {
    if (item.id === 'settings') {
      return !isViewOnly;
    }
    // If not master admin and not explicitly in accessiblePanels, hide it
    if (!isMasterAdmin && accessiblePanels && accessiblePanels.length > 0 && !accessiblePanels.includes(item.id)) {
      return false;
    }
    return true;
  });

  if (isMasterAdmin || userRole === 'Admin' || (accessiblePanels && accessiblePanels.includes('access'))) {
    visibleNavItems.push({ id: 'access', label: 'ACCESS REQUESTS', icon: ShieldAlert, component: AccessRequestsPanel });
  }

  if (isMasterAdmin) {
    visibleNavItems.push({ id: 'credentials', label: 'USER CREDENTIALS', icon: KeyRound, component: UserCredentialsPanel });
  }

  React.useEffect(() => {
    if (visibleNavItems.length > 0 && !activeTab) {
      setActiveTab(visibleNavItems[0].id);
      setHistory([visibleNavItems[0].id]);
    }
  }, [visibleNavItems, activeTab]);

  const modulesItems = visibleNavItems.filter(item => !['settings', 'access', 'credentials'].includes(item.id));
  const controlPanelItems = visibleNavItems.filter(item => ['settings', 'access', 'credentials'].includes(item.id));

  const handleTabChange = (id: string) => {
    if (id !== activeTab) {
      setHistory(prev => [...prev, id]);
      setActiveTab(id);
    }
    setMobileMenuOpen(false);
  };

  const handleBack = () => {
    if (history.length > 1) {
      const newHistory = [...history];
      newHistory.pop(); // remove current
      const prevTab = newHistory[newHistory.length - 1];
      setHistory(newHistory);
      setActiveTab(prevTab);
    }
  };

  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.1, 2));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.1, 0.5));

  const ActiveComponent = (visibleNavItems.find(item => item.id === activeTab)?.component as any) || null;

  const handleRequestSubmit = () => {
    if (requestName.trim()) {
      requestAccess(requestName.trim());
      setShowRequestModal(false);
    }
  }

  return (
    <div 
      className={`min-h-screen ${isDay ? 'bg-gray-100 text-gray-900' : 'bg-[#0A0A0A] text-[#E0E0E0]'} font-sans flex flex-col md:flex-row overflow-x-hidden transition-colors duration-500`}
      style={!isMobile ? { zoom: zoomLevel } as React.CSSProperties : undefined}
    >
      {/* Mobile Header */}
      <div className={`md:hidden ${isDay ? 'bg-white text-black' : 'bg-[#111111] text-white'} p-4 flex items-center justify-between border-b ${isDay ? 'border-gray-200' : 'border-[#2A2A2A]'} z-20 transition-colors duration-500`}>
        <div className="flex items-center space-x-3">
          {history.length > 1 && (
            <button onClick={handleBack} className={`p-1 mr-1 ${isDay ? 'text-gray-600 hover:text-black' : 'text-[#999] hover:text-white'} transition-colors`}>
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <MountecLogo className={`w-8 h-8 rounded-md ${isDay ? 'bg-gray-900' : 'bg-white'} p-1 shrink-0`} />
          <h1 className={`text-lg font-bold tracking-tight ${isDay ? 'text-black' : 'text-white'}`}>MOUNTEC <span className="text-blue-500">PTE LTD</span></h1>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleZoomOut} className={`p-1 ${isDay ? 'text-gray-600 hover:text-black' : 'text-[#999] hover:text-white'}`}>
            <ZoomOut className="w-5 h-5" />
          </button>
          <button onClick={handleZoomIn} className={`p-1 ${isDay ? 'text-gray-600 hover:text-black' : 'text-[#999] hover:text-white'}`}>
            <ZoomIn className="w-5 h-5" />
          </button>
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className={`p-1 ml-2 ${isDay ? 'text-gray-800' : 'text-white'}`}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Search */}
      <div className={`md:hidden ${isDay ? 'bg-gray-50 border-gray-200' : 'bg-[#141414] border-[#2A2A2A]'} border-b p-3 z-10 transition-colors duration-500`}>
        <div className="relative w-full">
          <Search className={`w-4 h-4 ${isDay ? 'text-gray-500' : 'text-[#777]'} absolute left-3 top-1/2 transform -translate-y-1/2`} />
          <input
            type="text"
            placeholder={`Search ${visibleNavItems.find(item => item.id === activeTab)?.label}...`}
            value={globalSearchQuery}
            onChange={e => setGlobalSearchQuery(e.target.value)}
            className={`w-full ${isDay ? 'bg-white border-gray-300 text-black' : 'bg-[#1A1A1A] border-[#333] text-white'} border text-xs rounded-full py-2 pl-9 pr-4 focus:outline-none focus:border-blue-500 transition-colors`}
          />
        </div>
      </div>

      {/* Mobile Backdrop Overlay */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-30 md:hidden transition-opacity duration-200"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <div className={`
        fixed inset-y-0 left-0 transform ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0 z-40 md:z-10 w-64 ${isDay ? 'bg-white text-gray-900 border-r-gray-200' : 'bg-[#111111] text-[#E0E0E0] border-r-[#2A2A2A]'} border-r transition-colors duration-200 ease-in-out flex flex-col shadow-2xl
      `}>
        <div className={`p-6 flex items-center justify-between border-b ${isDay ? 'border-gray-200' : 'border-[#2A2A2A]'}`}>
          <div className="flex items-center space-x-3">
            <MountecLogo className={`w-10 h-10 rounded-md ${isDay ? 'bg-gray-900' : 'bg-white'} p-1 shrink-0`} />
            <div>
              <h1 className={`text-xl font-bold ${isDay ? 'text-black' : 'text-white'} tracking-tight leading-tight uppercase`}>MOUNTEC</h1>
              <p className="text-sm text-blue-500 font-bold tracking-widest uppercase">PTE LTD</p>
            </div>
          </div>
          {/* Close menu button on mobile */}
          <button 
            onClick={() => setMobileMenuOpen(false)}
            className={`md:hidden p-1.5 ${isDay ? 'bg-gray-100 border-gray-200 text-gray-700' : 'bg-[#1A1A1A] border-[#333] text-[#777]'} border hover:border-blue-500 rounded-lg hover:text-white transition-all cursor-pointer`}
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-6 space-y-2 overflow-y-auto">
          <p className={`px-3 text-xs font-bold ${isDay ? 'text-gray-500' : 'text-[#777]'} mb-3 uppercase tracking-wider`}>MODULES</p>          {modulesItems.map((item) => {
            if (item.id === 'safety') {
              return (
                <div key="safety-menu-group" className="space-y-1">
                  {/* Root SAFETY button */}
                  <button
                    onClick={() => {
                      handleTabChange('safety');
                      setSafetyExpanded(!safetyExpanded);
                    }}
                    className={`
                      w-full flex items-center justify-between px-3 py-2.5 text-xs font-bold rounded-lg transition-colors
                      ${activeTab === 'safety' 
                        ? (isDay ? 'bg-gray-100 text-rose-600 border-rose-500/20' : 'bg-[#1A1A1A] text-rose-500 border-rose-500/20')
                        : (isDay ? 'text-gray-600 hover:bg-gray-100 hover:text-black' : 'text-[#999] hover:bg-[#1A1A1A] hover:text-white')}
                      border border-transparent
                    `}
                  >
                    <span className="flex items-center">
                      <item.icon className={`w-4 h-4 mr-3 ${activeTab === 'safety' ? 'text-rose-500' : (isDay ? 'text-gray-500' : 'text-[#777]')}`} />
                      5. SAFETY
                    </span>
                    {safetyExpanded ? <ChevronDown className="w-3.5 h-3.5 text-[#555]" /> : <ChevronRight className="w-3.5 h-3.5 text-[#555]" />}
                  </button>


                  {/* Safety Subfolders list */}
                  {safetyExpanded && (
                    <div className="pl-4 ml-2 border-l border-rose-500/10 space-y-1.5 pt-1">
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.1.1');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.1.1' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.1.1 DAILY TOOLBOX MEETING
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.1.2');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.1.2' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.1.2 PPE ISSUANCE RECORD
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.2');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.2' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.2 QUALITY RELATED
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.3');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.3' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.3 ENVIRONMENT RELATED
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.4');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.4' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.4 SQE RELATED FORMS
                      </button>
                      <button
                        onClick={() => {
                          setSelectedSafetyFolderId('5.1.5');
                          handleTabChange('safety');
                        }}
                        className={`w-full text-left px-2 py-1 text-[11px] font-semibold rounded transition-colors ${
                          selectedSafetyFolderId === '5.1.5' && activeTab === 'safety'
                            ? (isDay ? 'bg-gray-100 text-rose-600' : 'bg-[#1C1C1C] text-rose-500')
                            : (isDay ? 'text-gray-500 hover:bg-gray-50 hover:text-gray-900' : 'text-[#777] hover:bg-[#151515] hover:text-white')
                        }`}
                      >
                        5.1.5 AUDITING RELATED
                      </button>
                    </div>
                  )}
                </div>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`
                  w-full flex items-center px-3 py-2.5 text-xs font-bold rounded-lg transition-colors
                  ${activeTab === item.id 
                    ? (isDay ? 'bg-gray-100 text-blue-600 border border-gray-300' : 'bg-[#1A1A1A] text-blue-500 border border-[#333]') 
                    : (isDay ? 'text-gray-600 hover:bg-gray-100 hover:text-black' : 'text-[#999] hover:bg-[#1A1A1A] hover:text-white')}
                  border border-transparent
                `}
              >
                <item.icon className={`w-4 h-4 mr-3 ${activeTab === item.id ? 'text-blue-500' : (isDay ? 'text-gray-500' : 'text-[#777]')}`} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[#2A2A2A] space-y-4">
          {controlPanelItems.length > 0 && (
            <div>
              <p className={`px-3 text-xs font-bold ${isDay ? 'text-gray-500' : 'text-[#555]'} mb-2 uppercase tracking-wider`}>CONTROL PANEL</p>              <div className="space-y-1">
                {controlPanelItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`
                      w-full flex items-center px-3 py-2 text-xs font-bold rounded-lg transition-colors
                      ${activeTab === item.id 
                        ? (isDay ? 'bg-gray-100 text-blue-600 border border-gray-300' : 'bg-[#1A1A1A] text-blue-500 border border-[#333]') 
                        : (isDay ? 'text-gray-600 hover:bg-gray-100 hover:text-black' : 'text-[#999] hover:bg-[#1A1A1A] hover:text-white')}
                      border border-transparent
                    `}
                  >
                    <item.icon className={`w-4 h-4 mr-3 ${activeTab === item.id ? 'text-blue-500' : (isDay ? 'text-gray-500' : 'text-[#777]')}`} />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="pt-2 border-t border-[#222]">
            {user && (
              <div className="px-3 py-2 mb-2 bg-[#1A1A1A] border border-[#333] rounded-lg">
                <div className="flex items-center justify-between gap-1">
                  <div className="text-xs font-bold text-white truncate">{user.displayName || user.email?.split('@')[0]}</div>
                  <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded border uppercase tracking-wider ${
                    userRole === 'Master Admin' || isMasterAdmin
                      ? 'bg-[#2D1A3B] text-[#D6BCFA] border-[#553C9A]'
                      : userRole === 'Admin' || isUserAdmin
                      ? 'bg-[#0E2033] text-[#3182CE] border-[#1A365D]'
                      : 'bg-[#1A1D20] text-[#718096] border-[#2D3748]'
                  }`}>
                    {userRole === 'Master Admin' || isMasterAdmin ? 'MASTER ADMIN' : userRole === 'Admin' || isUserAdmin ? 'ADMIN' : 'USER'}
                  </span>
                </div>
                <div className="text-[10px] text-[#777] uppercase tracking-wider truncate mt-0.5">{user.email}</div>
              </div>
            )}
            <button
              onClick={logout}
              className="w-full flex items-center px-3 py-2.5 text-xs font-bold text-[#777] hover:text-white hover:bg-[#1A1A1A] rounded-lg transition-colors border border-transparent hover:border-[#333]"
            >
              <LogOut className="w-4 h-4 mr-3" />
              SIGN OUT
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-[#0A0A0A]">
        <header className={`${isDay ? 'bg-white border-gray-200' : 'bg-[#111111] border-[#2A2A2A]'} border-b h-16 px-8 hidden md:flex items-center justify-between shrink-0 transition-colors duration-500`}>
          <div className="flex items-center gap-4"> 
            {history.length > 1 && (
              <button 
                onClick={handleBack}
                className={`p-1.5 rounded ${isDay ? 'bg-gray-100 text-gray-600 hover:bg-gray-200 border-gray-300' : 'bg-[#1A1A1A] text-[#999] hover:bg-[#222] border-[#333]'} transition-colors border`}
                title="Go Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <h2 className={`text-sm font-bold uppercase tracking-widest ${isDay ? 'text-blue-600' : 'text-blue-500'} whitespace-nowrap`}>
              {visibleNavItems.find(item => item.id === activeTab)?.label}
            </h2>
          </div>
          
          <div className="flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <Search className={`w-4 h-4 ${isDay ? 'text-gray-500' : 'text-[#777]'} absolute left-3 top-1/2 transform -translate-y-1/2`} />
              <input
                type="text"
                placeholder={`Search in ${visibleNavItems.find(item => item.id === activeTab)?.label}...`}
                value={globalSearchQuery}
                onChange={e => setGlobalSearchQuery(e.target.value)}
                className={`w-full ${isDay ? 'bg-white border-gray-300 text-black' : 'bg-[#1A1A1A] border-[#333] text-white'} border text-xs rounded-full py-2 pl-9 pr-4 focus:outline-none focus:border-blue-500 transition-colors`}
              />
            </div>
          </div>

          <div className="flex items-center gap-6 shrink-0">
            <div className="flex items-center gap-2">
              {isPublicUrl && (
                <div className="mr-4">
                  {accessStatus === 'approved' ? (
                     <span className="text-xs font-bold text-green-500 px-3 py-1 bg-green-500/10 border border-green-500/30 rounded uppercase tracking-wider">Edit Access Granted</span>
                  ) : accessStatus === 'pending' ? (
                     <span className="text-xs font-bold text-blue-500 px-3 py-1 bg-blue-500/10 border border-blue-500/30 rounded uppercase tracking-wider">Access Pending</span>
                  ) : (
                     <button onClick={() => setShowRequestModal(true)} className="text-xs font-bold text-black px-3 py-1.5 bg-blue-500 hover:bg-blue-400 rounded uppercase tracking-wider transition-colors">Request Edit Access</button>
                  )}
                </div>
              )}
              <button onClick={handleZoomOut} className={`p-1.5 rounded ${isDay ? 'bg-gray-100 text-gray-600 hover:bg-gray-200 border-gray-300' : 'bg-[#1A1A1A] text-[#999] hover:bg-[#222] border-[#333]'} transition-colors border`} title="Zoom Out">
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className={`text-xs font-bold ${isDay ? 'text-gray-500' : 'text-[#777]'} min-w-[3ch] text-center`}>{Math.round(zoomLevel * 100)}%</span>
              <button onClick={handleZoomIn} className={`p-1.5 rounded ${isDay ? 'bg-gray-100 text-gray-600 hover:bg-gray-200 border-gray-300' : 'bg-[#1A1A1A] text-[#999] hover:bg-[#222] border-[#333]'} transition-colors border`} title="Zoom In">
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
            <div className={`h-8 w-[1px] ${isDay ? 'bg-gray-200' : 'bg-[#2A2A2A]'}`}></div>
            <div className={`flex items-center gap-2 text-sm ${isDay ? 'text-gray-600' : 'text-[#999]'}`}>
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              System Online
            </div>
            <div className={`h-8 w-[1px] ${isDay ? 'bg-gray-200' : 'bg-[#2A2A2A]'}`}></div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className={`text-xs font-semibold ${isDay ? 'text-black' : 'text-white'}`}>{user?.displayName || user?.email?.split('@')[0] || 'User'}</p>
                <p className={`text-[10px] ${isDay ? 'text-gray-500' : 'text-[#777]'}`}>Logged in as {userRole === 'Master Admin' || isMasterAdmin ? 'Master Admin' : userRole === 'Admin' || isUserAdmin ? 'Admin' : 'User'}</p>
              </div>
              <div className={`w-8 h-8 rounded-full ${isDay ? 'bg-gray-200 border-gray-300' : 'bg-[#2A2A2A] border-[#3A3A3A]'} border flex items-center justify-center text-xs ${isDay ? 'text-black' : 'text-white'} uppercase`}>
                {(user?.displayName || user?.email || 'U').substring(0, 2)}
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-6">
          <div className="max-w-[1600px] w-full mx-auto">
            {ActiveComponent && (
              <ActiveComponent 
                selectedFolderId={selectedSafetyFolderId}
                setSelectedFolderId={setSelectedSafetyFolderId}
                globalSearchQuery={globalSearchQuery}
                setGlobalSearchQuery={setGlobalSearchQuery}
                setActiveTab={handleTabChange}
              />
            )}
          </div>
        </div>
      </main>
      
      {showRequestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80">
          <div className="bg-[#111111] border border-[#333] p-6 rounded-xl shadow-2xl w-full max-w-sm">
            <h3 className="text-white font-bold mb-4">Request Edit Access</h3>
            <p className="text-xs text-[#999] mb-4">Confirm your Email ID so the admin knows who is requesting access.</p>
            <input 
              type="email" 
              value={requestName}
              onChange={e => setRequestName(e.target.value)}
              placeholder="Your Email ID"
              className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 mb-4 text-sm focus:outline-none focus:border-blue-500"
            />
            <div className="flex justify-end gap-3">
              <button onClick={() => setShowRequestModal(false)} className="text-xs text-[#999] hover:text-white uppercase font-bold">Cancel</button>
              <button onClick={handleRequestSubmit} disabled={!requestName.trim()} className="text-xs text-black bg-blue-500 hover:bg-blue-400 disabled:opacity-50 px-4 py-2 rounded uppercase font-bold transition-colors">Request</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
