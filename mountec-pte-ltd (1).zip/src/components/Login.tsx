import React, { useState } from 'react';
import { googleSignIn, db } from '../lib/firebase';
import { Building2, Mail, Lock, ArrowRight, ShieldCheck, UserPlus, LogIn, Eye, EyeOff } from 'lucide-react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import MountecLogo from './MountecLogo';
import { auth } from '../lib/firebase';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const result = await googleSignIn();
      if (result?.user?.email) {
        // Check if user exists in userCredentials
        const q = query(collection(db, 'userCredentials'), where('email', '==', result.user.email.toLowerCase()));
        const querySnapshot = await getDocs(q);
        if (querySnapshot.empty) {
          // Add them
          await addDoc(collection(db, 'userCredentials'), {
            email: result.user.email.toLowerCase(),
            password: '', // Google users don't have a password here
            name: result.user.displayName || result.user.email.split('@')[0],
            role: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(result.user.email.toLowerCase()) ? 'Master Admin' : 'User',
            accessiblePanels: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(result.user.email.toLowerCase())
              ? ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials']
              : ['executive', 'hr', 'ops', 'accounts', 'safety', 'general'],
            createdAt: Date.now()
          });
        }
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user' || err.code === 'auth/cancelled-popup-request') {
        setError('Sign-in window closed. Please sign in with kartikvicky9@gmail.com to bypass the current temporary Google blocks/verification screens.');
      } else {
        setError(err.message || 'Failed to sign in with Google');
      }
      setLoading(false);
    }
  };
  
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (isSignUp) {
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        setLoading(false);
        return;
      }

      try {
        // Try standard auth first
        await createUserWithEmailAndPassword(auth, email, password);
        
        // Also save a record in the userCredentials collection
        try {
          await addDoc(collection(db, 'userCredentials'), {
            email: email.trim().toLowerCase(),
            password: password,
            name: email.split('@')[0],
            role: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(email.toLowerCase()) ? 'Master Admin' : 'User',
            accessiblePanels: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(email.toLowerCase())
              ? ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials']
              : ['executive', 'hr', 'ops', 'accounts', 'safety', 'general'],
            createdAt: Date.now()
          });
        } catch (dbErr) {
          console.warn("Failed to save credentials in Firestore collection:", dbErr);
        }
        
        setSuccess('Account created successfully! Logging you in...');
      } catch (err: any) {
        // If standard Email/Password provider is disabled in Firebase (operation-not-allowed)
        if (err.code === 'auth/operation-not-allowed' || err.message?.includes('operation-not-allowed')) {
          try {
            // Check if the user already exists in userCredentials collection
            const q = query(collection(db, 'userCredentials'), where('email', '==', email.trim().toLowerCase()));
            const querySnapshot = await getDocs(q);
            if (!querySnapshot.empty) {
              throw new Error('An account with this email already exists.');
            }

            // Save to Firestore credentials registry
            await addDoc(collection(db, 'userCredentials'), {
              email: email.trim().toLowerCase(),
              password: password,
              name: email.split('@')[0],
              role: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(email.toLowerCase()) ? 'Master Admin' : 'User',
              accessiblePanels: ['kartikvicky9@gmail.com', 'mountecstorage@gmail.com', 'mountec21@gmail.com'].includes(email.toLowerCase())
                ? ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials']
                : ['executive', 'hr', 'ops', 'accounts', 'safety', 'general'],
              createdAt: Date.now()
            });

            // Set custom local session
            const customUser = {
              email: email.trim().toLowerCase(),
              displayName: email.split('@')[0],
              uid: 'custom-' + email.trim().toLowerCase(),
              isCustom: true
            };
            localStorage.setItem('mountec_custom_user', JSON.stringify(customUser));
            setSuccess('Account created successfully in directory! Logging you in...');
            
            setTimeout(() => {
              window.location.reload();
            }, 1000);
          } catch (dbErr: any) {
            setError(dbErr.message || 'Database error occurred. Please contact the administrator.');
            setLoading(false);
          }
        } else {
          setError(err.message || 'Failed to create account. Please try again.');
          setLoading(false);
        }
      }
    } else {
      try {
        // Try standard sign-in
        await signInWithEmailAndPassword(auth, email, password);
      } catch (err: any) {
        // Check if there is a matching user in our custom credentials database
        try {
          const q = query(collection(db, 'userCredentials'), where('email', '==', email.trim().toLowerCase()));
          const querySnapshot = await getDocs(q);
          
          if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            const userData = userDoc.data();
            
            if (userData.password === password) {
              const customUser = {
                email: userData.email,
                displayName: userData.name || userData.email.split('@')[0],
                uid: 'custom-' + userData.email,
                isCustom: true
              };
              localStorage.setItem('mountec_custom_user', JSON.stringify(customUser));
              setSuccess('Login successful! Welcome back...');
              
              setTimeout(() => {
                window.location.reload();
              }, 1000);
              return;
            } else {
              setError('Incorrect password. Please try again.');
              setLoading(false);
              return;
            }
          }
        } catch (dbErr: any) {
          console.error("Firestore credential check failed:", dbErr);
          setError(`Database directory check failed: ${dbErr.message || dbErr}`);
          setLoading(false);
          return;
        }

        setError(err.message || 'Failed to sign in. Please check your credentials.');
        setLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <MountecLogo className="w-16 h-16 rounded-xl bg-white p-1.5 shadow-lg shrink-0" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-white tracking-tight">
          MOUNTEC <span className="text-blue-500">PTE LTD</span>
        </h2>
        <p className="mt-2 text-center text-sm text-[#777]">
          Construction Management Portal
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-[#141414] py-8 px-4 shadow-2xl shadow-black/50 sm:rounded-2xl sm:px-10 border border-[#222]">
          
          <div className="flex border-b border-[#222] mb-6">
            <button
              onClick={() => {
                setIsSignUp(false);
                setError('');
                setSuccess('');
              }}
              className={`flex-1 pb-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors ${
                !isSignUp ? 'border-blue-500 text-white' : 'border-transparent text-[#555] hover:text-[#999]'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setIsSignUp(true);
                setError('');
                setSuccess('');
              }}
              className={`flex-1 pb-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors ${
                isSignUp ? 'border-blue-500 text-white' : 'border-transparent text-[#555] hover:text-[#999]'
              }`}
            >
              Create Account
            </button>
          </div>

          <form className="space-y-6" onSubmit={handleAuthSubmit}>
            <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider">Email address</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-[#555]" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 text-xs bg-[#0A0A0A] border-[#333] text-white rounded-lg py-2.5 border"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider">Password</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-[#555]" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-10 text-xs bg-[#0A0A0A] border-[#333] text-white rounded-lg py-2.5 border"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#555] hover:text-[#999] transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {isSignUp && (
              <div>
                <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider">Confirm Password</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-[#555]" />
                  </div>
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-10 text-xs bg-[#0A0A0A] border-[#333] text-white rounded-lg py-2.5 border"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#555] hover:text-[#999] transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-xs font-bold uppercase tracking-wider text-black bg-blue-600 hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#141414] focus:ring-blue-500 disabled:opacity-50 transition-colors"
              >
                {isSignUp ? (
                  <>
                    Sign Up
                    <UserPlus className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    Sign In with Password
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#333]" />
              </div>
              <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-wider">
                <span className="px-2 bg-[#141414] text-[#555]">Or continue with</span>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full flex justify-center items-center py-2.5 px-4 border border-[#333] rounded-lg shadow-sm bg-[#1A1A1A] text-xs font-bold uppercase tracking-wider text-[#E0E0E0] hover:bg-[#222] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#141414] focus:ring-blue-500 disabled:opacity-50 transition-colors"
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  <path fill="none" d="M0 0h48v48H0z" />
                </svg>
                Sign in with Google
              </button>
            </div>

          </div>
          
          {error && (
            <div className="mt-4 p-3 rounded-lg bg-red-950/30 border border-red-500/20 text-red-400 text-xs flex items-start">
              <ShieldCheck className="w-4 h-4 mr-2 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mt-4 p-3 rounded-lg bg-green-950/30 border border-green-500/20 text-green-400 text-xs flex items-start">
              <ShieldCheck className="w-4 h-4 mr-2 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
