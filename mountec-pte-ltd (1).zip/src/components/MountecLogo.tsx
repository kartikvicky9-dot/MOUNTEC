import React from 'react';

interface MountecLogoProps {
  className?: string;
  showText?: boolean;
  lightText?: boolean;
}

export default function MountecLogo({ className = 'w-16 h-16', showText = true, lightText = false }: MountecLogoProps) {
  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      <svg 
        viewBox="15 12 125 152" 
        className="w-full h-full"
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Definitions for Gradients and Shadows */}
        <defs>
          {/* Left/Right Bar Front Gradient (Orange/Peach) */}
          <linearGradient id="orangeFront" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#EF682A" />
            <stop offset="100%" stopColor="#D94E14" />
          </linearGradient>
          
          {/* Left/Right Bar Top Gradient */}
          <linearGradient id="orangeTop" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#FF9E6F" />
            <stop offset="100%" stopColor="#F7A37B" />
          </linearGradient>

          {/* Left/Right Bar Side Gradient */}
          <linearGradient id="orangeSide" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#C74B16" />
            <stop offset="100%" stopColor="#A03306" />
          </linearGradient>

          {/* Middle Bar Front Gradient (Blue) */}
          <linearGradient id="blueFront" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1E60C2" />
            <stop offset="100%" stopColor="#11459E" />
          </linearGradient>

          {/* Middle Bar Top Gradient */}
          <linearGradient id="blueTop" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#73A9F4" />
            <stop offset="100%" stopColor="#97C2FC" />
          </linearGradient>

          {/* Middle Bar Side Gradient */}
          <linearGradient id="blueSide" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0B2B66" />
            <stop offset="100%" stopColor="#061B42" />
          </linearGradient>

          {/* Drop shadow for the bars to give 3D depth */}
          <filter id="shadow" x="-10%" y="-10%" width="130%" height="130%">
            <feDropShadow dx="2" dy="4" stdDeviation="3" floodColor="#000" floodOpacity="0.25" />
          </filter>
        </defs>

        <g filter="url(#shadow)">
          {/* ================= BAR 1: LEFT ORANGE BAR ================= */}
          {/* Front Face */}
          <rect x="20" y="45" width="26" height="85" fill="url(#orangeFront)" stroke="#000000" strokeWidth="1.2" />
          {/* Top Face */}
          <path d="M 20 45 L 46 45 L 56 39 L 30 39 Z" fill="url(#orangeTop)" stroke="#000000" strokeWidth="1.2" />
          {/* Side Face */}
          <path d="M 46 45 L 56 39 L 56 124 L 46 130 Z" fill="url(#orangeSide)" stroke="#000000" strokeWidth="1.2" />

          {/* ================= BAR 2: MIDDLE BLUE BAR ================= */}
          {/* Front Face */}
          <rect x="55" y="65" width="20" height="65" fill="url(#blueFront)" stroke="#000000" strokeWidth="1.2" />
          {/* Top Face */}
          <path d="M 55 65 L 75 65 L 83 60 L 63 60 Z" fill="url(#blueTop)" stroke="#000000" strokeWidth="1.2" />
          {/* Side Face */}
          <path d="M 75 65 L 83 60 L 83 125 L 75 130 Z" fill="url(#blueSide)" stroke="#000000" strokeWidth="1.2" />

          {/* ================= BAR 3: RIGHT ORANGE BAR ================= */}
          {/* Front Face */}
          <rect x="83" y="22" width="32" height="108" fill="url(#orangeFront)" stroke="#000000" strokeWidth="1.2" />
          {/* Top Face */}
          <path d="M 83 22 L 115 22 L 127 15 L 95 15 Z" fill="url(#orangeTop)" stroke="#000000" strokeWidth="1.2" />
          {/* Side Face */}
          <path d="M 115 22 L 127 15 L 127 123 L 115 130 Z" fill="url(#orangeSide)" stroke="#000000" strokeWidth="1.2" />
        </g>

        {/* ================= TREND LINE (WHITE WITH Crisp Black Outline) ================= */}
        {/* Solid Black Outline/Border under the trend line to ensure high contrast */}
        <path 
          d="M 18 126 C 40 86, 55 74, 72 74 C 85 74, 90 84, 98 89 L 105 79 L 138 33" 
          stroke="#000000" 
          strokeWidth="7.5" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          fill="none" 
        />
        {/* Main white core line */}
        <path 
          d="M 18 126 C 40 86, 55 74, 72 74 C 85 74, 90 84, 98 89 L 105 79 L 138 33" 
          stroke="#FFFFFF" 
          strokeWidth="3.5" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          fill="none" 
        />

        {/* ================= MOUNTEC TEXT (INTEGRATED AND STRETCHED) ================= */}
        {showText && (
          <text 
            x="20" 
            y="156" 
            fill={lightText ? "#FFFFFF" : "#0F3577"} 
            fontFamily="'Arial Black', Impact, sans-serif" 
            fontWeight="900" 
            fontSize="26" 
            textLength="107" 
            lengthAdjust="spacingAndGlyphs"
          >MOUNTEC</text>
        )}
      </svg>
    </div>
  );
}
