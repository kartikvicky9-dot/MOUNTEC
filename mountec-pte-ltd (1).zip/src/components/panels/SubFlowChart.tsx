import React from 'react';

interface Step {
  id: string;
  title: string;
}

interface SubFlowChartProps {
  title: string;
  steps: Step[];
  onStepClick?: (step: Step) => void;
}

export default function SubFlowChart({ title, steps, onStepClick }: SubFlowChartProps) {
  return (
    <div className="p-6 text-white">
      <h3 className="text-2xl font-bold mb-6">{title}</h3>
      <div className="bg-gray-800 p-8 rounded-xl min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          {steps.map((step, index) => (
            <React.Fragment key={step.id}>
              <button
                onClick={() => onStepClick?.(step)}
                className="bg-gray-700 hover:bg-gray-600 transition-colors px-6 py-4 rounded-lg w-full max-w-md text-center font-semibold shadow-md"
              >
                {step.title}
              </button>
              {index < steps.length - 1 && (
                <div className="h-8 w-0.5 bg-gray-500"></div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
