import React, { useState } from 'react';
import { Wallet, Briefcase, FileText } from 'lucide-react';

export default function FinancePanel() {
  const [activeTab, setActiveTab] = useState('payable');

  const tabs = [
    { id: 'payable', label: 'Accounts Payable', icon: Wallet },
    { id: 'receivable', label: 'Accounts Receivable', icon: Briefcase },
    { id: 'payroll', label: 'Payroll', icon: FileText },
  ];

  const ActiveComponent = () => {
    switch(activeTab) {
      case 'payable': return <div className="p-4 text-white">Accounts Payable Content</div>;
      case 'receivable': return <div className="p-4 text-white">Accounts Receivable Content</div>;
      case 'payroll': return <div className="p-4 text-white">Payroll Content</div>;
      default: return null;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex space-x-2 border-b border-[#222]">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider flex items-center ${
              activeTab === tab.id 
                ? 'text-blue-500 border-b-2 border-blue-500' 
                : 'text-gray-500 hover:text-white'
            }`}
          >
            <tab.icon className="w-4 h-4 mr-2" />
            {tab.label}
          </button>
        ))}
      </div>
      <div className="bg-[#141414] rounded-lg border border-[#222]">
        <ActiveComponent />
      </div>
    </div>
  );
}
