import React from 'react';
import SubFlowChart from '../SubFlowChart';

export default function FinanceFlowChart() {
  const steps = [
    { id: '4.1', title: '4.1 BILLING (INVOICES, SOA, DEBIT/CREDIT NOTES)' },
    { id: '4.2', title: '4.2 EXPENSES MANAGEMENT (COST CATEGORIES, STAFF EXPENSES, SUB-CONTRACTORS, TRANSPORTATION, PETTY CASH)' },
    { id: '4.3', title: '4.3 GST FILING' },
    { id: '4.4', title: '4.4 ACCOUNTS FORECAST' },
    { id: '4.5', title: '4.5 AGM & FINANCIAL STATEMENT' },
    { id: '4.6', title: '4.6 BANK ACCOUNT INFORMATION' },
    { id: '4.7', title: '4.7 P&L' },
    { id: '4.8', title: '4.8 TAX RELATED' },
  ];
  return <SubFlowChart title="FINANCE & ACCOUNTING FLOW" steps={steps} />;
}
