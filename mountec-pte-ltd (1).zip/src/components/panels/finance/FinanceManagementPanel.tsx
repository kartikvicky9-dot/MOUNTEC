import React, { useState } from 'react';
import PlaceholderPanel from '../support/PlaceholderPanel';
import SalesInvoicePanel from './SalesInvoicePanel';

export default function FinanceManagementPanel() {
  const [activeTab, setActiveTab] = useState('4.1');
  const [activeSubTab, setActiveSubTab] = useState('4.1.1');

  const tabs = [
    { 
      id: '4.1', 
      label: '4.1 Billing', 
      component: () => null // Handled specially below to avoid nested state hook issues
    },
    { 
      id: '4.2', 
      label: '4.2 Expenses Management', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">4.2 Expenses Management</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>4.2.0 Cost categories</li>
            <li>4.2.1 General Expenses</li>
            <li>4.2.2 Staff & Workers Expenses</li>
            <li>4.2.3 Staff & Workers Salary
              <ul className="list-circle pl-5">
                <li>4.2.3.1 Staff & Workers CPF</li>
                <li>4.2.3.2 Staff & Workers Levy</li>
              </ul>
            </li>
            <li>4.2.4 Project Purchasing (MET)</li>
            <li>4.2.5 Sub-Contractors & Vendors</li>
            <li>4.2.6 Transportation Expenses</li>
            <li>4.2.7 Fine & Back Charges</li>
            <li>4.2.8 Petty Cash</li>
            <li>4.2.9 All Related Payout
              <ul className="list-circle pl-5">
                <li>4.2.9.1 Payment Voucher</li>
                <li>4.2.9.2 Payment Register</li>
              </ul>
            </li>
            <li>4.2.10 Deposit Payment</li>
          </ul>
        </div>
      )
    },
    { id: '4.3', label: '4.3 GST Filing', component: () => <PlaceholderPanel title="GST Filing" /> },
    { id: '4.4', label: '4.4 Accounts Forecast', component: () => <PlaceholderPanel title="Accounts Forecast" /> },
    { id: '4.5', label: '4.5 AGM & Financial Statement', component: () => <PlaceholderPanel title="AGM & Financial Statement" /> },
    { 
      id: '4.6', 
      label: '4.6 Bank Account Information', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">4.6 Bank Account Information</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>4.6.1 Forms & Endorsement</li>
            <li>4.6.2 Bank Statement</li>
          </ul>
        </div>
      )
    },
    { id: '4.7', label: '4.7 P&L', component: () => <PlaceholderPanel title="P&L" /> },
    { id: '4.8', label: '4.8 Tax Related', component: () => <PlaceholderPanel title="Tax Related" /> },
  ];

  const ActiveComponent = (tabs.find(t => t.id === activeTab)?.component || PlaceholderPanel) as any;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold p-6 border-b border-gray-800">4. Finance & Accounting</h2>
      <div className="flex flex-1 overflow-hidden">
        <div className="w-80 border-r border-gray-800 p-4 space-y-2 overflow-y-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left p-3 rounded text-sm ${activeTab === tab.id ? 'bg-blue-600' : 'hover:bg-gray-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          {activeTab === '4.1' ? (
            <div className="space-y-6">
              <div className="flex flex-wrap border-b border-gray-800 gap-4 pb-2">
                {[
                  { id: '4.1.1', label: '4.1.1 Sales Invoice' },
                  { id: '4.1.2', label: '4.1.2 Statement of Account (SOA)' },
                  { id: '4.1.3', label: '4.1.3 Debit Note' },
                  { id: '4.1.4', label: '4.1.4 Credit Note' },
                  { id: '4.1.5', label: '4.1.5 Other In-come' },
                ].map(subTab => (
                  <button
                    key={subTab.id}
                    onClick={() => setActiveSubTab(subTab.id)}
                    className={`text-xs font-semibold pb-2 border-b-2 transition-all ${
                      activeSubTab === subTab.id 
                        ? 'border-blue-500 text-blue-400 font-bold' 
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    {subTab.label}
                  </button>
                ))}
              </div>
              <div>
                {activeSubTab === '4.1.1' ? (
                  <SalesInvoicePanel />
                ) : (
                  <PlaceholderPanel title={
                    activeSubTab === '4.1.2' ? '4.1.2 Statement of Account (SOA)' :
                    activeSubTab === '4.1.3' ? '4.1.3 Debit Note' :
                    activeSubTab === '4.1.4' ? '4.1.4 Credit Note' : '4.1.5 Other In-come'
                  } />
                )}
              </div>
            </div>
          ) : (
            <ActiveComponent />
          )}
        </div>
      </div>
    </div>
  );
}
