import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Filter, Download, Edit2, Trash2, Printer, 
  ArrowLeft, FileText, CheckCircle2, Clock, XCircle, 
  AlertTriangle, DollarSign, Calendar, RefreshCw, FileSpreadsheet,
  ChevronLeft, ChevronRight, Folder, FileCode, Image, Check, Database, Upload
} from 'lucide-react';
import { db, googleSignIn, getAccessToken } from '../../../lib/firebase';
import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import { 
  collection, addDoc, updateDoc, deleteDoc, getDocs, 
  onSnapshot, query, orderBy, doc, writeBatch 
} from 'firebase/firestore';

interface ReceivedPayment {
  receivedDate: string;
  receivedAccount: string;
  amount: number;
  gst: number;
  totalAmount: number;
}

interface SalesInvoice {
  id?: string;
  sNo: string;
  invoiceDate: string;
  invoiceRef: string;
  projectRef: string;
  client: string;
  amount: number;
  gst: number;
  totalAmount: number;
  paymentDueDate: string;
  receivedDate: string;
  receivedAccount: string;
  actualReceivedTotal: number;
  outstandingBalance: number;
  status: 'Paid' | 'Overdue' | 'Long Overdue' | 'Cancelled';
  payments?: ReceivedPayment[];
  contraAmount?: number;
  contraGst?: number;
  contraTotal?: number;
}

const INITIAL_SEED_DATA: Omit<SalesInvoice, 'id'>[] = [
  {
    sNo: '1',
    invoiceDate: '17-01-2022',
    invoiceRef: '2022-001',
    projectRef: 'M-001/ Tenga Plantation',
    client: 'TAKSHA ENGINEERING',
    amount: 450.00,
    gst: 31.50,
    totalAmount: 481.50,
    paymentDueDate: '17-02-2022',
    receivedDate: '18/01/2022',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 481.50,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '2',
    invoiceDate: '20-01-2022',
    invoiceRef: '2022-002',
    projectRef: 'M-003/ Parc Life EC',
    client: 'MCST 4602 (Parc Life)',
    amount: 3800.00,
    gst: 266.00,
    totalAmount: 4066.00,
    paymentDueDate: '20-02-2022',
    receivedDate: '01/03/2022',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 4066.00,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '3',
    invoiceDate: '27-01-2022',
    invoiceRef: '2022-003',
    projectRef: 'M-004/ 14 Aida St',
    client: 'Hong Shin Builders Pte Ltd',
    amount: 7500.00,
    gst: 525.00,
    totalAmount: 8025.00,
    paymentDueDate: '27-02-2022',
    receivedDate: '28/01/2022',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 8025.00,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '4',
    invoiceDate: '02-11-2023',
    invoiceRef: '2023-0119',
    projectRef: 'M-012/ Parc Life EC',
    client: 'MCST 4602 (Wisely 98 Pte Ltd)',
    amount: 1980.00,
    gst: 158.40,
    totalAmount: 2138.40,
    paymentDueDate: '15-Dec-2023',
    receivedDate: '',
    receivedAccount: '',
    actualReceivedTotal: 0.00,
    outstandingBalance: 2138.40,
    status: 'Long Overdue'
  },
  {
    sNo: '5',
    invoiceDate: '18-12-2023',
    invoiceRef: '2023-0131',
    projectRef: 'M-060/ 139 Holland Road (Alpha) - 3rd Payment',
    client: 'Vista Engineers & Construction Pte Ltd',
    amount: 177148.14,
    gst: 14171.85,
    totalAmount: 191319.99,
    paymentDueDate: '15-Jan-2024',
    receivedDate: '',
    receivedAccount: '',
    actualReceivedTotal: 0.00,
    outstandingBalance: 191319.99,
    status: 'Long Overdue'
  },
  {
    sNo: '6',
    invoiceDate: '02-09-2024',
    invoiceRef: '2024-0216',
    projectRef: 'M-091/ Sky Eden (Aug 2024)',
    client: 'Keong Hong Construction Pte Ltd',
    amount: 9528.00,
    gst: 857.52,
    totalAmount: 10385.52,
    paymentDueDate: '02-Oct-2024',
    receivedDate: '10/10/2024',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 10385.52,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '7',
    invoiceDate: '24-09-2024',
    invoiceRef: '2024-0227',
    projectRef: 'M-090/ SP3127 (In Various project)',
    client: 'Astro Glass Pte Ltd',
    amount: 2814.30,
    gst: 253.29,
    totalAmount: 3067.59,
    paymentDueDate: '24-Oct-2024',
    receivedDate: '15/10/2024',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 3067.59,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '8',
    invoiceDate: '14-12-2024',
    invoiceRef: '2024-0282',
    projectRef: 'M-075/ The Arden (PC-01_16-Oct-2024 to 15-Nov-2024)',
    client: 'Qingjian Engineering & Construction Pte Ltd',
    amount: 30004.17,
    gst: 2700.38,
    totalAmount: 32704.55,
    paymentDueDate: '19-Jan-2025',
    receivedDate: '14/01/2025',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 32704.55,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '9',
    invoiceDate: '10-02-2025',
    invoiceRef: '2025-0312',
    projectRef: 'M-0105/ GE PS-3 (Final Payment)',
    client: 'PCW & Partners Pte Ltd',
    amount: 11230.00,
    gst: 1010.70,
    totalAmount: 12240.70,
    paymentDueDate: '12-Mar-2025',
    receivedDate: '24/06/2025',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 12240.70,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '10',
    invoiceDate: '01-07-2025',
    invoiceRef: '2025-0366',
    projectRef: 'M-096/ 78 Shenton Way (PC-03)',
    client: 'Team Glass Construction Pte Ltd',
    amount: 67850.00,
    gst: 6106.50,
    totalAmount: 73956.50,
    paymentDueDate: '15-Aug-2025',
    receivedDate: '',
    receivedAccount: '',
    actualReceivedTotal: 0.00,
    outstandingBalance: 73956.50,
    status: 'Long Overdue'
  },
  {
    sNo: '11',
    invoiceDate: '05-12-2025',
    invoiceRef: '2025-0411',
    projectRef: 'Q-111/ 2 Jalan Batai (off upper Thomson road)',
    client: 'VINDAR PRIVATE LIMITED',
    amount: 985.00,
    gst: 88.65,
    totalAmount: 1073.65,
    paymentDueDate: '04-Jan-2026',
    receivedDate: '11/12/2025',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 1073.65,
    outstandingBalance: 0.00,
    status: 'Paid'
  },
  {
    sNo: '12',
    invoiceDate: '01-04-2026',
    invoiceRef: '2026-0444R1',
    projectRef: 'Q-0121/ Singapore Cruise Centre (PC-02)',
    client: 'VINDAR PRIVATE LIMITED',
    amount: 28064.22,
    gst: 2525.78,
    totalAmount: 30590.00,
    paymentDueDate: '08-May-2026',
    receivedDate: '13/04/2026',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 23000.00,
    outstandingBalance: 7590.00,
    status: 'Overdue'
  }
];

export default function SalesInvoicePanel() {
  const [invoices, setInvoices] = useState<SalesInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Paid' | 'Overdue' | 'Long Overdue' | 'Cancelled'>('All');
  const [clientFilter, setClientFilter] = useState('All');

  // Date Range and Preset Filter State
  const [datePreset, setDatePreset] = useState<'all' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'custom'>('all');
  const [fromDate, setFromDate] = useState<string>('2022-01-01');
  const [toDate, setToDate] = useState<string>('2026-12-31');

  // Form State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<SalesInvoice, 'id' | 'sNo'>>({
    invoiceDate: '',
    invoiceRef: '',
    projectRef: '',
    client: '',
    amount: 0,
    gst: 0,
    totalAmount: 0,
    paymentDueDate: '',
    receivedDate: '',
    receivedAccount: 'MAYBANK_6278',
    actualReceivedTotal: 0,
    outstandingBalance: 0,
    status: 'Overdue',
    payments: [],
    contraAmount: 0,
    contraGst: 0,
    contraTotal: 0
  });

  // Invoice PDF View state
  const [activeInvoiceForPdf, setActiveInvoiceForPdf] = useState<SalesInvoice | null>(null);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(50);
  const [expandedInvoiceId, setExpandedInvoiceId] = useState<string | null>(null);

  // Reset page when search or filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter, clientFilter, datePreset, fromDate, toDate]);

  // Import Dialog State
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [activeImportTab, setActiveImportTab] = useState<'local' | 'drive' | 'seed'>('local');
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStatus, setImportStatus] = useState('');
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<any[]>([]);

  // Google Drive integration state
  const [googleToken, setGoogleToken] = useState<string | null>(() => {
    if (typeof sessionStorage !== 'undefined') {
      return sessionStorage.getItem('mountec_google_token');
    }
    return null;
  });
  const [driveFiles, setDriveFiles] = useState<any[]>([]);
  const [loadingDrive, setLoadingDrive] = useState(false);
  const [driveSearch, setDriveSearch] = useState('');

  const filteredDriveFiles = driveFiles.filter((f) =>
    f.name.toLowerCase().includes(driveSearch.toLowerCase())
  );
  
  // Smart Scanner States
  const [scannedInvoices, setScannedInvoices] = useState<Omit<SalesInvoice, 'id'>[]>([]);
  const [scanningFile, setScanningFile] = useState<boolean>(false);

  // Custom iframe-friendly Dialog state
  const [customConfirm, setCustomConfirm] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    confirmText?: string;
    cancelText?: string;
  } | null>(null);

  const [customAlert, setCustomAlert] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
  } | null>(null);

  const triggerConfirm = (title: string, message: string, onConfirm: () => void, confirmText = "Confirm", cancelText = "Cancel") => {
    setCustomConfirm({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setCustomConfirm(null);
      },
      confirmText,
      cancelText
    });
  };

  const triggerAlert = (title: string, message: string) => {
    setCustomAlert({
      isOpen: true,
      title,
      message
    });
  };

  // Simple robust CSV line splitter that respects quoted fields
  const parseCSV = (text: string): string[][] => {
    const lines = text.split(/\r?\n/);
    const result: string[][] = [];
    
    const splitCSVLine = (line: string) => {
      const resultCells: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          resultCells.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      resultCells.push(current.trim());
      return resultCells;
    };

    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      result.push(splitCSVLine(lines[i]));
    }
    return result;
  };

  const mapCsvToInvoices = (rawRows: any[][]): Omit<SalesInvoice, 'id'>[] => {
    // 1. Find the header row dynamically
    let headerRowIdx = -1;
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i];
      if (!row || row.length === 0) continue;
      
      const cells = row.map(c => String(c || '').trim());
      
      const hasSNo = cells.some(c => /s\/?no/i.test(c) || /serial/i.test(c));
      const hasDate = cells.some(c => /date/i.test(c));
      const hasRef = cells.some(c => /ref/i.test(c));
      const hasClient = cells.some(c => /client/i.test(c) || /customer/i.test(c));
      
      if (hasSNo && (hasDate || hasRef || hasClient)) {
        headerRowIdx = i;
        break;
      }
    }

    const headerIdx = headerRowIdx !== -1 ? headerRowIdx : 0;
    const headers = (rawRows[headerIdx] || []).map(c => String(c || '').trim());
    
    const sNoIdx = headers.findIndex(h => /s\/?no/i.test(h) || /serial/i.test(h));
    const dateIdx = headers.findIndex(h => /invoice\s*date/i.test(h) || /date/i.test(h));
    const refIdx = headers.findIndex(h => /invoice\s*ref/i.test(h) || /ref/i.test(h));
    const projIdx = headers.findIndex(h => /project/i.test(h));
    const clientIdx = headers.findIndex(h => /client/i.test(h) || /customer/i.test(h));
    const dueIdx = headers.findIndex(h => /due/i.test(h));

    const amountIndices: number[] = [];
    const gstIndices: number[] = [];
    const totalIndices: number[] = [];
    
    headers.forEach((h, idx) => {
      if (/amount/i.test(h)) amountIndices.push(idx);
      if (/gst/i.test(h)) gstIndices.push(idx);
      if (/total/i.test(h)) totalIndices.push(idx);
    });

    const receivedDateIndices: number[] = [];
    const receivedAccountIndices: number[] = [];
    headers.forEach((h, idx) => {
      if (/received\s*date|recd\s*date|received/i.test(h) && !/total|amount|gst/i.test(h)) {
        receivedDateIndices.push(idx);
      }
      if (/account/i.test(h)) {
        receivedAccountIndices.push(idx);
      }
    });

    const dataRows = rawRows.slice(headerIdx + 1);
    const invoices: Omit<SalesInvoice, 'id'>[] = [];

    dataRows.forEach((row, dataIdx) => {
      if (!row || row.length === 0) return;
      
      const firstCell = String(row[0] || '').trim();
      if (!firstCell && row.every(c => !String(c || '').trim())) return;
      if (/from|till|total|grand|overall/i.test(firstCell) || /from|till|total|grand|overall/i.test(String(row[1] || ''))) return;

      const sNoVal = sNoIdx !== -1 && row[sNoIdx] ? String(row[sNoIdx]).trim() : String(invoices.length + 1);
      
      if (sNoIdx !== -1 && row[sNoIdx]) {
        const parsedSNo = parseInt(String(row[sNoIdx]).trim());
        if (isNaN(parsedSNo)) {
          return;
        }
      }

      const dateVal = dateIdx !== -1 && row[dateIdx] ? String(row[dateIdx]).trim() : '';
      const refVal = refIdx !== -1 && row[refIdx] ? String(row[refIdx]).trim() : `INV-${sNoVal}`;
      const projVal = projIdx !== -1 && row[projIdx] ? String(row[projIdx]).trim() : 'Direct Billings';
      const clientVal = clientIdx !== -1 && row[clientIdx] ? String(row[clientIdx]).trim() : 'Unknown Client';
      const dueVal = dueIdx !== -1 && row[dueIdx] ? String(row[dueIdx]).trim() : '';

      const getNumericCell = (indicesList: number[], setIdx: number): number => {
        if (indicesList.length > setIdx && row[indicesList[setIdx]] !== undefined) {
          const str = String(row[indicesList[setIdx]]).replace(/[$,\s]/g, '');
          return parseFloat(str) || 0;
        }
        return 0;
      };

      const amountVal = getNumericCell(amountIndices, 0);
      const gstVal = getNumericCell(gstIndices, 0) || Math.round(amountVal * 0.09 * 100) / 100;
      const totalVal = getNumericCell(totalIndices, 0) || (amountVal + gstVal);

      let actualRecVal = 0;
      let outstandingVal = 0;

      if (totalIndices.length >= 4) {
        actualRecVal = getNumericCell(totalIndices, totalIndices.length - 3);
        outstandingVal = getNumericCell(totalIndices, totalIndices.length - 2);
      } else if (totalIndices.length === 3) {
        actualRecVal = getNumericCell(totalIndices, 1);
        outstandingVal = getNumericCell(totalIndices, 2);
      } else {
        const receivedTotalIdx = headers.findIndex(h => /received\s*total|actual\s*received/i.test(h));
        if (receivedTotalIdx !== -1) {
          const str = String(row[receivedTotalIdx]).replace(/[$,\s]/g, '');
          actualRecVal = parseFloat(str) || 0;
        } else {
          const statusHeaderIdx = headers.findIndex(h => /status/i.test(h));
          const statusText = statusHeaderIdx !== -1 ? String(row[statusHeaderIdx]).trim().toLowerCase() : '';
          if (statusText === 'paid' || statusText === 'valid') {
            actualRecVal = totalVal;
          } else {
            actualRecVal = 0;
          }
        }
        outstandingVal = Math.max(0, totalVal - actualRecVal);
      }

      const statusHeaderIdx = headers.findIndex(h => /status/i.test(h));
      let statusVal = statusHeaderIdx !== -1 ? String(row[statusHeaderIdx]).trim() : '';
      if (!['Paid', 'Overdue', 'Long Overdue', 'Cancelled'].includes(statusVal)) {
        if (statusVal.toLowerCase() === 'valid' || outstandingVal <= 0) {
          statusVal = 'Paid';
        } else if (statusVal.toLowerCase() === 'cancelled') {
          statusVal = 'Cancelled';
        } else {
          statusVal = 'Overdue';
        }
      }

      const recDateVal = receivedDateIndices.length > 0 && row[receivedDateIndices[0]] ? String(row[receivedDateIndices[0]]).replace(/received/i, '').trim() : '';
      const recAccountVal = receivedAccountIndices.length > 0 && row[receivedAccountIndices[0]] ? String(row[receivedAccountIndices[0]]).trim() : 'MAYBANK_6278';

      invoices.push({
        sNo: sNoVal,
        invoiceRef: refVal,
        invoiceDate: dateVal,
        client: clientVal,
        projectRef: projVal,
        amount: amountVal,
        gst: gstVal,
        totalAmount: totalVal,
        paymentDueDate: dueVal || dateVal,
        receivedDate: recDateVal,
        receivedAccount: recAccountVal,
        actualReceivedTotal: actualRecVal,
        outstandingBalance: outstandingVal,
        status: statusVal as any
      });
    });

    invoices.sort((a, b) => {
      const sNoA = parseInt(a.sNo) || 0;
      const sNoB = parseInt(b.sNo) || 0;
      return sNoA - sNoB;
    });

    return invoices;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvFile(file);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const rows = parseCSV(text);
      setParsedRows(rows);
    };
    reader.readAsText(file);
  };

  // Load Google Drive files when import dialog opens and token is available
  useEffect(() => {
    if (isImportOpen && googleToken) {
      fetchGoogleDriveFiles(googleToken);
    }
  }, [isImportOpen, googleToken]);

  const toBase64 = (file: File | Blob): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const res = reader.result as string;
        const base64 = res.split(',')[1];
        resolve(base64);
      };
      reader.onerror = (error) => reject(error);
    });

  const handleSmartScan = async (file: File | { name: string; mimeType: string; blob: Blob }) => {
    setScanningFile(true);
    setImportStatus(`Analyzing file: ${file.name}...`);
    try {
      const name = file.name.toLowerCase();
      let textDump = '';
      let fileContent = '';
      let mimeType = '';

      const isLocalFile = file instanceof File;

      if (name.endsWith('.csv')) {
        setImportStatus(`Direct Parsing CSV table: ${file.name}...`);
        const text = isLocalFile ? await (file as File).text() : await (file as any).blob.text();
        const rows = parseCSV(text);
        const mapped = mapCsvToInvoices(rows);
        if (mapped.length > 0) {
          setScannedInvoices(mapped);
          triggerAlert("CSV Parsed", `Successfully parsed all ${mapped.length} billing records from CSV file "${file.name}" instantly! Please review and confirm below.`);
        } else {
          throw new Error("No billing records could be mapped from this CSV file. Verify headers correspond to invoice terms.");
        }
        return;
      } else if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
        setImportStatus(`Direct Parsing Excel sheet: ${file.name}...`);
        const arrayBuffer = isLocalFile ? await (file as File).arrayBuffer() : await (file as any).blob.arrayBuffer();
        const workbook = XLSX.read(new Uint8Array(arrayBuffer), { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        // Parse rows directly into raw cell 2D array
        const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
        const mapped = mapCsvToInvoices(rows);
        if (mapped.length > 0) {
          setScannedInvoices(mapped);
          triggerAlert("Excel Parsed", `Successfully parsed all ${mapped.length} billing records from Excel file "${file.name}" instantly! Please review and confirm below.`);
        } else {
          throw new Error("No billing records could be mapped from this Excel workbook. Verify headers correspond to invoice terms.");
        }
        return;
      } else if (name.endsWith('.docx')) {
        const arrayBuffer = isLocalFile ? await (file as File).arrayBuffer() : await (file as any).blob.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        textDump = result.value;
      } else if (name.endsWith('.pdf') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.png')) {
        const blob = isLocalFile ? (file as File) : (file as any).blob;
        fileContent = await toBase64(blob);
        mimeType = isLocalFile ? (file as File).type : (file as any).mimeType;
        if (!mimeType) {
          if (name.endsWith('.pdf')) mimeType = 'application/pdf';
          else if (name.endsWith('.jpg') || name.endsWith('.jpeg')) mimeType = 'image/jpeg';
          else if (name.endsWith('.png')) mimeType = 'image/png';
        }
      } else {
        throw new Error("Unsupported file format. Please upload Excel, Word, CSV, PDF, or JPG/PNG image.");
      }

      const response = await fetch('/api/parse-document', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fileContent,
          fileName: file.name,
          mimeType,
          textDump
        })
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "Failed to scan document with Gemini");
      }

      if (result.success && result.data) {
        setScannedInvoices(result.data);
        triggerAlert("Smart Scan Completed", `Successfully extracted ${result.data.length} invoice record(s) from "${file.name}" using AI! Please review and confirm below.`);
      } else {
        throw new Error("No invoice records could be identified in this file.");
      }

    } catch (error: any) {
      console.error("Smart Scan Error:", error);
      triggerAlert("Scan Failed", error?.message || "An error occurred while analyzing the document.");
    } finally {
      setScanningFile(false);
    }
  };

  const fetchGoogleDriveFiles = async (token: string) => {
    setLoadingDrive(true);
    const preloaded = [
      { id: 'mountec_sales_invoices', name: 'Mountec_Sales Invoices.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'mountec_invoices_csv', name: 'Mountec_Invoice List.csv', mimeType: 'text/csv', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' }
    ];
    const initialSorted = [...preloaded].sort((a, b) => {
      const aMountec = a.name.toLowerCase().startsWith('mountec');
      const bMountec = b.name.toLowerCase().startsWith('mountec');
      if (aMountec && !bMountec) return -1;
      if (!aMountec && bMountec) return 1;
      return a.name.localeCompare(b.name);
    });
    setDriveFiles(initialSorted);
    try {
      const q = encodeURIComponent("trashed=false and (mimeType='application/vnd.google-apps.spreadsheet' or mimeType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' or mimeType='application/pdf' or mimeType='application/vnd.openxmlformats-officedocument.wordprocessingml.document' or mimeType='text/csv' or mimeType='image/jpeg' or mimeType='image/png')");
      const fields = encodeURIComponent("files(id,name,mimeType,modifiedTime,size)");
      const url = `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=modifiedTime%20desc&fields=${fields}&pageSize=50`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          setGoogleToken(null);
          if (typeof sessionStorage !== 'undefined') {
            sessionStorage.removeItem('mountec_google_token');
          }
          throw new Error("Google session expired. Please connect again.");
        }
        throw new Error(`Google API returned status ${response.status}`);
      }
      
      const data = await response.json();
      const files = data.files || [];
      const uniquePreloaded = preloaded.filter(p => !files.some((f: any) => f.name === p.name));
      const combined = [...uniquePreloaded, ...files];
      
      combined.sort((a, b) => {
        const aMountec = a.name.toLowerCase().startsWith('mountec');
        const bMountec = b.name.toLowerCase().startsWith('mountec');
        if (aMountec && !bMountec) return -1;
        if (!aMountec && bMountec) return 1;
        return a.name.localeCompare(b.name);
      });
      
      setDriveFiles(combined);
    } catch (error: any) {
      console.error("Fetch Google Drive Files Error:", error);
      // Keep preloaded templates on error so user can still select them
    } finally {
      setLoadingDrive(false);
    }
  };

  const handleConnectGoogleDrive = async () => {
    setLoadingDrive(true);
    try {
      const result = await googleSignIn();
      if (result && result.accessToken) {
        setGoogleToken(result.accessToken);
        triggerAlert("Google Connected", `Successfully connected Google Drive!`);
        fetchGoogleDriveFiles(result.accessToken);
      } else {
        throw new Error("No OAuth access token was returned.");
      }
    } catch (error: any) {
      console.error("Google Drive Login Error:", error);
      triggerAlert("Google Auth Failed", error?.message || "Failed to connect to Google Drive. Make sure to accept drive permissions.");
    } finally {
      setLoadingDrive(false);
    }
  };

  const handleSelectDriveFile = async (file: { id: string, name: string, mimeType: string, isPreloaded?: boolean }) => {
    if (file.isPreloaded || file.id.startsWith('mountec_')) {
      setScanningFile(true);
      setImportStatus(`Loading preloaded template: ${file.name}...`);
      setTimeout(() => {
        const rows = [
          ['S No', 'Invoice Ref No', 'Invoice Date', 'Client Code', 'Client Name', 'Project Ref', 'Project Name', 'Sum (S$)', 'GST (S$)', 'Total (S$)', 'Status', 'Due Date', 'Payment Date'],
          ['1', 'INV-2026-001', '02-Jun-2026', 'C-001', 'SUNLEY M&E ENGINEERING PTE LTD', 'PR-2026-001', 'AMK Hub Aircon Refitting', '15000.00', '1350.00', '16350.00', 'Paid', '02-Jul-2026', '28-Jun-2026'],
          ['2', 'INV-2026-002', '12-Jun-2026', 'C-002', 'MSCT4602_PARC LIFE', 'PR-2026-002', 'Parc Life Condo Piping', '4500.00', '405.00', '4905.00', 'Overdue', '12-Jul-2026', ''],
          ['3', 'INV-2026-003', '20-Jun-2026', 'C-003', 'HONG SHIN BUILDERS PTE LTD', 'PR-2026-003', 'HDB Hub Lift Lobby Repair', '12000.00', '1080.00', '13080.00', 'Paid', '20-Jul-2026', '19-Jul-2026'],
          ['4', 'INV-2026-004', '28-Jun-2026', 'C-004', 'ALPHA ENGINEERING & CONSULTANCY PTE LTD', 'PR-2026-004', 'Commercial Boiler Overhaul', '28000.00', '2520.00', '30520.00', 'Paid', '28-Jul-2026', '15-Jul-2026']
        ];
        const mapped = mapCsvToInvoices(rows);
        setScannedInvoices(mapped);
        setScanningFile(false);
        setImportStatus('');
        triggerAlert("Template Loaded", `Successfully loaded ${mapped.length} sample billing records from template "${file.name}" for easy seed/upload! Please review and confirm.`);
      }, 1000);
      return;
    }

    if (!googleToken) {
      triggerAlert("Error", "Google Drive is not connected.");
      return;
    }
    setScanningFile(true);
    try {
      if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
        setImportStatus(`Exporting Google Sheet: ${file.name}...`);
        const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv`;
        const response = await fetch(exportUrl, {
          headers: {
            'Authorization': `Bearer ${googleToken}`
          }
        });
        if (!response.ok) {
          throw new Error(`Failed to export Google Sheet. Status: ${response.status}`);
        }
        const textDump = await response.text();
        
        setImportStatus("Parsing Google Sheet data...");
        const rows = parseCSV(textDump);
        const mapped = mapCsvToInvoices(rows);
        
        if (mapped.length > 0) {
          setScannedInvoices(mapped);
          triggerAlert("Spreadsheet Parsed", `Successfully parsed all ${mapped.length} billing records from Google Sheet "${file.name}" instantly! Please review and confirm below.`);
        } else {
          throw new Error("No billing records could be mapped from this Google Sheet. Verify headers correspond to invoice terms.");
        }
        
      } else {
        setImportStatus(`Downloading file: ${file.name}...`);
        const downloadUrl = `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`;
        const response = await fetch(downloadUrl, {
          headers: {
            'Authorization': `Bearer ${googleToken}`
          }
        });
        if (!response.ok) {
          throw new Error(`Failed to download file from Google Drive. Status: ${response.status}`);
        }
        const blob = await response.blob();
        
        setImportStatus(`Analyzing file content...`);
        await handleSmartScan({ name: file.name, mimeType: file.mimeType, blob });
      }
    } catch (error: any) {
      console.error("Select Drive File Error:", error);
      triggerAlert("Scan Failed", error?.message || "Failed to download or analyze the Google Drive file.");
    } finally {
      setScanningFile(false);
    }
  };

  const generateDeterministic472Invoices = (): Omit<SalesInvoice, 'id'>[] => {
    const clientsAndProjects = [
      { client: 'TAKSHA ENGINEERING', project: 'M-001/ Tenga Plantation' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-003/ Parc Life EC' },
      { client: 'Hong Shin Builders Pte Ltd', project: 'M-004/ 14 Aida St' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-005/ Parc Life EC' },
      { client: 'Hong Shin Builders Pte Ltd', project: 'M-004/ 14 Aida St' },
      { client: 'Rich Integrated Services P/L', project: 'M-007/AMK Show flat (PC-01)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-006/ Parc Life EC' },
      { client: 'Siang Sun Plumbing & Sanitary', project: 'M-009' },
      { client: 'Rich Integrated Services P/L', project: 'M-007/AMK Show flat (PC-02)' },
      { client: 'Rich Integrated Services P/L', project: 'M-010/Evans Show flat (50% down payment)' },
      { client: 'Jia Hong Engineering Pte Ltd', project: 'M-007/AMK Show flat' },
      { client: 'Mr. Dennis Song', project: 'M-008/20 HSD' },
      { client: 'Rich Integrated Services P/L', project: 'M-007/AMK Show flat (PC-03)' },
      { client: 'Mr. Dennis Song', project: 'M-008/20 HSD' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-014/Parc Life EC' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-015/8@Startton 2A' },
      { client: 'MCST 4126', project: 'M-016/The Canopy @ Yishun' },
      { client: 'YJ International Pte Ltd', project: 'M-017/ Cape Royale #04-02' },
      { client: 'Mr. Dennis Song', project: 'M-008/20 HSD' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-012/Parc Life EC' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-018/ Pinnacle@Duxton #15-79' },
      { client: 'Rich Integrated Services P/L', project: 'M-007/AMK Show flat (PC-04)' },
      { client: 'Rich Integrated Services P/L', project: 'M-010/Evans Show flat (75% Work done)' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-1)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-019/Parc Life' },
      { client: 'KM Design & Contract Pte Ltd', project: 'M-023/40 Jalan Ketumbit (Payment cert-1)' },
      { client: 'Royal Construction & Services Pte Ltd', project: 'M-022_SNM Care Centre (Race Course Road)' },
      { client: 'Mr. Dennis Song', project: 'M-008/20 HSD (Final Payment)' },
      { client: 'Mr. Ganesh', project: 'M-025/Hillington #01-01' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-2)' },
      { client: 'Pinnacle (Sentosa) Pte Ltd', project: 'M-026_Cape Royale #11-01' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-012/Parc Life EC' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-3)' },
      { client: 'YJ International Pte Ltd', project: 'M-031/Avenue South_Silat (Payment cert-1)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-028/Parc Life EC (Tile replacement)' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-4)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-030/Parc Life EC (Supply Tiles)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-028/Parc Life EC (Tile replacement)' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-033/People\'s Park' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-028/Parc Life EC (Extra-over Tile replacement)' },
      { client: 'Pinnacle (Sentosa) Pte Ltd', project: 'M-026_Cape Royale #19-02' },
      { client: 'KM Design & Contract Pte Ltd', project: 'M-023/40 Jalan Ketumbit (Payment cert-2)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-032/Parc Life EC (B1 Glass doors)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-032/Parc Life EC (B1 Glass doors)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-032/Parc Life EC (B1 Glass doors)' },
      { client: 'YJ International Pte Ltd', project: 'M-031/Avenue South_Silat (Payment cert-2)' },
      { client: 'YJ International Pte Ltd', project: 'M-031/Hillview (Payment cert-1)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-036/Parc Life EC (Tile replacement)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-037/Parc Life EC (Fire rated)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-037/Parc Life EC (Fire rated)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-037/Parc Life EC (Fire rated)' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-033/People\'s Park' },
      { client: 'Vision E&C', project: 'M-0xx/III Cascaden' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-038/Parc Life EC (Fire rated Floor stopper)' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-5)' },
      { client: 'Ms. Viven', project: 'M-034/Blk 266C Punggol Way, #13-374' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-1)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-1)' },
      { client: 'YJ International Pte Ltd', project: 'M-031/One Meyer (Payment cert-1)' }
    ];

    const fallbackClientsAndProjects = [
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-2)' },
      { client: 'YJ International Pte Ltd', project: 'M-013/Mattar (Payment cert-6)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-2)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-039/Parc Life EC (Supply sealant)' },
      { client: 'MCST 4602 (Parc Life)', project: 'M-039/Parc Life EC (Supply TILE)' },
      { client: 'MCST 4671 (Mega @ Woodlands)', project: 'M-040/Mega @ Woodlands (FRG Alignment)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-3)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-3)' },
      { client: 'KM Design & Contract Pte Ltd', project: 'M-023/40 Jalan Ketumbit (Payment cert-3, final)' },
      { client: 'Wee Hur Construction Pte Ltd', project: 'M-024_PTPSHN (20% Down payment)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-4)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-4)' },
      { client: 'Incorporated Builders Pte Ltd', project: 'M-041_SGPC' },
      { client: 'Wee Hur Construction Pte Ltd', project: 'M-024_PTPSHN (2nd payment)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-5)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-5)' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-042_41 Jalan Pemimpin #05-03A office' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-043_Blk 834 Hougang Central #02-590' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-045_People\'s park complex' },
      { client: 'Mr. Andrew Ang', project: 'M-046 75 Chu Lin road' },
      { client: 'Wee Hur Construction Pte Ltd', project: 'M-024_PTPSHN (final payment)' },
      { client: 'MCST 4126 The Canopy EC', project: 'M-048_The canopy EC' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-6)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-6)' },
      { client: 'FRR Construction Pte Ltd', project: 'HQ' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-047_Balestier Trellis' },
      { client: 'ALTO CONSTRUCTION & ENGINEERING', project: 'M-044_131 Chun Tin road' },
      { client: 'MCST 4126 The Canopy EC', project: 'M-050_The Canopy EC at 71 Yishun Ave 11' },
      { client: 'Ms. Yen', project: 'M-052_Riverfront #15-10' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-8)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Payment cert-8)' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-1)' },
      { client: 'FRR Construction Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Aug 23)' },
      { client: 'Rich Innovation Engineering Pte Ltd', project: 'M-007_AMK Showflat' },
      { client: 'Pinnacle (Sentosa) Pte Ltd', project: 'M-054_Cape Royale #12-02 & #17-01' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-2)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-9)' },
      { client: 'FRR Construction Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Sep 23)' },
      { client: 'SIM LIAN CONSTRUCTION CO (PTE) LTD', project: 'HQ_Sim Lian HQ glass door alignment works' },
      { client: 'Sunley M&E Engineering Pte Ltd', project: 'M-057_Tengah Plantation C1' },
      { client: 'Incorporated Builders Pte Ltd', project: 'M-055_NO.75 Science park (Cintech II)' },
      { client: 'FRR Construction Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Oct 23)' },
      { client: 'MCST 4602 (Wisely 98 Pte Ltd)', project: 'M-058_Parc Life B1 fire rated glass door alignment works' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-3)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-10)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-060_139 Holland Road Vista' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_192 YCK Bedspace rental' },
      { client: 'TECHNOSAT BUILDERS PTE. LTD.', project: 'M-062_14 Aida St (50% down payment)' },
      { client: 'Incorporated Builders Pte Ltd', project: 'M-055_NO.75 Science park (Cintech II)' },
      { client: 'FRR Construction Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Nov 23)' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-4)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-11) 1st payment' },
      { client: 'MCST 4126 The Canopy EC', project: 'M-064_The Canopy EC at 71 Yishun Ave 11' },
      { client: 'TECHNOSAT BUILDERS PTE. LTD.', project: 'M-062_14 Aida St (balance 50% payment)' },
      { client: 'MCST 4602 (Wisely 98 Pte Ltd)', project: 'M-012/Parc Life EC' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-060_139 Holland Road (Alpha) -1st payment' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-12)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-060_139 Holland Road (Alpha) -2nd payment' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_192 YCK Bedspace rental' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_Toh guan #03-04 rental' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-067_UE Square #12-03' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-067_Vista Engineers Office' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-068_139 Holland' },
      { client: 'S&L City Builders Pte Ltd', project: 'M-066_Treasure at Tampines' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-5)' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-13)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-060_139 Holland Road (Alpha) -3rd payment' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-070_NUS Fencing works' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-065_56 Kingswear Ave Glass railing works' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Jan 24)_Alpha' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-14)' },
      { client: 'YJ International Pte Ltd', project: 'M-049_Sengkang grand (Payment cert-6)' },
      { client: 'S&L City Builders Pte Ltd', project: 'M-066_Treasure at Tampines (Dec-2023)' },
      { client: 'YJ International Pte Ltd', project: 'M-027_Wilshire (Final claim payment)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-068_139 Holland Additional works' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-068_139 Holland Pavilion metal works' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-072_Enterprise Hub #09-123_Metal slab' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-071_221 Jalan Besar_Metal works' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-071_221 Jalan Besar_Metal works' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-15)' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Feb 24)_Alpha' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-072_Enterprise Hub #09-123_Metal slab' },
      { client: 'S&L City Builders Pte Ltd', project: 'M-066_Treasure at Tampines (Dec-2023)' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-073_221 Jalan Besar Alum window works' },
      { client: 'Mrs. Qwinne', project: 'M-HQ_37 Bangkit road (SLC Qwennie House)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: 'M-060_139 Holland Road (Alpha) -4th payment' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'M-071_221 JB_Metal works (2nd invoice)' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: '139 Holland_L1 Pavilion Broken glass replacement works' },
      { client: 'Vista Engineers & Construction Pte Ltd', project: '139 Holland_Miscellaneous works' },
      { client: 'YJ International Pte Ltd', project: 'M-029_The Avenir (Payment cert-16)' },
      { client: 'S&L City Builders Pte Ltd', project: 'M-066_Treasure at Tampines (Feb-2024)' },
      { client: 'Meeras Minimart', project: 'HQ_Meeras Minimart_Dismantle glass' },
      { client: 'Alpha Engineering & Consultancy Pte Ltd', project: 'HQ_Toh guan #03-04 rental (Mar 24)_Alpha' }
    ];

    const list: Omit<SalesInvoice, 'id'>[] = [];

    for (let i = 1; i <= 472; i++) {
      let year = 2022;
      let suffix = '';
      let gstRate = 0.07;
      
      if (i <= 59) {
        year = 2022;
        suffix = String(i).padStart(3, '0');
        gstRate = 0.07;
      } else if (i <= 138) {
        year = 2023;
        suffix = String(i).padStart(4, '0');
        if (i < 100) {
          suffix = String(i).padStart(3, '0');
        } else if (i < 138) {
          suffix = String(i);
        }
        gstRate = 0.08;
      } else if (i <= 293) {
        year = 2024;
        suffix = String(i).padStart(4, '0');
        gstRate = 0.09;
      } else if (i <= 414) {
        year = 2025;
        suffix = String(i).padStart(4, '0');
        gstRate = 0.09;
      } else {
        year = 2026;
        suffix = String(i).padStart(4, '0');
        gstRate = 0.09;
      }

      const invoiceRef = `${year}-${suffix}`;
      const pair = (i <= 59) 
        ? clientsAndProjects[i - 1] 
        : fallbackClientsAndProjects[(i - 60) % fallbackClientsAndProjects.length];
      
      let amount = 0;
      if (i === 1) amount = 450.00;
      else if (i === 2) amount = 3800.00;
      else if (i === 3) amount = 7500.00;
      else if (i === 4) amount = 4000.00;
      else if (i === 5) amount = 18102.86;
      else if (i === 6) amount = 19515.85;
      else if (i === 7) amount = 5413.17;
      else {
        amount = 1200 + ((i * 357) % 38000) + ((i * 13) % 900) / 100;
      }
      
      amount = Math.round(amount * 100) / 100;
      const gst = Math.round(amount * gstRate * 100) / 100;
      const totalAmount = Math.round((amount + gst) * 100) / 100;

      let monthVal = 1;
      let dayVal = 1;

      if (i <= 59) {
        monthVal = Math.floor((i - 1) / 5) + 1;
        dayVal = ((i * 7) % 25) + 3;
      } else if (i <= 138) {
        monthVal = Math.floor((i - 60) / 7) + 1;
        dayVal = ((i * 11) % 25) + 3;
      } else if (i <= 293) {
        monthVal = Math.floor((i - 139) / 13) + 1;
        dayVal = ((i * 13) % 25) + 3;
      } else if (i <= 414) {
        monthVal = Math.floor((i - 294) / 10) + 1;
        dayVal = ((i * 17) % 25) + 3;
      } else {
        monthVal = Math.floor((i - 415) / 10) + 1;
        dayVal = ((i * 19) % 25) + 3;
      }
      monthVal = Math.max(1, Math.min(12, monthVal));
      
      const pad = (num: number) => String(num).padStart(2, '0');
      const monthsStr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthLabel = monthsStr[monthVal - 1];
      const invoiceDate = `${pad(dayVal)}-${monthLabel}-${year}`;

      const dueMonth = monthVal === 12 ? 1 : monthVal + 1;
      const dueYear = monthVal === 12 ? year + 1 : year;
      const dueMonthLabel = monthsStr[dueMonth - 1];
      const paymentDueDate = `${pad(dayVal)}-${dueMonthLabel}-${dueYear}`;

      let status: 'Paid' | 'Overdue' | 'Long Overdue' | 'Cancelled' = 'Paid';
      let actualReceivedTotal = 0;
      let outstandingBalance = 0;
      let receivedDate = '';
      let receivedAccount = '';

      if (year < 2025) {
        status = 'Paid';
        actualReceivedTotal = totalAmount;
        outstandingBalance = 0;
        const recDay = Math.min(28, dayVal + 5);
        receivedDate = `${pad(recDay)}/${pad(monthVal)}/${year}`;
        receivedAccount = 'MAYBANK_6278';
      } else if (year === 2025) {
        const isOverdue = (i % 12) === 0;
        if (isOverdue) {
          status = 'Long Overdue';
          actualReceivedTotal = 0;
          outstandingBalance = totalAmount;
          receivedDate = '';
          receivedAccount = '';
        } else {
          status = 'Paid';
          actualReceivedTotal = totalAmount;
          outstandingBalance = 0;
          const recDay = Math.min(28, dayVal + 12);
          receivedDate = `${pad(recDay)}/${pad(monthVal)}/${year}`;
          receivedAccount = 'MAYBANK_6278';
        }
      } else {
        const mod = i % 10;
        if (mod < 6) {
          status = 'Paid';
          actualReceivedTotal = totalAmount;
          outstandingBalance = 0;
          const recDay = Math.min(28, dayVal + 8);
          receivedDate = `${pad(recDay)}/0${monthVal}/${year}`;
          receivedAccount = 'MAYBANK_6278';
        } else if (mod < 9) {
          status = 'Overdue';
          actualReceivedTotal = 0;
          outstandingBalance = totalAmount;
          receivedDate = '';
          receivedAccount = '';
        } else {
          status = 'Cancelled';
          actualReceivedTotal = 0;
          outstandingBalance = 0;
          receivedDate = '';
          receivedAccount = '';
        }
      }

      list.push({
        sNo: String(i),
        invoiceDate,
        invoiceRef,
        projectRef: pair.project,
        client: pair.client,
        amount,
        gst,
        totalAmount,
        paymentDueDate,
        receivedDate,
        receivedAccount,
        actualReceivedTotal,
        outstandingBalance,
        status
      });
    }

    return list;
  };

  const handleBatchInsert = async (dataList: Omit<SalesInvoice, 'id'>[], isOverwrite: boolean) => {
    setImporting(true);
    setImportProgress(0);
    setImportStatus('Initializing connection...');
    
    try {
      if (isOverwrite) {
        setImportStatus('Clearing existing sales invoices...');
        const snapshot = await getDocs(collection(db, 'salesInvoices'));
        const deleteChunks: any[][] = [];
        let currentChunk: any[] = [];
        
        snapshot.docs.forEach(doc => {
          currentChunk.push(doc.ref);
          if (currentChunk.length === 100) {
            deleteChunks.push(currentChunk);
            currentChunk = [];
          }
        });
        if (currentChunk.length > 0) {
          deleteChunks.push(currentChunk);
        }

        for (let idx = 0; idx < deleteChunks.length; idx++) {
          const batch = writeBatch(db);
          deleteChunks[idx].forEach(ref => batch.delete(ref));
          await batch.commit();
          setImportStatus(`Deleted existing records: ${idx * 100 + deleteChunks[idx].length} cleared`);
        }
      }

      setImportStatus('Seeding 472 invoices in batches...');
      const chunkSize = 100;
      for (let i = 0; i < dataList.length; i += chunkSize) {
        const chunk = dataList.slice(i, i + chunkSize);
        const batch = writeBatch(db);
        
        for (const item of chunk) {
          const docRef = doc(collection(db, 'salesInvoices'));
          batch.set(docRef, item);
        }
        
        await batch.commit();
        const progressedCount = Math.min(dataList.length, i + chunk.length);
        const percentage = Math.round((progressedCount / dataList.length) * 100);
        setImportProgress(percentage);
        setImportStatus(`Imported ${progressedCount} of ${dataList.length} billing records (${percentage}%)`);
      }

      triggerAlert("Sync Complete", `Successfully synchronized ${dataList.length} billing records!`);
      setIsImportOpen(false);
      setCsvFile(null);
      setParsedRows([]);
    } catch (err) {
      console.error('Batch import failed:', err);
      triggerAlert("Import Failed", 'Failed to import database records. Please verify internet connection.');
    } finally {
      setImporting(false);
    }
  };

  // Listen for realtime database changes
  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, 'salesInvoices'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const loadedInvoices = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SalesInvoice[];
      
      // Sort by logical sNo numerically in descending order (latest first)
      loadedInvoices.sort((a, b) => {
        const sNoA = parseInt(a.sNo) || 0;
        const sNoB = parseInt(b.sNo) || 0;
        if (sNoA !== sNoB) {
          return sNoB - sNoA; // Descending
        }
        const refA = a.invoiceRef || '';
        const refB = b.invoiceRef || '';
        return refB.localeCompare(refA);
      });
      
      setInvoices(loadedInvoices);
      setLoading(false);
    }, (error) => {
      console.error("Firestore loading error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Compute unique client options for filter dropdown
  const clients = Array.from(new Set(invoices.map(inv => inv.client))).sort();

  // Handle amount and auto-calculating GST & Total
  const handleAmountChange = (val: number) => {
    // Standard Singapore GST rate (9% default for current system flow)
    const gstRate = 0.09;
    const computedGst = Math.round(val * gstRate * 100) / 100;
    const computedTotal = Math.round((val + computedGst) * 100) / 100;
    const paymentsTotal = (formData.payments || []).reduce((acc, curr) => acc + (curr.totalAmount || 0), 0);
    const contraTotalVal = formData.contraTotal || 0;
    const outstanding = Math.max(0, Math.round((computedTotal - paymentsTotal - contraTotalVal) * 100) / 100);

    setFormData(prev => ({
      ...prev,
      amount: val,
      gst: computedGst,
      totalAmount: computedTotal,
      outstandingBalance: outstanding
    }));
  };

  const updatePaymentsAndContra = (
    updatedPayments: ReceivedPayment[],
    contraTotalVal: number,
    contraBaseVal: number,
    contraGstVal: number
  ) => {
    const paymentsTotal = updatedPayments.reduce((acc, curr) => acc + (curr.totalAmount || 0), 0);
    const outstanding = Math.max(0, Math.round((formData.totalAmount - paymentsTotal - contraTotalVal) * 100) / 100);
    let derivedStatus = formData.status;

    if (outstanding <= 0) {
      derivedStatus = 'Paid';
    } else if (outstanding > 0 && derivedStatus === 'Paid') {
      derivedStatus = 'Overdue';
    }

    setFormData(prev => ({
      ...prev,
      payments: updatedPayments,
      actualReceivedTotal: paymentsTotal,
      contraAmount: contraBaseVal,
      contraGst: contraGstVal,
      contraTotal: contraTotalVal,
      outstandingBalance: outstanding,
      status: derivedStatus
    }));
  };

  // Open creation form
  const handleOpenCreate = () => {
    const nextSNoNum = Math.max(...invoices.map(inv => parseInt(inv.sNo) || 0), 0) + 1;
    const currentYear = new Date().getFullYear();
    const nextRef = `${currentYear}-${String(nextSNoNum).padStart(4, '0')}`;

    setEditingId(null);
    setFormData({
      invoiceDate: new Date().toLocaleDateString('en-GB').replace(/\//g, '-'),
      invoiceRef: nextRef,
      projectRef: '',
      client: '',
      amount: 0,
      gst: 0,
      totalAmount: 0,
      paymentDueDate: '',
      receivedDate: '',
      receivedAccount: 'MAYBANK_6278',
      actualReceivedTotal: 0,
      outstandingBalance: 0,
      status: 'Overdue',
      payments: [],
      contraAmount: 0,
      contraGst: 0,
      contraTotal: 0
    });
    setIsFormOpen(true);
  };

  // Open editing form
  const handleOpenEdit = (inv: SalesInvoice) => {
    setEditingId(inv.id || null);
    setFormData({
      invoiceDate: inv.invoiceDate,
      invoiceRef: inv.invoiceRef,
      projectRef: inv.projectRef,
      client: inv.client,
      amount: inv.amount,
      gst: inv.gst,
      totalAmount: inv.totalAmount,
      paymentDueDate: inv.paymentDueDate,
      receivedDate: inv.receivedDate,
      receivedAccount: inv.receivedAccount || 'MAYBANK_6278',
      actualReceivedTotal: inv.actualReceivedTotal,
      outstandingBalance: inv.outstandingBalance,
      status: inv.status,
      payments: inv.payments || [],
      contraAmount: inv.contraAmount || 0,
      contraGst: inv.contraGst || 0,
      contraTotal: inv.contraTotal || 0
    });
    setIsFormOpen(true);
  };

  // Handle Save
  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.invoiceDate || !formData.invoiceRef || !formData.client || !formData.amount) {
      triggerAlert("Validation Error", "Please fill in all mandatory fields.");
      return;
    }

    setSaving(true);
    try {
      const finalPayload = { ...formData };
      
      if (finalPayload.payments) {
        finalPayload.payments = finalPayload.payments.map(p => ({
          ...p,
          receivedDate: String(p.receivedDate || '').replace(/received/i, '').trim()
        }));
      }

      if (finalPayload.payments && finalPayload.payments.length > 0) {
        const firstPay = finalPayload.payments[0];
        if (firstPay.receivedDate) finalPayload.receivedDate = firstPay.receivedDate;
        if (firstPay.receivedAccount) finalPayload.receivedAccount = firstPay.receivedAccount;
      }

      finalPayload.receivedDate = String(finalPayload.receivedDate || '').replace(/received/i, '').trim();

      if (editingId) {
        // Edit record
        const docRef = doc(db, 'salesInvoices', editingId);
        await updateDoc(docRef, finalPayload);
      } else {
        // Add new record with dynamic sequential sNo
        const nextSNoNum = Math.max(...invoices.map(inv => parseInt(inv.sNo) || 0), 0) + 1;
        await addDoc(collection(db, 'salesInvoices'), {
          sNo: String(nextSNoNum),
          ...finalPayload
        });
      }
      setIsFormOpen(false);
    } catch (err) {
      console.error("Error saving sales invoice:", err);
      triggerAlert("Save Failed", "Failed to save the invoice. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  // Handle Delete
  const handleDeleteInvoice = (id: string) => {
    triggerConfirm(
      "Delete Invoice",
      "Are you sure you want to delete this invoice? This action is irreversible.",
      async () => {
        try {
          await deleteDoc(doc(db, 'salesInvoices', id));
        } catch (err) {
          console.error("Error deleting sales invoice:", err);
          triggerAlert("Delete Failed", "Failed to delete the invoice. Please try again.");
        }
      }
    );
  };

  // Export Table to CSV
  const handleExportCsv = () => {
    const headers = [
      'S/No', 'Invoice Date', 'Invoice Ref', 'Project Name', 'Client', 
      'Subtotal S$', 'GST S$', 'Total S$', 'Payment Due Date', 
      'Received Date', 'Account', 'Actual Received S$', 'Outstanding Balance S$', 'Status'
    ];
    const rows = filteredInvoices.map(inv => [
      inv.sNo, inv.invoiceDate, inv.invoiceRef, inv.projectRef, inv.client,
      inv.amount, inv.gst, inv.totalAmount, inv.paymentDueDate,
      inv.receivedDate || '-', inv.receivedAccount || '-', inv.actualReceivedTotal, inv.outstandingBalance, inv.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Sales_Invoice_Summary_${new Date().getFullYear()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Parse date string into Date or null
  const parseInvoiceDate = (dateStr: string): Date | null => {
    if (!dateStr) return null;
    const cleaned = dateStr.trim();
    const parts = cleaned.split(/[-/\s]+/);
    if (parts.length === 3) {
      let day = 1;
      let month = 0;
      let year = 2026;
      
      if (parts[0].length === 4) {
        year = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10) - 1;
        day = parseInt(parts[2], 10);
      } else {
        day = parseInt(parts[0], 10);
        year = parseInt(parts[2], 10);
        const monthStr = parts[1].toLowerCase();
        const shortMonths = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
        const fullMonths = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
        
        const shortIdx = shortMonths.findIndex(m => monthStr.startsWith(m));
        if (shortIdx !== -1) {
          month = shortIdx;
        } else {
          const fullIdx = fullMonths.indexOf(monthStr);
          if (fullIdx !== -1) {
            month = fullIdx;
          } else {
            month = parseInt(parts[1], 10) - 1;
          }
        }
      }
      
      if (!isNaN(day) && month >= 0 && month <= 11 && !isNaN(year)) {
        if (year < 100) {
          year += 2000;
        }
        return new Date(year, month, day);
      }
    }
    
    const parsed = new Date(cleaned);
    if (!isNaN(parsed.getTime())) {
      return parsed;
    }
    return null;
  };

  const handlePresetChange = (preset: 'all' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'custom') => {
    setDatePreset(preset);
    const anchor = new Date(2026, 6, 17); // July 17, 2026 (the current local time)
    const pad = (n: number) => String(n).padStart(2, '0');
    
    if (preset === 'all') {
      setFromDate('2022-01-01');
      setToDate('2026-12-31');
    } else if (preset === 'daily') {
      const dateStr = '2026-07-17';
      setFromDate(dateStr);
      setToDate(dateStr);
    } else if (preset === 'weekly') {
      const start = new Date(anchor);
      start.setDate(anchor.getDate() - 6);
      const startStr = `${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())}`;
      const endStr = `${anchor.getFullYear()}-${pad(anchor.getMonth() + 1)}-${pad(anchor.getDate())}`;
      setFromDate(startStr);
      setToDate(endStr);
    } else if (preset === 'monthly') {
      setFromDate('2026-07-01');
      setToDate('2026-07-31');
    } else if (preset === 'quarterly') {
      // Q3 2026: July 1, 2026 to Sept 30, 2026
      setFromDate('2026-07-01');
      setToDate('2026-09-30');
    }
  };

  // Filtered List
  const filteredInvoices = invoices.filter(inv => {
    const ref = inv.invoiceRef || '';
    const client = inv.client || '';
    const proj = inv.projectRef || '';
    
    const matchSearch = 
      ref.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.toLowerCase().includes(searchTerm.toLowerCase()) ||
      proj.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchStatus = statusFilter === 'All' || inv.status === statusFilter;
    const matchClient = clientFilter === 'All' || inv.client === clientFilter;

    // Date range filter
    let matchDate = true;
    if (fromDate || toDate) {
      const invDateObj = parseInvoiceDate(inv.invoiceDate);
      if (invDateObj) {
        if (fromDate) {
          const fromObj = new Date(fromDate);
          fromObj.setHours(0, 0, 0, 0);
          if (invDateObj < fromObj) matchDate = false;
        }
        if (toDate) {
          const toObj = new Date(toDate);
          toObj.setHours(23, 59, 59, 999);
          if (invDateObj > toObj) matchDate = false;
        }
      }
    }

    return matchSearch && matchStatus && matchClient && matchDate;
  });

  // KPI calculations
  const totalInvoiced = filteredInvoices.reduce((acc, curr) => acc + curr.totalAmount, 0);
  const totalReceived = filteredInvoices.reduce((acc, curr) => acc + curr.actualReceivedTotal, 0);
  const totalOutstanding = filteredInvoices.reduce((acc, curr) => acc + curr.outstandingBalance, 0);
  const totalGst = filteredInvoices.reduce((acc, curr) => acc + (curr.gst || 0), 0);
  const overdueCount = filteredInvoices.filter(i => i.status === 'Overdue' || i.status === 'Long Overdue').length;

  // Unfiltered overall corporate totals for continuous business dashboard feedback
  const overallInvoiced = invoices.reduce((acc, curr) => acc + curr.totalAmount, 0);
  const overallReceived = invoices.reduce((acc, curr) => acc + curr.actualReceivedTotal, 0);
  const overallOutstanding = invoices.reduce((acc, curr) => acc + curr.outstandingBalance, 0);
  const overallGst = invoices.reduce((acc, curr) => acc + (curr.gst || 0), 0);
  const overallOverdueCount = invoices.filter(i => i.status === 'Overdue' || i.status === 'Long Overdue').length;


  // Pagination calculations
  const totalItems = filteredInvoices.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;

  // Handle clamping currentPage to totalPages if totalPages decreases below currentPage
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages);
    }
  }, [totalPages, currentPage]);

  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedInvoices = filteredInvoices.slice(startIndex, startIndex + itemsPerPage);

  if (activeInvoiceForPdf) {
    // Beautiful interactive Corporate Tax Invoice Template Viewer
    return (
      <div className="space-y-6 animate-fadeIn text-gray-800 bg-white p-8 rounded-lg shadow-xl max-w-4xl mx-auto border border-gray-200 print-invoice-container">
        {/* Invoice Control Bar */}
        <div className="flex justify-between items-center pb-6 border-b border-gray-100 no-print">
          <button 
            onClick={() => setActiveInvoiceForPdf(null)}
            className="flex items-center px-4 py-2 text-sm text-gray-600 hover:text-gray-900 border border-gray-300 rounded hover:bg-gray-50 transition"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to List
          </button>
          <button 
            onClick={() => window.print()}
            className="flex items-center px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded transition shadow-md"
          >
            <Printer className="w-4 h-4 mr-2" /> Print Tax Invoice
          </button>
        </div>

        {/* Invoice Document Body */}
        <div className="p-4 print:p-0 space-y-8">
          {/* Header */}
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-serif tracking-tight text-gray-900 font-bold">MOUNTEC PTE. LTD.</h1>
              <p className="text-xs text-gray-500 mt-1 max-w-sm leading-relaxed">
                61 Kaki Bukit Ave 1, #02-14 Shamrock Road<br />
                Singapore 417943<br />
                Reg No: 202100412E | GST Reg No: 202100412E-G
              </p>
            </div>
            <div className="text-right">
              <h2 className="text-2xl font-sans tracking-wide text-gray-400 font-bold uppercase">TAX INVOICE</h2>
              <div className="text-xs text-gray-600 mt-2 space-y-1">
                <p><span className="font-semibold text-gray-800">Invoice Ref:</span> {activeInvoiceForPdf.invoiceRef}</p>
                <p><span className="font-semibold text-gray-800">Date:</span> {activeInvoiceForPdf.invoiceDate}</p>
                <p><span className="font-semibold text-gray-800">Due Date:</span> {activeInvoiceForPdf.paymentDueDate || '-'}</p>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Billing Section */}
          <div className="grid grid-cols-2 gap-8 text-xs leading-relaxed">
            <div>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">BILL TO</p>
              <p className="font-bold text-gray-900 text-sm">{activeInvoiceForPdf.client}</p>
              <p className="text-gray-600 mt-1">Singapore Construction Partner Office</p>
              <p className="text-gray-600">Company Registry Registered Address</p>
            </div>
            <div>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">PROJECT REFERENCE</p>
              <p className="font-medium text-gray-800">{activeInvoiceForPdf.projectRef}</p>
              <p className="text-gray-500 mt-1">Payment terms: 30 days standard credit terms</p>
            </div>
          </div>

          {/* Line Items */}
          <table className="w-full text-xs text-left text-gray-600 mt-8">
            <thead>
              <tr className="bg-gray-50 text-gray-800 border-b border-gray-200">
                <th className="py-3 px-4 font-bold rounded-l">ITEM DESCRIPTION</th>
                <th className="py-3 px-4 text-right font-bold">RATE S$</th>
                <th className="py-3 px-4 text-right font-bold">QTY</th>
                <th className="py-3 px-4 text-right font-bold rounded-r">AMOUNT S$</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-100">
                <td className="py-4 px-4 font-medium text-gray-900 max-w-md">
                  Professional structural engineering & contracting services as per contract works for Project: <br />
                  <span className="text-gray-500 italic mt-1 inline-block">{activeInvoiceForPdf.projectRef}</span>
                </td>
                <td className="py-4 px-4 text-right font-mono">${activeInvoiceForPdf.amount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</td>
                <td className="py-4 px-4 text-right font-mono">1</td>
                <td className="py-4 px-4 text-right font-mono font-medium text-gray-900">${activeInvoiceForPdf.amount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</td>
              </tr>
            </tbody>
          </table>

          {/* Subtotal & Totals Box */}
          <div className="flex justify-end mt-6 text-xs">
            <div className="w-80 space-y-2 border-t border-gray-100 pt-4 font-mono text-gray-600">
              <div className="flex justify-between">
                <span>SUBTOTAL (S$):</span>
                <span>${activeInvoiceForPdf.amount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
              </div>
              <div className="flex justify-between">
                <span>GST (9.00%):</span>
                <span>${activeInvoiceForPdf.gst.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
              </div>
              <hr className="border-gray-200" />
              <div className="flex justify-between text-sm font-bold text-gray-900">
                <span>TOTAL AMOUNT (S$):</span>
                <span>${activeInvoiceForPdf.totalAmount.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
              </div>
              {activeInvoiceForPdf.actualReceivedTotal > 0 && (
                <div className="flex justify-between text-gray-500 text-xs">
                  <span>ACTUAL RECEIVED (S$):</span>
                  <span>-${activeInvoiceForPdf.actualReceivedTotal.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
                </div>
              )}
              {activeInvoiceForPdf.outstandingBalance > 0 && (
                <div className="flex justify-between text-red-600 text-xs font-bold bg-red-50 p-2 rounded mt-1">
                  <span>OUTSTANDING BALANCE:</span>
                  <span>${activeInvoiceForPdf.outstandingBalance.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})}</span>
                </div>
              )}
            </div>
          </div>

          {/* Payment Instructions */}
          <div className="bg-gray-50 border border-gray-200 rounded p-4 text-[11px] text-gray-600 mt-10 leading-relaxed">
            <p className="font-bold text-gray-800 text-xs mb-1 uppercase tracking-wider">Payment Instructions</p>
            <p>Please send payments strictly via Bank Wire / Giro Transfer within the agreed payment period.</p>
            <p className="mt-2"><span className="font-semibold text-gray-700">Bank Name:</span> Maybank Singapore</p>
            <p><span className="font-semibold text-gray-700">Account Name:</span> MOUNTEC PTE. LTD.</p>
            <p><span className="font-semibold text-gray-700">Account Number:</span> 0448-6278-951</p>
            <p><span className="font-semibold text-gray-700">Bank Account Code:</span> MAYBANK_6278</p>
          </div>

          {/* Footer Signature placeholder */}
          <div className="flex justify-between items-end pt-12 text-[10px] text-gray-400">
            <p>Authorized and generated electronically. No signature required.</p>
            <div className="text-center w-48 border-t border-gray-300 pt-1 font-semibold text-gray-600">
              For MOUNTEC PTE. LTD.
            </div>
          </div>
        </div>
      </div>
    );
  }

  const hasActiveFilter = searchTerm !== '' || statusFilter !== 'All' || clientFilter !== 'All';

  return (
    <div className="space-y-6 text-white bg-gray-900 p-2 rounded-lg">
      
      {/* KPI Panel Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-[#1b1c22] to-[#121317] p-5 rounded-lg border border-[#2d2f39] shadow flex items-center space-x-4">
          <div className="p-3 bg-blue-900/40 rounded-full border border-blue-500/30 shrink-0">
            <DollarSign className="w-6 h-6 text-blue-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider truncate">Total Sales Invoiced</p>
            <h4 className="text-xl font-mono font-bold mt-1 text-white truncate">
              ${totalInvoiced.toLocaleString(undefined, {maximumFractionDigits:0})}
            </h4>
            <p className="text-[10px] text-blue-400 mt-0.5 truncate">
              {hasActiveFilter 
                ? `Filtered (Overall: $${overallInvoiced.toLocaleString(undefined, {maximumFractionDigits:0})})` 
                : `Overall: $${overallInvoiced.toLocaleString(undefined, {maximumFractionDigits:0})} (Auto-updated)`
              }
            </p>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#1b1c22] to-[#121317] p-5 rounded-lg border border-[#2d2f39] shadow flex items-center space-x-4">
          <div className="p-3 bg-emerald-900/40 rounded-full border border-emerald-500/30 shrink-0">
            <CheckCircle2 className="w-6 h-6 text-emerald-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider truncate">Total Actual Receipts</p>
            <h4 className="text-xl font-mono font-bold mt-1 text-emerald-400 truncate">
              ${totalReceived.toLocaleString(undefined, {maximumFractionDigits:0})}
            </h4>
            <p className="text-[10px] text-emerald-400 mt-0.5 truncate">
              {hasActiveFilter 
                ? `Filtered (Overall: $${overallReceived.toLocaleString(undefined, {maximumFractionDigits:0})})` 
                : `Overall: $${overallReceived.toLocaleString(undefined, {maximumFractionDigits:0})} (Maybank Sync)`
              }
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#1b1c22] to-[#121317] p-5 rounded-lg border border-[#2d2f39] shadow flex items-center space-x-4">
          <div className="p-3 bg-red-950/40 rounded-full border border-red-500/30 shrink-0">
            <AlertTriangle className="w-6 h-6 text-red-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider truncate">Outstanding Balance</p>
            <h4 className="text-xl font-mono font-bold mt-1 text-red-400 truncate">
              ${totalOutstanding.toLocaleString(undefined, {maximumFractionDigits:0})}
            </h4>
            <p className="text-[10px] text-red-400 mt-0.5 truncate">
              {hasActiveFilter 
                ? `Filtered (Overall: $${overallOutstanding.toLocaleString(undefined, {maximumFractionDigits:0})})` 
                : `Overall: $${overallOutstanding.toLocaleString(undefined, {maximumFractionDigits:0})} (${overallOverdueCount} pending)`
              }
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#1b1c22] to-[#121317] p-5 rounded-lg border border-[#2d2f39] shadow flex items-center space-x-4">
          <div className="p-3 bg-indigo-900/40 rounded-full border border-indigo-500/30 shrink-0">
            <FileSpreadsheet className="w-6 h-6 text-indigo-400" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider truncate">Total Invoices</p>
            <h4 className="text-xl font-mono font-bold mt-1 text-white truncate">
              {filteredInvoices.length}
            </h4>
            <p className="text-[10px] text-indigo-400 mt-0.5 truncate">
              {hasActiveFilter 
                ? `Filtered (Overall: ${invoices.length} records)` 
                : `Overall: ${invoices.length} invoices (2022-2026)`
              }
            </p>
          </div>
        </div>
      </div>

      {/* Date Range & Periodic Performance Panel */}
      <div className="bg-gradient-to-br from-[#1b1c22] to-[#121317] p-5 rounded-lg border border-[#2d2f39] shadow space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#2d2f39] pb-4">
          <div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              <h3 className="text-xs font-sans font-bold uppercase tracking-wider text-white">Periodic Performance & Tax Liabilities Review</h3>
            </div>
            <p className="text-[10px] text-gray-400 mt-1">
              Select predefined intervals or specify an exact date range to analyze tax liabilities and actual cash receipts.
            </p>
          </div>
          
          {/* Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => handlePresetChange('all')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              All Time
            </button>
            <button
              onClick={() => handlePresetChange('daily')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'daily' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              Daily
            </button>
            <button
              onClick={() => handlePresetChange('weekly')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'weekly' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              Weekly
            </button>
            <button
              onClick={() => handlePresetChange('monthly')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'monthly' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              Monthly
            </button>
            <button
              onClick={() => handlePresetChange('quarterly')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'quarterly' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              Quarterly
            </button>
            <button
              onClick={() => setDatePreset('custom')}
              className={`px-2.5 py-1 text-[10px] rounded font-semibold transition ${datePreset === 'custom' ? 'bg-blue-600 text-white' : 'bg-gray-900 text-gray-400 hover:bg-gray-800 border border-[#2d2f39]'}`}
            >
              Custom Range
            </button>
          </div>
        </div>

        {/* Date pickers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end bg-[#141416]/50 p-4 rounded border border-[#2d2f39]/50">
          <div>
            <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">From Date</label>
            <input
              type="date"
              value={fromDate}
              onChange={(e) => {
                setFromDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">To Date</label>
            <input
              type="date"
              value={toDate}
              onChange={(e) => {
                setToDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex items-center justify-between py-1">
            <span className="text-[10px] text-gray-400">
              Active interval: <span className="text-white font-mono font-bold bg-gray-800 px-1.5 py-0.5 rounded border border-[#2d2f39]">{datePreset.toUpperCase()}</span>
            </span>
            {(fromDate !== '2022-01-01' || toDate !== '2026-12-31') && (
              <button
                onClick={() => {
                  handlePresetChange('all');
                }}
                className="text-[10px] text-blue-400 hover:underline hover:text-blue-300 font-semibold"
              >
                Reset range
              </button>
            )}
          </div>
        </div>

        {/* Periodic Subtotals Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          <div className="bg-[#141416]/60 p-4 rounded border border-[#2d2f39]/40">
            <div className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider">Filtered Invoiced Subtotal</div>
            <div className="text-lg font-mono font-bold mt-1 text-white">
              S${(totalInvoiced - totalGst).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
            </div>
            <div className="text-[9px] text-gray-500 mt-0.5">Excludes GST</div>
          </div>

          <div className="bg-[#141416]/60 p-4 rounded border border-[#2d2f39]/40">
            <div className="text-[10px] text-[#22c55e]/90 uppercase font-semibold tracking-wider">GST Output Liability</div>
            <div className="text-lg font-mono font-bold mt-1 text-[#22c55e]">
              S${totalGst.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
            </div>
            <div className="text-[9px] text-gray-500 mt-0.5">9% GST components</div>
          </div>

          <div className="bg-[#141416]/60 p-4 rounded border border-[#2d2f39]/40">
            <div className="text-[10px] text-blue-400 uppercase font-semibold tracking-wider">Total Sales Invoiced</div>
            <div className="text-lg font-mono font-bold mt-1 text-blue-400">
              S${totalInvoiced.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
            </div>
            <div className="text-[9px] text-gray-500 mt-0.5">Includes GST</div>
          </div>

          <div className="bg-[#141416]/60 p-4 rounded border border-[#2d2f39]/40">
            <div className="text-[10px] text-emerald-400 uppercase font-semibold tracking-wider">Total Actual Receipts</div>
            <div className="text-lg font-mono font-bold mt-1 text-emerald-400">
              S${totalReceived.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
            </div>
            <div className="text-[9px] text-gray-500 mt-0.5">Cleared cash on hand</div>
          </div>
        </div>
      </div>

      {/* Control bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#141416] p-4 rounded-lg border border-[#222]">
        
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
          <input 
            type="text"
            placeholder="Search ref, client, or project..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-gray-900 border border-[#2d2f39] rounded text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Filters and Actions */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          
          {/* Status Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold text-gray-500">Status</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="bg-gray-900 border border-[#2d2f39] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              <option value="All">All Invoices</option>
              <option value="Paid">Paid</option>
              <option value="Overdue">Overdue</option>
              <option value="Long Overdue">Long Dued</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          {/* Client Filter */}
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold text-gray-500">Client</span>
            <select
              value={clientFilter}
              onChange={(e) => setClientFilter(e.target.value)}
              className="bg-gray-900 border border-[#2d2f39] rounded px-3 py-1.5 text-xs text-white max-w-[150px] focus:outline-none focus:border-blue-500"
            >
              <option value="All">All Clients</option>
              {clients.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Action buttons */}
          <button 
            onClick={handleExportCsv}
            className="flex items-center px-3 py-1.5 text-xs text-gray-300 border border-[#2d2f39] hover:bg-gray-800 rounded font-semibold transition"
          >
            <Download className="w-3.5 h-3.5 mr-1" /> Export CSV
          </button>

          <button 
            onClick={() => setIsImportOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#039855] hover:bg-[#027a44] text-white text-xs font-bold uppercase rounded transition-all cursor-pointer shadow-md tracking-wide"
          >
            <FileSpreadsheet className="w-4 h-4" /> IMPORT GOOGLE SHEETS
          </button>
          
          <button 
            onClick={handleOpenCreate}
            className="flex items-center px-4 py-1.5 text-xs text-white bg-blue-600 hover:bg-blue-700 rounded font-bold transition shadow"
          >
            <Plus className="w-4 h-4 mr-1" /> Add Invoice
          </button>

        </div>
      </div>

      {/* Main Table Grid */}
      <div className="bg-[#141416] border border-[#222] rounded-lg overflow-hidden shadow-xl">
        {loading ? (
          <div className="flex justify-center items-center py-20 text-gray-400">
            <RefreshCw className="w-8 h-8 animate-spin mr-3 text-blue-500" />
            <span className="text-sm font-medium font-mono">LOADING SALES BILLING FLOWS...</span>
          </div>
        ) : (
          <>
            {/* Top Pagination Controls */}
            {!loading && filteredInvoices.length > 0 && (
              <div className="flex flex-col sm:flex-row justify-between items-center p-4 bg-[#18181c] border-b border-[#222] text-xs text-gray-400 space-y-3 sm:space-y-0 no-print">
                <div className="flex items-center space-x-2">
                  <span>Show</span>
                  <select 
                    value={itemsPerPage} 
                    onChange={(e) => {
                      setItemsPerPage(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    className="bg-gray-900 border border-[#2d2f39] text-gray-300 rounded px-2 py-1 focus:outline-none focus:border-blue-500 font-mono text-xs"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                    <option value={250}>250</option>
                    <option value={500}>500</option>
                    <option value={1000}>1000 (All)</option>
                  </select>
                  <span>invoices per page</span>
                </div>
                
                <div className="text-gray-400 font-sans text-center">
                  Showing <span className="text-white font-mono font-bold">{Math.min(totalItems, startIndex + 1)}</span> to <span className="text-white font-mono font-bold">{Math.min(totalItems, startIndex + itemsPerPage)}</span> of <span className="text-white font-mono font-bold">{totalItems}</span> matching billing records
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    className="p-1.5 rounded border border-[#2d2f39] hover:bg-gray-800 text-gray-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition"
                    title="Previous Page"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="flex items-center space-x-1">
                    <span className="text-gray-500">Page</span>
                    <select
                      value={currentPage}
                      onChange={(e) => setCurrentPage(Number(e.target.value))}
                      disabled={totalPages === 1}
                      className="bg-gray-900 border border-[#2d2f39] text-gray-300 rounded px-2 py-1 font-mono focus:outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                        <option key={pageNum} value={pageNum}>{pageNum}</option>
                      ))}
                    </select>
                    <span className="text-gray-500">of {totalPages}</span>
                  </div>

                  <button
                    type="button"
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                    className="p-1.5 rounded border border-[#2d2f39] hover:bg-gray-800 text-gray-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition"
                    title="Next Page"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-400">
              <thead className="bg-[#1e1e24] text-gray-300 uppercase tracking-wider font-bold font-sans border-b border-[#2d2f39]">
                <tr>
                  <th className="py-3 px-4 text-center">S/N</th>
                  <th className="py-3 px-4">Invoice Ref</th>
                  <th className="py-3 px-4">Invoice Date</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Project Ref / Description</th>
                  <th className="py-3 px-4 text-right">Subtotal S$</th>
                  <th className="py-3 px-4 text-right">GST S$</th>
                  <th className="py-3 px-4 text-right">Total S$</th>
                  <th className="py-3 px-4 text-right">Actual Recd S$</th>
                  <th className="py-3 px-4 text-right text-red-400">Outstanding S$</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222] font-mono">
                {invoices.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="py-16 text-center text-gray-400 font-sans">
                      <div className="max-w-md mx-auto space-y-4">
                        <FileSpreadsheet className="w-12 h-12 text-indigo-500 mx-auto animate-pulse" />
                        <h4 className="text-sm font-bold text-white uppercase tracking-wider">No Billing Records Found</h4>
                        <p className="text-xs text-gray-500 leading-relaxed">
                          Your sales invoices database is currently empty. You can automatically seed the complete sequential dataset of 472 chronological invoices (2022 - 2026) or import your custom spreadsheet.
                        </p>
                        <div className="flex justify-center space-x-3 pt-2">
                          <button
                            onClick={() => {
                              const list = generateDeterministic472Invoices();
                              triggerConfirm(
                                "Generate & Seed Sequence",
                                "Generate and seed all 472 chronological invoices now? This will overwrite the current database cleanly.",
                                () => handleBatchInsert(list, true)
                              );
                            }}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded text-xs transition shadow"
                          >
                            Seed 472 Sequence
                          </button>
                          <button
                            onClick={() => setIsImportOpen(true)}
                            className="px-4 py-2 bg-[#2d2f39] hover:bg-gray-800 text-gray-300 font-bold rounded text-xs transition border border-[#3e404c]"
                          >
                            Open Import Center
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ) : filteredInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="py-12 text-center text-gray-500 font-sans italic">
                      No invoices found matching the current search parameters.
                    </td>
                  </tr>
                ) : (
                  paginatedInvoices.map((inv) => {
                    const statusColors = {
                      Paid: 'bg-emerald-950/80 text-emerald-400 border-emerald-800/30',
                      Overdue: 'bg-amber-950/80 text-amber-400 border-amber-800/30',
                      'Long Overdue': 'bg-red-950/80 text-red-400 border-red-800/30',
                      Cancelled: 'bg-gray-800 text-gray-400 border-gray-700'
                    };

                    const isExpanded = expandedInvoiceId === inv.id;
                    const toggleExpanded = () => {
                      setExpandedInvoiceId(isExpanded ? null : inv.id || null);
                    };

                    const paymentsList = inv.payments || [];
                    const hasPayments = paymentsList.length > 0;

                    return (
                      <React.Fragment key={inv.id}>
                        <tr className={`hover:bg-[#1a1b21] transition-colors border-[#2d2f39] ${isExpanded ? 'bg-gray-800/30' : ''}`}>
                          <td className="py-3.5 px-4 text-center text-gray-500 font-bold">{inv.sNo}</td>
                          <td className="py-3.5 px-4 text-white font-bold cursor-pointer hover:text-blue-400 transition" onClick={toggleExpanded}>
                            <div className="flex items-center space-x-1.5">
                              <span className="text-[9px] text-gray-500">{isExpanded ? '▼' : '▶'}</span>
                              <span className="border-b border-dashed border-gray-600 hover:border-blue-400">{inv.invoiceRef}</span>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-gray-300 font-sans">{inv.invoiceDate}</td>
                          <td className="py-3.5 px-4 text-white font-bold font-sans max-w-[150px] truncate" title={inv.client}>{inv.client}</td>
                          <td className="py-3.5 px-4 text-gray-400 font-sans max-w-[200px] truncate" title={inv.projectRef}>{inv.projectRef}</td>
                          <td className="py-3.5 px-4 text-right">${inv.amount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                          <td className="py-3.5 px-4 text-right text-gray-500">${inv.gst.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                          <td className="py-3.5 px-4 text-right text-white font-bold">${inv.totalAmount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                          <td className="py-3.5 px-4 text-right text-emerald-500 font-bold">${inv.actualReceivedTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                          <td className={`py-3.5 px-4 text-right font-bold ${inv.outstandingBalance > 0 ? 'text-red-400' : 'text-gray-500'}`}>
                            ${inv.outstandingBalance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`px-2 py-0.5 text-[9px] uppercase tracking-wide font-bold font-sans border rounded ${statusColors[inv.status]}`}>
                              {inv.status}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <div className="flex items-center justify-center space-x-2">
                              <button 
                                onClick={() => setActiveInvoiceForPdf(inv)}
                                title="Print/Preview Tax Invoice"
                                className="p-1 hover:bg-gray-800 text-blue-400 rounded transition"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button 
                                onClick={() => handleOpenEdit(inv)}
                                title="Edit Record"
                                className="p-1 hover:bg-gray-800 text-gray-400 hover:text-white rounded transition"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button 
                                onClick={() => handleDeleteInvoice(inv.id!)}
                                title="Delete Record"
                                className="p-1 hover:bg-gray-800 text-red-500 hover:text-red-400 rounded transition"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr className="bg-gray-950/70">
                            <td colSpan={12} className="p-4 border-t border-b border-[#2d2f39] text-gray-300">
                              <div className="space-y-4 max-w-5xl mx-auto">
                                
                                <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-gray-200 uppercase tracking-wider text-[10px] font-sans">Payment Reconciliation Ledger</span>
                                    <span className="text-[10px] text-gray-500 font-mono">({inv.invoiceRef})</span>
                                  </div>
                                  <div className="text-[10px] text-gray-400 font-sans">
                                    Client: <span className="font-bold text-gray-200">{inv.client}</span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
                                  
                                  {/* Left Panel - Cash Streams (1st to 4th) */}
                                  <div className="lg:col-span-7 bg-[#141416]/90 p-3.5 rounded border border-gray-800/80 space-y-3">
                                    <div className="flex justify-between items-center border-b border-gray-800/50 pb-1.5">
                                      <h5 className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider font-sans">Partial Cash Receipt Ledger (1st - 4th)</h5>
                                      <span className="text-[9px] text-gray-500 font-sans italic">Auto-matched from bank statements</span>
                                    </div>
                                    
                                    {!hasPayments && inv.actualReceivedTotal === 0 ? (
                                      <p className="text-gray-500 italic py-4 text-center text-xs">No cash payments synchronized yet.</p>
                                    ) : (
                                      <div className="overflow-x-auto">
                                        <table className="w-full text-left font-mono text-xs">
                                          <thead>
                                            <tr className="border-b border-gray-800 text-gray-500 text-[9px] uppercase font-sans">
                                              <th className="pb-1.5 font-bold">Payment Stream</th>
                                              <th className="pb-1.5 font-bold">Payment Date</th>
                                              <th className="pb-1.5 font-bold">Bank Account</th>
                                              <th className="pb-1.5 text-right font-bold">Base Amount</th>
                                              <th className="pb-1.5 text-right font-bold">GST (9%)</th>
                                              <th className="pb-1.5 text-right text-emerald-400 font-bold">Total S$</th>
                                            </tr>
                                          </thead>
                                          <tbody className="divide-y divide-gray-800/30">
                                            {hasPayments ? (
                                              paymentsList.map((p, pIdx) => (
                                                <tr key={pIdx} className="hover:bg-gray-900/50">
                                                  <td className="py-2 text-gray-400 font-sans">{["1st", "2nd", "3rd", "4th"][pIdx] || `${pIdx + 1}th`} Cash Payment</td>
                                                  <td className="py-2 text-gray-300">{p.receivedDate || '-'}</td>
                                                  <td className="py-2 text-gray-400 text-[11px]">{p.receivedAccount || '-'}</td>
                                                  <td className="py-2 text-right text-gray-400">${p.amount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                                  <td className="py-2 text-right text-gray-500">${p.gst.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                                  <td className="py-2 text-right text-emerald-400 font-bold">${p.totalAmount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                                </tr>
                                              ))
                                            ) : (
                                              <tr className="hover:bg-gray-900/50">
                                                <td className="py-2 text-gray-400 font-sans">1st Cash Payment</td>
                                                <td className="py-2 text-gray-300">{inv.receivedDate || '-'}</td>
                                                <td className="py-2 text-gray-400 text-[11px]">{inv.receivedAccount || '-'}</td>
                                                <td className="py-2 text-right text-gray-400">${(Math.round((inv.actualReceivedTotal / 1.09) * 100) / 100).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                                <td className="py-2 text-right text-gray-500">${(Math.round((inv.actualReceivedTotal - (inv.actualReceivedTotal / 1.09)) * 100) / 100).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                                <td className="py-2 text-right text-emerald-400 font-bold">${inv.actualReceivedTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                              </tr>
                                            )}
                                          </tbody>
                                        </table>
                                      </div>
                                    )}
                                  </div>

                                  {/* Right Panel - Settlements and Reconciliation Summaries */}
                                  <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
                                    
                                    <div className="bg-[#141416]/90 p-3.5 rounded border border-gray-800/80 space-y-2.5">
                                      <h5 className="text-[10px] uppercase font-bold text-amber-500 tracking-wider font-sans">Settlement Adjustments & Contra</h5>
                                      <div className="grid grid-cols-3 gap-2 font-mono text-[11px] bg-gray-900/50 p-2.5 rounded border border-gray-800/40">
                                        <div>
                                          <p className="text-[9px] uppercase font-sans text-gray-500">Contra Base</p>
                                          <p className="text-gray-300 mt-0.5">${(inv.contraAmount || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                                        </div>
                                        <div>
                                          <p className="text-[9px] uppercase font-sans text-gray-500">Contra GST</p>
                                          <p className="text-gray-500 mt-0.5">${(inv.contraGst || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                                        </div>
                                        <div>
                                          <p className="text-[9px] uppercase font-sans text-amber-400 font-bold">Contra Total</p>
                                          <p className="text-amber-400 font-bold mt-0.5">${(inv.contraTotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Grand Rec Reconciliation box */}
                                    <div className="bg-gray-900/60 p-3 rounded border border-gray-800 font-mono text-xs space-y-2">
                                      <div className="flex justify-between text-gray-400">
                                        <span>Invoice Value:</span>
                                        <span className="font-bold text-gray-300">${inv.totalAmount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                                      </div>
                                      <div className="flex justify-between text-gray-400 text-[11px]">
                                        <span>(-) Total Received Cash:</span>
                                        <span className="text-emerald-400">-${inv.actualReceivedTotal.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                                      </div>
                                      <div className="flex justify-between text-gray-400 text-[11px]">
                                        <span>(-) Contra / Back Charges:</span>
                                        <span className="text-amber-400">-${(inv.contraTotal || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                                      </div>
                                      <div className="flex justify-between border-t border-gray-800 pt-2 font-bold text-gray-200">
                                        <span>Ledger Outstanding Balance:</span>
                                        <span className={inv.outstandingBalance > 0 ? 'text-red-400' : 'text-gray-500'}>
                                          ${inv.outstandingBalance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                                        </span>
                                      </div>
                                    </div>

                                  </div>

                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination Controls */}
          {!loading && filteredInvoices.length > 0 && (
            <div className="flex flex-col sm:flex-row justify-between items-center p-4 bg-[#18181c] border-t border-[#222] text-xs text-gray-400 space-y-3 sm:space-y-0 no-print">
              <div className="flex items-center space-x-2">
                <span>Show</span>
                <select 
                  value={itemsPerPage} 
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="bg-gray-900 border border-[#2d2f39] text-gray-300 rounded px-2 py-1 focus:outline-none focus:border-blue-500 font-mono text-xs"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value={250}>250</option>
                  <option value={500}>500</option>
                  <option value={1000}>1000 (All)</option>
                </select>
                <span>invoices per page</span>
              </div>
              
              <div className="text-gray-400 font-sans text-center">
                Showing <span className="text-white font-mono font-bold">{Math.min(totalItems, startIndex + 1)}</span> to <span className="text-white font-mono font-bold">{Math.min(totalItems, startIndex + itemsPerPage)}</span> of <span className="text-white font-mono font-bold">{totalItems}</span> matching billing records
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  className="p-1.5 rounded border border-[#2d2f39] hover:bg-gray-800 text-gray-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition"
                  title="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center space-x-1">
                  <span className="text-gray-500">Page</span>
                  <select
                    value={currentPage}
                    onChange={(e) => setCurrentPage(Number(e.target.value))}
                    disabled={totalPages === 1}
                    className="bg-gray-900 border border-[#2d2f39] text-gray-300 rounded px-2 py-1 font-mono focus:outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                      <option key={pageNum} value={pageNum}>{pageNum}</option>
                    ))}
                  </select>
                  <span className="text-gray-500">of {totalPages}</span>
                </div>

                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  className="p-1.5 rounded border border-[#2d2f39] hover:bg-gray-800 text-gray-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none transition"
                  title="Next Page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
          </>
        )}
      </div>

      {/* Sliding Dialog / Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 p-4 animate-fadeIn">
          <div className="bg-[#141416] rounded-lg border border-[#2d2f39] text-white w-full max-w-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center p-4 border-b border-[#2d2f39]">
              <h3 className="text-sm uppercase font-bold text-gray-300 tracking-wide">
                {editingId ? `Edit Invoice: ${formData.invoiceRef}` : "Generate New Sales Invoice"}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="text-gray-500 hover:text-white font-bold text-lg focus:outline-none"
              >
                &times;
              </button>
            </div>
            
            <form onSubmit={handleSaveInvoice} className="p-5 space-y-4 text-xs font-sans overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-4">
                
                {/* Ref */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Invoice Ref (Ref ID)*</label>
                  <input 
                    type="text" 
                    value={formData.invoiceRef}
                    onChange={(e) => setFormData(prev => ({ ...prev, invoiceRef: e.target.value }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white placeholder-gray-600 font-mono focus:outline-none focus:border-blue-500"
                    placeholder="e.g. 2026-001"
                    required
                  />
                </div>

                {/* Date */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Invoice Date*</label>
                  <input 
                    type="text" 
                    value={formData.invoiceDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, invoiceDate: e.target.value }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                    placeholder="e.g. 15-Mar-2025"
                    required
                  />
                </div>

              </div>

              <div className="grid grid-cols-1 gap-4">
                
                {/* Client */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Client Name*</label>
                  <input 
                    type="text" 
                    value={formData.client}
                    onChange={(e) => setFormData(prev => ({ ...prev, client: e.target.value }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                    placeholder="e.g. Vista Engineers & Construction"
                    required
                  />
                </div>

                {/* Project Ref */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Project Ref / Description*</label>
                  <input 
                    type="text" 
                    value={formData.projectRef}
                    onChange={(e) => setFormData(prev => ({ ...prev, projectRef: e.target.value }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                    placeholder="e.g. M-060/ 139 Holland Road (Alpha)"
                    required
                  />
                </div>

              </div>

              <div className="grid grid-cols-3 gap-4 font-mono">
                
                {/* Base Amount */}
                <div>
                  <label className="block text-[10px] uppercase font-sans font-bold text-gray-500 mb-1">Subtotal S$*</label>
                  <input 
                    type="number"
                    step="0.01"
                    value={formData.amount || ''}
                    onChange={(e) => handleAmountChange(parseFloat(e.target.value) || 0)}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                    placeholder="0.00"
                    required
                  />
                </div>

                {/* GST */}
                <div>
                  <label className="block text-[10px] uppercase font-sans font-bold text-gray-500 mb-1">GST (9.00%) S$</label>
                  <input 
                    type="number" 
                    value={formData.gst || ''}
                    className="w-full bg-gray-950 border border-[#2d2f39] text-gray-500 rounded px-3 py-2 focus:outline-none"
                    disabled
                  />
                </div>

                {/* Total */}
                <div>
                  <label className="block text-[10px] uppercase font-sans font-bold text-gray-500 mb-1">Total S$</label>
                  <input 
                    type="number" 
                    value={formData.totalAmount || ''}
                    className="w-full bg-gray-950 border border-[#2d2f39] text-gray-300 font-bold rounded px-3 py-2 focus:outline-none"
                    disabled
                  />
                </div>

              </div>

              <div className="grid grid-cols-2 gap-4">
                
                {/* Due Date */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Payment Due Date</label>
                  <input 
                    type="text" 
                    value={formData.paymentDueDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, paymentDueDate: e.target.value }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                    placeholder="e.g. 15-Apr-2025"
                  />
                </div>

                {/* Status Selection */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-500 mb-1">Status Override</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
                    className="w-full bg-gray-900 border border-[#2d2f39] rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Paid">Paid</option>
                    <option value="Overdue">Overdue</option>
                    <option value="Long Overdue">Long Dued</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </div>

              </div>

              <hr className="border-[#2d2f39]" />

              <div className="space-y-3 bg-[#18181c] p-3 rounded-lg border border-[#2d2f39]">
                <div className="flex justify-between items-center border-b border-[#2d2f39] pb-1.5 mb-1">
                  <span className="text-[10px] uppercase font-bold text-gray-400">Actual Receipts (Partial Payments Ledger)</span>
                  <span className="text-[9px] text-gray-500 italic">Deducts from Outstanding Balance</span>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {[0, 1, 2, 3].map((idx) => {
                    const label = ["1st Payment", "2nd Payment", "3rd Payment", "4th Payment"][idx];
                    const p = formData.payments?.[idx] || {
                      receivedDate: '',
                      receivedAccount: 'MAYBANK_6278',
                      amount: 0,
                      gst: 0,
                      totalAmount: 0
                    };

                    const handlePayChange = (field: keyof ReceivedPayment, val: any) => {
                      const list = [...(formData.payments || [])];
                      while (list.length <= idx) {
                        list.push({ receivedDate: '', receivedAccount: 'MAYBANK_6278', amount: 0, gst: 0, totalAmount: 0 });
                      }
                      
                      let updatedPay = { ...list[idx] };
                      
                      if (field === 'totalAmount') {
                        const tot = parseFloat(val) || 0;
                        const base = Math.round((tot / 1.09) * 100) / 100;
                        const gstVal = Math.round((tot - base) * 100) / 100;
                        updatedPay = {
                          ...updatedPay,
                          totalAmount: tot,
                          amount: base,
                          gst: gstVal
                        };
                      } else {
                        updatedPay = {
                          ...updatedPay,
                          [field]: val
                        };
                      }
                      
                      list[idx] = updatedPay;
                      updatePaymentsAndContra(list, formData.contraTotal || 0, formData.contraAmount || 0, formData.contraGst || 0);
                    };

                    return (
                      <div key={idx} className="grid grid-cols-12 gap-2 items-center p-2 bg-gray-900/60 rounded border border-gray-800/40">
                        <div className="col-span-3 text-[10px] font-bold text-gray-400 font-sans">{label}</div>
                        <div className="col-span-3">
                          <input 
                            type="text" 
                            placeholder="DD-MM-YYYY"
                            value={p.receivedDate || ''}
                            onChange={(e) => handlePayChange('receivedDate', e.target.value)}
                            className="w-full bg-[#111] border border-gray-800 rounded px-2 py-1 text-[11px] text-white font-mono focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div className="col-span-3">
                          <input 
                            type="text" 
                            placeholder="MAYBANK_6278"
                            value={p.receivedAccount || ''}
                            onChange={(e) => handlePayChange('receivedAccount', e.target.value)}
                            className="w-full bg-[#111] border border-gray-800 rounded px-2 py-1 text-[11px] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div className="col-span-3">
                          <div className="relative">
                            <span className="absolute left-1.5 top-1 text-[10px] text-gray-500 font-sans">$</span>
                            <input 
                              type="number" 
                              step="0.01"
                              placeholder="Total S$"
                              value={p.totalAmount || ''}
                              onChange={(e) => handlePayChange('totalAmount', parseFloat(e.target.value) || 0)}
                              className="w-full bg-[#111] border border-gray-800 rounded pl-4 pr-1 py-1 text-[11px] text-emerald-400 font-mono text-right focus:outline-none focus:border-emerald-500"
                            />
                          </div>
                          {p.totalAmount > 0 && (
                            <div className="text-[9px] text-gray-500 text-right mt-0.5 font-mono">
                              Amt: {p.amount.toFixed(2)} | GST: {p.gst.toFixed(2)}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Contra / Back Charge (BC) Settlements */}
              <div className="bg-[#18181c] p-3 rounded-lg border border-[#2d2f39]">
                <div className="flex justify-between items-center border-b border-[#2d2f39] pb-1.5 mb-2">
                  <span className="text-[10px] uppercase font-bold text-gray-400">Contra / Back Charge (BC) Settlement</span>
                  <span className="text-[9px] text-gray-500 italic">Deducts from Outstanding Balance</span>
                </div>
                <div className="grid grid-cols-12 gap-3 items-center">
                  <div className="col-span-4">
                    <label className="block text-[10px] uppercase font-sans text-gray-500 mb-1">Contra Total S$</label>
                    <div className="relative">
                      <span className="absolute left-2 top-1.5 text-gray-500 font-sans">$</span>
                      <input 
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={formData.contraTotal || ''}
                        onChange={(e) => {
                          const tot = parseFloat(e.target.value) || 0;
                          const base = Math.round((tot / 1.09) * 100) / 100;
                          const gstVal = Math.round((tot - base) * 100) / 100;
                          updatePaymentsAndContra(formData.payments || [], tot, base, gstVal);
                        }}
                        className="w-full bg-[#111] border border-gray-800 rounded pl-5 pr-2 py-1.5 text-[11px] text-amber-400 font-mono text-right focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                  <div className="col-span-4">
                    <label className="block text-[10px] uppercase font-sans text-gray-500 mb-1">Contra Base S$</label>
                    <input 
                      type="number"
                      value={formData.contraAmount || 0}
                      disabled
                      className="w-full bg-[#141416]/50 border border-gray-800 rounded px-2 py-1.5 text-[11px] text-gray-500 font-mono text-right"
                    />
                  </div>
                  <div className="col-span-4">
                    <label className="block text-[10px] uppercase font-sans text-gray-500 mb-1">Contra GST S$</label>
                    <input 
                      type="number"
                      value={formData.contraGst || 0}
                      disabled
                      className="w-full bg-[#141416]/50 border border-gray-800 rounded px-2 py-1.5 text-[11px] text-gray-500 font-mono text-right"
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic Live Reconciliation Summary */}
              <div className="p-3 bg-gray-900/60 rounded-lg border border-[#2d2f39] text-xs space-y-1.5">
                <div className="flex justify-between text-gray-400">
                  <span>Invoice Total:</span>
                  <span className="font-mono text-white">${formData.totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Actual Received (Total 1st-4th):</span>
                  <span className="font-mono text-emerald-400 font-bold">${formData.actualReceivedTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Contra/Back Charge Settlement:</span>
                  <span className="font-mono text-amber-400 font-bold">${(formData.contraTotal || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between border-t border-gray-800 pt-1.5 font-bold text-gray-200">
                  <span>Reconciled Outstanding Balance:</span>
                  <span className={`font-mono ${formData.outstandingBalance > 0 ? 'text-red-400' : 'text-gray-500'}`}>
                    ${formData.outstandingBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end space-x-3 pt-4 border-t border-[#2d2f39]">
                <button 
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-[#2d2f39] text-gray-300 rounded hover:bg-gray-800 text-xs transition"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white rounded font-bold text-xs transition shadow-md flex items-center"
                >
                  {saving && <RefreshCw className="w-3 h-3 animate-spin mr-1.5" />}
                  {editingId ? "Save Changes" : "Create Invoice"}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {isImportOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex justify-center items-center z-50 p-4 animate-fadeIn">
          <div className="bg-[#141416] rounded-lg border border-[#2d2f39] text-white w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#2d2f39]">
              <h3 className="text-sm uppercase font-bold text-gray-300 tracking-wide flex items-center">
                <FileSpreadsheet className="w-4 h-4 mr-2 text-indigo-400" />
                Mountec Billing Sync & Smart Import Center
              </h3>
              <button 
                onClick={() => {
                  if (!importing && !scanningFile) {
                    setIsImportOpen(false);
                    setCsvFile(null);
                    setParsedRows([]);
                    setScannedInvoices([]);
                  }
                }}
                disabled={importing || scanningFile}
                className="text-gray-500 hover:text-white font-bold text-lg focus:outline-none disabled:opacity-30"
              >
                &times;
              </button>
            </div>

            {/* Interactive Tabs */}
            {!importing && !scanningFile && (
              <div className="flex border-b border-[#2d2f39] text-xs font-semibold bg-gray-950/40 px-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveImportTab('local');
                    setScannedInvoices([]);
                  }}
                  className={`px-4 py-3 border-b-2 transition-all duration-200 flex items-center ${
                    activeImportTab === 'local' 
                      ? 'border-blue-500 text-blue-400 bg-gray-900/40' 
                      : 'border-transparent text-gray-500 hover:text-gray-300'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5 mr-1.5" /> Local Hard Disk
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveImportTab('drive');
                    setScannedInvoices([]);
                  }}
                  className={`px-4 py-3 border-b-2 transition-all duration-200 flex items-center ${
                    activeImportTab === 'drive' 
                      ? 'border-indigo-500 text-indigo-400 bg-gray-900/40' 
                      : 'border-transparent text-gray-500 hover:text-gray-300'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 mr-1.5" /> Google Drive
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveImportTab('seed');
                    setScannedInvoices([]);
                  }}
                  className={`px-4 py-3 border-b-2 transition-all duration-200 flex items-center ${
                    activeImportTab === 'seed' 
                      ? 'border-teal-500 text-teal-400 bg-gray-900/40' 
                      : 'border-transparent text-gray-500 hover:text-gray-300'
                  }`}
                >
                  <Database className="w-3.5 h-3.5 mr-1.5" /> System Dataset Seeding
                </button>
              </div>
            )}

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* LOADING OR SCANNING STATE */}
              {(importing || scanningFile) ? (
                <div className="space-y-4 text-center py-12">
                  <RefreshCw className="w-12 h-12 animate-spin mx-auto text-indigo-500" />
                  <p className="text-sm font-semibold text-white font-mono">{importStatus}</p>
                  <div className="w-full bg-gray-800 rounded-full h-3 max-w-md mx-auto overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${importProgress || 35}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-gray-500 font-mono uppercase tracking-widest">Processing and structuring data using Gemini AI</p>
                </div>
              ) : (
                <div className="space-y-6">
                  
                  {/* TAB 1: LOCAL HARD DISK (AI SMART SCANNER) */}
                  {activeImportTab === 'local' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                        
                        <div className="md:col-span-2 bg-gray-900/40 p-5 rounded-lg border border-[#2d2f39] flex flex-col justify-between space-y-4">
                          <div className="space-y-2">
                            <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wide font-sans">AI Multi-Format Smart Scanner</h4>
                            <p className="text-gray-400 leading-relaxed text-[11px] font-sans">
                              Drag and drop or select any billing document. Our intelligent document analyzer automatically parses <strong>Excel (.xlsx/.xls)</strong>, <strong>Word (.docx)</strong>, <strong>PDFs</strong>, <strong>JPG/PNG Scans</strong>, or <strong>CSV</strong> spreadsheets to extract correct invoice records.
                            </p>
                            
                            <div className="border-2 border-dashed border-[#2d2f39] hover:border-blue-500 rounded-lg p-6 text-center cursor-pointer transition relative bg-gray-950/40">
                              <input 
                                type="file" 
                                accept=".csv,.xlsx,.xls,.docx,.pdf,.jpg,.jpeg,.png"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) handleSmartScan(file);
                                }}
                                className="absolute inset-0 opacity-0 cursor-pointer"
                              />
                              <Upload className="w-8 h-8 text-blue-500 mx-auto mb-2 animate-bounce" />
                              <p className="text-xs text-gray-300 font-sans font-semibold">
                                Click or drop any billing file here
                              </p>
                              <p className="text-[10px] text-gray-500 font-mono mt-1">
                                Excel, Word, PDF, JPG, PNG, CSV accepted
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Traditional CSV Mapper Side Panel */}
                        <div className="bg-gray-900/20 p-5 rounded-lg border border-[#2d2f39]/60 flex flex-col justify-between space-y-4">
                          <div className="space-y-2">
                            <h4 className="text-[11px] font-bold text-gray-400 uppercase tracking-wide font-sans">Legacy CSV Mapper</h4>
                            <p className="text-gray-500 leading-relaxed text-[10px] font-sans">
                              Use the traditional structural header scanner for clean CSV files.
                            </p>
                            <div className="border border-dashed border-[#2d2f39]/50 p-2.5 rounded text-center relative bg-gray-950/20">
                              <input 
                                type="file" 
                                accept=".csv"
                                onChange={handleFileChange}
                                className="absolute inset-0 opacity-0 cursor-pointer"
                              />
                              <p className="text-[10px] text-gray-400">
                                {csvFile ? `Selected: ${csvFile.name}` : "Upload CSV file"}
                              </p>
                            </div>
                            {parsedRows.length > 0 && (
                              <button
                                onClick={() => {
                                  const mapped = mapCsvToInvoices(parsedRows);
                                  setScannedInvoices(mapped);
                                  triggerAlert("CSV Parsed", `Extracted ${mapped.length} rows using standard mapper. Review below.`);
                                }}
                                className="w-full mt-2 py-1.5 bg-blue-900/60 hover:bg-blue-800 text-white rounded text-[10px] font-sans font-bold transition"
                              >
                                Preview CSV Map ({parsedRows.length} Rows)
                              </button>
                            )}
                          </div>
                          <p className="text-[9px] text-gray-500 font-sans italic">Fast, offline-ready mapping</p>
                        </div>

                      </div>
                    </div>
                  )}

                  {/* TAB 2: GOOGLE DRIVE SYNC (mountec21@gmail.com) */}
                  {activeImportTab === 'drive' && (
                    <div className="space-y-6">
                      {!googleToken ? (
                        <div className="bg-gray-900/40 border border-[#2d2f39] p-8 rounded-lg text-center space-y-4 max-w-lg mx-auto">
                          <FileSpreadsheet className="w-12 h-12 text-indigo-400 mx-auto animate-pulse" />
                          <div className="space-y-1">
                            <h4 className="text-sm font-bold text-white">Google Drive Integration</h4>
                            <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                              Securely connect to your Google Drive to browse, download, and extract invoices directly from shared drives or personal folders.
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={handleConnectGoogleDrive}
                            className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded transition shadow flex items-center mx-auto gap-2"
                          >
                            <FileSpreadsheet className="w-4 h-4" />
                            Connect Google Drive (mountec21@gmail.com)
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {/* Search and connected state */}
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-gray-900/30 border border-[#2d2f39] p-3 rounded-lg">
                            <div className="flex items-center gap-2 text-xs">
                              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                              <span className="font-semibold text-emerald-400">Connected:</span>
                              <span className="text-gray-300 font-mono text-[11px]">Google Drive API</span>
                            </div>
                            <div className="flex items-center gap-2 w-full sm:w-auto">
                              <input 
                                type="text"
                                placeholder="Search Drive files..."
                                value={driveSearch}
                                onChange={(e) => setDriveSearch(e.target.value)}
                                className="bg-gray-950 border border-[#2d2f39] text-white text-xs rounded px-3 py-1.5 focus:outline-none focus:border-indigo-500 w-full sm:w-64 font-sans"
                              />
                              <button
                                type="button"
                                onClick={() => fetchGoogleDriveFiles(googleToken)}
                                className="p-1.5 bg-gray-800 hover:bg-gray-700 rounded text-gray-300 transition"
                                title="Refresh"
                              >
                                <RefreshCw className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Drive Files List */}
                          {loadingDrive ? (
                            <div className="py-12 text-center text-gray-400 flex flex-col justify-center items-center gap-2">
                              <RefreshCw className="w-6 h-6 animate-spin text-indigo-500" />
                              <span className="text-xs font-mono">Loading Google Drive files...</span>
                            </div>
                          ) : driveFiles.length === 0 ? (
                            <div className="py-12 border border-dashed border-[#2d2f39] rounded-lg text-center text-gray-500 text-xs">
                              No files found in Google Drive matching Excel, Google Sheets, PDF, Word, or image formats.
                            </div>
                          ) : (
                            <div className="border border-[#2d2f39] bg-gray-950/20 rounded-lg overflow-hidden max-h-60 overflow-y-auto">
                              <table className="w-full text-left text-[11px]">
                                <thead>
                                  <tr className="bg-gray-900 text-gray-400 border-b border-[#2d2f39]">
                                    <th className="p-2.5">File Name</th>
                                    <th className="p-2.5">Format</th>
                                    <th className="p-2.5">Modified Date</th>
                                    <th className="p-2.5 text-right">Actions</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {filteredDriveFiles.map((file) => (
                                    <tr key={file.id} className="border-b border-[#2d2f39]/40 hover:bg-gray-900/30 transition text-gray-300">
                                      <td className="p-2.5 flex items-center gap-2">
                                        {file.mimeType.includes('spreadsheet') || file.mimeType.includes('excel') || file.mimeType.includes('csv') ? (
                                          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                                        ) : file.mimeType.includes('word') || file.mimeType.includes('document') ? (
                                          <FileText className="w-4 h-4 text-blue-400" />
                                        ) : file.mimeType.includes('pdf') ? (
                                          <FileText className="w-4 h-4 text-red-400" />
                                        ) : file.mimeType.includes('image') ? (
                                          <Image className="w-4 h-4 text-purple-400" />
                                        ) : (
                                          <FileText className="w-4 h-4 text-gray-400" />
                                        )}
                                        <span className="font-medium truncate max-w-[280px]" title={file.name}>{file.name}</span>
                                      </td>
                                      <td className="p-2.5 font-mono text-[9px] text-gray-500">
                                        {file.mimeType.split('.').pop()?.split('/').pop()?.toUpperCase()}
                                      </td>
                                      <td className="p-2.5 text-gray-400 font-mono text-[10px]">
                                        {new Date(file.modifiedTime).toLocaleDateString('en-GB')}
                                      </td>
                                      <td className="p-2.5 text-right">
                                        <button
                                          type="button"
                                          onClick={() => handleSelectDriveFile(file)}
                                          className="px-2.5 py-1 bg-indigo-600/80 hover:bg-indigo-600 text-white font-semibold text-[10px] rounded transition shadow font-sans"
                                        >
                                          Import & AI Scan
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 3: SYSTEM DATASET SEEDING */}
                  {activeImportTab === 'seed' && (
                    <div className="bg-gray-900/40 p-5 rounded-lg border border-[#2d2f39] flex flex-col justify-between space-y-4 text-xs">
                      <div className="space-y-2">
                        <h4 className="text-xs font-bold text-teal-400 uppercase tracking-wide font-sans">Sync Complete Sequence (001 - 0472)</h4>
                        <p className="text-gray-400 leading-relaxed text-[11px] font-sans">
                          Instantly populates the system with the entire sequential dataset of 472 corporate sales invoices from index <strong className="text-gray-200 font-mono">2022-001</strong> up to <strong className="text-gray-200 font-mono">2026-0472</strong>.
                        </p>
                        <ul className="list-disc pl-4 text-gray-500 space-y-1 text-[10px] leading-snug font-sans">
                          <li>Chronological year assignment (2022-2026)</li>
                          <li>Historical GST rates (7%, 8%, 9%) applied correctly</li>
                          <li>Deterministic billing subtotals ($350 - $140,000)</li>
                          <li>Automated Maybank account sync and outstanding logs</li>
                        </ul>
                      </div>
                      <div className="space-y-2 pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            const list = generateDeterministic472Invoices();
                            triggerConfirm(
                              "Generate & Seed Dataset",
                              "Generate and import all 472 chronological invoices? This is the highly recommended default to populate the database cleanly.",
                              () => handleBatchInsert(list, true)
                            );
                          }}
                          className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded transition text-center shadow font-sans"
                        >
                          Generate & Seed 472 Invoices
                        </button>
                        <p className="text-[10px] text-gray-500 text-center italic font-sans">Overwrites existing invoices cleanly</p>
                      </div>
                    </div>
                  )}

                  {/* INTERACTIVE EXTRACTED PREVIEW PANEL */}
                  {scannedInvoices.length > 0 && (
                    <div className="space-y-4 border-t border-[#2d2f39] pt-4 animate-fadeIn">
                      <div className="flex justify-between items-center">
                        <h4 className="text-xs font-bold text-teal-400 uppercase tracking-wider flex items-center">
                          <Check className="w-4 h-4 mr-1 text-teal-400" /> Extracted Invoices Preview ({scannedInvoices.length})
                        </h4>
                        <button 
                          type="button"
                          onClick={() => setScannedInvoices([])}
                          className="text-[10px] text-red-400 hover:underline font-mono"
                        >
                          Discard Preview
                        </button>
                      </div>
                      <div className="max-h-52 overflow-y-auto border border-[#2d2f39] rounded bg-gray-950/40 text-[10px]">
                        <table className="w-full text-left font-mono">
                          <thead>
                            <tr className="bg-gray-900 text-gray-400 border-b border-[#2d2f39]">
                              <th className="p-2">Invoice Ref</th>
                              <th className="p-2">Client</th>
                              <th className="p-2">Date</th>
                              <th className="p-2">Amount</th>
                              <th className="p-2">GST</th>
                              <th className="p-2">Total</th>
                              <th className="p-2">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {scannedInvoices.map((inv, idx) => (
                              <tr key={idx} className="border-b border-[#2d2f39]/40 text-gray-300">
                                <td className="p-2 font-bold text-white">{inv.invoiceRef}</td>
                                <td className="p-2 truncate max-w-[120px]" title={inv.client}>{inv.client}</td>
                                <td className="p-2">{inv.invoiceDate}</td>
                                <td className="p-2">${inv.amount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td className="p-2">${inv.gst.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td className="p-2 text-teal-400">${inv.totalAmount.toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                                <td className="p-2">
                                  <span className={`px-1.5 py-0.5 rounded-full text-[8px] font-bold ${
                                    inv.status === 'Paid' ? 'bg-teal-950 text-teal-400 border border-teal-500/20' : 'bg-red-950 text-red-400 border border-red-500/20'
                                  }`}>
                                    {inv.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="flex justify-end gap-3 pt-2 text-[11px]">
                        <button
                          type="button"
                          onClick={() => {
                            triggerConfirm(
                              "Append Extracted Invoices",
                              `Do you want to append these ${scannedInvoices.length} extracted invoices to your current records?`,
                              () => {
                                handleBatchInsert(scannedInvoices, false);
                                setScannedInvoices([]);
                              }
                            );
                          }}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded transition shadow font-sans"
                        >
                          Append ({scannedInvoices.length} Records)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            triggerConfirm(
                              "Clear & Overwrite Invoices",
                              `WARNING: This will CLEAR your entire existing sales invoices database and import these ${scannedInvoices.length} extracted records. Are you sure?`,
                              () => {
                                handleBatchInsert(scannedInvoices, true);
                                setScannedInvoices([]);
                              }
                            );
                          }}
                          className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded transition shadow font-sans"
                        >
                          Clear & Overwrite ({scannedInvoices.length} Records)
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* Danger Zone */}
              {!importing && !scanningFile && (
                <div className="bg-red-950/20 border border-red-500/20 rounded-lg p-4 flex justify-between items-center text-xs">
                  <div>
                    <h5 className="font-bold text-red-400 font-sans">Clear Billing Database</h5>
                    <p className="text-[10px] text-gray-500 mt-0.5 font-sans">Wipe all sales invoices from the Firestore collection to start fresh.</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      triggerConfirm(
                        "WARNING: WIPE DATABASE",
                        "Are you sure you want to delete ALL invoices? This action is permanent and cannot be undone!",
                        async () => {
                          setImporting(true);
                          setImportProgress(0);
                          setImportStatus("Clearing all records...");
                          try {
                            const snapshot = await getDocs(collection(db, "salesInvoices"));
                            const batch = writeBatch(db);
                            snapshot.docs.forEach(doc => batch.delete(doc.ref));
                            await batch.commit();
                            triggerAlert("Wiped Successfully", "The sales invoices database is now empty.");
                            setIsImportOpen(false);
                          } catch (err) {
                            console.error(err);
                            triggerAlert("Error", "Failed to clear the sales invoices collection.");
                          } finally {
                            setImporting(false);
                          }
                        }
                      );
                    }}
                    className="px-3 py-1.5 bg-red-900 hover:bg-red-800 text-white font-bold rounded text-[10px] transition font-sans"
                  >
                    Clear Database
                  </button>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex justify-end p-4 bg-gray-950 border-t border-[#2d2f39] space-x-3 text-xs">
              <button 
                type="button"
                disabled={importing || scanningFile}
                onClick={() => {
                  setIsImportOpen(false);
                  setCsvFile(null);
                  setParsedRows([]);
                  setScannedInvoices([]);
                }}
                className="px-4 py-1.5 border border-[#2d2f39] text-gray-400 rounded hover:bg-gray-900 transition disabled:opacity-30 font-sans"
              >
                Close Center
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom iframe-friendly Confirm Dialog */}
      {customConfirm && customConfirm.isOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex justify-center items-center z-50 p-4 animate-fadeIn">
          <div className="bg-[#141416] rounded-lg border border-[#2d2f39] text-white w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-gray-200 uppercase tracking-wider">{customConfirm.title}</h4>
            <p className="text-xs text-gray-400 leading-relaxed font-sans">{customConfirm.message}</p>
            <div className="flex justify-end space-x-3 text-xs pt-2">
              <button
                onClick={() => {
                  if (customConfirm.confirmText === "Clear & Import" && customConfirm.cancelText === "Append") {
                    // Treat Cancel as the alternate "Append" action
                    const mapped = mapCsvToInvoices(parsedRows);
                    handleBatchInsert(mapped, false);
                  }
                  setCustomConfirm(null);
                }}
                className="px-4 py-2 border border-[#2d2f39] text-gray-400 rounded hover:bg-gray-900 transition font-sans"
              >
                {customConfirm.cancelText || "Cancel"}
              </button>
              <button
                onClick={customConfirm.onConfirm}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded transition font-sans"
              >
                {customConfirm.confirmText || "Confirm"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom iframe-friendly Alert Dialog */}
      {customAlert && customAlert.isOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex justify-center items-center z-50 p-4 animate-fadeIn">
          <div className="bg-[#141416] rounded-lg border border-[#2d2f39] text-white w-full max-w-sm shadow-2xl p-6 space-y-4">
            <h4 className="text-sm font-bold text-gray-200 uppercase tracking-wider">{customAlert.title}</h4>
            <p className="text-xs text-gray-400 leading-relaxed font-sans">{customAlert.message}</p>
            <div className="flex justify-end text-xs pt-2">
              <button
                onClick={() => setCustomAlert(null)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded transition font-sans"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
