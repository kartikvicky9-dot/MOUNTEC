import React from 'react';
import SubFlowChart from '../SubFlowChart';

export default function SafetyFlowChart() {
  const steps = [
    { id: '5.1.1', title: '5.1.1 SAFETY RELATED' },
    { id: '5.1.2', title: '5.1.2 QUALITY RELATED' },
    { id: '5.1.3', title: '5.1.3 ENVIRONMENT RELATED' },
    { id: '5.1.4', title: '5.1.4 ALL SQE RELATED FORMS' },
    { id: '5.1.5', title: '5.1.5 AUDITING RELATED' },
  ];
  return <SubFlowChart title="SAFETY FLOW" steps={steps} />;
}
