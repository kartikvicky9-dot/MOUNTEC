import React, { useState } from 'react';
import PlaceholderPanel from '../support/PlaceholderPanel';

export default function SafetyManagementPanel() {
  const safetySections = [
    {
      id: '5.1.1',
      title: '5.1.1 SAFETY RELATED',
      subItems: ['5.1.1.1 DAILY TOOLBOX MEETING', '5.1.1.2 PPE ISSUANCE RECORD']
    },
    { id: '5.1.2', title: '5.1.2 QUALITY RELATED' },
    { id: '5.1.3', title: '5.1.3 ENVIRONMENT RELATED' },
    { id: '5.1.4', title: '5.1.4 ALL SQE RELATED FORMS' },
    { id: '5.1.5', title: '5.1.5 AUDITING RELATED' },
  ];

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white p-6">
      <h2 className="text-2xl font-bold mb-6 border-b border-gray-800 pb-4">5. Safety</h2>
      <div className="space-y-6">
        <h3 className="text-xl font-semibold text-gray-300">5.1 Safety, Quality & Environment Related</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {safetySections.map(section => (
            <div key={section.id} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <h4 className="font-bold text-lg mb-2">{section.title}</h4>
              {section.subItems && (
                <ul className="pl-4 list-disc text-gray-400">
                  {section.subItems.map(item => <li key={item}>{item}</li>)}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
