import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAppContext } from '../../../context/AppContext';
import SignatureCanvas from 'react-signature-canvas';
import Webcam from 'react-webcam';
import { formatDate } from '../../../lib/dateUtils';
import { 
  Save, 
  Printer, 
  Camera, 
  X, 
  Upload, 
  RefreshCcw, 
  Loader2, 
  ShieldAlert, 
  Database, 
  AlertCircle,
  Folder, 
  FolderOpen, 
  ChevronRight, 
  ChevronDown, 
  Search, 
  Trash2, 
  Share2, 
  Download, 
  Info, 
  FileText, 
  Shield, 
  FileSpreadsheet, 
  FileCode, 
  Image, 
  CheckSquare,
  Ruler,
  ZoomIn,
  ZoomOut,
  MessageSquare,
  Mail,
  Plus,
  Check,
  ExternalLink,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Edit2
} from 'lucide-react';
import jsPDF from 'jspdf';
import { toCanvas } from 'html-to-image';
import { getAccessToken, googleSignIn, db } from '../../../lib/firebase';
import { Worker, SpreadsheetData } from '../../../types';
import { collection, query, where, getDocs, addDoc, deleteDoc, doc, orderBy, onSnapshot, updateDoc, writeBatch } from 'firebase/firestore';
import MountecLogo from '../../MountecLogo';

interface PpeItem {
  id: string;
  name: string;
  code?: string;
  isDefault?: boolean;
  createdAt?: number;
}

const DEFAULT_PPE_ITEMS: PpeItem[] = [
  { id: 'helmet', name: 'Safety Helmet', code: 'Helmet', isDefault: true, createdAt: 1 },
  { id: 'shoes', name: 'Safety Shoes', code: 'Shoes', isDefault: true, createdAt: 2 },
  { id: 'harness', name: 'Full Body Harness', code: 'Harness', isDefault: true, createdAt: 3 },
  { id: 'vest', name: 'Reflective Vest', code: 'Vest', isDefault: true, createdAt: 4 },
  { id: 'goggles', name: 'Safety Goggles', code: 'Goggles', isDefault: true, createdAt: 5 },
  { id: 'gloves', name: 'Hand Gloves', code: 'Gloves', isDefault: true, createdAt: 6 },
  { id: 'earmuffs', name: 'Ear Muffs/Plugs', code: 'Earmuffs', isDefault: true, createdAt: 7 },
  { id: 'mask', name: 'Dust/Respirator Mask', code: 'Mask', isDefault: true, createdAt: 8 },
];

const ppeItemDisplayMap: Record<string, string> = {
  helmet: 'Safety Helmet',
  shoes: 'Safety Shoes',
  harness: 'Full Body Harness',
  vest: 'Reflective Vest',
  goggles: 'Safety Goggles',
  gloves: 'Hand Gloves',
  earmuffs: 'Ear Muffs/Plugs',
  mask: 'Dust/Respirator Mask'
};

const defaultChecklist = [
  "Wear personal protective equipment (PPE) before enter into the site.",
  "Usage of Fall protection equipment such as full body harnesses and proper anchorage while working at height.",
  "Ensure all the related work tools are free from defects. Do not use any faulty tools/equipment and if found report immediate to your direct superior.",
  "Pre-operational inspection checklist for usage of Boomlift & Scissor lift.",
  "Ensure all the related Equipment /Tools are with regular maintenance & inspection. Use appropriate Equipment/Tools for the related works.",
  "Effective Teamwork and with Good Communication at all the time.",
  "Comply PTW wheres applicable.",
  "Follow individual site safety rules and regulation at all times.",
  "",
  ""
];

// Document Interfaces
interface CustomDocument {
  id: string;
  category: string;
  title: string;
  description: string;
  fileName: string;
  content: string;
  size: string;
  uploadedBy?: string;
  createdAt?: number;
  interactiveType?: string;
  isPreloaded?: boolean;
}

// Safety preloaded documents
const preloadedDocuments: Record<string, Array<{
  title: string;
  description: string;
  fileName: string;
  size: string;
  interactiveType?: string;
  content: string;
}>> = {
};

export default function SafetyPanel({
  selectedFolderId: propSelectedFolderId,
  setSelectedFolderId: propSetSelectedFolderId,
  globalSearchQuery = '',
  setGlobalSearchQuery,
  setActiveTab
}: {
  selectedFolderId?: string;
  setSelectedFolderId?: (id: string) => void;
  globalSearchQuery?: string;
  setGlobalSearchQuery?: (val: string) => void;
  setActiveTab?: (tab: string) => void;
} = {}) {
  const { 
    workers, 
    setWorkers, 
    rawData, 
    setRawData, 
    updateRawData,
    sheetId, 
    setSheetId, 
    sheetRange, 
    setSheetRange, 
    isViewOnly, 
    isMasterAdmin,
    user,
    selectedEmployeeIdFor23,
    setSelectedEmployeeIdFor23
  } = useAppContext();
  
  // Folder explorer states
  const [localSelectedFolderId, setLocalSelectedFolderId] = useState<string>('5.1.1.1');
  const selectedFolderId = propSelectedFolderId !== undefined ? propSelectedFolderId : localSelectedFolderId;
  const setSelectedFolderId = propSetSelectedFolderId !== undefined ? propSetSelectedFolderId : setLocalSelectedFolderId;

  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    '5.1': true,
    '5.1.1': true
  });

  useEffect(() => {
    if (selectedFolderId) {
      setExpandedFolders(prev => ({
        ...prev,
        '5.1': true,
        '5.1.1': true
      }));
    }
  }, [selectedFolderId]);
  const searchQuery = globalSearchQuery;
  const [customDocs, setCustomDocs] = useState<CustomDocument[]>([]);
  const [docsLoading, setDocsLoading] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<CustomDocument | null>(null);
  const [sharingDoc, setSharingDoc] = useState<CustomDocument | null>(null);

  // Custom Upload Form Fields
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocDesc, setNewDocDesc] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [newDocFileName, setNewDocFileName] = useState('');
  const [newDocSize, setNewDocSize] = useState('120 KB');
  const [isDragging, setIsDragging] = useState(false);

  // PDF Preview states
  const [pdfPage, setPdfPage] = useState(1);
  const [pdfZoom, setPdfZoom] = useState(100);
  const [pdfSearchQuery, setPdfSearchQuery] = useState('');
  const [pdfSigned, setPdfSigned] = useState(false);
  const [pdfSigText, setPdfSigText] = useState('');
  const [pdfSigFont, setPdfSigFont] = useState('cursive');

  // CAD AutoCAD Preview States
  const [cadZoom, setCadZoom] = useState(100);
  const [cadMeasureActive, setCadMeasureActive] = useState(false);
  const [cadPoints, setCadPoints] = useState<Array<{x: number, y: number}>>([]);
  const [cadCoords, setCadCoords] = useState({ x: 0, y: 0 });
  const [cadActiveLayer, setCadActiveLayer] = useState({
    walls: true,
    piping: true,
    annotations: true,
    grid: true
  });

  // Daily Site Toolbox states (previously from original form)
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [driveFileUrl, setDriveFileUrl] = useState<string | null>(null);
  const [driveFileName, setDriveFileName] = useState<string | null>(null);
  const [shareFormat, setShareFormat] = useState<'pdf' | 'excel' | 'word' | 'jpg'>('pdf');

  const [projectTitle, setProjectTitle] = useState('');
  const [company, setCompany] = useState('MOUNTEC PTE LTD');
  const [dateTime, setDateTime] = useState(() => {
    const now = new Date();
    return now.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  });
  const [noOfWorkers, setNoOfWorkers] = useState('');
  const [conductingOfficer, setConductingOfficer] = useState('');
  const [showOfficerDropdown, setShowOfficerDropdown] = useState(false);
  const officerDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (officerDropdownRef.current && !officerDropdownRef.current.contains(event.target as Node)) {
        setShowOfficerDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  const [checklist, setChecklist] = useState<string[]>(defaultChecklist);
  const [attendance, setAttendance] = useState<Array<{ name: string, wpNo: string, employeeId: string }>>([]);
  const [workerSignatures, setWorkerSignatures] = useState<Record<string, string>>({});
  
  const signatureRef = useRef<SignatureCanvas>(null);
  const signatureRefs = useRef<{[key: number]: SignatureCanvas | null}>({});

  // Camera State
  const [showCamera, setShowCamera] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const webcamRef = useRef<Webcam>(null);
  
  // Worker Signature Modal State
  const [activeSignWorkerIndex, setActiveSignWorkerIndex] = useState<number | null>(null);
  const activeWorkerSigPad = useRef<SignatureCanvas>(null);
  
  const formRef = useRef<HTMLDivElement>(null);
  const [isSaving, setIsSaving] = useState(false);

  // DB Workers subscription for local & remote worker particulars
  const [dbWorkers, setDbWorkers] = useState<any[]>([]);

  useEffect(() => {
    const qWorkers = query(collection(db, 'workers'));
    const unsubscribeWorkers = onSnapshot(qWorkers, (snapshot) => {
      const firestoreWorkers = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as any));
      let localWorkers: any[] = [];
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        localWorkers = stored ? JSON.parse(stored) : [];
      } catch (e) {
        // ignore
      }
      
      const firestoreIds = new Set(firestoreWorkers.map((w: any) => w.id));
      const firestoreSpreadsheetIds = new Set(
        firestoreWorkers.map((w: any) => w.spreadsheetId).filter(Boolean) as string[]
      );
      
      const firestoreStintKeys = new Set(
        firestoreWorkers.map((w: any) => {
          const empId = (w.employeeId || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return empId && sNo ? `${empId}-${sNo}` : '';
        }).filter(Boolean)
      );

      const firestoreNameKeys = new Set(
        firestoreWorkers.map((w: any) => {
          const name = (w.nameOfWorker || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return name && sNo ? `${name}-${sNo}` : '';
        }).filter(Boolean)
      );
      
      const uniqueLocal = localWorkers.filter((w: any) => {
        if (firestoreIds.has(w.id)) return false;
        if (w.id && firestoreSpreadsheetIds.has(w.id)) return false;
        
        const empId = (w.employeeId || '').trim().toUpperCase();
        const sNo = (w.sNo || '').trim().toUpperCase();
        if (empId && sNo) {
          const stintKey = `${empId}-${sNo}`;
          if (firestoreStintKeys.has(stintKey)) return false;
        }

        const name = (w.nameOfWorker || '').trim().toUpperCase();
        if (name && sNo) {
          const nameKey = `${name}-${sNo}`;
          if (firestoreNameKeys.has(nameKey)) return false;
        }
        
        return true;
      });
      setDbWorkers([...firestoreWorkers, ...uniqueLocal]);
    }, (error) => {
      console.warn("Firestore error loading workers in SafetyPanel:", error);
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        if (stored) setDbWorkers(JSON.parse(stored));
      } catch (e) { /* ignore */ }
    });
    return () => unsubscribeWorkers();
  }, []);

  const combinedWorkers = React.useMemo(() => {
    const list = [...dbWorkers];
    const existingNames = new Set(list.map(w => (w.nameOfWorker || w.name || '').toLowerCase().trim()));
    const existingEmpIds = new Set(list.map(w => (w.employeeId || '').toLowerCase().trim()).filter(Boolean));
    
    (workers || []).forEach((w: any) => {
      const name = (w.nameOfWorker || w.name || '').toLowerCase().trim();
      const empId = (w.employeeId || '').toLowerCase().trim();
      if (!existingNames.has(name) && (!empId || !existingEmpIds.has(empId))) {
        list.push({
          id: w.id,
          nameOfWorker: w.nameOfWorker || w.name,
          employeeId: w.employeeId || '',
          nationality: w.nationality || '',
          wpsPassStatus: w.wpsPassStatus || w.status || 'LIVE',
          wpsPassNo: w.wpsPassNo || '',
          finNo: w.finNo || ''
        });
      }
    });
    return list;
  }, [dbWorkers, workers]);

  const filteredOfficers = React.useMemo(() => {
    const list = (combinedWorkers || []).filter((w: any) => (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE');
    if (!conductingOfficer) return list;
    const queryStr = conductingOfficer.toLowerCase();
    return list.filter((w: any) => {
      const name = (w.nameOfWorker || w.name || '').toLowerCase();
      const empId = (w.employeeId || '').toLowerCase();
      return name.includes(queryStr) || empId.includes(queryStr);
    });
  }, [combinedWorkers, conductingOfficer]);

  const findMasterRecord = useCallback((name: string, wpNo: string) => {
    if (!combinedWorkers || combinedWorkers.length === 0) return null;
    const cleanName = (name || '').toLowerCase().trim();
    const cleanWp = (wpNo || '').toLowerCase().trim();
    if (!cleanName && !cleanWp) return null;
    
    return combinedWorkers.find((w: any) => {
      const matchWp = cleanWp && (
        (w.wpsPassNo || '').toLowerCase().trim().includes(cleanWp) ||
        (w.employeeId || '').toLowerCase().trim().includes(cleanWp) ||
        (w.finNo || '').toLowerCase().trim().includes(cleanWp)
      );
      const matchName = cleanName && (w.nameOfWorker || w.name || '').toLowerCase().trim().includes(cleanName);
      return matchWp || matchName;
    });
  }, [combinedWorkers]);

  // PPE Issuance Record States
  const [ppeIssuances, setPpeIssuances] = useState<any[]>([]);
  const [ppeLoading, setPpeLoading] = useState(false);
  const [showPpeModal, setShowPpeModal] = useState(false);
  const [ppeSearchQuery, setPpeSearchQuery] = useState('');
  
  // New PPE Form States
  const [ppeWorkerId, setPpeWorkerId] = useState('');
  const [ppeDate, setPpeDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [ppeItems, setPpeItems] = useState<Record<string, boolean>>({});
  const [ppeType, setPpeType] = useState('New');
  const [ppeRemarks, setPpeRemarks] = useState('');
  const [ppeIssuer, setPpeIssuer] = useState('');
  const ppeSignatureRef = useRef<SignatureCanvas>(null);

  // Dynamic PPE Items catalog states
  const [ppeItemList, setPpeItemList] = useState<PpeItem[]>([]);
  const [ppeItemsLoading, setPpeItemsLoading] = useState(false);
  const [isPpeItemModalOpen, setIsPpeItemModalOpen] = useState(false);
  const [editingPpeItem, setEditingPpeItem] = useState<PpeItem | null>(null);
  const [ppeItemName, setPpeItemName] = useState('');
  const [ppeItemCode, setPpeItemCode] = useState('');

  const rotateImage = (base64Src: string, degrees: number): Promise<string> => {
    return new Promise((resolve) => {
      const img = new window.Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(base64Src);
          return;
        }
        
        // Calculate new canvas size based on rotation
        if (degrees % 180 === 90) {
          canvas.width = img.height;
          canvas.height = img.width;
        } else {
          canvas.width = img.width;
          canvas.height = img.height;
        }
        
        // Center of canvas, rotate, and draw
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((degrees * Math.PI) / 180);
        ctx.drawImage(img, -img.width / 2, -img.height / 2);
        
        resolve(canvas.toDataURL('image/jpeg', 0.9));
      };
      img.onerror = () => {
        resolve(base64Src);
      };
      img.src = base64Src;
    });
  };

  const ensureLandscapeAndAdd = (base64Src: string) => {
    const img = new window.Image();
    img.crossOrigin = "anonymous";
    img.onload = async () => {
      if (img.height > img.width) {
        // It's portrait. Rotate 90 degrees clockwise to make it landscape.
        try {
          const rotated = await rotateImage(base64Src, 90);
          setPhotos(prev => [...prev, rotated]);
        } catch (err) {
          console.error("Auto-rotation failed:", err);
          setPhotos(prev => [...prev, base64Src]);
        }
      } else {
        // Already landscape or square
        setPhotos(prev => [...prev, base64Src]);
      }
    };
    img.onerror = () => {
      setPhotos(prev => [...prev, base64Src]);
    };
    img.src = base64Src;
  };

  const getLoggedDateString = (): string => {
    if (!dateTime) {
      return new Date().toISOString().split('T')[0];
    }
    try {
      const timestamp = Date.parse(dateTime);
      if (!isNaN(timestamp)) {
        const d = new Date(timestamp);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
      }
    } catch (e) {
      console.warn("Date.parse failed for:", dateTime, e);
    }
    const monthMap: Record<string, string> = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
    };
    const cleanStr = dateTime.trim().toLowerCase();
    const regexFull = /([a-z]{3})\s+(\d{1,2}),?\s+(\d{4})/;
    const match = cleanStr.match(regexFull);
    if (match) {
      const monthShort = match[1];
      const dayNum = match[2];
      const yearNum = match[3];
      const m = monthMap[monthShort];
      if (m) {
        return `${yearNum}-${m}-${dayNum.padStart(2, '0')}`;
      }
    }
    const regexDmy = /(\d{1,2})[\/\.-](\d{1,2})[\/\.-](\d{4})/;
    const matchDmy = cleanStr.match(regexDmy);
    if (matchDmy) {
      return `${matchDmy[3]}-${matchDmy[2].padStart(2, '0')}-${matchDmy[1].padStart(2, '0')}`;
    }
    const regexYmd = /(\d{4})[\/\.-](\d{1,2})[\/\.-](\d{1,2})/;
    const matchYmd = cleanStr.match(regexYmd);
    if (matchYmd) {
      return `${matchYmd[1]}-${matchYmd[2].padStart(2, '0')}-${matchYmd[3].padStart(2, '0')}`;
    }
    return new Date().toISOString().split('T')[0];
  };

  // Camera Capture
  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        ensureLandscapeAndAdd(imageSrc);
      }
    }
  }, [webcamRef]);

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      Array.from(e.target.files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            ensureLandscapeAndAdd(reader.result as string);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleRotate = async (index: number) => {
    try {
      const rotated = await rotateImage(photos[index], 90);
      setPhotos(prev => {
        const copy = [...prev];
        copy[index] = rotated;
        return copy;
      });
    } catch (err) {
      console.error("Failed to rotate image:", err);
    }
  };

  const movePhoto = (index: number, direction: 'left' | 'right') => {
    setPhotos(prev => {
      const nextIdx = direction === 'left' ? index - 1 : index + 1;
      if (nextIdx < 0 || nextIdx >= prev.length) return prev;
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[nextIdx];
      copy[nextIdx] = temp;
      return copy;
    });
  };

  // Google Sheets Data Parsing (previously in SafetyPanel)
  const normalizeData = (values: string[][]) => {
    const maxCols = Math.max(...values.map(r => r.length));
    return values.map(row => {
        const newRow = [...row];
        while(newRow.length < maxCols) newRow.push('');
        return newRow;
    });
  };

  const updateParsedWorkers = (dataValues: string[][]) => {
    if (!dataValues || dataValues.length === 0) return;
    const headers = dataValues[0];
    const nameIndex = headers.findIndex(h => h.toLowerCase().includes('name'));
    const roleIndex = headers.findIndex(h => h.toLowerCase().includes('role') || h.toLowerCase().includes('position'));
    const statusIndex = headers.findIndex(h => h.toLowerCase().includes('status'));
    
    const parsedWorkers: Worker[] = dataValues.slice(1).map((row, index) => ({
      id: `w-${index}`,
      name: nameIndex >= 0 ? row[nameIndex] : row[0] || 'Unknown',
      role: roleIndex >= 0 ? row[roleIndex] : row[1] || 'Worker',
      status: statusIndex >= 0 ? (row[statusIndex] as any) : 'Active'
    }));
    
    setWorkers(parsedWorkers);
  };

  const fetchSheetData = async () => {
    if (!sheetId) {
      setError('Please enter a Google Sheet ID');
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      let token = await getAccessToken(true);
      
      if (!token) {
        try {
          const result = await googleSignIn(true);
          if (result && result.accessToken) {
            token = result.accessToken;
          } else {
            throw new Error('Authentication succeeded but no access token was returned.');
          }
        } catch (authErr: any) {
          throw new Error(`Not authenticated. Sign in failed: ${authErr?.message || 'Unknown'}`);
        }
      }
      
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetRange}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        const errMsg = errData.error?.message || 'Failed to fetch spreadsheet data';
        if (response.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click SYNC again to sign in and authorize.');
        }
        throw new Error(errMsg);
      }
      
      const data: SpreadsheetData = await response.json();
      
      if (!data.values || data.values.length === 0) {
        throw new Error('No data found in the specified range');
      }
      
      const normalized = normalizeData(data.values);
      await updateRawData(normalized, true);
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const saveSheetData = async (dataToSave?: string[][]) => {
    if (!sheetId) return;
    
    const data = dataToSave || rawData;
    setSaving(true);
    setError('');
    
    try {
      let token = await getAccessToken(true);
      
      if (!token) {
        try {
          const result = await googleSignIn(true);
          if (result && result.accessToken) {
            token = result.accessToken;
          } else {
            throw new Error('Authentication succeeded but no access token was returned.');
          }
        } catch (authErr: any) {
          throw new Error(`Not authenticated. Sign in failed: ${authErr?.message || 'Unknown'}`);
        }
      }
      
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetRange}?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          range: sheetRange,
          majorDimension: 'ROWS',
          values: data
        })
      });
      
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        const errMsg = errData.error?.message || 'Failed to save spreadsheet data';
        if (response.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click SYNC again to sign in and authorize.');
        }
        throw new Error(errMsg);
      }
      
      await updateRawData(data, true);
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    const newData = [...rawData];
    newData[rowIndex] = [...newData[rowIndex]];
    newData[rowIndex][colIndex] = value;
    updateRawData(newData, false); // Update locally instantly, will write to Firestore on blur/save
  };

  const addRow = async () => {
    if (rawData.length === 0) return;
    const newRow = new Array(rawData[0].length).fill('');
    const newData = [...rawData, newRow];
    await updateRawData(newData, true);
    saveSheetData(newData);
  };

  const isInitializedRef = useRef(false);

  useEffect(() => {
    // If we have already initialized from localStorage or synced, don't overwrite
    if (isInitializedRef.current && attendance.length > 0) return;

    // Get active workers from combinedWorkers (which includes both Firestore HR particulars & spreadsheet workers)
    const activeWorkers = (combinedWorkers || []).filter((w: any) => {
      const status = (w.wpsPassStatus || w.status || '').toLowerCase().trim();
      return status !== 'cancelled';
    });

    const extractedWorkers = activeWorkers.map((w: any) => ({
      name: w.nameOfWorker || w.name || '',
      wpNo: w.wpsPassNo || w.employeeId || w.finNo || 'permit/pass no',
      employeeId: w.employeeId || ''
    }));

    const sortedWorkers = [...extractedWorkers].sort((a, b) => {
      const idA = (a.employeeId || '').trim();
      const idB = (b.employeeId || '').trim();
      if (!idA && !idB) return 0;
      if (!idA) return 1;
      if (!idB) return -1;
      return idA.localeCompare(idB, undefined, { numeric: true, sensitivity: 'base' });
    });

    if (sortedWorkers.length > 0) {
      setAttendance(sortedWorkers);
      setNoOfWorkers(sortedWorkers.length.toString());
      isInitializedRef.current = true;
    } else {
      const fallback = Array.from({ length: 10 }).map(() => ({ name: '', wpNo: '', employeeId: '' }));
      setAttendance(fallback);
      setNoOfWorkers('0');
    }
  }, [combinedWorkers]);

  // Self-heal loaded or existing attendance records that are missing wpNo or employeeId but have name matched in combinedWorkers
  useEffect(() => {
    if (!combinedWorkers || combinedWorkers.length === 0 || attendance.length === 0) return;
    
    let changed = false;
    const healedAttendance = attendance.map(worker => {
      const wp = (worker.wpNo || '').trim().toLowerCase();
      const name = (worker.name || '').trim().toLowerCase();
      const empId = (worker.employeeId || '').trim();
      
      if (name) {
        const match = combinedWorkers.find((w: any) => {
          const wName = (w.nameOfWorker || w.name || '').trim().toLowerCase();
          return wName === name;
        });
        
        if (match) {
          const correctWp = match.wpsPassNo || match.employeeId || match.finNo || '';
          const correctEmpId = match.employeeId || '';
          let updated = { ...worker };
          let workerChanged = false;
          
          if (correctWp && (!wp || wp === 'permit/pass no' || wp !== correctWp.toLowerCase())) {
            updated.wpNo = correctWp;
            workerChanged = true;
          }
          if (correctEmpId && empId !== correctEmpId) {
            updated.employeeId = correctEmpId;
            workerChanged = true;
          }
          
          if (workerChanged) {
            changed = true;
            return updated;
          }
        }
      }
      return worker;
    });
    
    if (changed) {
      const sortedHealed = [...healedAttendance].sort((a, b) => {
        const idA = (a.employeeId || '').trim();
        const idB = (b.employeeId || '').trim();
        if (!idA && !idB) return 0;
        if (!idA) return 1;
        if (!idB) return -1;
        return idA.localeCompare(idB, undefined, { numeric: true, sensitivity: 'base' });
      });
      setAttendance(sortedHealed);
    }
  }, [combinedWorkers, attendance]);

  const stateRef = useRef({
    projectTitle,
    company,
    noOfWorkers,
    conductingOfficer,
    checklist,
    attendance,
    workerSignatures
  });

  useEffect(() => {
    stateRef.current = { projectTitle, company, noOfWorkers, conductingOfficer, checklist, attendance, workerSignatures };
  }, [projectTitle, company, noOfWorkers, conductingOfficer, checklist, attendance, workerSignatures]);

  useEffect(() => {
    const saved = localStorage.getItem('mountec_safety_autosave');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.projectTitle) setProjectTitle(parsed.projectTitle);
        if (parsed.company) setCompany(parsed.company);
        if (parsed.conductingOfficer) setConductingOfficer(parsed.conductingOfficer);
        if (parsed.checklist) setChecklist(parsed.checklist);
        if (parsed.workerSignatures) setWorkerSignatures(parsed.workerSignatures);
        if (parsed.attendance && parsed.attendance.length > 0) {
          const restored = parsed.attendance.map((w: any) => ({
            name: w.name || '',
            wpNo: w.wpNo || '',
            employeeId: w.employeeId || ''
          }));
          const sortedRestored = [...restored].sort((a, b) => {
            const idA = (a.employeeId || '').trim();
            const idB = (b.employeeId || '').trim();
            if (!idA && !idB) return 0;
            if (!idA) return 1;
            if (!idB) return -1;
            return idA.localeCompare(idB, undefined, { numeric: true, sensitivity: 'base' });
          });
          setAttendance(sortedRestored);
          setNoOfWorkers(sortedRestored.length.toString());
          isInitializedRef.current = true;
        }
      } catch (e) {
        console.error("Failed to parse autosave", e);
      }
    }

    const interval = setInterval(() => {
      localStorage.setItem('mountec_safety_autosave', JSON.stringify(stateRef.current));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const syncFromMasterList = () => {
    const activeWorkers = (combinedWorkers || []).filter((w: any) => {
      const status = (w.wpsPassStatus || w.status || '').toLowerCase().trim();
      return status !== 'cancelled';
    });

    const extractedWorkers = activeWorkers.map((w: any) => ({
      name: w.nameOfWorker || w.name || '',
      wpNo: w.wpsPassNo || w.employeeId || w.finNo || '',
      employeeId: w.employeeId || ''
    }));

    const sortedWorkers = [...extractedWorkers].sort((a, b) => {
      const idA = (a.employeeId || '').trim();
      const idB = (b.employeeId || '').trim();
      if (!idA && !idB) return 0;
      if (!idA) return 1;
      if (!idB) return -1;
      return idA.localeCompare(idB, undefined, { numeric: true, sensitivity: 'base' });
    });

    if (sortedWorkers.length > 0) {
      setAttendance(sortedWorkers);
      setNoOfWorkers(sortedWorkers.length.toString());
      isInitializedRef.current = true;
      alert(`Attendee list synchronized with master database! (${sortedWorkers.length} active workers loaded in Employee ID ascending order)`);
    } else {
      alert("No active workers found in master database to sync.");
    }
  };

  const handleChecklistChange = (index: number, value: string) => {
    const newChecklist = [...checklist];
    newChecklist[index] = value;
    setChecklist(newChecklist);
  };

  const handleAttendanceChange = (index: number, field: 'name' | 'wpNo' | 'employeeId', value: string) => {
    const newAttendance = [...attendance];
    newAttendance[index] = { ...newAttendance[index], [field]: value };
    setAttendance(newAttendance);
  };

  const getShareText = () => {
    let text = `📋 *MOUNTEC PTE LTD - DAILY SITE TOOLBOX MEETING RECORD*\n\n`;
    text += `🏢 *Company:* ${company || 'MOUNTEC PTE LTD'}\n`;
    text += `🏗️ *Project Title:* ${projectTitle || 'N/A'}\n`;
    text += `📅 *Date/Time:* ${dateTime || 'N/A'}\n`;
    text += `👤 *Conducting Officer:* ${conductingOfficer || 'N/A'}\n`;
    text += `👷 *No. of Workers Attended:* ${noOfWorkers || attendance.length || '0'}\n\n`;
    
    if (checklist && checklist.length > 0) {
      const activeChecklist = checklist.filter(item => item.trim() !== '');
      if (activeChecklist.length > 0) {
        text += `✅ *Core Safety Briefings:* \n`;
        activeChecklist.forEach((item, idx) => {
          text += `  ${idx + 1}. ${item}\n`;
        });
        text += `\n`;
      }
    }
    
    text += `📎 *Selected Format for Sharing:* ${shareFormat.toUpperCase()}\n`;
    text += `(Clicking WhatsApp/Email compiles and downloads your ${shareFormat.toUpperCase()} file to your device, ready to be attached!)\n\n`;
    
    if (driveFileUrl) {
      text += `📂 *Google Drive Backup PDF:* ${driveFileUrl}\n`;
    }
    return text;
  };

  const getEmailHref = () => {
    const subject = encodeURIComponent(`Daily Site Toolbox Meeting Record - ${projectTitle || 'Mountec'}`);
    const body = encodeURIComponent(getShareText());
    return `mailto:?subject=${subject}&body=${body}`;
  };

  const generatePdf = async (): Promise<jsPDF | null> => {
    if (!formRef.current) return null;
    try {
      const printHiddenElements = formRef.current.querySelectorAll('.print\\:hidden');
      printHiddenElements.forEach((el: any) => el.style.display = 'none');
      
      const targetEl = formRef.current;
      
      const originalStyles = {
        overflow: targetEl.style.overflow,
        height: targetEl.style.height,
        maxHeight: targetEl.style.maxHeight,
        width: targetEl.style.width,
        maxWidth: targetEl.style.maxWidth,
        padding: targetEl.style.padding
      };

      // Force fixed desktop layout styles during capture to prevent wrapping/line-breaks/cutoffs
      targetEl.style.overflow = 'visible';
      targetEl.style.height = 'auto';
      targetEl.style.maxHeight = 'none';
      targetEl.style.width = '800px';
      targetEl.style.maxWidth = '800px';
      targetEl.style.padding = '40px';

      const overflowParents: {el: HTMLElement, original: string}[] = [];
      let parent = targetEl.parentElement;
      while (parent && parent !== document.body) {
        const style = window.getComputedStyle(parent);
        if (style.overflow === 'auto' || style.overflow === 'hidden' || style.overflow === 'scroll' || style.overflowY === 'auto' || style.overflowY === 'hidden' || style.overflowY === 'scroll') {
          overflowParents.push({ el: parent, original: parent.style.overflow });
          parent.style.overflow = 'visible';
        }
        parent = parent.parentElement;
      }
      
      // Brief pause to allow browser layout calculation & reflow to the fixed 800px width
      await new Promise(resolve => setTimeout(resolve, 150));
      
      const canvas = await toCanvas(targetEl, { 
        pixelRatio: 3, 
        backgroundColor: '#ffffff',
        width: 800,
        height: targetEl.scrollHeight
      });
      const imgData = canvas.toDataURL("image/png", 1.0);
      
      // Restore styles
      overflowParents.forEach(op => { op.el.style.overflow = op.original; });
      targetEl.style.overflow = originalStyles.overflow;
      targetEl.style.height = originalStyles.height;
      targetEl.style.maxHeight = originalStyles.maxHeight;
      targetEl.style.width = originalStyles.width;
      targetEl.style.maxWidth = originalStyles.maxWidth;
      targetEl.style.padding = originalStyles.padding;
      printHiddenElements.forEach((el: any) => el.style.display = '');
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgProps = pdf.getImageProperties(imgData);
      
      const pdfWidth = pageWidth;
      const pdfHeight = (imgProps.height * pageWidth) / imgProps.width;
      
      let yOffset = 0;
      let isFirstPage = true;
      
      while (yOffset < pdfHeight) {
        if (!isFirstPage) {
          pdf.addPage();
        }
        
        pdf.addImage(imgData, "PNG", 0, -yOffset, pdfWidth, pdfHeight, undefined, 'FAST');
        
        yOffset += pageHeight;
        isFirstPage = false;
      }

      const totalPages = (pdf as any).internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i);
        pdf.setFontSize(8);
        pdf.setTextColor(150, 150, 150);
        pdf.text(`Page ${i} of ${totalPages}`, pageWidth - 15, pageHeight - 10, { align: 'right' });
      }
      
      return pdf;
    } catch (err) {
      console.error("Failed to generate PDF:", err);
      return null;
    }
  };

  const downloadPdfFile = async () => {
    try {
      const pdf = await generatePdf();
      if (!pdf) {
        alert("Could not generate PDF document. Please try again.");
        return;
      }
      const dateStr = getLoggedDateString();
      pdf.save(`Toolbox_Meeting_${dateStr}.pdf`);
    } catch (err) {
      console.error("Failed to download PDF:", err);
      alert("Could not generate PDF document. Please try again.");
    }
  };

  const downloadJpgFile = async () => {
    if (!formRef.current) return;
    try {
      const printHiddenElements = formRef.current.querySelectorAll('.print\\:hidden');
      printHiddenElements.forEach((el: any) => el.style.display = 'none');
      
      const targetEl = formRef.current;
      
      const originalStyles = {
        overflow: targetEl.style.overflow,
        height: targetEl.style.height,
        maxHeight: targetEl.style.maxHeight,
        width: targetEl.style.width,
        maxWidth: targetEl.style.maxWidth,
        padding: targetEl.style.padding
      };

      // Force fixed desktop layout styles during capture to prevent wrapping/line-breaks/cutoffs
      targetEl.style.overflow = 'visible';
      targetEl.style.height = 'auto';
      targetEl.style.maxHeight = 'none';
      targetEl.style.width = '800px';
      targetEl.style.maxWidth = '800px';
      targetEl.style.padding = '40px';

      const overflowParents: {el: HTMLElement, original: string}[] = [];
      let parent = targetEl.parentElement;
      while (parent && parent !== document.body) {
        const style = window.getComputedStyle(parent);
        if (style.overflow === 'auto' || style.overflow === 'hidden' || style.overflow === 'scroll' || style.overflowY === 'auto' || style.overflowY === 'hidden' || style.overflowY === 'scroll') {
          overflowParents.push({ el: parent, original: parent.style.overflow });
          parent.style.overflow = 'visible';
        }
        parent = parent.parentElement;
      }
      
      // Brief pause to allow browser layout calculation & reflow to the fixed 800px width
      await new Promise(resolve => setTimeout(resolve, 150));
      
      const canvas = await toCanvas(targetEl, { 
        pixelRatio: 3, 
        backgroundColor: '#ffffff',
        width: 800,
        height: targetEl.scrollHeight
      });
      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      
      // Restore styles
      overflowParents.forEach(op => { op.el.style.overflow = op.original; });
      targetEl.style.overflow = originalStyles.overflow;
      targetEl.style.height = originalStyles.height;
      targetEl.style.maxHeight = originalStyles.maxHeight;
      targetEl.style.width = originalStyles.width;
      targetEl.style.maxWidth = originalStyles.maxWidth;
      targetEl.style.padding = originalStyles.padding;
      printHiddenElements.forEach((el: any) => el.style.display = '');
      
      const dateStr = getLoggedDateString();
      const a = document.createElement('a');
      a.href = imgData;
      a.download = `Toolbox_Meeting_${dateStr}.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error("Failed to generate JPG:", err);
      alert("Could not generate JPG image. Please try again.");
    }
  };

  const downloadWordFile = () => {
    const dateStr = getLoggedDateString();
    let html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <title>Toolbox Meeting Record</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; }
        h1 { text-align: center; color: #1E3A8A; font-size: 22pt; margin-bottom: 5px; }
        h2 { text-align: center; color: #4B5563; font-size: 14pt; margin-top: 0; margin-bottom: 30px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #D1D5DB; padding: 10px; text-align: left; }
        th { background-color: #F3F4F6; font-weight: bold; }
        .section-title { font-size: 14pt; font-weight: bold; color: #1F2937; border-bottom: 2px solid #E5E7EB; padding-bottom: 5px; margin-top: 30px; margin-bottom: 15px; }
        .bullet-list { margin-left: 20px; }
      </style>
    </head>
    <body>
      <h1>${company || 'MOUNTEC PTE LTD'}</h1>
      <h2>DAILY SITE TOOLBOX MEETING RECORD</h2>
      
      <div class="section-title">MEETING DETAILS</div>
      <table>
        <tr>
          <th style="width: 30%">Project Title</th>
          <td>${projectTitle || 'N/A'}</td>
        </tr>
        <tr>
          <th>Date & Time</th>
          <td>${dateTime || 'N/A'}</td>
        </tr>
        <tr>
          <th>Conducting Officer</th>
          <td>${conductingOfficer || 'N/A'}</td>
        </tr>
        <tr>
          <th>No. of Workers Attended</th>
          <td>${noOfWorkers || attendance.length || '0'}</td>
        </tr>
      </table>
      
      <div class="section-title">CORE SAFETY BRIEFINGS & CHECKLIST</div>
      <ol class="bullet-list">
    `;
    
    checklist.filter(item => item.trim() !== '').forEach(item => {
      html += `<li>${item}</li>`;
    });
    
    html += `
      </ol>
      
      <div class="section-title">WORKER ATTENDANCE & SIGNATURES</div>
      <table>
        <thead>
          <tr>
            <th style="width: 10%">S/N</th>
            <th style="width: 25%">Employee ID</th>
            <th style="width: 35%">Employee Full Name</th>
            <th style="width: 15%">Work Permit No.</th>
            <th style="width: 15%">Signature Status</th>
          </tr>
        </thead>
        <tbody>
    `;
    
    attendance.forEach((worker, idx) => {
      const hasSig = !!workerSignatures[idx];
      html += `
        <tr>
          <td>${idx + 1}</td>
          <td>${worker.employeeId || 'N/A'}</td>
          <td>${worker.name || 'N/A'}</td>
          <td>${worker.wpNo || 'N/A'}</td>
          <td>${hasSig ? 'Signed ✓' : 'Pending'}</td>
        </tr>
      `;
    });
    
    html += `
        </tbody>
      </table>
      
      <div style="margin-top: 50px; text-align: right;">
        <p>Report Generated on: ${new Date().toLocaleString()}</p>
      </div>
    </body>
    </html>`;
    
    const blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Toolbox_Meeting_${dateStr}.doc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadExcelFile = () => {
    const dateStr = getLoggedDateString();
    let html = `<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <style>
        table { border-collapse: collapse; font-family: Arial, sans-serif; }
        th { background-color: #1E3A8A; color: white; font-weight: bold; text-align: left; border: 1px solid #D1D5DB; }
        td { border: 1px solid #D1D5DB; padding: 6px; }
        .header-title { font-size: 16pt; font-weight: bold; color: #1E3A8A; }
        .section-hdr { background-color: #F3F4F6; font-weight: bold; font-size: 11pt; border: 1px solid #D1D5DB; }
      </style>
    </head>
    <body>
      <table>
        <tr>
          <td colspan="5" class="header-title" style="text-align: center; height: 40px; vertical-align: middle;">${company || 'MOUNTEC PTE LTD'}</td>
        </tr>
        <tr>
          <td colspan="5" style="text-align: center; font-weight: bold; font-size: 12pt; height: 25px;">DAILY SITE TOOLBOX MEETING RECORD</td>
        </tr>
        <tr><td colspan="5"></td></tr>
        
        <tr class="section-hdr">
          <td colspan="5">MEETING DETAILS</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Project Title:</td>
          <td colspan="4">${projectTitle || 'N/A'}</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Date & Time:</td>
          <td colspan="4">${dateTime || 'N/A'}</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">Conducting Officer:</td>
          <td colspan="4">${conductingOfficer || 'N/A'}</td>
        </tr>
        <tr>
          <td style="font-weight: bold;">No. of Workers:</td>
          <td colspan="4">${noOfWorkers || attendance.length || '0'}</td>
        </tr>
        <tr><td colspan="5"></td></tr>
        
        <tr class="section-hdr">
          <td colspan="5">CORE SAFETY BRIEFINGS & CHECKLIST</td>
        </tr>
    `;
    
    checklist.filter(item => item.trim() !== '').forEach((item, idx) => {
      html += `
        <tr>
          <td style="text-align: center; font-weight: bold;">${idx + 1}</td>
          <td colspan="4">${item}</td>
        </tr>
      `;
    });
    
    html += `
        <tr><td colspan="5"></td></tr>
        <tr class="section-hdr">
          <td colspan="5">WORKER ATTENDANCE & SIGNATURES</td>
        </tr>
        <tr style="background-color: #E5E7EB; font-weight: bold;">
          <td>S/N</td>
          <td>Employee ID</td>
          <td>Employee Full Name</td>
          <td>Work Permit No.</td>
          <td>Signature Status</td>
        </tr>
    `;
    
    attendance.forEach((worker, idx) => {
      const hasSig = !!workerSignatures[idx];
      html += `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td>${worker.employeeId || 'N/A'}</td>
          <td>${worker.name || 'N/A'}</td>
          <td>${worker.wpNo || 'N/A'}</td>
          <td style="color: ${hasSig ? '#059669' : '#DC2626'}; font-weight: bold;">${hasSig ? 'Signed' : 'Pending'}</td>
        </tr>
      `;
    });
    
    html += `
      </table>
    </body>
    </html>`;
    
    const blob = new Blob(['\ufeff' + html], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Toolbox_Meeting_${dateStr}.xls`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadSelectedFormat = async (silent = false) => {
    if (shareFormat === 'pdf') {
      await downloadPdfFile();
    } else if (shareFormat === 'jpg') {
      await downloadJpgFile();
    } else if (shareFormat === 'word') {
      downloadWordFile();
    } else if (shareFormat === 'excel') {
      downloadExcelFile();
    }
    if (!silent) {
      alert(`Toolbox Meeting Record successfully compiled and downloaded as ${shareFormat.toUpperCase()}!`);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSaveToDrive = async () => {
    try {
      let token = await getAccessToken(true);
      if (!token) {
        try {
          const result = await googleSignIn(true);
          token = result?.accessToken || null;
        } catch (error: any) {
          console.error("Sign in failed:", error);
          alert(`Sign in failed: ${error?.message || 'Unknown error'}. If you see "unauthorized domain", please add "${window.location.hostname}" to your Firebase Authorized Domains in the Firebase Console (Authentication > Settings > Authorized domains). If popup was blocked, please allow popups or open in a new tab.`);
          return;
        }
      }
      
      if (!token) {
        alert('Please log in with Google to save to Drive.');
        return;
      }
      
      if (!formRef.current) return;
      
      setIsSaving(true);
      
      const pdf = await generatePdf();
      if (!pdf) {
        alert("Failed to generate PDF for Google Drive upload.");
        return;
      }
      
      const pdfBlob = pdf.output('blob');
      const dateStr = getLoggedDateString();
      const folderName = `5.1.1.1_DAILY TOOLBOX RECORD`;
      
      const queryStr = encodeURIComponent(`mimeType='application/vnd.google-apps.folder' and name='${folderName}' and trashed=false`);
      const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${queryStr}&fields=files(id)&supportsAllDrives=true&includeItemsFromAllDrives=true`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const searchData = await searchRes.json().catch(() => ({}));
      if (!searchRes.ok) {
        const errMsg = searchData.error?.message || JSON.stringify(searchData);
        if (searchRes.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click BACK UP again to sign in and authorize.');
        }
        throw new Error(`Folder search failed: ${errMsg}`);
      }
      
      let folderId = '';
      if (searchData.files && searchData.files.length > 0) {
        folderId = searchData.files[0].id;
      } else {
        const createRes = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder'
          })
        });
        const createData = await createRes.json().catch(() => ({}));
        if (!createRes.ok) {
          const errMsg = createData.error?.message || JSON.stringify(createData);
          if (createRes.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
            const { clearCachedToken } = await import('../../../lib/firebase');
            clearCachedToken();
            throw new Error('Your Google session has expired or is invalid. Please click BACK UP again to sign in and authorize.');
          }
          throw new Error(`Folder creation failed: ${errMsg}`);
        }
        folderId = createData.id;
      }
      
      const fileName = `Toolbox_Meeting_${dateStr}_${Date.now()}.pdf`;
      const createFileRes = await fetch('https://www.googleapis.com/drive/v3/files?supportsAllDrives=true&fields=id,name,webViewLink', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: fileName,
          parents: [folderId],
          mimeType: 'application/pdf'
        })
      });
      const createFileData = await createFileRes.json().catch(() => ({}));
      if (!createFileRes.ok) {
        const errMsg = createFileData.error?.message || JSON.stringify(createFileData);
        if (createFileRes.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click BACK UP again to sign in and authorize.');
        }
        throw new Error(`File creation failed: ${errMsg}`);
      }
      const fileId = createFileData.id;
      const fileUrl = createFileData.webViewLink || null;
      
      const uploadRes = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media&supportsAllDrives=true`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/pdf'
        },
        body: pdfBlob
      });
      
      if (!uploadRes.ok) {
        const uploadData = await uploadRes.json().catch(() => ({}));
        const errMsg = uploadData.error?.message || JSON.stringify(uploadData);
        if (uploadRes.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click BACK UP again to sign in and authorize.');
        }
        throw new Error(`Media upload failed: ${errMsg}`);
      }
      
      setDriveFileUrl(fileUrl);
      setDriveFileName(fileName);
      
      alert(`Toolbox meeting signed document successfully compiled as PDF and backed up inside Google Drive folder: "${folderName}" as "${fileName}".`);
      
    } catch (err: any) {
      console.error(err);
      alert(`Failed to export PDF file: ${err.message || 'Unknown'}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Fetch Safety Custom Documents from Firebase in real-time
  const fetchCustomDocuments = () => {};

  useEffect(() => {
    setDocsLoading(true);
    const q = query(collection(db, 'hrDocuments'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docsList: CustomDocument[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        if (data.category && data.category.startsWith('5.')) {
          docsList.push({ id: docSnap.id, ...data } as CustomDocument);
        }
      });
      setCustomDocs(docsList);
      setDocsLoading(false);
    }, (err: any) => {
      console.warn('Firestore subscription failed, falling back to local storage:', err);
      try {
        const saved = localStorage.getItem('mountec_safety_documents');
        if (saved) {
          setCustomDocs(JSON.parse(saved));
        }
      } catch (e) {
        // ignore
      }
      setDocsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // PPE Issuance Records subscription
  useEffect(() => {
    setPpeLoading(true);
    const q = query(collection(db, 'ppeIssuanceRecords'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      setPpeIssuances(list);
      setPpeLoading(false);
    }, (err) => {
      console.warn('PPE subscription failed, falling back to local storage:', err);
      try {
        const saved = localStorage.getItem('mountec_ppe_issuances');
        if (saved) {
          setPpeIssuances(JSON.parse(saved));
        }
      } catch (e) {
        // ignore
      }
      setPpeLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Dynamic PPE Items subscription
  useEffect(() => {
    setPpeItemsLoading(true);
    const q = query(collection(db, 'ppeItems'), orderBy('createdAt', 'asc'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const list: PpeItem[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as PpeItem);
      });
      
      if (list.length === 0) {
        // Seed DEFAULT_PPE_ITEMS
        try {
          const batch = writeBatch(db);
          DEFAULT_PPE_ITEMS.forEach((item) => {
            const docRef = doc(collection(db, 'ppeItems'), item.id);
            batch.set(docRef, {
              name: item.name,
              code: item.code || '',
              isDefault: true,
              createdAt: item.createdAt || Date.now()
            });
          });
          await batch.commit();
        } catch (err) {
          console.error("Failed to seed default PPE items:", err);
          setPpeItemList(DEFAULT_PPE_ITEMS);
        }
      } else {
        // Sort to ensure default items and older items are at the top
        list.sort((a, b) => {
          const ca = a.createdAt || 0;
          const cb = b.createdAt || 0;
          return ca - cb;
        });
        setPpeItemList(list);
      }
      setPpeItemsLoading(false);
    }, (err) => {
      console.warn('Failed to load PPE items from Firestore, falling back:', err);
      try {
        const saved = localStorage.getItem('mountec_custom_ppe_items');
        if (saved) {
          setPpeItemList([...DEFAULT_PPE_ITEMS, ...JSON.parse(saved)]);
        } else {
          setPpeItemList(DEFAULT_PPE_ITEMS);
        }
      } catch (e) {
        setPpeItemList(DEFAULT_PPE_ITEMS);
      }
      setPpeItemsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddPpeIssuance = async () => {
    if (!ppeWorkerId) {
      alert('Please select a worker.');
      return;
    }
    
    const selectedWorker = (combinedWorkers || []).find((w: any) => w.id === ppeWorkerId);
    if (!selectedWorker) {
      alert('Selected worker not found.');
      return;
    }
    
    const activeItems = Object.keys(ppeItems)
      .filter(id => ppeItems[id])
      .map(id => {
        const found = ppeItemList.find(item => item.id === id);
        return found ? found.name : id;
      });
    if (activeItems.length === 0) {
      alert('Please select at least one PPE item.');
      return;
    }
    
    let signatureData = '';
    if (ppeSignatureRef.current && !ppeSignatureRef.current.isEmpty()) {
      signatureData = ppeSignatureRef.current.getTrimmedCanvas().toDataURL('image/png');
    } else {
      alert('Please provide the receiver signature.');
      return;
    }
    
    const newRecord = {
      workerId: ppeWorkerId,
      workerName: selectedWorker.nameOfWorker || selectedWorker.name || 'Unknown Worker',
      workerEmployeeId: selectedWorker.employeeId || '',
      date: ppeDate,
      items: activeItems,
      type: ppeType,
      remarks: ppeRemarks,
      signature: signatureData,
      issuer: ppeIssuer || 'Authorized Safety Officer',
      createdAt: Date.now()
    };
    
    try {
      await addDoc(collection(db, 'ppeIssuanceRecords'), newRecord);
    } catch (err) {
      console.warn('Failed to add to Firestore, saving locally:', err);
      const localRecord = { id: 'local-' + Date.now(), ...newRecord };
      const updated = [localRecord, ...ppeIssuances];
      setPpeIssuances(updated);
      localStorage.setItem('mountec_ppe_issuances', JSON.stringify(updated));
    }
    
    // Reset Form
    setPpeWorkerId('');
    setPpeDate(new Date().toISOString().split('T')[0]);
    setPpeItems({});
    setPpeType('New');
    setPpeRemarks('');
    setPpeIssuer('');
    if (ppeSignatureRef.current) {
      ppeSignatureRef.current.clear();
    }
    setShowPpeModal(false);
  };

  // Dynamic PPE Catalog save/delete handlers
  const handleSavePpeItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ppeItemName.trim()) {
      alert('PPE Name is required.');
      return;
    }

    const itemData = {
      name: ppeItemName.trim(),
      code: ppeItemCode.trim(),
      isDefault: editingPpeItem ? !!editingPpeItem.isDefault : false,
      createdAt: editingPpeItem && editingPpeItem.createdAt ? editingPpeItem.createdAt : Date.now()
    };

    try {
      if (editingPpeItem) {
        const itemRef = doc(db, 'ppeItems', editingPpeItem.id);
        await updateDoc(itemRef, itemData);
      } else {
        await addDoc(collection(db, 'ppeItems'), itemData);
      }
    } catch (err) {
      console.warn('Failed to save PPE item to Firestore, updating locally:', err);
      // Local fallback
      const updatedList = [...ppeItemList];
      if (editingPpeItem) {
        const index = updatedList.findIndex(i => i.id === editingPpeItem.id);
        if (index !== -1) {
          updatedList[index] = { ...editingPpeItem, ...itemData };
        }
      } else {
        const newItem = { id: 'local-ppe-' + Date.now(), ...itemData };
        updatedList.push(newItem);
      }
      setPpeItemList(updatedList);
      
      const customOnly = updatedList.filter(i => !i.isDefault);
      localStorage.setItem('mountec_custom_ppe_items', JSON.stringify(customOnly));
    }

    setIsPpeItemModalOpen(false);
    setEditingPpeItem(null);
    setPpeItemName('');
    setPpeItemCode('');
  };

  const handleDeletePpeItem = async (item: PpeItem) => {
    if (item.isDefault) {
      alert('Default PPE items cannot be deleted.');
      return;
    }

    const confirmDelete = window.confirm(`Are you sure you want to delete "${item.name}"?`);
    if (!confirmDelete) return;

    try {
      const itemRef = doc(db, 'ppeItems', item.id);
      await deleteDoc(itemRef);
    } catch (err) {
      console.warn('Failed to delete PPE item from Firestore, updating locally:', err);
      // Local fallback
      const updatedList = ppeItemList.filter(i => i.id !== item.id);
      setPpeItemList(updatedList);
      const customOnly = updatedList.filter(i => !i.isDefault);
      localStorage.setItem('mountec_custom_ppe_items', JSON.stringify(customOnly));
    }
  };

  const handleDeletePpeIssuance = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this PPE issuance record?')) return;
    try {
      if (id.startsWith('local-')) {
        const updated = ppeIssuances.filter(item => item.id !== id);
        setPpeIssuances(updated);
        localStorage.setItem('mountec_ppe_issuances', JSON.stringify(updated));
      } else {
        await deleteDoc(doc(db, 'ppeIssuanceRecords', id));
      }
    } catch (err) {
      console.error('Failed to delete PPE record:', err);
    }
  };

  const handlePrintPpeSlip = (record: any) => {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Outer border
    pdf.setDrawColor(40, 40, 40);
    pdf.setLineWidth(1);
    pdf.rect(10, 10, 190, 277);

    // Inner lines / header
    pdf.setFillColor(30, 41, 59); // bg-slate-800 color
    pdf.rect(11, 11, 188, 30, 'F');

    pdf.setTextColor(255, 255, 255);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(22);
    pdf.text('MOUNTEC PTE LTD', 15, 22);

    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(9);
    pdf.text('WSH Act Compliance Log - ISO 9001, ISO 14001 & ISO 45001', 15, 28);

    // Title of Doc
    pdf.setTextColor(30, 41, 59);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(16);
    pdf.text('PERSONAL PROTECTIVE EQUIPMENT (PPE) ISSUANCE SLIP', 15, 55);

    pdf.setFontSize(10);
    pdf.setTextColor(100, 100, 100);
    pdf.text(`Reference: PPE-SLIP-${record.id.slice(0, 8).toUpperCase()}`, 15, 62);
    pdf.line(15, 65, 195, 65);

    // Details Grid
    pdf.setTextColor(50, 50, 50);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Worker Name:', 15, 75);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.workerName, 60, 75);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Employee ID:', 15, 83);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.workerEmployeeId || 'N/A', 60, 83);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Date of Issuance:', 15, 91);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.date, 60, 91);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Type of Issuance:', 15, 99);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.type, 60, 99);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Issued Items:', 15, 107);
    pdf.setFont('helvetica', 'normal');
    const itemsStr = record.items.map((i: string) => (ppeItemDisplayMap[i] || i).toUpperCase()).join(', ');
    pdf.text(itemsStr, 60, 107);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Issuer Name / Auth:', 15, 115);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.issuer || 'Authorized Safety Officer', 60, 115);

    pdf.setFont('helvetica', 'bold');
    pdf.text('Remarks / Notes:', 15, 123);
    pdf.setFont('helvetica', 'normal');
    pdf.text(record.remarks || 'Standard item deployment without issues.', 60, 123);

    // Boxed Section for WSH confirmation
    pdf.setFillColor(245, 247, 250);
    pdf.rect(15, 135, 180, 45, 'F');
    pdf.setDrawColor(200, 200, 200);
    pdf.rect(15, 135, 180, 45, 'S');

    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(10);
    pdf.setTextColor(30, 41, 59);
    pdf.text('SAFETY ACKNOWLEDGEMENT & COMPLIANCE AGREEMENT', 20, 142);
    
    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(8.5);
    pdf.setTextColor(80, 80, 80);
    pdf.text('I hereby declare that I have received the Personal Protective Equipment (PPE) specified above in new/excellent condition.', 20, 150);
    pdf.text('I agree to wear, maintain, and inspect this equipment prior to all operations in compliance with Mountec policies', 20, 155);
    pdf.text('& Workplace Safety & Health guidelines. If any of the items are found defective, I will immediately report to supervisors.', 20, 160);
    pdf.text('Failure to comply with safety compliance is subject to Singapore WSH regulatory penalties and direct corporate penalty.', 20, 165);

    // Signatures
    pdf.setTextColor(50, 50, 50);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(10);
    pdf.text('RECEIVER SIGNATURE:', 15, 200);
    pdf.text('ISSUER AUTHENTICATION:', 120, 200);

    if (record.signature) {
      pdf.addImage(record.signature, 'PNG', 15, 205, 50, 25);
    } else {
      pdf.setFont('helvetica', 'italic');
      pdf.text('(Signature Pending)', 15, 210);
    }

    pdf.line(15, 235, 75, 235);
    pdf.line(120, 235, 180, 235);

    pdf.setFont('helvetica', 'normal');
    pdf.setFontSize(8);
    pdf.setTextColor(150, 150, 150);
    pdf.text('CONFIDENTIAL SAFETY RECORDS - MOUNTEC MECHANICAL OPERATIONS', 15, 270);
    pdf.text(`Timestamp: ${new Date(record.createdAt).toLocaleString()}`, 120, 270);

    pdf.save(`PPE_SLIP_${record.workerName.replace(/\s+/g, '_')}_${record.date}.pdf`);
  };

  // Handle document uploads
  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle || !newDocFileName) return;

    const lower = newDocFileName.toLowerCase();
    let finalFileName = newDocFileName;
    const hasValidExtension = lower.endsWith('.pdf') || lower.endsWith('.dwg') || lower.endsWith('.xlsx') || lower.endsWith('.xls') || lower.endsWith('.docx') || lower.endsWith('.doc') || lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg');
    if (!hasValidExtension) {
      finalFileName = `${newDocFileName}.pdf`;
    }

    const lowerFinal = finalFileName.toLowerCase();
    let inferredType: string | undefined = undefined;
    if (lowerFinal.endsWith('.pdf')) inferredType = 'pdf_preview';
    else if (lowerFinal.endsWith('.dwg')) inferredType = 'dwg_preview';
    else if (lowerFinal.endsWith('.xlsx') || lowerFinal.endsWith('.xls')) inferredType = 'xlsx_preview';
    else if (lowerFinal.endsWith('.docx') || lowerFinal.endsWith('.doc')) inferredType = 'docx_preview';
    else if (lowerFinal.endsWith('.png') || lowerFinal.endsWith('.jpg') || lowerFinal.endsWith('.jpeg')) inferredType = 'image_preview';

    const docData = {
      category: selectedFolderId,
      title: newDocTitle,
      description: newDocDesc || 'Uploaded safety resource document',
      content: newDocContent || '',
      fileName: finalFileName,
      uploadedBy: user?.email || 'System User',
      createdAt: Date.now(),
      size: newDocSize || `${(Math.random() * 200 + 45).toFixed(0)} KB`,
      interactiveType: inferredType
    };

    setDocsLoading(true);
    try {
      await addDoc(collection(db, 'hrDocuments'), docData);
      fetchCustomDocuments();
    } catch (err) {
      console.warn('Failed to upload to Firestore, using local storage backup:', err);
      const updatedLocal = [...customDocs, { id: `local-${Date.now()}`, ...docData }];
      setCustomDocs(updatedLocal);
      localStorage.setItem('mountec_safety_documents', JSON.stringify(updatedLocal));
    } finally {
      setDocsLoading(false);
      setShowUploadModal(false);
      setNewDocTitle('');
      setNewDocDesc('');
      setNewDocContent('');
      setNewDocFileName('');
    }
  };

  // Handle Drag & Drop uploading
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      setNewDocFileName(file.name);
      setNewDocTitle(file.name.split('.')[0].replace(/_/g, ' ').toUpperCase());
      setNewDocSize(`${(file.size / 1024).toFixed(0)} KB`);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setNewDocContent(text || '');
      };
      reader.readAsText(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setNewDocFileName(file.name);
      setNewDocTitle(file.name.split('.')[0].replace(/_/g, ' ').toUpperCase());
      setNewDocSize(`${(file.size / 1024).toFixed(0)} KB`);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setNewDocContent(text || '');
      };
      reader.readAsText(file);
    }
  };

  // Document removal
  const handleDeleteDocument = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this custom safety document?')) return;
    setDocsLoading(true);
    try {
      await deleteDoc(doc(db, 'hrDocuments', id));
      fetchCustomDocuments();
    } catch (err) {
      console.warn('Failed to delete in Firestore, removing from local storage state:', err);
      const updatedLocal = customDocs.filter(d => d.id !== id);
      setCustomDocs(updatedLocal);
      localStorage.setItem('mountec_safety_documents', JSON.stringify(updatedLocal));
    } finally {
      setDocsLoading(false);
    }
  };

  // Folder helper transitions
  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [folderId]: !prev[folderId]
    }));
  };

  // Filter current active category items
  const activePreloaded = preloadedDocuments[selectedFolderId] || [];
  const activeCustom = customDocs.filter(d => d.category === selectedFolderId);
  const combinedDocs = [
    ...activePreloaded.map(d => ({ id: `sys-${d.fileName}`, category: selectedFolderId, uploadedBy: 'System Preload', createdAt: 1718000000, ...d, isPreloaded: true })),
    ...activeCustom.map(d => ({ ...d, isPreloaded: false }))
  ].filter(doc => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    doc.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
    doc.fileName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getDocIcon = (category: string) => {
    if (category.startsWith('5.1.1.1')) return <CheckSquare className="w-4 h-4 text-emerald-400" />;
    if (category.startsWith('5.1.1.2')) return <Shield className="w-4 h-4 text-blue-400" />;

    return <FileText className="w-4 h-4 text-gray-400" />;
  };

  const getDocColorClass = (category: string) => {
    if (category.startsWith('5.1.1.1')) return 'border-emerald-500/20 hover:border-emerald-500/50';
    if (category.startsWith('5.1.1.2')) return 'border-blue-500/20 hover:border-blue-500/50';

    return 'border-[#333] hover:border-blue-500/30';
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 min-h-[calc(100vh-10rem)]">
      
      {/* ========================================================= */}
      {/* MAIN WORKSPACE WINDOW                                     */}
      {/* ========================================================= */}
      <div className="flex-1 bg-[#141414] border border-[#222] p-6 rounded-xl shadow-xl overflow-hidden flex flex-col">
        
        {/* VIEW 1: 5.1.1.1 DAILY SITE TOOLBOX MEETING FORM */}
        {selectedFolderId === '5.1.1.1' ? (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#222] pb-4">
              <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 flex items-center">
                <ShieldAlert className="w-5 h-5 mr-2 shrink-0 text-blue-500" />
                DAILY TOOLBOX MEETING SIGN-OFF
              </h2>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={fetchSheetData}
                  disabled={loading}
                  className="flex items-center px-3 py-1.5 bg-[#1C1C1C] hover:bg-[#252525] text-white border border-[#333] text-xs font-semibold rounded uppercase tracking-wider transition-all disabled:opacity-40"
                >
                  <RefreshCcw className={`w-3.5 h-3.5 mr-2 ${loading ? 'animate-spin' : ''}`} />
                  Sync spreadsheet
                </button>
                <button
                  onClick={() => saveSheetData()}
                  disabled={saving || rawData.length === 0}
                  className="flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold rounded uppercase tracking-wider transition-all disabled:opacity-40"
                >
                  {saving ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 mr-2" />
                      Save Database
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Google Sheets Sync Controller panel */}
            <div className="p-4 bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="space-y-1 w-full md:w-auto">
                <p className="text-xs font-bold text-white flex items-center">
                  <Database className="w-3.5 h-3.5 text-blue-500 mr-1.5 shrink-0" />
                  Google Sheet Integration Controller
                </p>
                <p className="text-[10px] text-gray-500 font-medium">Coordinate morning team sign-offs directly with active database rows.</p>
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
                <div className="flex flex-col">
                  <span className="text-[9px] uppercase font-bold text-gray-500 mb-1">Spreadsheet ID Reference</span>
                  <input
                    type="text"
                    value={sheetId || ''}
                    onChange={(e) => setSheetId(e.target.value)}
                    placeholder="Enter spreadsheet ID"
                    className="bg-[#0A0A0A] border border-[#333] text-white rounded px-2.5 py-1.5 text-xs w-48 focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] uppercase font-bold text-gray-500 mb-1">Data Range</span>
                  <input
                    type="text"
                    value={sheetRange || ''}
                    onChange={(e) => setSheetRange(e.target.value)}
                    placeholder="e.g. Sheet1!A1:C50"
                    className="bg-[#0A0A0A] border border-[#333] text-white rounded px-2.5 py-1.5 text-xs w-28 focus:outline-none focus:border-blue-500 font-mono text-center"
                  />
                </div>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-950/20 border border-red-900/50 text-red-400 text-xs rounded-lg flex items-center">
                <AlertCircle className="w-4 h-4 mr-2 text-red-500 shrink-0" />
                {error}
              </div>
            )}

            {/* Daily Toolbox Briefing Paper Sheet Canvas */}
            <div className="bg-neutral-900 border border-neutral-800 p-2 sm:p-6 rounded-xl overflow-x-auto">
              <div ref={formRef} className="bg-white text-black p-10 rounded shadow-2xl mx-auto w-[800px] shrink-0 select-text print-invoice-container">
                
                {/* PDF Header Logo and Metadata block */}
                <div className="flex justify-between items-center border-b-2 border-gray-900 pb-4 mb-6">
                  <div>
                    <h1 className="text-2xl font-black uppercase tracking-tight leading-none text-gray-950">MOUNTEC PTE LTD</h1>
                    <div className="text-left text-[9px] text-gray-400 leading-normal mt-1.5 font-semibold">
                      <p>WSH Act Compliance Log - ISO 9001, ISO 14001 & ISO 45001 Cert</p>
                    </div>
                  </div>
                  <div className="flex items-center shrink-0">
                    <MountecLogo className="w-14 h-14" />
                  </div>
                </div>

                <div className="text-center mb-6">
                  <h2 className="text-lg font-black uppercase tracking-wide border-b border-gray-300 pb-1.5 text-gray-900">DAILY TOOLBOX MEETING RECORD</h2>
                  <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold tracking-widest">Morning Briefing, Hazard Assessment & Signature Sign-off log</p>
                </div>

                {/* Form Inputs Grid */}
                <div className="grid grid-cols-2 gap-4 text-xs mb-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-gray-400">1. Project Title / Location</label>
                    <input 
                      type="text" 
                      value={projectTitle}
                      onChange={e => setProjectTitle(e.target.value)}
                      placeholder="e.g. Block 28 Piping Installation Site"
                      className="w-full bg-transparent border-b border-gray-300 pb-1 font-semibold text-gray-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-gray-400">2. Subcontractor Company</label>
                    <input 
                      type="text" 
                      value={company}
                      onChange={e => setCompany(e.target.value)}
                      placeholder="e.g. MOUNTEC PTE LTD"
                      className="w-full bg-transparent border-b border-gray-300 pb-1 font-semibold text-gray-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-gray-400">3. Date & Time Logged</label>
                    <input 
                      type="text" 
                      value={dateTime}
                      onChange={e => setDateTime(e.target.value)}
                      className="w-full bg-transparent border-b border-gray-300 pb-1 font-semibold text-gray-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div className="space-y-1 relative" ref={officerDropdownRef}>
                    <label className="block text-[10px] uppercase font-bold text-gray-400">4. Briefing Conducting Officer</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        value={conductingOfficer}
                        onChange={e => {
                          setConductingOfficer(e.target.value);
                          setShowOfficerDropdown(true);
                        }}
                        onFocus={() => setShowOfficerDropdown(true)}
                        placeholder="Enter Supervisor/Officer Name"
                        className="w-full bg-transparent border-b border-gray-300 pb-1 font-semibold text-gray-900 focus:outline-none focus:border-blue-600 pr-8"
                      />
                      {conductingOfficer && (
                        <button
                          type="button"
                          onClick={() => {
                            setConductingOfficer('');
                            setShowOfficerDropdown(true);
                          }}
                          className="absolute right-1 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    {showOfficerDropdown && (
                      <div className="absolute z-50 left-0 right-0 mt-1 max-h-56 overflow-y-auto bg-white border border-gray-200 rounded-md shadow-lg divide-y divide-gray-100 text-left">
                        {filteredOfficers.length > 0 ? (
                          filteredOfficers.slice(0, 15).map((w: any) => {
                            const name = w.nameOfWorker || w.name || 'Unknown Worker';
                            const empId = w.employeeId || 'No ID';
                            return (
                              <button
                                key={w.id}
                                type="button"
                                onClick={() => {
                                  setConductingOfficer(name);
                                  setShowOfficerDropdown(false);
                                }}
                                className="w-full text-left px-3 py-2 hover:bg-blue-50 transition-colors flex justify-between items-center"
                              >
                                <span className="font-semibold text-gray-800">{name}</span>
                                <span className="text-[10px] font-mono text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">{empId}</span>
                              </button>
                            );
                          })
                        ) : (
                          <div className="px-3 py-2 text-gray-400 text-[11px] italic">
                            No matching employee found. Type name manually.
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-bold text-gray-400">5. Total Workers Present</label>
                    <input 
                      type="text" 
                      value={noOfWorkers}
                      onChange={e => setNoOfWorkers(e.target.value)}
                      placeholder="0"
                      className="w-full bg-transparent border-b border-gray-300 pb-1 font-semibold text-gray-900 focus:outline-none focus:border-blue-600 font-mono"
                    />
                  </div>
                </div>

                {/* Section A: Checklist items */}
                <div className="mb-6">
                  <h3 className="font-bold text-xs uppercase bg-gray-900 text-white px-3 py-1.5 rounded mb-3 tracking-wider">A. Daily Safety Topic & Briefing items</h3>
                  <p className="text-[10px] text-gray-500 mb-2 italic">Confirm all of the following issues have been highlighted to the worker workforce:</p>
                  
                  <div className="space-y-1 text-xs">
                    {checklist.map((item, idx) => (
                      <div 
                        key={idx} 
                        className={`flex items-center space-x-2 py-1 border-b border-gray-100 ${item.trim() === '' ? 'print:hidden' : ''}`}
                      >
                        <span className="font-mono text-gray-400 text-[10px] w-6 shrink-0">{String(idx + 1).padStart(2, '0')}.</span>
                        <input 
                          type="text" 
                          value={item}
                          onChange={e => handleChecklistChange(idx, e.target.value)}
                          placeholder="[Add custom safety briefing point details here]"
                          className="flex-1 bg-transparent text-gray-800 placeholder-gray-300 focus:outline-none"
                        />
                        {idx >= 8 && (
                          <button
                            type="button"
                            onClick={() => {
                              setChecklist(prev => prev.filter((_, i) => i !== idx));
                            }}
                            className="p-1 hover:bg-red-50 text-red-500 hover:text-red-700 rounded transition-all print:hidden cursor-pointer"
                            title="Remove briefing point"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 flex justify-start print:hidden">
                    <button
                      type="button"
                      onClick={() => setChecklist(prev => [...prev, ''])}
                      className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 border border-gray-300 rounded text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs hover:shadow-sm"
                      title="Add a new custom safety briefing row"
                    >
                      <Plus className="w-3.5 h-3.5 text-blue-600" /> Add Custom Briefing Point
                    </button>
                  </div>
                </div>

                {/* Section B: Worker Attendance & signature pad link */}
                <div className="mb-6">
                  <div className="flex flex-row justify-between items-center mb-3 gap-2">
                    <h3 className="font-bold text-xs uppercase bg-gray-900 text-white px-3 py-1.5 rounded tracking-wider flex-1">B. Worker Attendance & Sign-off list</h3>
                    <button
                      type="button"
                      onClick={syncFromMasterList}
                      className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-[10px] font-bold uppercase tracking-wider transition-colors flex items-center gap-1.5 cursor-pointer print:hidden shadow-sm hover:shadow-md shrink-0"
                      title="Sync attendee names and permit numbers with the HR master workers list"
                    >
                      <RefreshCcw className="w-3 h-3" /> Sync with HR Database
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-500 mb-3 italic">All attendees must digitally sign to confirm compliance with site guidelines.</p>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#1A1A1A] text-[#777] border-b border-[#222] text-[10px] uppercase font-bold tracking-wider">
                          <th className="px-3 py-2 w-10 border-r border-[#222]">S/N</th>
                          <th className="px-3 py-2 w-32 border-r border-[#222]">Employee ID</th>
                          <th className="px-3 py-2 w-48 border-r border-[#222]">Employee Full Name</th>
                          <th className="px-3 py-2 w-32 border-r border-[#222]">WP/ID Number</th>
                          <th className="px-3 py-2 text-right">Attendee Signature Panel</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {attendance.map((worker, idx) => (
                          <tr key={idx} className="hover:bg-gray-50/50">
                            <td className="py-2 font-mono text-gray-400">{idx + 1}</td>
                            <td className="py-1">
                              <input 
                                type="text"
                                value={worker.employeeId || ''}
                                onChange={e => handleAttendanceChange(idx, 'employeeId', e.target.value)}
                                placeholder="EMP ID"
                                className="w-full bg-transparent border-b border-transparent hover:border-gray-200 focus:border-blue-500 focus:outline-none font-semibold text-gray-800"
                              />
                            </td>
                            <td className="py-1">
                              <div className="flex items-center gap-1.5 justify-between pr-2">
                                <input 
                                  type="text"
                                  value={worker.name}
                                  onChange={e => handleAttendanceChange(idx, 'name', e.target.value)}
                                  placeholder="Attendee name"
                                  className="w-full bg-transparent border-b border-transparent hover:border-gray-200 focus:border-blue-500 focus:outline-none font-semibold text-gray-800"
                                />
                                {(() => {
                                  const master = findMasterRecord(worker.name, worker.wpNo);
                                  if (master) {
                                    return (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          if (setSelectedEmployeeIdFor23 && setActiveTab) {
                                            setSelectedEmployeeIdFor23(master.employeeId || master.nameOfWorker || master.name || '');
                                            setActiveTab('hr');
                                          }
                                        }}
                                        title={`Direct autolink to 2.3 Master Record for ${master.nameOfWorker || master.name}`}
                                        className="p-1 hover:bg-blue-50 hover:text-blue-600 rounded transition-all text-gray-400 flex items-center shrink-0 border border-transparent hover:border-blue-100 print:hidden cursor-pointer"
                                      >
                                        <ExternalLink className="w-3.5 h-3.5" />
                                      </button>
                                    );
                                  }
                                  return null;
                                })()}
                              </div>
                            </td>
                            <td className="py-1">
                              <input 
                                type="text"
                                value={worker.wpNo}
                                onChange={e => handleAttendanceChange(idx, 'wpNo', e.target.value)}
                                placeholder="permit/pass no"
                                className="w-full bg-transparent border-b border-transparent hover:border-gray-200 focus:border-blue-500 focus:outline-none font-mono text-gray-600 uppercase"
                              />
                            </td>
                            <td className="py-1 text-right">
                              {workerSignatures[idx] ? (
                                <div className="flex items-center justify-end space-x-2">
                                  <img 
                                    src={workerSignatures[idx]} 
                                    alt="Sign" 
                                    className="h-6 border border-gray-200 rounded bg-gray-50 object-contain max-w-[120px]" 
                                    referrerPolicy="no-referrer"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newSigs = { ...workerSignatures };
                                      delete newSigs[idx];
                                      setWorkerSignatures(newSigs);
                                    }}
                                    className="p-1 text-red-500 hover:text-red-700 font-black print:hidden text-[9px]"
                                  >
                                    Reset
                                  </button>
                                </div>
                              ) : (
                                <div className="flex flex-col items-end gap-1.5 print:hidden">
                                  <button
                                    type="button"
                                    onClick={() => setActiveSignWorkerIndex(idx)}
                                    className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-600 border border-blue-200 rounded text-[9px] font-bold uppercase transition-colors"
                                  >
                                    Draw Sign
                                  </button>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[9px] text-gray-400">OR</span>
                                    <input 
                                      type="text"
                                      placeholder="Type Sign..."
                                      className="px-1.5 py-0.5 border border-gray-200 rounded text-[9px] w-16 text-black focus:outline-none"
                                      onBlur={(e) => {
                                        if (e.target.value.trim()) {
                                          setWorkerSignatures(prev => ({
                                            ...prev,
                                            [idx]: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="150" height="40"><text x="10" y="25" style="font:italic bold 20px cursive;fill:%231d4ed8;">${encodeURIComponent(e.target.value.trim())}</text></svg>`
                                          }));
                                        }
                                      }}
                                    />
                                  </div>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Photographic compliance evidence attachment block */}
                {photos.length > 0 && (
                  <div className="mt-8 border-t border-gray-200 pt-6">
                    <h3 className="font-bold text-xs uppercase bg-gray-900 text-white px-3 py-1.5 rounded mb-3 tracking-wider">C. Photographic compliance attachment</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {photos.map((ph, index) => (
                        <div key={index} className="relative border rounded overflow-hidden shadow-sm bg-gray-50 flex flex-col items-center justify-between group">
                          {/* Image Wrapper */}
                          <div className="flex-1 w-full h-44 flex items-center justify-center p-2 relative overflow-hidden bg-white">
                            <img src={ph} alt="Evidence" className="max-h-full max-w-full object-contain transition-all" referrerPolicy="no-referrer" />
                            
                            {/* Delete button (top-right overlay) */}
                            <button
                              type="button"
                              onClick={() => removePhoto(index)}
                              className="absolute top-2 right-2 p-1.5 bg-red-600/90 hover:bg-red-600 rounded-full text-white transition-colors print:hidden shadow-xs"
                              title="Delete Photo"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Controls Bar */}
                          <div className="w-full bg-gray-100 border-t border-gray-200 p-2 flex items-center justify-between text-gray-600 print:hidden">
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                disabled={index === 0}
                                onClick={() => movePhoto(index, 'left')}
                                className="p-1 bg-white hover:bg-gray-200 border border-gray-300 rounded disabled:opacity-40 text-gray-700 transition-colors"
                                title="Move Left"
                              >
                                <ArrowLeft className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                disabled={index === photos.length - 1}
                                onClick={() => movePhoto(index, 'right')}
                                className="p-1 bg-white hover:bg-gray-200 border border-gray-300 rounded disabled:opacity-40 text-gray-700 transition-colors"
                                title="Move Right"
                              >
                                <ArrowRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            
                            <button
                              type="button"
                              onClick={() => handleRotate(index)}
                              className="flex items-center gap-1 px-2 py-1 bg-blue-600 text-white hover:bg-blue-700 rounded text-[10px] font-bold uppercase transition-colors"
                              title="Rotate 90 degrees clockwise"
                            >
                              <RotateCw className="w-3 h-3" />
                              <span>Rotate</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}


              </div>
            </div>

            {/* Print/Save Toolbox Actions */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-[#1A1A1A] border border-[#222] rounded-xl">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setShowCamera(!showCamera)}
                  className="flex items-center px-4 py-2 bg-[#252525] hover:bg-[#2C2C2C] text-white rounded text-xs font-bold uppercase transition-colors"
                >
                  <Camera className="w-4 h-4 mr-2 text-blue-500" />
                  {showCamera ? 'Hide Camera' : 'Webcam Capture'}
                </button>
                <button
                  type="button"
                  onClick={() => document.getElementById('photo-direct-upload')?.click()}
                  className="flex items-center px-4 py-2 bg-[#252525] hover:bg-[#2C2C2C] text-white rounded text-xs font-bold uppercase transition-colors"
                  title="Upload images from device"
                >
                  <Upload className="w-4 h-4 mr-2 text-emerald-500" />
                  Upload Photo
                </button>
                <input 
                  type="file"
                  id="photo-direct-upload"
                  className="hidden"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="flex items-center px-4 py-2 bg-[#1C1C1C] hover:bg-[#222] border border-[#333] text-gray-300 rounded text-xs font-bold uppercase transition-colors"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Print hardcopy
                </button>
                <button
                  onClick={handleSaveToDrive}
                  disabled={isSaving}
                  className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition-colors disabled:opacity-40"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving to Drive...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save to Google Drive
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Share Toolbox Actions */}
            <div className="space-y-3 p-4 bg-[#1A1A1A] border border-[#222] rounded-xl">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#2A2A2A] pb-3">
                <div className="flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-emerald-500" />
                  <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Share Meeting Record</span>
                </div>
                
                {/* Format selection toggles */}
                <div className="flex flex-wrap items-center gap-1.5 bg-[#121212] p-1 rounded-lg border border-[#333]">
                  <button
                    onClick={() => setShareFormat('pdf')}
                    className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                      shareFormat === 'pdf'
                        ? 'bg-emerald-600 text-white'
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    PDF
                  </button>
                  <button
                    onClick={() => setShareFormat('excel')}
                    className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                      shareFormat === 'excel'
                        ? 'bg-emerald-600 text-white'
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    Excel
                  </button>
                  <button
                    onClick={() => setShareFormat('word')}
                    className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                      shareFormat === 'word'
                        ? 'bg-emerald-600 text-white'
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    Word
                  </button>
                  <button
                    onClick={() => setShareFormat('jpg')}
                    className={`px-2.5 py-1.5 rounded text-[10px] font-bold uppercase transition-colors flex items-center gap-1 ${
                      shareFormat === 'jpg'
                        ? 'bg-emerald-600 text-white'
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <Image className="w-3.5 h-3.5" />
                    JPG
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
                <div className="text-[10px] text-gray-400 max-w-sm">
                  Selecting a format and clicking share will auto-compile & download the <strong className="text-emerald-400 font-bold">{shareFormat.toUpperCase()}</strong> file, ready to be attached!
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleDownloadSelectedFormat()}
                    className="flex items-center px-4 py-2 bg-[#2A2A2A] hover:bg-[#333] border border-[#444] text-gray-200 rounded text-xs font-bold uppercase transition-colors"
                  >
                    <Download className="w-4 h-4 mr-2 text-emerald-400" />
                    Download {shareFormat.toUpperCase()}
                  </button>

                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(getShareText())}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => handleDownloadSelectedFormat(true)}
                    className="flex items-center px-4 py-2 bg-[#25D366] hover:bg-[#20ba5a] text-black rounded text-xs font-bold uppercase transition-colors"
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    WhatsApp
                  </a>
                  
                  <a
                    href={getEmailHref()}
                    onClick={() => handleDownloadSelectedFormat(true)}
                    className="flex items-center px-4 py-2 bg-[#D44638] hover:bg-[#c53e30] text-white rounded text-xs font-bold uppercase transition-colors"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Email
                  </a>

                  {driveFileUrl && (
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-[#141414] border border-green-500/20 text-[10px] text-green-400 font-medium rounded-md">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                      <span>Drive Backup Online</span>
                    </div>
                  )}
                </div>
              </div>
            </div>


            {/* Camera Viewport Modal Panel */}
            {showCamera && (
              <div className="fixed inset-0 z-[100] bg-black flex flex-col">
                <div className="p-4 flex justify-between items-center bg-[#111] border-b border-[#222]">
                  <h4 className="text-sm font-bold text-white uppercase tracking-widest flex items-center">
                    <Camera className="w-5 h-5 mr-3 text-blue-500" />
                    Site Camera Viewport
                  </h4>
                  <div className="flex gap-4 items-center">
                    <span className="text-xs text-gray-400 hidden sm:inline-block">Captured images will be appended to the PDF export.</span>
                    <button
                      onClick={() => setShowCamera(false)}
                      className="p-2 bg-[#222] hover:bg-[#333] rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 relative flex bg-black justify-center items-center overflow-hidden">
                  <Webcam
                    audio={false}
                    ref={webcamRef}
                    screenshotFormat="image/jpeg"
                    videoConstraints={{ facingMode }}
                    className="w-full h-full object-cover sm:object-contain"
                  />
                  
                  <button
                    onClick={() => setFacingMode(prev => prev === 'user' ? 'environment' : 'user')}
                    className="absolute top-4 left-4 p-3 bg-black/50 hover:bg-black/70 text-white rounded-lg shadow-lg transition-colors border border-white/10 flex items-center gap-2 text-xs font-bold uppercase tracking-wider backdrop-blur-md"
                  >
                    <RefreshCcw className="w-5 h-5" />
                    Switch
                  </button>

                  <button
                    onClick={capture}
                    className="absolute bottom-8 left-1/2 -translate-x-1/2 p-5 bg-white text-black rounded-full shadow-[0_0_0_4px_rgba(255,255,255,0.3)] hover:scale-105 transition-transform"
                  >
                    <Camera className="w-8 h-8" />
                  </button>

                  {/* Photos Preview Overlay */}
                  {photos.length > 0 && (
                    <div className="absolute bottom-4 right-4 flex flex-row-reverse gap-2 max-w-[40%] overflow-x-auto p-2 bg-black/50 backdrop-blur-md rounded-lg border border-white/10">
                      {photos.map((photo, i) => (
                        <div key={i} className="relative w-16 h-16 sm:w-20 sm:h-20 shrink-0 rounded border border-white/20 overflow-hidden group">
                          <img src={photo} alt={`Captured ${i}`} className="w-full h-full object-cover" />
                          <button 
                            onClick={() => setPhotos(prev => prev.filter((_, idx) => idx !== i))} 
                            className="absolute top-0 right-0 bg-red-500 hover:bg-red-600 text-white p-1 rounded-bl md:opacity-0 md:group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3 sm:w-4 sm:h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : selectedFolderId === '5.1.1.2' ? (
          /* VIEW 1.5: 5.1.1.2 PERSONAL PROTECTIVE EQUIPMENT (PPE) ISSUANCE RECORD */
          <div className="space-y-6 flex-1 flex flex-col">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#222] pb-4">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 flex items-center">
                  <Shield className="w-5 h-5 mr-2 shrink-0 text-blue-500" />
                  5.1.1.2 PERSONAL PROTECTIVE EQUIPMENT (PPE) ISSUANCE REGISTRY
                </h2>
                <p className="text-xs text-[#777] mt-1">
                  Official log tracking corporate PPE deployments, worker endorsements, and WSH compliance.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setShowPpeModal(true)}
                  className="flex items-center justify-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold rounded uppercase tracking-wider transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Issue PPE Equipment
                </button>
              </div>
            </div>

            {/* Metrics cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-4 rounded-xl">
                <p className="text-[10px] font-bold text-[#666] uppercase tracking-wider">Total Records</p>
                <p className="text-2xl font-bold text-white mt-1">{ppeIssuances.length}</p>
                <p className="text-[10px] text-emerald-500 mt-1 font-semibold flex items-center">
                  <Check className="w-3 h-3 mr-1" />
                  Compliant with WSH
                </p>
              </div>
              <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-4 rounded-xl">
                <p className="text-[10px] font-bold text-[#666] uppercase tracking-wider">New Deployments</p>
                <p className="text-2xl font-bold text-blue-400 mt-1">
                  {ppeIssuances.filter(p => p.type === 'New').length}
                </p>
                <p className="text-[10px] text-[#555] mt-1">Fresh gear issued</p>
              </div>
              <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-4 rounded-xl">
                <p className="text-[10px] font-bold text-[#666] uppercase tracking-wider">Replacements</p>
                <p className="text-2xl font-bold text-amber-500 mt-1">
                  {ppeIssuances.filter(p => p.type && p.type.startsWith('Replacement')).length}
                </p>
                <p className="text-[10px] text-[#555] mt-1">Damaged/expired items</p>
              </div>
              <div className="bg-[#1A1A1A] border border-[#2A2A2A] p-4 rounded-xl">
                <p className="text-[10px] font-bold text-[#666] uppercase tracking-wider">Active Workers Signed</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {new Set(ppeIssuances.map(p => p.workerId)).size}
                </p>
                <p className="text-[10px] text-[#555] mt-1">Personnel covered</p>
              </div>
            </div>

            {/* Search and Registry List */}
            <div className="bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl overflow-hidden flex flex-col flex-1">
              <div className="p-4 border-b border-[#2A2A2A] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:max-w-md">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#555]" />
                  <input
                    type="text"
                    value={ppeSearchQuery}
                    onChange={(e) => setPpeSearchQuery(e.target.value)}
                    placeholder="Search by worker name, employee ID, or item..."
                    className="w-full bg-[#111] border border-[#333] text-white rounded-lg pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-blue-500 placeholder-[#555]"
                  />
                  {ppeSearchQuery && (
                    <button
                      onClick={() => setPpeSearchQuery('')}
                      className="absolute right-3 top-2.5 text-[#555] hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <div className="text-[10px] font-bold text-[#666] uppercase tracking-wider">
                  Showing {
                    ppeIssuances.filter(p => {
                      const queryStr = ppeSearchQuery.toLowerCase();
                      return (p.workerName || '').toLowerCase().includes(queryStr) ||
                             (p.workerEmployeeId || '').toLowerCase().includes(queryStr) ||
                             (p.items || []).join(' ').toLowerCase().includes(queryStr) ||
                             (p.type || '').toLowerCase().includes(queryStr);
                    }).length
                  } records
                </div>
              </div>

              {/* Table / List */}
              {ppeLoading ? (
                <div className="flex flex-col items-center justify-center py-12 flex-1">
                  <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                  <p className="text-xs text-[#666] mt-3 uppercase tracking-widest font-semibold">Loading Safety Records...</p>
                </div>
              ) : ppeIssuances.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 flex-1 text-center p-6">
                  <Shield className="w-12 h-12 text-[#333] mb-3" />
                  <p className="text-sm font-bold text-white uppercase tracking-wider">No PPE Issuance Records Found</p>
                  <p className="text-xs text-[#555] mt-1 max-w-xs">
                    Get started by logging a new safety gear issuance. All slips will be stored securely with worker endorsements.
                  </p>
                  <button
                    onClick={() => setShowPpeModal(true)}
                    className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold rounded uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Issue PPE Gear
                  </button>
                </div>
              ) : (
                <div className="overflow-x-auto flex-1">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-[#2A2A2A] bg-[#1F1F1F]">
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider">Worker Details</th>
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider">Date & Type</th>
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider">Equipment Issued</th>
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider">Receiver Signature</th>
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider">Issuer Auth</th>
                        <th className="p-4 text-[10px] font-bold text-[#666] uppercase tracking-wider text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#2A2A2A]">
                      {ppeIssuances
                        .filter(p => {
                          const queryStr = ppeSearchQuery.toLowerCase();
                          return (p.workerName || '').toLowerCase().includes(queryStr) ||
                                 (p.workerEmployeeId || '').toLowerCase().includes(queryStr) ||
                                 (p.items || []).join(' ').toLowerCase().includes(queryStr) ||
                                 (p.type || '').toLowerCase().includes(queryStr);
                        })
                        .map((record) => (
                          <tr key={record.id} className="hover:bg-[#1C1C1C] transition-colors">
                            <td className="p-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500 text-xs font-bold shrink-0">
                                  {record.workerName.charAt(0).toUpperCase()}
                                </div>
                                <div>
                                  <div className="flex items-center gap-1.5">
                                    <p className="text-xs font-bold text-white">{record.workerName}</p>
                                    {(() => {
                                      const master = findMasterRecord(record.workerName, record.workerEmployeeId);
                                      if (master) {
                                        return (
                                          <button
                                            type="button"
                                            onClick={() => {
                                              if (setSelectedEmployeeIdFor23 && setActiveTab) {
                                                setSelectedEmployeeIdFor23(master.employeeId || master.nameOfWorker || master.name || '');
                                                setActiveTab('hr');
                                              }
                                            }}
                                            title={`Direct autolink to 2.3 Master Record for ${master.nameOfWorker || master.name}`}
                                            className="p-0.5 hover:bg-blue-950 hover:text-blue-400 rounded transition-all text-gray-500 flex items-center shrink-0 border border-transparent hover:border-blue-900 cursor-pointer print:hidden"
                                          >
                                            <ExternalLink className="w-3 h-3" />
                                          </button>
                                        );
                                      }
                                      return null;
                                    })()}
                                  </div>
                                  <p className="text-[10px] text-[#555] font-mono mt-0.5">{record.workerEmployeeId || 'No ID'}</p>
                                </div>
                              </div>
                            </td>
                            <td className="p-4">
                              <p className="text-xs text-white">{record.date}</p>
                              <span className={`inline-block px-1.5 py-0.5 text-[9px] font-bold rounded mt-1 uppercase ${
                                record.type === 'New'
                                  ? 'bg-blue-500/10 text-blue-400'
                                  : record.type && record.type.includes('Damaged')
                                  ? 'bg-rose-500/10 text-rose-400'
                                  : record.type && record.type.includes('Expired')
                                  ? 'bg-amber-500/10 text-amber-400'
                                  : 'bg-gray-500/10 text-gray-400'
                              }`}>
                                {record.type}
                              </span>
                            </td>
                            <td className="p-4 max-w-xs">
                              <div className="flex flex-wrap gap-1">
                                {(record.items || []).map((item: string) => (
                                  <span key={item} className="px-1.5 py-0.5 bg-[#252525] border border-[#333] text-white rounded text-[9px] font-mono capitalize">
                                    {ppeItemDisplayMap[item] || item}
                                  </span>
                                ))}
                              </div>
                              {record.remarks && (
                                <p className="text-[10px] text-[#555] italic mt-1 truncate" title={record.remarks}>
                                  "{record.remarks}"
                                </p>
                              )}
                            </td>
                            <td className="p-4">
                              {record.signature ? (
                                <div className="bg-[#252525] border border-[#333] rounded p-1 inline-block">
                                  <img src={record.signature} alt="Signature" referrerPolicy="no-referrer" className="h-6 w-16 object-contain filter invert opacity-90" />
                                </div>
                              ) : (
                                <span className="text-[10px] text-[#555] italic">None</span>
                              )}
                            </td>
                            <td className="p-4 text-xs text-white/80">
                              <p className="font-medium">{record.issuer || 'Authorized Safety Officer'}</p>
                              <p className="text-[9px] text-[#555] mt-0.5">Timestamp: {new Date(record.createdAt).toLocaleDateString()}</p>
                            </td>
                            <td className="p-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => handlePrintPpeSlip(record)}
                                  className="p-1.5 bg-[#252525] border border-[#333] text-white rounded hover:border-blue-500 hover:text-blue-400 transition-all cursor-pointer"
                                  title="Print PPE Slip (PDF)"
                                >
                                  <Printer className="w-3.5 h-3.5" />
                                </button>
                                {!isViewOnly && (
                                  <button
                                    onClick={() => handleDeletePpeIssuance(record.id)}
                                    className="p-1.5 bg-[#252525] border border-[#333] text-white rounded hover:border-red-500 hover:text-red-400 transition-all cursor-pointer"
                                    title="Delete Record"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        ) : (
          
          /* VIEW 2: SAFETY REGISTRY DOCUMENT WORKSPACE (FOR QUALITY, ENVIRONMENT, ETC.) */
          <div className="space-y-6 flex-1 flex flex-col">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#222] pb-4">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 flex items-center">
                  {getDocIcon(selectedFolderId)}
                  <span className="ml-2">

                  </span>
                </h2>
                <p className="text-[10px] text-gray-500 uppercase mt-1 tracking-wider">
                  Mountec Mechanical System Library Archive
                </p>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setShowUploadModal(true)}
                  className="flex items-center px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold rounded-lg uppercase tracking-wider transition-all shadow-md shrink-0"
                >
                  <Upload className="w-3.5 h-3.5 mr-2" />
                  Upload Resource
                </button>
              </div>
            </div>

            {/* Document Listing Grid */}
            {docsLoading ? (
              <div className="flex-1 flex flex-col items-center justify-center py-20 text-gray-500 space-y-3">
                <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                <p className="text-xs uppercase font-bold tracking-widest">Loading documents from Firestore...</p>
              </div>
            ) : combinedDocs.length === 0 ? (
              <div className="flex-1 border-2 border-dashed border-[#222] rounded-xl flex flex-col items-center justify-center p-12 text-center">
                <FileText className="w-10 h-10 text-gray-600 mb-3" />
                <p className="text-xs font-bold text-white uppercase tracking-wider">No files indexed in this folder</p>
                <p className="text-[11px] text-gray-500 mt-1 max-w-sm">No safety resource documents are currently available under this category. Upload custom safety materials to populate the registry.</p>
                <button
                  onClick={() => setShowUploadModal(true)}
                  className="mt-4 px-4 py-2 bg-[#1A1A1A] hover:bg-[#252525] text-blue-400 hover:text-blue-300 text-[10px] font-bold uppercase tracking-wider border border-[#333] hover:border-blue-500/20 rounded-lg transition-all"
                >
                  Upload First Document
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {combinedDocs.map(docData => (
                  <div
                    key={docData.id}
                    className={`p-5 bg-[#181818] border rounded-xl shadow-md flex flex-col justify-between hover:bg-[#1C1C1C] transition-all cursor-pointer group hover:scale-[1.01] ${getDocColorClass(selectedFolderId)}`}
                    onClick={() => {
                      setSelectedDoc(docData as any);
                      setPdfPage(1);
                      setPdfSigned(false);
                      setCadPoints([]);
                    }}
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-3">
                        <div className="p-2 rounded bg-[#1F1F1F] group-hover:bg-[#252525] transition-colors shrink-0">
                          {getDocIcon(selectedFolderId)}
                        </div>
                        {docData.isPreloaded ? (
                          <span className="text-[8px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 px-1.5 py-0.5 rounded uppercase tracking-wider">Preloaded System</span>
                        ) : (
                          <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
                            <span className="text-[8px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 py-0.5 rounded uppercase tracking-wider">User Upload</span>
                            <button
                              onClick={() => handleDeleteDocument(docData.id)}
                              className="p-1 text-gray-500 hover:text-red-400 transition-colors"
                              title="Delete Resource"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors leading-snug">{docData.title}</h4>
                        <p className="text-[11px] text-gray-500 line-clamp-2 leading-relaxed">{docData.description}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between border-t border-[#222] pt-3 mt-4 text-[9px] text-gray-500 font-mono">
                      <span className="truncate max-w-[120px]">File: {docData.fileName}</span>
                      <span>Size: {docData.size}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* UPLOAD DOCUMENT MODAL DIALOG                              */}
      {/* ========================================================= */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-[#333] p-6 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden relative">
            <button
              onClick={() => {
                setShowUploadModal(false);
                setNewDocTitle('');
                setNewDocDesc('');
                setNewDocContent('');
                setNewDocFileName('');
              }}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-2.5 text-blue-500 border-b border-[#222] pb-3 mb-4">
              <Upload className="w-5 h-5" />
              <h3 className="text-sm font-bold uppercase tracking-widest text-white">Upload Safety Resource File</h3>
            </div>

            <form onSubmit={handleUploadDocument} className="space-y-4 text-xs">
              
              {/* Drag & Drop Canvas */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('file-picker')?.click()}
                className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-500/5' 
                    : 'border-[#2D2D2D] hover:border-gray-500 bg-[#141414] hover:bg-[#161616]'
                }`}
              >
                <input 
                  type="file" 
                  id="file-picker" 
                  className="hidden" 
                  onChange={handleFileSelect}
                  accept=".pdf,.dwg,.xlsx,.xls,.docx,.doc,.png,.jpg,.jpeg"
                />
                <Upload className="w-8 h-8 text-blue-500 mx-auto mb-2.5" />
                {newDocFileName ? (
                  <div className="space-y-1">
                    <p className="font-mono text-xs text-white break-all">{newDocFileName}</p>
                    <p className="text-[10px] text-gray-500">File Selected ({newDocSize})</p>
                  </div>
                ) : (
                  <div>
                    <p className="font-bold text-white">Drag & drop your document file here</p>
                    <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wide">Supports PDF, DWG (CAD), Excel, Word, or images</p>
                    <p className="text-[9px] text-blue-500 mt-2">or browse files from system</p>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Dossier / Document Title</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={e => setNewDocTitle(e.target.value)}
                  placeholder="e.g. BLOCK 28 SITE PIPING STANDARDS"
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Description Abstract</label>
                <input
                  type="text"
                  value={newDocDesc}
                  onChange={e => setNewDocDesc(e.target.value)}
                  placeholder="e.g. Official ISO certified safety policy briefing sheets."
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Document Content (Text/Markdown Preview)</label>
                <textarea
                  value={newDocContent}
                  onChange={e => setNewDocContent(e.target.value)}
                  placeholder="Enter the text content of your document for preview..."
                  rows={4}
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500 resize-none font-mono"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowUploadModal(false);
                    setNewDocTitle('');
                    setNewDocDesc('');
                    setNewDocContent('');
                    setNewDocFileName('');
                  }}
                  className="px-4 py-2 bg-[#1A1A1A] text-[#999] border border-[#333] rounded hover:text-white text-xs font-bold uppercase transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition-colors"
                >
                  Confirm Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 5.1.1.2 PERSONAL PROTECTIVE EQUIPMENT ISSUANCE MODAL      */}
      {/* ========================================================= */}
      {showPpeModal && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#111] border border-[#2A2A2A] rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden relative my-8">
            <button
              onClick={() => {
                setShowPpeModal(false);
                setPpeWorkerId('');
                setPpeDate(new Date().toISOString().split('T')[0]);
                setPpeItems({
                  helmet: false,
                  shoes: false,
                  harness: false,
                  vest: false,
                  goggles: false,
                  gloves: false,
                  earmuffs: false,
                  mask: false,
                });
                setPpeType('New');
                setPpeRemarks('');
                setPpeIssuer('');
                if (ppeSignatureRef.current) {
                  ppeSignatureRef.current.clear();
                }
              }}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-6 border-b border-[#2A2A2A] flex items-center space-x-2.5 text-blue-500">
              <Shield className="w-5 h-5 text-blue-500" />
              <h3 className="text-sm font-bold uppercase tracking-widest text-white">Issue PPE Equipment Slip</h3>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleAddPpeIssuance(); }} className="p-6 space-y-4 text-xs">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Select Worker / Employee</label>
                  <select
                    value={ppeWorkerId}
                    onChange={(e) => setPpeWorkerId(e.target.value)}
                    required
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  >
                    <option value="">-- Select Employee --</option>
                    {combinedWorkers.map((w: any) => {
                      const name = w.nameOfWorker || w.name || 'Unknown Worker';
                      const empId = w.employeeId ? ` (${w.employeeId})` : '';
                      const status = w.wpsPassStatus ? ` - ${w.wpsPassStatus.toUpperCase()}` : '';
                      return (
                        <option key={w.id} value={w.id}>
                          {name}{empId}{status}
                        </option>
                      );
                    })}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Issuance Date</label>
                  <input
                    type="date"
                    required
                    value={ppeDate}
                    onChange={(e) => setPpeDate(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Issuance Type</label>
                  <select
                    value={ppeType}
                    onChange={(e) => setPpeType(e.target.value)}
                    required
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  >
                    <option value="New">New Issue (First Deployment)</option>
                    <option value="Replacement (Damaged)">Replacement (Damaged Gear)</option>
                    <option value="Replacement (Expired)">Replacement (Expired Gear)</option>
                    <option value="Replacement (Lost)">Replacement (Lost Gear)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Authorized Issuer / Safety Officer</label>
                  <input
                    type="text"
                    required
                    value={ppeIssuer}
                    onChange={(e) => setPpeIssuer(e.target.value)}
                    placeholder="Safety Officer Name"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* PPE Items Checkboxes */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider">Select Issued Equipment</label>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingPpeItem(null);
                      setPpeItemName('');
                      setPpeItemCode('');
                      setIsPpeItemModalOpen(true);
                    }}
                    className="flex items-center gap-1 px-2 py-0.5 bg-blue-600 hover:bg-blue-500 text-black text-[9px] font-bold uppercase rounded cursor-pointer transition-colors"
                  >
                    <Plus className="w-2.5 h-2.5" />
                    Add PPE
                  </button>
                </div>

                <div className="max-h-48 overflow-y-auto bg-[#141414] border border-[#222] p-3 rounded-xl custom-scrollbar">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ppeItemList.map((item) => {
                      const isChecked = !!ppeItems[item.id];
                      return (
                        <div key={item.id} className="flex items-center justify-between p-1 hover:bg-[#1A1A1A] rounded transition-colors group">
                          <label className="flex items-center space-x-2 cursor-pointer text-white flex-1 min-w-0">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => setPpeItems(prev => ({ ...prev, [item.id]: e.target.checked }))}
                              className="rounded border-[#333] text-blue-600 focus:ring-blue-500/50 bg-[#1A1A1A]"
                            />
                            <span className="truncate text-xs text-white" title={item.name}>
                              {item.name}
                              {item.code && (
                                <span className="ml-1.5 text-[9px] text-[#555] font-mono">({item.code})</span>
                              )}
                            </span>
                          </label>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {(!item.isDefault || isMasterAdmin) && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingPpeItem(item);
                                  setPpeItemName(item.name);
                                  setPpeItemCode(item.code || '');
                                  setIsPpeItemModalOpen(true);
                                }}
                                className="p-0.5 text-gray-400 hover:text-blue-400 transition cursor-pointer"
                                title="Edit PPE Item"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                            )}
                            {!item.isDefault && (
                              <button
                                type="button"
                                onClick={() => handleDeletePpeItem(item)}
                                className="p-0.5 text-gray-400 hover:text-rose-500 transition cursor-pointer"
                                title="Delete PPE Item"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Remarks / Asset Numbers</label>
                <textarea
                  value={ppeRemarks}
                  onChange={(e) => setPpeRemarks(e.target.value)}
                  placeholder="Specify sizes, unique asset tag numbers, serial numbers, or condition remarks..."
                  rows={2}
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              {/* Signature Pad */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider">Receiver Signature (Touchscreen / Mouse Sign)</label>
                  <button
                    type="button"
                    onClick={() => ppeSignatureRef.current?.clear()}
                    className="text-[9px] text-[#777] hover:text-white uppercase font-bold"
                  >
                    Clear Canvas
                  </button>
                </div>
                <div className="border border-[#333] bg-white rounded-lg overflow-hidden h-28">
                  <SignatureCanvas
                    ref={ppeSignatureRef}
                    penColor="black"
                    canvasProps={{ className: 'w-full h-full cursor-crosshair' }}
                  />
                </div>
              </div>

              {/* Form Controls */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowPpeModal(false);
                    setPpeWorkerId('');
                    setPpeDate(new Date().toISOString().split('T')[0]);
                    setPpeItems({
                      helmet: false,
                      shoes: false,
                      harness: false,
                      vest: false,
                      goggles: false,
                      gloves: false,
                      earmuffs: false,
                      mask: false,
                    });
                    setPpeType('New');
                    setPpeRemarks('');
                    setPpeIssuer('');
                    if (ppeSignatureRef.current) {
                      ppeSignatureRef.current.clear();
                    }
                  }}
                  className="px-4 py-2 bg-[#1A1A1A] text-[#999] border border-[#333] rounded hover:text-white text-xs font-bold uppercase transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition-colors"
                >
                  Issue & Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* CORE SAFETY DOCUMENT WORKSPACE/READER MODAL DIALOG       */}
      {/* ========================================================= */}
      {selectedDoc && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-black rounded-xl w-full max-w-4xl p-8 my-8 shadow-2xl relative print:p-0 print:border-none print:shadow-none print:my-0">
            
            {/* Header info bar - Hidden in Print */}
            <div className="flex items-center justify-between border-b border-gray-200 pb-4 mb-6 print:hidden">
              <div className="flex items-center space-x-3">
                <span className="p-2 rounded bg-blue-50 text-blue-600">
                  {getDocIcon(selectedFolderId)}
                </span>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600">MOUNTEC PTE LTD SAFETY REGISTRY</p>
                  <p className="text-xs text-gray-500 font-medium">Index Reference: Folder {selectedFolderId}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => window.print()}
                  className="flex items-center px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold uppercase rounded transition-colors"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  Print File
                </button>
                <button
                  onClick={() => setSharingDoc(selectedDoc)}
                  className="flex items-center px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5 mr-1.5" />
                  Share File
                </button>
                <button
                  onClick={() => {
                    const blob = new Blob([selectedDoc.content || ''], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = selectedDoc.fileName;
                    link.click();
                  }}
                  className="flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  Download
                </button>
                <button
                  onClick={() => {
                    setSelectedDoc(null);
                  }}
                  className="px-3 py-1.5 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  Close
                </button>
              </div>
            </div>

            {/* DOCUMENT CANVAS CONTAINER */}
            <div className="min-h-[500px] flex flex-col justify-between">
              
              {/* COMPONENT: CAD AUTO-CAD BLUEPRINT PREVIEW (dwg_preview) */}
              {selectedDoc.interactiveType === 'dwg_preview' ? (
                <div className="space-y-4">
                  {/* CAD Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0C0C0C] p-3 rounded-lg border border-[#222] print:hidden">
                    <div className="flex items-center space-x-2 text-xs">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse animate-duration-1000"></span>
                      <span className="text-gray-300 font-bold uppercase text-[10px] tracking-wider font-mono">AUTOCAD MEASURE INTEGRATION PORT</span>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-gray-400">
                      <button 
                        type="button"
                        onClick={() => {
                          setCadMeasureActive(!cadMeasureActive);
                          setCadPoints([]);
                        }}
                        className={`flex items-center px-2.5 py-1 rounded border text-[10px] font-bold uppercase transition-all ${
                          cadMeasureActive 
                            ? 'bg-emerald-950 text-emerald-400 border-emerald-500' 
                            : 'bg-[#141414] text-gray-300 border-[#333] hover:border-gray-500'
                        }`}
                      >
                        <Ruler className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
                        {cadMeasureActive ? 'Measuring...' : 'Measure tool'}
                      </button>

                      <button 
                        type="button"
                        onClick={() => {
                          setCadPoints([]);
                          setCadZoom(100);
                        }}
                        className="px-2.5 py-1 bg-[#141414] text-gray-300 border border-[#333] hover:border-gray-500 rounded text-[10px] font-bold uppercase transition-all"
                      >
                        Reset CAD
                      </button>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-gray-400 font-mono">
                      <span>ZOOM:</span>
                      <button type="button" onClick={() => setCadZoom(z => Math.max(50, z - 10))} className="p-1 hover:text-white">-</button>
                      <span>{cadZoom}%</span>
                      <button type="button" onClick={() => setCadZoom(z => Math.min(200, z + 10))} className="p-1 hover:text-white">+</button>
                    </div>
                  </div>

                  {/* CAD Workspace Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                    {/* Canvas Area */}
                    <div className="lg:col-span-3 bg-black rounded-lg border border-[#222] h-[450px] relative overflow-hidden flex flex-col justify-between select-none">
                      {/* Grid Background Overlay */}
                      <div 
                        onMouseMove={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const x = ((e.clientX - rect.left) * (800 / rect.width)).toFixed(1);
                          const y = ((e.clientY - rect.top) * (400 / rect.height)).toFixed(1);
                          setCadCoords({ x: parseFloat(x), y: parseFloat(y) });
                        }}
                        onClick={(e) => {
                          if (!cadMeasureActive) return;
                          const rect = e.currentTarget.getBoundingClientRect();
                          const x = Math.round((e.clientX - rect.left) * (800 / rect.width));
                          const y = Math.round((e.clientY - rect.top) * (400 / rect.height));
                          
                          if (cadPoints.length >= 2) {
                            setCadPoints([{ x, y }]);
                          } else {
                            setCadPoints(prev => [...prev, { x, y }]);
                          }
                        }}
                        className="absolute inset-0 cursor-crosshair"
                        style={{
                          backgroundImage: cadActiveLayer.grid ? 'radial-gradient(circle, #222 1px, transparent 1px)' : 'none',
                          backgroundSize: '20px 20px',
                        }}
                      >
                        {/* High-tech CAD SVG */}
                        <svg 
                          viewBox="0 0 800 400" 
                          className="w-full h-full"
                          style={{ transform: `scale(${cadZoom / 100})`, transformOrigin: 'center' }}
                        >
                          {/* Layer 1: Structural Concrete Walls (Gray) */}
                          {cadActiveLayer.walls && (
                            <g stroke="#444" strokeWidth="4" fill="none" opacity="0.8">
                              <rect x="50" y="50" width="700" height="300" rx="10" />
                              <line x1="280" y1="50" x2="280" y2="350" strokeDasharray="5,5" strokeWidth="2" />
                              <line x1="520" y1="50" x2="520" y2="350" strokeDasharray="5,5" strokeWidth="2" />
                              <rect x="100" y="100" width="120" height="80" rx="4" />
                              <rect x="580" y="200" width="120" height="100" rx="4" />
                            </g>
                          )}

                          {/* Layer 2: Piping Installations (Vibrant Cyan and Blue) */}
                          {cadActiveLayer.piping && (
                            <g fill="none">
                              {/* Main Feed Pipe */}
                              <path d="M 80,140 L 400,140 L 400,260 L 720,260" stroke="#00D2FF" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                              <circle cx="400" cy="140" r="10" fill="#FFC700" stroke="#000" strokeWidth="2" />
                              <circle cx="400" cy="260" r="10" fill="#FFC700" stroke="#000" strokeWidth="2" />
                              
                              {/* Branch Line 1 */}
                              <path d="M 400,140 L 600,140 L 600,80" stroke="#005CFF" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                              {/* Branch Line 2 */}
                              <path d="M 200,140 L 200,300" stroke="#005CFF" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                            </g>
                          )}

                          {/* Layer 3: Annotations, dimensions, labels */}
                          {cadActiveLayer.annotations && (
                            <g fill="#FFF" fontFamily="monospace" fontSize="10">
                              <text x="390" y="125" fill="#FFC700" fontWeight="bold">JOINT VALVE #04</text>
                              <text x="390" y="290" fill="#FFC700" fontWeight="bold">FLOW PUMP #11</text>
                              <text x="410" y="195" fill="#00D2FF">MAIN DIA DN150</text>
                              <text x="140" y="210" fill="#005CFF">BRANCH LINE DN100</text>
                              
                              {/* Dimension arrows */}
                              <line x1="50" y1="370" x2="750" y2="370" stroke="#FF5C00" strokeWidth="1.5" />
                              <polygon points="50,370 60,366 60,374" fill="#FF5C00" />
                              <polygon points="750,370 740,366 740,374" fill="#FF5C00" />
                              <text x="360" y="382" fill="#FF5C00" fontWeight="bold">7,000 MM (TOTAL WIDTH)</text>
                            </g>
                          )}

                          {/* Measurement vector line feedback */}
                          {cadPoints.map((pt, idx) => (
                            <circle key={idx} cx={pt.x} cy={pt.y} r="5" fill="#FF0055" />
                          ))}

                          {cadPoints.length === 2 && (
                            <g>
                              <line x1={cadPoints[0].x} y1={cadPoints[0].y} x2={cadPoints[1].x} y2={cadPoints[1].y} stroke="#FF0055" strokeWidth="2" strokeDasharray="4,4" />
                              <rect 
                                x={Math.min(cadPoints[0].x, cadPoints[1].x) + Math.abs(cadPoints[0].x - cadPoints[1].x) / 2 - 40} 
                                y={Math.min(cadPoints[0].y, cadPoints[1].y) + Math.abs(cadPoints[0].y - cadPoints[1].y) / 2 - 10} 
                                width="90" 
                                height="18" 
                                rx="3" 
                                fill="#FF0055" 
                              />
                              <text 
                                x={Math.min(cadPoints[0].x, cadPoints[1].x) + Math.abs(cadPoints[0].x - cadPoints[1].x) / 2 - 32} 
                                y={Math.min(cadPoints[0].y, cadPoints[1].y) + Math.abs(cadPoints[0].y - cadPoints[1].y) / 2 + 2} 
                                fill="#FFF" 
                                fontFamily="monospace" 
                                fontSize="9" 
                                fontWeight="bold"
                              >
                                {(Math.sqrt(Math.pow(cadPoints[1].x - cadPoints[0].x, 2) + Math.pow(cadPoints[1].y - cadPoints[0].y, 2)) * 12.5).toFixed(0)} MM
                              </text>
                            </g>
                          )}
                        </svg>
                      </div>

                      {/* CAD Coords Status and Layer controls */}
                      <div className="absolute bottom-3 left-3 bg-black/80 border border-[#333] px-3 py-1.5 rounded text-[9px] font-mono text-gray-400 leading-normal flex items-center space-x-3 select-none">
                        <span>X: {cadCoords.x} MM</span>
                        <span className="w-[1px] h-3 bg-[#333]"></span>
                        <span>Y: {cadCoords.y} MM</span>
                      </div>
                    </div>

                    {/* Cad Control panel sidebar */}
                    <div className="bg-[#0C0C0C] rounded-lg border border-[#222] p-5 space-y-5 print:hidden select-none">
                      <h5 className="font-bold uppercase text-[10px] tracking-wider text-gray-300 font-mono border-b border-[#222] pb-2">Active Layers</h5>
                      
                      <div className="space-y-3 text-[11px] font-medium">
                        <label className="flex items-center space-x-2.5 cursor-pointer text-gray-300 hover:text-white">
                          <input 
                            type="checkbox" 
                            checked={cadActiveLayer.walls} 
                            onChange={e => setCadActiveLayer(prev => ({ ...prev, walls: e.target.checked }))}
                            className="rounded border-[#333] bg-[#141414] text-blue-500 focus:ring-0 focus:ring-offset-0" 
                          />
                          <span>Concrete Walls Layer</span>
                        </label>
                        <label className="flex items-center space-x-2.5 cursor-pointer text-gray-300 hover:text-white">
                          <input 
                            type="checkbox" 
                            checked={cadActiveLayer.piping} 
                            onChange={e => setCadActiveLayer(prev => ({ ...prev, piping: e.target.checked }))}
                            className="rounded border-[#333] bg-[#141414] text-blue-500 focus:ring-0 focus:ring-offset-0" 
                          />
                          <span>Piping & Joints Layer</span>
                        </label>
                        <label className="flex items-center space-x-2.5 cursor-pointer text-gray-300 hover:text-white">
                          <input 
                            type="checkbox" 
                            checked={cadActiveLayer.annotations} 
                            onChange={e => setCadActiveLayer(prev => ({ ...prev, annotations: e.target.checked }))}
                            className="rounded border-[#333] bg-[#141414] text-blue-500 focus:ring-0 focus:ring-offset-0" 
                          />
                          <span>Dimensions & Labels</span>
                        </label>
                        <label className="flex items-center space-x-2.5 cursor-pointer text-gray-300 hover:text-white">
                          <input 
                            type="checkbox" 
                            checked={cadActiveLayer.grid} 
                            onChange={e => setCadActiveLayer(prev => ({ ...prev, grid: e.target.checked }))}
                            className="rounded border-[#333] bg-[#141414] text-blue-500 focus:ring-0 focus:ring-offset-0" 
                          />
                          <span>Snap-to Grid Dot-Mesh</span>
                        </label>
                      </div>

                      <div className="bg-[#141414] p-3.5 rounded-lg border border-[#222] text-[10px] text-gray-400 leading-normal font-mono">
                        <p className="font-bold text-gray-200 mb-1">MEASURING HINTS:</p>
                        <p>1. Tap the "Measure tool" on top bar.</p>
                        <p className="mt-1">2. Click two coordinates on the drawing to calculate absolute dimensional spacing.</p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                
                /* COMPONENT: STANDARD PAPER SHEET / PDF DOCUMENT VIEWER */
                <div className="space-y-4">
                  {/* PDF Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-gray-100 p-3 rounded-lg border border-gray-200 print:hidden">
                    <div className="flex items-center space-x-3 text-xs">
                      <button 
                        type="button"
                        disabled={pdfPage <= 1}
                        onClick={() => setPdfPage(p => Math.max(1, p - 1))}
                        className="px-2 py-1 bg-white hover:bg-gray-50 border rounded shadow-xs text-gray-700 disabled:opacity-40 font-semibold"
                      >
                        Previous
                      </button>
                      <span className="font-medium">Page {pdfPage} of 3</span>
                      <button 
                        type="button"
                        disabled={pdfPage >= 3}
                        onClick={() => setPdfPage(p => Math.min(3, p + 1))}
                        className="px-2 py-1 bg-white hover:bg-gray-50 border rounded shadow-xs text-gray-700 disabled:opacity-40 font-semibold"
                      >
                        Next
                      </button>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-gray-400">
                      <button 
                        type="button"
                        onClick={() => setPdfZoom(z => Math.max(50, z - 25))}
                        className="p-1 text-gray-500 hover:text-gray-900"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <span className="font-mono text-gray-800 font-bold">{pdfZoom}%</span>
                      <button 
                        type="button"
                        onClick={() => setPdfZoom(z => Math.min(200, z + 25))}
                        className="p-1 text-gray-500 hover:text-gray-900"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-2 text-xs w-full sm:w-auto">
                      <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <input 
                        type="text" 
                        value={pdfSearchQuery}
                        onChange={e => setPdfSearchQuery(e.target.value)}
                        placeholder="Search text in document..."
                        className="px-2 py-1 bg-white border border-gray-300 rounded text-xs focus:outline-none focus:border-blue-500 w-full sm:w-40 text-black"
                      />
                    </div>
                  </div>

                  {/* Paper Sheet Rendering Area */}
                  <div className="bg-gray-500 p-8 rounded-lg border border-gray-600 max-h-[600px] overflow-y-auto flex justify-center">
                    <div 
                      style={{ transform: `scale(${pdfZoom / 100})`, transformOrigin: 'top center' }}
                      className="bg-white p-12 w-full max-w-2xl min-h-[750px] shadow-xl relative transition-transform duration-200 select-text text-gray-800 font-sans"
                    >
                      {/* Document Watermark */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
                        <p className="text-6xl font-black rotate-45 uppercase">MOUNTEC APPROVED</p>
                      </div>

                      {/* Header */}
                      <div className="flex justify-between items-center border-b border-gray-300 pb-4 mb-6">
                        <div>
                          <h4 className="text-sm font-black uppercase text-gray-950 tracking-tight">MOUNTEC SAFETY ARCHIVE</h4>
                          <p className="text-[9px] text-blue-600 font-bold uppercase tracking-wider">OFFICIAL SYSTEM DOCUMENTS DOSSIER</p>
                        </div>
                        <div className="text-right font-mono text-[9px] text-gray-400">
                          <p>REF: SF-DOC-{selectedDoc.fileName.toUpperCase().slice(0, 6)}</p>
                          <p>CLASSIFICATION: HIGH</p>
                        </div>
                      </div>

                      {/* Render Page contents */}
                      {pdfPage === 1 && (
                        <div className="space-y-4">
                          <h1 className="text-lg font-bold text-gray-900 uppercase border-b pb-1 tracking-tight">{selectedDoc.title}</h1>
                          <p className="text-xs text-gray-500 font-semibold italic uppercase">Document Abstract & General Profile</p>
                          
                          <div className="text-xs text-gray-700 leading-relaxed space-y-3">
                            <p className="font-semibold text-gray-900 uppercase">1. Safety, Quality and Environmental Compliance Policies</p>
                            <p>This official dossier registers operational standards, regulatory rules, and administrative templates for Mountec mechanical safety workflows. All operations are strictly conducted under the Workplace Safety and Health Act (WSHA) in alignment with Ministry of Manpower guidelines.</p>
                            
                            <p className="font-semibold text-gray-900 uppercase">2. Document Evaluation audits</p>
                            <p>The documentation included herein represents standard templates, corporate guidelines, or uploaded personnel data. These records are subject to quarterly internal quality evaluations by the safety committee headed by Kartik Vicky (MD) and Chen Wei (Safety Executive).</p>
                          </div>

                          <div className="p-4 bg-blue-50 border-l-4 border-blue-600 rounded-r-lg mt-6 text-xs text-gray-700">
                            <p className="font-bold text-blue-900 mb-1">Interactive Highlight Search</p>
                            {pdfSearchQuery ? (
                              <p>Searching for <span className="font-mono bg-yellow-200 px-1 text-black">"{pdfSearchQuery}"</span>... Highlight matches are highlighted on pages when found.</p>
                            ) : (
                              <p>Enter keywords in the toolbar search box above to scan throughout text assets.</p>
                            )}
                          </div>
                        </div>
                      )}

                      {pdfPage === 2 && (
                        <div className="space-y-4">
                          <h2 className="text-md font-bold text-gray-900 uppercase tracking-tight">PAGE 2: DOCUMENT DETAILS & CORE BODY CONTENT</h2>
                          <div className="border-b border-gray-200 pb-2 mb-2 text-xs font-mono text-gray-400">Section 2.1 - Core Details Data Log</div>

                          <div className="text-xs text-gray-700 space-y-4 leading-relaxed bg-gray-50 p-5 rounded-lg border border-gray-100 font-sans">
                            {selectedDoc.content ? (
                              <p className="whitespace-pre-wrap">{selectedDoc.content}</p>
                            ) : (
                              <div className="space-y-2">
                                <p className="font-semibold uppercase text-gray-900">Document Contents Profile</p>
                                <p>Standard document structure preloaded for Mountec. This document contains corporate references and safety procedures.</p>
                                <p className="italic text-gray-500">Ensure any printed hardcopies of this document are properly shredded once they are no longer required for active site inspection logs.</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {pdfPage === 3 && (
                        <div className="space-y-4">
                          <h2 className="text-md font-bold text-gray-900 uppercase tracking-tight">PAGE 3: COMPLIANCE SIGN-OFF & CERTIFICATION MATRIX</h2>
                          <div className="border-b border-gray-200 pb-2 mb-2 text-xs font-mono text-gray-400">Section 3.1 - Approval and Validation</div>

                          <div className="text-xs text-gray-700 leading-relaxed space-y-3">
                            <p>By reviewing this document, Mountec Pte Ltd confirms full alignment with safety practices. All staff are trained regularly to abide by these standards in daily industrial construction activities.</p>
                          </div>

                          {/* Interactive Signature Area */}
                          <div className="mt-8 p-4 bg-gray-50 border border-gray-200 rounded-lg space-y-3 print:border-none print:bg-white">
                            <p className="font-bold text-[10px] text-gray-400 uppercase tracking-wider">OFFICER COMPLIANCE DIGITAL SIGN-OFF</p>
                            
                            {pdfSigned ? (
                              <div className="flex items-center justify-between border border-gray-300 p-4 rounded bg-white">
                                <div className="space-y-1">
                                  <p className="text-[9px] text-gray-400 uppercase font-bold">Authorized Sign-off By</p>
                                  <p className="font-bold text-sm text-blue-700 font-mono italic uppercase tracking-wider">{pdfSigText || user?.displayName || 'Kumar Raj'}</p>
                                  <p className="text-[8px] text-gray-400 font-mono">Date: {formatDate(new Date())} | Timestamp verified securely</p>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setPdfSigned(false)}
                                  className="px-2 py-1 bg-red-100 hover:bg-red-200 text-red-700 text-[10px] font-bold uppercase rounded transition-colors print:hidden"
                                >
                                  Clear
                                </button>
                              </div>
                            ) : (
                              <div className="flex flex-wrap items-center gap-3 print:hidden">
                                <input 
                                  type="text" 
                                  value={pdfSigText}
                                  onChange={e => {
                                    setPdfSigText(e.target.value);
                                    setPdfSigned(true);
                                  }}
                                  placeholder="Initials..."
                                  className="px-2 py-1.5 bg-white border border-gray-300 rounded text-xs focus:outline-none w-20 text-black font-bold uppercase"
                                />
                                <select
                                  value={pdfSigFont}
                                  onChange={e => setPdfSigFont(e.target.value)}
                                  className="px-2 py-1.5 bg-white border border-gray-300 rounded text-xs text-black font-semibold"
                                >
                                  <option value="cursive">Cursive Font</option>
                                  <option value="mono">Technical Mono</option>
                                </select>
                                <button
                                  type="button"
                                  onClick={() => setPdfSigned(!pdfSigned)}
                                  className={`px-4 py-1.5 rounded font-bold uppercase text-[10px] tracking-wider transition-colors ${
                                    pdfSigned 
                                      ? 'bg-rose-600 hover:bg-rose-500 text-white' 
                                      : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                  }`}
                                >
                                  {pdfSigned ? 'Clear Sign' : 'Apply Sign'}
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Footer */}
                      <div className="absolute bottom-6 left-12 right-12 border-t border-gray-200 pt-3 flex justify-between items-center text-[8px] text-gray-400 font-mono">
                        <span>CONFIDENTIAL - FOR INTERNAL SAFETY USE</span>
                        <span>PAGE {pdfPage} OF 3</span>
                        <span>Mountec Singapore Systems</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Print notice */}
              <div className="mt-4 text-center text-xs text-gray-500 italic print:hidden">
                Verify details on screens before sending printed copy to field supervisors.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SHARING DIALOG MODAL                                      */}
      {/* ========================================================= */}
      {sharingDoc && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-[#333] p-6 rounded-2xl shadow-2xl w-full max-w-sm">
            <h3 className="text-white font-bold mb-2">Share Safety File</h3>
            <p className="text-[11px] text-gray-400 mb-4 leading-normal">Generate secure validation shares for supervisor teams in local sites.</p>
            
            <div className="space-y-3">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(`https://mountec-safety-systems.sg/viewer?ref=${sharingDoc.fileName}`);
                  alert('Internal share link successfully copied to clipboard!');
                  setSharingDoc(null);
                }}
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-black font-bold uppercase text-xs rounded transition-colors"
              >
                Copy Supervisor Link
              </button>
              <button
                onClick={() => {
                  alert(`Direct SMS share request successfully dispatched for file "${sharingDoc.title}".`);
                  setSharingDoc(null);
                }}
                className="w-full py-2 bg-[#252525] hover:bg-[#2C2C2C] text-white border border-[#333] font-bold uppercase text-xs rounded transition-colors"
              >
                Dispatched via SMS Alert
              </button>
              <button
                onClick={() => setSharingDoc(null)}
                className="w-full py-2 bg-transparent hover:text-white text-gray-500 font-bold uppercase text-xs rounded transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Worker Signature Modal */}
      {activeSignWorkerIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl overflow-hidden w-full max-w-md shadow-2xl relative">
            <div className="p-4 bg-gray-100 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-black font-bold uppercase text-xs">
                Draw Signature - {attendance[activeSignWorkerIndex]?.name || `Worker ${activeSignWorkerIndex + 1}`}
              </h3>
              <button 
                onClick={() => setActiveSignWorkerIndex(null)}
                className="p-1 text-gray-500 hover:text-black transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="border-2 border-dashed border-gray-300 rounded bg-gray-50 h-48 relative overflow-hidden mb-4">
                <SignatureCanvas
                  ref={activeWorkerSigPad}
                  canvasProps={{ className: "w-full h-full cursor-crosshair" }}
                />
              </div>
              
              <div className="flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => activeWorkerSigPad.current?.clear()}
                  className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-bold text-xs uppercase transition-colors"
                >
                  Clear Pad
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveSignWorkerIndex(null)}
                    className="px-4 py-2 bg-transparent hover:bg-gray-100 text-gray-500 rounded font-bold text-xs uppercase transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (activeWorkerSigPad.current && !activeWorkerSigPad.current.isEmpty()) {
                        const dataUrl = activeWorkerSigPad.current.getCanvas().toDataURL('image/png');
                        setWorkerSignatures(prev => ({
                          ...prev,
                          [activeSignWorkerIndex]: dataUrl
                        }));
                        setActiveSignWorkerIndex(null);
                      } else {
                        alert('Please provide a signature first.');
                      }
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-bold text-xs uppercase transition-colors"
                  >
                    Save Sign
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* ADD/EDIT PPE ITEM MODAL                                    */}
      {/* ========================================================= */}
      {isPpeItemModalOpen && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <form onSubmit={handleSavePpeItem} className="bg-[#111111] border border-[#333] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="p-5 border-b border-[#222] flex justify-between items-center bg-[#161616]">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-500" />
                {editingPpeItem ? 'Edit PPE Item' : 'Add New PPE Item'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsPpeItemModalOpen(false);
                  setEditingPpeItem(null);
                  setPpeItemName('');
                  setPpeItemCode('');
                }}
                className="text-gray-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  PPE Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={ppeItemName}
                  onChange={(e) => setPpeItemName(e.target.value)}
                  placeholder="e.g. Ear Muffs, Safety Vest, Face Shield"
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  Optional PPE Code / Type
                </label>
                <input
                  type="text"
                  value={ppeItemCode}
                  onChange={(e) => setPpeItemCode(e.target.value)}
                  placeholder="e.g. EM-01, SV-02, FS-03"
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="p-5 border-t border-[#222] flex justify-end gap-2.5 bg-[#161616]">
              <button
                type="button"
                onClick={() => {
                  setIsPpeItemModalOpen(false);
                  setEditingPpeItem(null);
                  setPpeItemName('');
                  setPpeItemCode('');
                }}
                className="px-4 py-2 bg-transparent hover:bg-[#1A1A1A] text-gray-400 hover:text-white border border-transparent rounded text-xs font-bold uppercase transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition cursor-pointer"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
