import React from 'react';

export default function CompanyProfilesPanel() {
  return (
    <div className="p-4">
      <h3 className="text-xl font-bold text-white mb-4">1.5 Company Profiles</h3>
      <div className="bg-gray-800 p-4 rounded text-gray-300">
        Company Profile content...
      </div>
    </div>
  );
}
