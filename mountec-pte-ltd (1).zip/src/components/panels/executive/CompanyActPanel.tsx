import React from 'react';

export default function CompanyActPanel() {
  return (
    <div className="p-4">
      <h3 className="text-xl font-bold text-white mb-4">1.2 The Company Act [Constitution]</h3>
      <div className="bg-gray-800 p-4 rounded text-gray-300">
        Company Constitution content...
      </div>
    </div>
  );
}
