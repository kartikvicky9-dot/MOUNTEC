import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ExecutiveFlowChart from './ExecutiveFlowChart';
import HRFlowChart from '../hr/HRFlowChart';
import OperationsFlowChart from '../operations/OperationsFlowChart';
import FinanceFlowChart from '../finance/FinanceFlowChart';
import SafetyFlowChart from '../hseq/SafetyFlowChart';
import SupportFlowChart from '../support/SupportFlowChart';

const modules = [
  { id: '1', title: '1. EXECUTIVE & GOVERNANCE', component: ExecutiveFlowChart },
  { id: '2', title: '2. HUMAN CAPITAL MANAGEMENT', component: HRFlowChart },
  { id: '3', title: '3. OPERATIONS & DELIVERY', component: OperationsFlowChart },
  { id: '4', title: '4. FINANCE & ACCOUNTING', component: FinanceFlowChart },
  { id: '5', title: '5. SAFETY', component: SafetyFlowChart },
  { id: '6', title: '6. SUPPORT & GENERAL', component: SupportFlowChart },
];

export default function OverallFlowChart({ globalSearchQuery, setActiveTab }: { globalSearchQuery: string, setActiveTab: (id: string) => void }) {
  const [activeModule, setActiveModule] = useState<string | null>(null);

  const filteredModules = modules.filter(m => 
    m.title.toLowerCase().includes(globalSearchQuery.toLowerCase())
  );

  const ActiveComponent = activeModule 
    ? modules.find(m => m.id === activeModule)?.component 
    : null;

  return (
    <div className="p-6 text-white">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-bold">
          {activeModule ? modules.find(m => m.id === activeModule)?.title : 'Overall Flow Chart'}
        </h3>
        <AnimatePresence>
          {activeModule && (
            <motion.button 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onClick={() => setActiveModule(null)}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm"
            >
              Back to Overall
            </motion.button>
          )}
        </AnimatePresence>
      </div>
      <div className="bg-gray-800 p-8 rounded-xl min-h-[400px]">
        <AnimatePresence mode="wait">
          {ActiveComponent ? (
            <motion.div
              key="active"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <ActiveComponent />
            </motion.div>
          ) : (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center gap-4"
            >
              {filteredModules.map((module, index) => (
                <React.Fragment key={module.id}>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                        setActiveModule(module.id);
                        const map: Record<string, string> = { '1': 'executive', '2': 'hr', '3': 'ops', '4': 'accounts', '5': 'safety', '6': 'general' };
                        const tabId = map[module.id];
                        if (tabId) setActiveTab(tabId);
                      }}
                    className="bg-gray-700 hover:bg-gray-600 transition-colors px-6 py-4 rounded-lg w-full max-w-md text-center font-semibold shadow-md"
                  >
                    {module.title}
                  </motion.button>
                  {index < filteredModules.length - 1 && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: 32 }}
                      className="w-0.5 bg-gray-500"
                    ></motion.div>
                  )}
                </React.Fragment>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
