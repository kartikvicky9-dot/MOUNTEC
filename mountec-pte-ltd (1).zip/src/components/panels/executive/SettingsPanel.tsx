import React from 'react';
import { Settings, Bell, Music, Layout } from 'lucide-react';
import { useAppContext } from '../../../context/AppContext';

export default function SettingsPanel() {
  const { preferences, updatePreferences } = useAppContext();
  
  return (
    <div className="space-y-6">
      <div className="bg-[#141414] p-6 rounded-xl shadow-2xl border border-[#222]">
        <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-6 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          App Settings
        </h2>
        
        <div className="space-y-6 max-w-2xl">
          {/* Notification Settings */}
          <div className="bg-[#1A1A1A] border border-[#333] rounded-lg p-6">
            <h3 className="text-white text-sm font-bold uppercase mb-4 flex items-center">
              <Bell className="w-4 h-4 mr-2 text-[#777]" />
              Notifications
            </h3>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white font-medium">Task Notifications</p>
                <p className="text-xs text-[#999] mt-1">Show popup alerts when you have pending tasks</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="sr-only peer"
                  checked={preferences?.showTaskNotifications ?? true}
                  onChange={(e) => updatePreferences({ showTaskNotifications: e.target.checked })}
                />
                <div className="w-11 h-6 bg-[#333] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
