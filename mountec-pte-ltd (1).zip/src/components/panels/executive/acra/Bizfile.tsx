import React from 'react';

export default function Bizfile() {
  return <div className="p-4 text-white">Bizfile [ACRA] Content (1.3.2)</div>;
}
