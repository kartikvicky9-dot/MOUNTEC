import React from 'react';

export default function SharesRelated() {
  return <div className="p-4 text-white">Shares Related Content (1.3.3)</div>;
}
