import React from 'react';

export default function Bizsafe() {
  return <div className="p-4 text-white">Bizsafe Content (1.4.1)</div>;
}
