import React, { useState } from 'react';
import CompanyPolicy from './policies/CompanyPolicy';
import OrgChart from './policies/OrgChart';
import SOP from './policies/SOP';

export default function PoliciesOrgChartPanel() {
  const [activeSubTab, setActiveSubTab] = useState('policy');

  return (
    <div className="p-4 text-white">
      <h3 className="text-xl font-bold mb-4">1.1 Policies & Org Chart</h3>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setActiveSubTab('policy')} className={`p-2 rounded ${activeSubTab === 'policy' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.1.1 Policy</button>
        <button onClick={() => setActiveSubTab('org')} className={`p-2 rounded ${activeSubTab === 'org' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.1.2 Org Chart</button>
        <button onClick={() => setActiveSubTab('sop')} className={`p-2 rounded ${activeSubTab === 'sop' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.1.3 SOP</button>
      </div>
      <div className="bg-gray-800 p-4 rounded">
        {activeSubTab === 'policy' && <CompanyPolicy />}
        {activeSubTab === 'org' && <OrgChart />}
        {activeSubTab === 'sop' && <SOP />}
      </div>
    </div>
  );
}
