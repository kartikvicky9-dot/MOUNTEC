import React, { useState } from 'react';
import Bizsafe from './certifications/Bizsafe';
import ISO from './certifications/ISO';

export default function CertificationsPanel() {
  const [activeSubTab, setActiveSubTab] = useState('bizsafe');

  return (
    <div className="p-4 text-white">
      <h3 className="text-xl font-bold mb-4">1.4 Certifications</h3>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setActiveSubTab('bizsafe')} className={`p-2 rounded ${activeSubTab === 'bizsafe' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.4.1 Bizsafe</button>
        <button onClick={() => setActiveSubTab('iso')} className={`p-2 rounded ${activeSubTab === 'iso' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.4.2 ISO</button>
      </div>
      <div className="bg-gray-800 p-4 rounded">
        {activeSubTab === 'bizsafe' && <Bizsafe />}
        {activeSubTab === 'iso' && <ISO />}
      </div>
    </div>
  );
}
