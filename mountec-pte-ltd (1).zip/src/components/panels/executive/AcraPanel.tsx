import React, { useState } from 'react';
import Secretarial from './acra/Secretarial';
import Bizfile from './acra/Bizfile';
import SharesRelated from './acra/SharesRelated';

export default function AcraPanel() {
  const [activeSubTab, setActiveSubTab] = useState('secretarial');

  return (
    <div className="p-4 text-white">
      <h3 className="text-xl font-bold mb-4">1.3 ACRA</h3>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setActiveSubTab('secretarial')} className={`p-2 rounded ${activeSubTab === 'secretarial' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.3.1 Secretarial</button>
        <button onClick={() => setActiveSubTab('bizfile')} className={`p-2 rounded ${activeSubTab === 'bizfile' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.3.2 Bizfile</button>
        <button onClick={() => setActiveSubTab('shares')} className={`p-2 rounded ${activeSubTab === 'shares' ? 'bg-blue-600' : 'bg-gray-800'}`}>1.3.3 Shares</button>
      </div>
      <div className="bg-gray-800 p-4 rounded">
        {activeSubTab === 'secretarial' && <Secretarial />}
        {activeSubTab === 'bizfile' && <Bizfile />}
        {activeSubTab === 'shares' && <SharesRelated />}
      </div>
    </div>
  );
}
