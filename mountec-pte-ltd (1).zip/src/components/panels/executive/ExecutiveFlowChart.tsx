import React, { useState } from 'react';
import SubFlowChart from '../SubFlowChart';
import PoliciesOrgChartPanel from './PoliciesOrgChartPanel';
import CompanyActPanel from './CompanyActPanel';
import AcraPanel from './AcraPanel';
import CertificationsPanel from './CertificationsPanel';
import CompanyProfilesPanel from './CompanyProfilesPanel';
import { motion, AnimatePresence } from 'motion/react';

const steps = [
  { id: '1.1', title: '1.1 POLICIES & ORG CHART', component: PoliciesOrgChartPanel },
  { id: '1.2', title: '1.2 THE COMPANY ACT [CONSTITUTION]', component: CompanyActPanel },
  { id: '1.3', title: '1.3 ACRA', component: AcraPanel },
  { id: '1.4', title: '1.4 BIZSAFE & ISO CERTIFICATIONS', component: CertificationsPanel },
  { id: '1.5', title: '1.5 EMAIL, ID & PASSWORD', component: CompanyProfilesPanel },
  { id: '1.6', title: '1.6 LETTERS & MEMO', component: () => <div>Letters & Memo Panel</div> },
  { id: '1.7', title: '1.7 COMPANY PROFILES', component: CompanyProfilesPanel },
  { id: '1.8', title: '1.8 SURVEY RELATED', component: () => <div>Survey Related Panel</div> },
  { id: '1.9', title: '1.9 EVENT & GATHERING RELATED', component: () => <div>Event & Gathering Related Panel</div> },
  { id: '1.10', title: '1.10 OVERHEAD RELATED', component: () => <div>Overhead Related Panel</div> },
];

export default function ExecutiveFlowChart() {
  const [activeStep, setActiveStep] = useState<typeof steps[0] | null>(null);

  if (activeStep) {
    const ActiveComponent = activeStep.component;
    return (
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
      >
        <button 
          onClick={() => setActiveStep(null)}
          className="mb-4 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm text-white"
        >
          Back to Executive Flow
        </button>
        <ActiveComponent />
      </motion.div>
    );
  }

  return <SubFlowChart title="EXECUTIVE & GOVERNANCE FLOW" steps={steps} onStepClick={setActiveStep as any} />;
}
