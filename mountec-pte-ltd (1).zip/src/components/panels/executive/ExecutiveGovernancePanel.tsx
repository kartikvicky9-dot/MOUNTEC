import React, { useState } from 'react';
import PoliciesOrgChartPanel from './PoliciesOrgChartPanel';
import CompanyActPanel from './CompanyActPanel';
import AcraPanel from './AcraPanel';
import CertificationsPanel from './CertificationsPanel';
import CompanyProfilesPanel from './CompanyProfilesPanel';

export default function ExecutiveGovernancePanel() {
  const [activeTab, setActiveTab] = useState('1.1');

  const tabs = [
    { id: '1.1', label: '1.1 Policies & Org Chart', component: PoliciesOrgChartPanel },
    { id: '1.2', label: '1.2 The Company Act [Constitution]', component: CompanyActPanel },
    { id: '1.3', label: '1.3 ACRA', component: AcraPanel },
    { id: '1.4', label: '1.4 BizSAFE & ISO CERTIFICATIONS', component: CertificationsPanel },
    { id: '1.5', label: '1.5 Email, ID & Password', component: () => <div>Email, ID & Password Panel</div> },
    { id: '1.6', label: '1.6 Letters & Memo', component: () => <div>Letters & Memo Panel</div> },
    { id: '1.7', label: '1.7 Company Profiles', component: CompanyProfilesPanel },
    { id: '1.8', label: '1.8 Survey Related', component: () => <div>Survey Related Panel</div> },
    { id: '1.9', label: '1.9 Event & Gathering Related', component: () => <div>Event & Gathering Related Panel</div> },
    { id: '1.10', label: '1.10 Overhead Related', component: () => <div>Overhead Related Panel</div> },
  ];

  const ActiveComponent = tabs.find(t => t.id === activeTab)?.component || PoliciesOrgChartPanel;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold p-6 border-b border-gray-800">1. Executive & Governance</h2>
      <div className="flex flex-1">
        <div className="w-64 border-r border-gray-800 p-4 space-y-2 overflow-y-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left p-3 rounded ${activeTab === tab.id ? 'bg-blue-600' : 'hover:bg-gray-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
}
