import React, { useState, useEffect } from 'react';
import FileUploadButton from '../../../FileUploadButton';
import documentUtils from '../../../../lib/documentUtils';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../../../lib/firebase';

export default function OrgChart() {
  const [files, setFiles] = useState<any[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'documents'), where('category', '==', 'orgchart'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setFiles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsubscribe;
  }, []);

  const handleUpload = async (file: File, displayName: string) => {
    await documentUtils.uploadDocument('orgchart', file, displayName);
  };

  return (
    <div className="p-4 text-white">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold">COMPANY ORG CHART CONTENT (1.1.2)</h3>
        <FileUploadButton onUpload={handleUpload} />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-300">
          <thead className="text-xs uppercase bg-gray-700 text-gray-400">
            <tr>
              <th className="px-4 py-3">Document Name</th>
              <th className="px-4 py-3">Updated</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {files.map(file => (
              <tr key={file.id} className="border-b border-gray-700 bg-gray-800">
                <td className="px-4 py-3 font-medium text-white">{file.displayName}</td>
                <td className="px-4 py-3">{new Date(file.updatedAt?.toDate()).toLocaleDateString()}</td>
                <td className="px-4 py-3 text-right flex justify-end gap-2">
                  {file.downloadURL && (
                    <>
                      <a href={file.downloadURL} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">Preview</a>
                      <a href={file.downloadURL} download={file.originalName} className="text-green-400 hover:text-green-300">Download</a>
                    </>
                  )}
                  <button className="text-yellow-400 hover:text-yellow-300" onClick={() => documentUtils.shareFile(file.downloadURL, file.displayName)}>Share</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
