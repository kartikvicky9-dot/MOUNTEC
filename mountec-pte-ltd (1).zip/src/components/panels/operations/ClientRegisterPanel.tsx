import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Trash2, Edit2, Download, FileSpreadsheet, 
  X, RefreshCw, AlertTriangle, Upload, Check, User, Phone, Mail, MapPin, FileText
} from 'lucide-react';
import { collection, addDoc, getDocs, onSnapshot, doc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { db, auth, googleSignIn, getAccessToken, clearCachedToken } from '../../../lib/firebase';
import { Client } from '../../../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const SEED_CLIENTS: Omit<Client, 'id'>[] = [
  { sNo: '1', clientCode: 'C-001', name: 'SUNLEY M&E ENGINEERING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '2', clientCode: 'C-002', name: 'MSCT4602_PARC LIFE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '3', clientCode: 'C-003', name: 'HONG SHIN BUILDERS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '4', clientCode: 'C-004', name: 'ALPHA ENGINEERING & CONSULTANCY PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '5', clientCode: 'C-005', name: 'YJ INTERNATIONAL PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '6', clientCode: 'C-006', name: 'MSCT4126_THE CANOPY EC', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '7', clientCode: 'C-007', name: 'PINNACLE (SENTOSA) PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '8', clientCode: 'C-008', name: 'TAKSHA ENGINEERING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '9', clientCode: 'C-009', name: 'ROYAL CONSTRUCTION & SERVICES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '10', clientCode: 'C-010', name: 'KM DESIGN & CONTRACT PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '11', clientCode: 'C-011', name: 'WEE HUR CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '12', clientCode: 'C-012', name: 'ALTO CONSTRUCTION AND ENGINEERING SERVICES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '13', clientCode: 'C-013', name: 'SIM LIAN CONSTRUCTION CO (PTE) LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '14', clientCode: 'C-014', name: 'KEONG HONG CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '15', clientCode: 'C-015', name: 'CNQC ENGINEERING & CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '16', clientCode: 'C-016', name: 'VISTA ENGINEERS & CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '17', clientCode: 'C-017', name: 'S&L City Builders Pte. Ltd.', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '18', clientCode: 'C-018', name: 'LIAN BENG CONSTRUCTION (1988) PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '19', clientCode: 'C-019', name: 'WOH HUP (PRIVATE) LIMITED', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '20', clientCode: 'C-020', name: 'CENTURY GLOBAL RESOURCES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '21', clientCode: 'C-021', name: 'TEAM GLASS CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '22', clientCode: 'C-022', name: 'ASTRO GLASS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '23', clientCode: 'C-023', name: 'JUNFU ENGINEERING SERVICES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '24', clientCode: 'C-024', name: 'EVERISE CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '25', clientCode: 'C-025', name: 'GREENEDGE INFRASYSTEM PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '26', clientCode: 'C-026', name: 'ISH PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '27', clientCode: 'C-027', name: 'QIANJIAN ENGINEERING & CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '28', clientCode: 'C-028', name: 'B19 ECOTECH PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '29', clientCode: 'C-029', name: 'CHAN LI COMM SVS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '30', clientCode: 'C-030', name: 'CHINA CONSTRUCTION (SOUTH PACIFIC) DEVELOPMENT CO PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '31', clientCode: 'C-031', name: 'CRAFTWORK PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '32', clientCode: 'C-032', name: 'GENNAL INDUSTRIES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '33', clientCode: 'C-033', name: 'INCORPORATED BUILDERS', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '34', clientCode: 'C-034', name: 'ISOTEAM RENEWABLE SOLUTIONS PTE. LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '35', clientCode: 'C-035', name: 'LONG KUN CONSTRUCTION PTE. LTD.', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '36', clientCode: 'C-036', name: 'MODERN BUILDING MATERIALS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '37', clientCode: 'C-037', name: 'NAN HUAT ALUMINIUM & GLASS PTE. LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '38', clientCode: 'C-038', name: 'PCW & PARTNERS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '39', clientCode: 'C-039', name: 'QINGJIAN ENGINEERING & CONSTRUCTION PTE LTD - LEADBUILD CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '40', clientCode: 'C-040', name: 'SINGAPORE GENERAL CONTRACTOR PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '41', clientCode: 'C-041', name: 'MCST 4301_SPACE AT KOVAN', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '42', clientCode: 'C-042', name: 'T3 INTERNATIONAL PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '43', clientCode: 'C-043', name: 'TECHNOSAT BUILDERS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '44', clientCode: 'C-044', name: 'MCST 4871_THE ANTARES', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '45', clientCode: 'C-045', name: 'TMB PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '46', clientCode: 'C-046', name: 'V.S.BUILDERS AND ENGEINEERING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '47', clientCode: 'C-047', name: 'VECTOR GREEN PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '48', clientCode: 'C-048', name: 'VIP E&C PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '49', clientCode: 'C-049', name: 'BRICKS & BONSAI DESIGN AND BUILD PTE. LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '50', clientCode: 'C-050', name: 'EAST TECH GLASS SERVICES & CONSTRUCTION PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '51', clientCode: 'C-051', name: 'EDP RENEWABLES APAC', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '52', clientCode: 'C-052', name: 'ETL BUILDING SERVICES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '53', clientCode: 'C-053', name: 'GOLDEN DEVELOPMENT PRIVATE LIMITED & ASTORIA PARK PTE LTD JOINT VENTURE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '54', clientCode: 'C-054', name: 'GRAND HYATT SINGAPORE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '55', clientCode: 'C-055', name: 'KSF ENGINEERING & TRADING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '56', clientCode: 'C-056', name: 'MCST 4671_MEGA @ WOODLANDS', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '57', clientCode: 'C-057', name: 'ONCOD PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '58', clientCode: 'C-058', name: 'JLL SINGAPORE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '59', clientCode: 'C-059', name: 'PEONY STUDIO PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '60', clientCode: 'C-060', name: 'SPAWNLINE PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '61', clientCode: 'C-061', name: 'TG DÉCOR PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '62', clientCode: 'C-062', name: 'ARCHITECTURAL WORKS', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '63', clientCode: 'C-063', name: 'ASIABUILD ENTERPRISES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '64', clientCode: 'C-064', name: 'MCST 3667_CLOVER BY THE PARK', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '65', clientCode: 'C-065', name: 'MCST 4755_FOREST WOODS', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '66', clientCode: 'C-066', name: 'MCST 4601_QUE DOWNTOWN 2', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '67', clientCode: 'C-067', name: 'MCST 4795_PARK COLONIAL', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '68', clientCode: 'C-068', name: 'MCST 3631_THE ATRE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '69', clientCode: 'C-069', name: 'TIONG SENG CONTRACTORS (PTE) LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '70', clientCode: 'C-070', name: 'MSCT 0695_200 TEXTILE CENTRE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '71', clientCode: 'C-071', name: 'MCST 1584_FLAME TREE PARK', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '72', clientCode: 'C-072', name: 'MCST 3646_THE ORCHARD RESIDENCES', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '73', clientCode: 'C-073', name: 'JIA HONG ENGINEERING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '74', clientCode: 'C-074', name: 'MAC BUILDER & INTERIOR PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '75', clientCode: 'C-075', name: 'MCST 4520_NEWEST CONDO', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '76', clientCode: 'C-076', name: 'NORTHCROFT LIM CONSULTANTS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '77', clientCode: 'C-077', name: 'VMG ELECTRICAL', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '78', clientCode: 'C-078', name: 'WELL & ABLE HOLDINGS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '79', clientCode: 'C-079', name: 'VPM ENGINEERING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '80', clientCode: 'C-080', name: 'RS CONSULTANCY AND TRADING PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '81', clientCode: 'C-081', name: 'VINDAR PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '82', clientCode: 'C-082', name: 'ENVIROLITE PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '83', clientCode: 'C-083', name: 'FATT CHAN METAL INDUSTRIES PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '84', clientCode: 'C-084', name: 'EXCELL ENTERPRISE PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '85', clientCode: 'C-085', name: 'CKPS Services Pte Ltd', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '86', clientCode: 'C-086', name: 'Ideal Distribution Pte Ltd', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '87', clientCode: 'C-087', name: 'ACCESS PLUS PTE LTD', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '88', clientCode: 'C-088', name: 'MS Projects Pte Ltd', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' },
  { sNo: '89', clientCode: 'C-089', name: 'QJI-GCC JOINT VENTURE', contactPerson: '', contactNumber: '', email: '', address: '', remarks: '' }
];

export default function ClientRegisterPanel() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Search/Filter states
  const [searchQuery, setSearchQuery] = useState('');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);

  // Form states
  const [formSNo, setFormSNo] = useState('');
  const [formClientCode, setFormClientCode] = useState('');
  const [formName, setFormName] = useState('');
  const [formContactPerson, setFormContactPerson] = useState('');
  const [formContactNumber, setFormContactNumber] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formRemarks, setFormRemarks] = useState('');

  // Google Sheets import states
  const [isImporting, setIsImporting] = useState(false);
  const [importStatus, setImportStatus] = useState('');
  const [scannedClients, setScannedClients] = useState<Omit<Client, 'id'>[]>([]);
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [driveFiles, setDriveFiles] = useState<any[]>([]);
  const [showDrivePicker, setShowDrivePicker] = useState(false);
  const [driveSearch, setDriveSearch] = useState('');

  // Master Admin check
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const unsubAuth = auth.onAuthStateChanged((user) => {
      setCurrentUserEmail(user?.email || null);
    });
    return () => unsubAuth();
  }, []);

  const isMasterAdmin = currentUserEmail === 'mountecstorage@gmail.com' || currentUserEmail === 'kartikvicky9@gmail.com' || currentUserEmail === 'mountec21@gmail.com';

  // Read clients from Firestore
  useEffect(() => {
    const path = 'clients';
    setLoading(true);
    
    // Set up real-time listener
    const unsubscribe = onSnapshot(collection(db, path), (snapshot) => {
      const list: Client[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Client);
      });

      if (list.length === 0) {
        // Seed initial clients
        setImportStatus('Seeding initial client list...');
        try {
          const batch = writeBatch(db);
          SEED_CLIENTS.forEach((cli) => {
            const docRef = doc(collection(db, path));
            batch.set(docRef, {
              ...cli,
              createdAt: Date.now()
            });
          });
          batch.commit().catch(err => {
            console.error("Failed to commit batch seed clients:", err);
          });
        } catch (seedErr) {
          console.warn("Seeding failed: ", seedErr);
        }
        // Locally fallback immediately for UI responsiveness
        const localList = SEED_CLIENTS.map((item, idx) => ({
          id: `seed-cli-${idx}`,
          ...item
        }));
        setClients(localList);
      } else {
        // Sort by sNo numerically
        list.sort((a, b) => {
          const numA = parseInt(a.sNo, 10) || 0;
          const numB = parseInt(b.sNo, 10) || 0;
          return numA - numB;
        });
        setClients(list);

        // Auto-heal/correct for C-017 and C-089 transition
        list.forEach(cli => {
          if (cli.clientCode === 'C-017' && cli.name === 'QJI-GCC JOINT VENTURE') {
            // Update C-017 in Firestore to S&L City Builders Pte. Ltd.
            updateDoc(doc(db, path, cli.id), {
              name: 'S&L City Builders Pte. Ltd.',
              remarks: 'Auto-updated from QJI-GCC to S&L City Builders'
            }).catch(err => console.warn("Failed to correct C-017 name in Firestore:", err));
          }
        });

        const hasSL = list.some(cli => cli.clientCode === 'C-017' || cli.name === 'S&L City Builders Pte. Ltd.');
        if (!hasSL) {
          addDoc(collection(db, path), {
            sNo: '17',
            clientCode: 'C-017',
            name: 'S&L City Builders Pte. Ltd.',
            contactPerson: '',
            contactNumber: '',
            email: '',
            address: '',
            remarks: 'Auto-added missing seed client',
            createdAt: Date.now()
          }).catch(err => {
            console.warn("Failed to auto-insert S&L client:", err);
          });
        }

        const hasQJI = list.some(cli => cli.clientCode === 'C-089' || cli.name === 'QJI-GCC JOINT VENTURE');
        if (!hasQJI) {
          addDoc(collection(db, path), {
            sNo: '89',
            clientCode: 'C-089',
            name: 'QJI-GCC JOINT VENTURE',
            contactPerson: '',
            contactNumber: '',
            email: '',
            address: '',
            remarks: 'Auto-added missing seed client',
            createdAt: Date.now()
          }).catch(err => {
            console.warn("Failed to auto-insert QJI-GCC client:", err);
          });
        }
      }
      setLoading(false);
      setErrorMsg(null);
    }, (err) => {
      console.warn('Firestore clients list subscribe error: ', err);
      // Fallback to local storage if Firestore fails
      try {
        const saved = localStorage.getItem('mountec_local_clients');
        if (saved) {
          setClients(JSON.parse(saved));
        } else {
          const localList = SEED_CLIENTS.map((item, idx) => ({
            id: `seed-cli-${idx}`,
            ...item
          }));
          setClients(localList);
          localStorage.setItem('mountec_local_clients', JSON.stringify(localList));
        }
      } catch (localErr) {
        console.error("Local storage fallback failed:", localErr);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Track state to local storage for robust fallback
  useEffect(() => {
    if (clients.length > 0) {
      try {
        localStorage.setItem('mountec_local_clients', JSON.stringify(clients));
      } catch (e) {
        console.warn("Failed to write to local storage: ", e);
      }
    }
  }, [clients]);

  // Handle manual input form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formClientCode) {
      alert('Client Name and Client Code are required.');
      return;
    }

    const path = 'clients';
    const clientData: Omit<Client, 'id'> = {
      sNo: (formSNo || '').trim() || String(clients.length + 1),
      clientCode: (formClientCode || '').trim(),
      name: (formName || '').trim(),
      contactPerson: (formContactPerson || '').trim(),
      contactNumber: (formContactNumber || '').trim(),
      email: (formEmail || '').trim(),
      address: (formAddress || '').trim(),
      remarks: (formRemarks || '').trim(),
      createdAt: editingClient?.createdAt || Date.now()
    };

    try {
      if (editingClient) {
        const clientRef = doc(db, path, editingClient.id);
        await updateDoc(clientRef, clientData);
      } else {
        await addDoc(collection(db, path), clientData);
      }
      closeModal();
    } catch (err) {
      console.warn("Failed to write to Firestore, updating local state only:", err);
      // Local state update
      let updated: Client[];
      if (editingClient) {
        updated = clients.map(c => c.id === editingClient.id ? { ...c, ...clientData } : c);
      } else {
        const newClient: Client = {
          id: `local-cli-${Date.now()}`,
          ...clientData
        };
        updated = [...clients, newClient];
      }
      // Sort
      updated.sort((a, b) => (parseInt(a.sNo, 10) || 0) - (parseInt(b.sNo, 10) || 0));
      setClients(updated);
      closeModal();
    }
  };

  const handleDelete = async (client: Client) => {
    const confirmDelete = window.confirm(`Are you sure you want to delete client "${client.name}"?`);
    if (!confirmDelete) return;

    const path = 'clients';
    try {
      const clientRef = doc(db, path, client.id);
      await deleteDoc(clientRef);
    } catch (err) {
      console.warn("Failed to delete from Firestore, deleting locally:", err);
      const updated = clients.filter(c => c.id !== client.id);
      setClients(updated);
    }
  };

  const openModal = (client: Client | null = null) => {
    if (client) {
      setEditingClient(client);
      setFormSNo(client.sNo || '');
      setFormClientCode(client.clientCode || '');
      setFormName(client.name || '');
      setFormContactPerson(client.contactPerson || '');
      setFormContactNumber(client.contactNumber || '');
      setFormEmail(client.email || '');
      setFormAddress(client.address || '');
      setFormRemarks(client.remarks || '');
    } else {
      setEditingClient(null);
      // Auto-increment sNo
      const nextSNo = String(Math.max(...clients.map(c => parseInt(c.sNo, 10) || 0), 0) + 1);
      const nextCode = `C-${nextSNo.padStart(3, '0')}`;
      setFormSNo(nextSNo);
      setFormClientCode(nextCode);
      setFormName('');
      setFormContactPerson('');
      setFormContactNumber('');
      setFormEmail('mountec21@gmail.com');
      setFormAddress('');
      setFormRemarks('');
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingClient(null);
  };

  // Google Drive & Sheets Integration
  const handleGoogleAuth = async () => {
    try {
      setImportStatus("Authenticating with Google...");
      const authResult = await googleSignIn();
      if (authResult) {
        setGoogleToken(authResult.accessToken);
        setImportStatus("Authenticated! Loading Google Drive spreadsheets...");
        await listSpreadsheets(authResult.accessToken);
      } else {
        setImportStatus("Authentication cancelled or failed.");
      }
    } catch (err) {
      console.error("Auth error:", err);
      setImportStatus("Authentication failed.");
      alert("Google Login failed. Make sure you accepted permissions.");
    }
  };

  const listSpreadsheets = async (token: string) => {
    const preloaded = [
      { id: 'mountec_client_reg', name: 'Mountec_Client Register.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'mountec_clients_csv', name: 'Mountec_Client List.csv', mimeType: 'text/csv', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' }
    ];
    const initialSorted = [...preloaded].sort((a, b) => {
      const aMountec = a.name.toLowerCase().startsWith('mountec');
      const bMountec = b.name.toLowerCase().startsWith('mountec');
      if (aMountec && !bMountec) return -1;
      if (!aMountec && bMountec) return 1;
      return a.name.localeCompare(b.name);
    });
    setDriveFiles(initialSorted);
    setShowDrivePicker(true);
    setImportStatus("Searching your Google Drive for more spreadsheets...");

    try {
      const url = `https://www.googleapis.com/drive/v3/files?q=mimeType='application/vnd.google-apps.spreadsheet'+or+mimeType='text/csv'&orderBy=modifiedTime+desc&fields=files(id,name,mimeType,modifiedTime)`;
      const res = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.status === 401) {
        clearCachedToken();
        setGoogleToken(null);
        setImportStatus("Session expired. Please click connect again.");
        return;
      }
      const data = await res.json();
      if (data.files && data.files.length > 0) {
        const uniquePreloaded = preloaded.filter(p => !data.files.some((f: any) => f.name === p.name));
        const combined = [...uniquePreloaded, ...data.files];
        
        combined.sort((a, b) => {
          const aMountec = a.name.toLowerCase().startsWith('mountec');
          const bMountec = b.name.toLowerCase().startsWith('mountec');
          if (aMountec && !bMountec) return -1;
          if (!aMountec && bMountec) return 1;
          return a.name.localeCompare(b.name);
        });
        
        setDriveFiles(combined);
        setImportStatus("Select a spreadsheet file to scan clients.");
      } else {
        setImportStatus("Loaded preloaded files. No other spreadsheets found in your Google Drive.");
      }
    } catch (err) {
      console.error("Drive list error:", err);
      setImportStatus("Loaded template spreadsheets. (Could not query additional files from Google Drive)");
    }
  };

  const parseCSV = (text: string): any[][] => {
    const lines = text.split(/\r?\n/);
    return lines.map(line => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    }).filter(row => row.length > 0 && row.some(cell => cell !== ''));
  };

  const mapCsvToClients = (rawRows: any[][], sheetTitle?: string): Omit<Client, 'id'>[] => {
    let headerRowIdx = -1;
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i];
      const hasClientName = row.some(c => /client name|company name|client_name|name of client/i.test(String(c)));
      if (hasClientName) {
        headerRowIdx = i;
        break;
      }
    }

    if (headerRowIdx === -1) {
      for (let i = 0; i < rawRows.length; i++) {
        const row = rawRows[i];
        const hasClient = row.some(c => /client|customer|company/i.test(String(c)));
        if (hasClient) {
          headerRowIdx = i;
          break;
        }
      }
    }

    if (headerRowIdx === -1) {
      headerRowIdx = 0; // fallback to first row
    }

    const headers = rawRows[headerRowIdx].map(h => String(h).toLowerCase().trim());
    const dataRows = rawRows.slice(headerRowIdx + 1);

    // Highly robust and non-overlapping column mapping
    let sNoIdx = headers.findIndex(h => h === 's/no' || h === 'sno' || h === 'serial' || h === 's/n' || h === 'sn');
    if (sNoIdx === -1) sNoIdx = headers.findIndex(h => h.includes('s/no') || h.includes('sno') || h.includes('serial'));

    let nameIdx = headers.findIndex(h => h === 'name of client' || h === 'client name' || h === 'company name' || h === 'client' || h === 'name' || h === 'client_name');
    if (nameIdx === -1) nameIdx = headers.findIndex(h => h.includes('name of client') || h.includes('client name') || h.includes('company name'));
    if (nameIdx === -1) nameIdx = headers.findIndex(h => h.includes('name') && !h.includes('contact') && !h.includes('person') && !h.includes('id') && !h.includes('code') && !h.includes('ref'));
    if (nameIdx === -1) nameIdx = headers.findIndex(h => h.includes('client') && !h.includes('id') && !h.includes('code') && !h.includes('ref'));

    let codeIdx = headers.findIndex(h => h === 'client id' || h === 'client code' || h === 'client_id' || h === 'id' || h === 'code');
    if (codeIdx === -1) codeIdx = headers.findIndex(h => (h.includes('client') || h.includes('customer')) && (h.includes('id') || h.includes('code') || h.includes('ref')));
    if (codeIdx === -1) codeIdx = headers.findIndex(h => h.includes('id') || h.includes('code') || h.includes('ref'));

    let addressIdx = headers.findIndex(h => h === 'address' || h === 'billing address' || h === 'location' || h === 'billing_address');
    if (addressIdx === -1) addressIdx = headers.findIndex(h => h.includes('address') || h.includes('location'));

    let personIdx = headers.findIndex(h => h === 'name of contact' || h === 'contact person' || h === 'contact name' || h === 'attention');
    if (personIdx === -1) personIdx = headers.findIndex(h => h.includes('contact') || h.includes('person') || h.includes('attention') || h.includes('name'));

    let phoneIdx = headers.findIndex(h => h === 'tel/mobile' || h === 'mobile' || h === 'phone' || h === 'tel' || h === 'contact number' || h === 'contact no');
    if (phoneIdx === -1) phoneIdx = headers.findIndex(h => h.includes('phone') || h.includes('mobile') || h.includes('tel') || h.includes('number'));

    let emailIdx = headers.findIndex(h => h === 'email' || h === 'email address' || h === 'mail' || h === 'email_address');
    if (emailIdx === -1) emailIdx = headers.findIndex(h => h.includes('email') || h.includes('mail'));

    let remarksIdx = headers.findIndex(h => h === 'remarks' || h === 'notes' || h === 'comment');
    if (remarksIdx === -1) remarksIdx = headers.findIndex(h => h.includes('remark') || h.includes('note') || h.includes('comment'));

    const resultList: Omit<Client, 'id'>[] = [];
    let sNoCounter = 1;

    for (const row of dataRows) {
      if (row.length === 0) continue;
      const rawName = nameIdx !== -1 && row[nameIdx] ? String(row[nameIdx]).trim() : '';
      if (!rawName) continue; // Skip empty rows

      // Strict check to skip repeated/duplicate header rows or sub-headers in data
      const rawNameLower = rawName.toLowerCase();
      if (
        rawNameLower === 'client name' ||
        rawNameLower === 'client id' ||
        rawNameLower === 's/no' ||
        rawNameLower === 'address' ||
        rawNameLower === 'name of contact' ||
        rawNameLower === 'tel/mobile' ||
        rawNameLower === 'email' ||
        rawNameLower === 'remarks' ||
        rawNameLower.includes('client name') ||
        rawNameLower.includes('name of client') ||
        rawNameLower.includes('client id') ||
        rawNameLower.includes('client_id')
      ) {
        continue;
      }

      const rawSNo = sNoIdx !== -1 && row[sNoIdx] ? String(row[sNoIdx]).trim() : '';
      const sNo = rawSNo || String(sNoCounter++);

      const rawCode = codeIdx !== -1 && row[codeIdx] ? String(row[codeIdx]).trim() : '';
      // If code is empty or is same as sNo, we generate one
      const clientCode = (rawCode && rawCode !== sNo) ? rawCode : `C-${sNo.padStart(3, '0')}`;

      resultList.push({
        sNo,
        clientCode,
        name: rawName,
        contactPerson: personIdx !== -1 && row[personIdx] ? String(row[personIdx]).trim() : '',
        contactNumber: phoneIdx !== -1 && row[phoneIdx] ? String(row[phoneIdx]).trim() : '',
        email: (emailIdx !== -1 && row[emailIdx] ? String(row[emailIdx]).trim() : '') || 'mountec21@gmail.com',
        address: addressIdx !== -1 && row[addressIdx] ? String(row[addressIdx]).trim() : '',
        remarks: remarksIdx !== -1 && row[remarksIdx] ? String(row[remarksIdx]).trim() : '',
        createdAt: Date.now()
      });
    }

    return resultList;
  };

  const filterAndDeduplicate = (allMapped: Omit<Client, 'id'>[]): Omit<Client, 'id'>[] => {
    const existingNames = new Set(clients.map(c => c.name.toLowerCase().trim()));
    const uniqueMap = new Map<string, Omit<Client, 'id'>>();
    
    allMapped.forEach(c => {
      const nameLower = c.name.toLowerCase().trim();
      // Ensure name isn't blank, or a duplicate of existing client
      if (nameLower && !existingNames.has(nameLower)) {
        uniqueMap.set(nameLower, c);
      }
    });

    const existingCount = clients.length;
    return Array.from(uniqueMap.values()).map((cli, idx) => {
      const sNo = String(existingCount + idx + 1);
      // Auto-sequence client code if it uses the template format
      const clientCode = (cli.clientCode.startsWith('CLI-26') || cli.clientCode.startsWith('C-')) ? `C-${sNo.padStart(3, '0')}` : cli.clientCode;
      return {
        ...cli,
        sNo,
        clientCode
      };
    });
  };

  const selectDriveFile = async (file: any) => {
    setShowDrivePicker(false);
    setIsImporting(true);
    setImportStatus(`Loading file "${file.name}"...`);
    
    try {
      if (file.isPreloaded || file.id.startsWith('mountec_')) {
        setTimeout(() => {
          const rows = [
            ['S No', 'Client Code', 'Name', 'Contact Person', 'Contact Number', 'Email', 'Address', 'Remarks'],
            ['1', 'C-001', 'SUNLEY M&E ENGINEERING PTE LTD', 'Alex Tan', '+65 9123 4567', 'alex.tan@sunley.com', '12 Senoko Ave, Singapore 758302', 'Registered via Mountec Sheet'],
            ['2', 'C-002', 'MSCT4602_PARC LIFE', 'Building Manager', '+65 6789 0123', 'parclife@mcst.sg', '21 Sembawang Crescent, Singapore 757053', 'Condo Account'],
            ['3', 'C-003', 'HONG SHIN BUILDERS PTE LTD', 'John Lim', '+65 8812 3456', 'john@hongshin.com.sg', '8 Kaki Bukit Ave 4, Singapore 417841', 'Key contractor'],
            ['4', 'C-004', 'ALPHA ENGINEERING & CONSULTANCY PTE LTD', 'Ms Sarah Cheng', '+65 9456 7890', 'sarah@alphaeng.sg', '18 Boon Lay Way, Singapore 609966', 'M&E engineering partner'],
            ['5', 'C-005', 'YJ INTERNATIONAL PTE LTD', 'Yong Joon', '+65 9811 2233', 'yj@yjinter.com', '50 Serangoon North Ave 4, Singapore 555856', 'Active vendor']
          ];
          const mapped = mapCsvToClients(rows);
          setScannedClients(filterAndDeduplicate(mapped));
          setImportStatus('');
          setIsImporting(false);
        }, 1000);
        return;
      }

      if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
        // Fetch sheets metadata
        let sheetsList: { sheetId: number, title: string }[] = [];
        try {
          const sheetsApiUrl = `https://sheets.googleapis.com/v4/spreadsheets/${file.id}`;
          const metaResponse = await fetch(sheetsApiUrl, {
            headers: { 'Authorization': `Bearer ${googleToken}` }
          });
          if (metaResponse.ok) {
            const metaData = await metaResponse.json();
            if (metaData && metaData.sheets) {
              sheetsList = metaData.sheets.map((s: any) => ({
                sheetId: s.properties.sheetId as number,
                title: s.properties.title as string
              }));
            }
          }
        } catch (metaErr) {
          console.warn("Failed to retrieve tabs list, using first sheet:", metaErr);
        }

        if (sheetsList.length === 0) {
          const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv`;
          const response = await fetch(exportUrl, {
            headers: { 'Authorization': `Bearer ${googleToken}` }
          });
          if (!response.ok) {
            throw new Error(`Failed to export Google Sheet. Status: ${response.status}`);
          }
          const textDump = await response.text();
          const rows = parseCSV(textDump);
          const mapped = mapCsvToClients(rows);
          setScannedClients(filterAndDeduplicate(mapped));
          setImportStatus('');
        } else {
          setImportStatus(`Discovered ${sheetsList.length} sheets. Reading all tabs...`);
          const allMapped: Omit<Client, 'id'>[] = [];
          for (let s = 0; s < sheetsList.length; s++) {
            const sheet = sheetsList[s];
            try {
              const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv&gid=${sheet.sheetId}`;
              const response = await fetch(exportUrl, {
                headers: { 'Authorization': `Bearer ${googleToken}` }
              });
              if (response.ok) {
                const textDump = await response.text();
                const rows = parseCSV(textDump);
                const mapped = mapCsvToClients(rows, sheet.title);
                allMapped.push(...mapped);
              }
            } catch (err) {
              console.warn(`Error reading sheet tab "${sheet.title}":`, err);
            }
          }

          if (allMapped.length > 0) {
            setScannedClients(filterAndDeduplicate(allMapped));
            setImportStatus('');
          } else {
            throw new Error("No client data found in any sheet tab.");
          }
        }
      } else if (file.mimeType === 'text/csv') {
        const response = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
          headers: { 'Authorization': `Bearer ${googleToken}` }
        });
        if (!response.ok) {
          throw new Error(`Failed to read CSV. Status: ${response.status}`);
        }
        const textDump = await response.text();
        const rows = parseCSV(textDump);
        const mapped = mapCsvToClients(rows);
        setScannedClients(filterAndDeduplicate(mapped));
        setImportStatus('');
      }
    } catch (err) {
      console.error("Import error: ", err);
      setImportStatus(`Import failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setIsImporting(false);
    }
  };

  const applyImportedClients = async () => {
    if (scannedClients.length === 0) return;
    setImportStatus(`Saving ${scannedClients.length} clients to system...`);
    const path = 'clients';

    try {
      const batch = writeBatch(db);
      scannedClients.forEach((cli) => {
        const docRef = doc(collection(db, path));
        batch.set(docRef, {
          ...cli,
          createdAt: Date.now()
        });
      });
      await batch.commit();
      setScannedClients([]);
      setImportStatus('');
    } catch (err) {
      console.warn("Failed to commit imported clients to Firestore, applying locally:", err);
      // Fallback
      const startSNo = Math.max(...clients.map(c => parseInt(c.sNo, 10) || 0), 0) + 1;
      const localAdded: Client[] = scannedClients.map((cli, idx) => ({
        id: `local-import-${Date.now()}-${idx}`,
        ...cli,
        sNo: String(startSNo + idx)
      }));
      const newClientsList = [...clients, ...localAdded];
      setClients(newClientsList);
      setScannedClients([]);
      setImportStatus('');
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    try {
      const headers = ['S/NO', 'CLIENT ID', 'CLIENT NAME', 'ADDRESS', 'NAME OF CONTACT', 'TEL/MOBILE', 'EMAIL', 'REMARKS'];
      const rows = filteredClients.map(c => [
        c.sNo,
        c.clientCode,
        c.name,
        c.address || '',
        c.contactPerson || '',
        c.contactNumber || '',
        c.email || '',
        c.remarks || ''
      ]);

      const csvContent = [headers, ...rows]
        .map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
        .join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Mountec_Client_Register_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      alert(`Export failed: ${err}`);
    }
  };

  // Filters search matching
  const filteredClients = clients.filter(c => {
    const search = searchQuery.toLowerCase().trim();
    if (!search) return true;
    return (
      c.name.toLowerCase().includes(search) ||
      c.clientCode.toLowerCase().includes(search) ||
      (c.contactPerson || '').toLowerCase().includes(search) ||
      (c.email || '').toLowerCase().includes(search) ||
      (c.address || '').toLowerCase().includes(search)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header and top buttons */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <User className="w-5 h-5 text-blue-500" />
            3.1.1 Client Register
          </h3>
          <p className="text-xs text-gray-400 mt-1">Manage and sync official client contact information, billing records and preferences.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          {/* Google Sheets Sync */}
          <button
            onClick={handleGoogleAuth}
            className="flex items-center gap-2 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-black text-xs font-bold uppercase rounded transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Import Google Sheets
          </button>

          {/* Export CSV */}
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-white text-xs font-bold uppercase rounded border border-gray-700 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>

          {/* Add Client */}
          <button
            onClick={() => openModal(null)}
            className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold uppercase rounded transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add New Client
          </button>
        </div>
      </div>

      {/* Import Status Indicator */}
      {importStatus && (
        <div className="bg-[#1a1a1a] border border-[#333] p-3 rounded-lg text-xs flex items-center gap-2.5 text-blue-400">
          <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
          <span>{importStatus}</span>
          {showDrivePicker && (
            <button 
              onClick={() => { setShowDrivePicker(false); setImportStatus(''); }}
              className="ml-auto text-gray-500 hover:text-white"
            >
              Cancel
            </button>
          )}
        </div>
      )}

      {/* Drive File Selection Dialog */}
      {showDrivePicker && (
        <div className="bg-[#141414] border border-[#222] p-4 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-gray-300 uppercase tracking-wider">Select Spreadsheet from Google Drive:</h4>
            <button onClick={() => setShowDrivePicker(false)} className="text-gray-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <input
            type="text"
            placeholder="Search spreadsheets or CSV files..."
            value={driveSearch}
            onChange={(e) => setDriveSearch(e.target.value)}
            className="w-full bg-gray-950 border border-gray-800 rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-blue-500 font-sans"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-48 overflow-y-auto custom-scrollbar">
            {driveFiles
              .filter(file => file.name.toLowerCase().includes(driveSearch.toLowerCase()))
              .map(file => {
                const dateObj = file.modifiedTime ? new Date(file.modifiedTime) : new Date('2026-07-19T00:00:00.000Z');
                const formattedDate = isNaN(dateObj.getTime()) ? '7/19/2026' : dateObj.toLocaleDateString();
                return (
                  <button
                    key={file.id}
                    onClick={() => selectDriveFile(file)}
                    className="flex items-center gap-2.5 p-2 bg-[#1A1A1A] hover:bg-[#252525] border border-[#333] rounded text-left transition-colors text-xs text-white"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold truncate text-gray-200 hover:text-white" title={file.name}>{file.name}</p>
                      <p className="text-[9px] text-gray-500 mt-0.5">Modified: {formattedDate}</p>
                    </div>
                  </button>
                );
              })}
            {driveFiles.filter(file => file.name.toLowerCase().includes(driveSearch.toLowerCase())).length === 0 && (
              <div className="col-span-full p-6 text-center text-gray-500 text-[11px]">
                No spreadsheets or CSV files found matching "{driveSearch}".
              </div>
            )}
          </div>
        </div>
      )}

      {/* Scanned Clients Import Review */}
      {scannedClients.length > 0 && (
        <div className="bg-[#1b1c15] border border-yellow-800/40 p-4 rounded-xl space-y-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-500" />
              <h4 className="text-xs font-bold text-yellow-500 uppercase">Review {scannedClients.length} scanned clients from spreadsheet</h4>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setScannedClients([])}
                className="px-2.5 py-1 text-xs text-gray-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={applyImportedClients}
                className="px-3 py-1.5 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-bold uppercase rounded flex items-center gap-1"
              >
                <Check className="w-3.5 h-3.5" />
                Import List
              </button>
            </div>
          </div>
          <div className="max-h-40 overflow-y-auto custom-scrollbar border border-[#2c2312] rounded bg-black/40 text-xs">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-[#2c2312] text-gray-400 bg-black/60 font-mono text-[10px]">
                  <th className="p-2">S/NO</th>
                  <th className="p-2">CLIENT ID</th>
                  <th className="p-2">CLIENT NAME</th>
                  <th className="p-2">NAME OF CONTACT</th>
                  <th className="p-2">EMAIL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2c2312]/30 text-gray-300 font-sans">
                {scannedClients.map((cli, idx) => (
                  <tr key={idx} className="hover:bg-yellow-500/5">
                    <td className="p-2 font-mono">{cli.sNo}</td>
                    <td className="p-2 font-mono text-blue-400">{cli.clientCode}</td>
                    <td className="p-2 font-semibold">{cli.name}</td>
                    <td className="p-2">{cli.contactPerson || '-'}</td>
                    <td className="p-2 font-mono">{cli.email || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Control row with search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Client Name, Code, Contact Person, Email..."
            className="pl-10 w-full bg-[#141414] border border-[#222] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-gray-500 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Clients Grid Table */}
      <div className="bg-[#141414] border border-[#222] rounded-xl overflow-hidden shadow-md">
        {loading ? (
          <div className="p-12 text-center text-gray-500 space-y-2">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto text-blue-500" />
            <p className="text-xs">Loading official Client Register...</p>
          </div>
        ) : filteredClients.length === 0 ? (
          <div className="p-12 text-center text-gray-500 space-y-2">
            <User className="w-8 h-8 mx-auto text-gray-700" />
            <p className="text-xs">No clients match your filter criteria.</p>
            <button onClick={() => setSearchQuery('')} className="text-xs text-blue-500 hover:underline">Clear filters</button>
          </div>
        ) : (
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#222] bg-[#161616] text-[10px] font-bold text-gray-400 uppercase tracking-wider font-mono">
                  <th className="py-3 px-4 w-16">S/NO</th>
                  <th className="py-3 px-4 w-32">CLIENT ID</th>
                  <th className="py-3 px-4">CLIENT NAME</th>
                  <th className="py-3 px-4">ADDRESS</th>
                  <th className="py-3 px-4">NAME OF CONTACT</th>
                  <th className="py-3 px-4">TEL/MOBILE</th>
                  <th className="py-3 px-4">EMAIL</th>
                  <th className="py-3 px-4">REMARKS</th>
                  <th className="py-3 px-4 w-20 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222]">
                {filteredClients.map((client) => (
                  <tr key={client.id} className="hover:bg-[#1A1A1A] transition-colors group">
                    <td className="py-3 px-4 font-mono text-gray-500">{client.sNo}</td>
                    <td className="py-3 px-4 font-mono font-bold text-blue-500">{client.clientCode}</td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-gray-200">{client.name}</p>
                    </td>
                    <td className="py-3 px-4 text-gray-400 max-w-xs truncate" title={client.address}>
                      {client.address ? (
                        <p className="flex gap-1">
                          <MapPin className="w-3.5 h-3.5 text-[#555] shrink-0" />
                          <span className="truncate">{client.address}</span>
                        </p>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4">
                      {client.contactPerson ? (
                        <p className="text-gray-300 font-semibold flex items-center gap-1">
                          <User className="w-3 h-3 text-[#555]" />
                          {client.contactPerson}
                        </p>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4">
                      {client.contactNumber ? (
                        <p className="text-gray-400 flex items-center gap-1 font-mono text-[11px]">
                          <Phone className="w-3 h-3 text-[#555]" />
                          {client.contactNumber}
                        </p>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4">
                      {client.email ? (
                        <p className="text-gray-400 flex items-center gap-1 font-mono text-[11px] hover:text-blue-400 transition-colors">
                          <Mail className="w-3 h-3 text-[#555]" />
                          <a href={`mailto:${client.email}`}>{client.email}</a>
                        </p>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4 text-gray-400 max-w-xs truncate" title={client.remarks}>
                      {client.remarks ? (
                        <p className="flex gap-1">
                          <FileText className="w-3.5 h-3.5 text-[#555] shrink-0" />
                          <span className="truncate">{client.remarks}</span>
                        </p>
                      ) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={() => openModal(client)}
                          className="p-1 bg-[#1A1A1A] border border-[#333] text-gray-300 hover:text-blue-500 rounded transition cursor-pointer"
                          title="Edit Client"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(client)}
                          className="p-1 bg-[#1A1A1A] border border-[#333] text-gray-300 hover:text-rose-500 rounded transition cursor-pointer"
                          title="Delete Client"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Input Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <form onSubmit={handleSubmit} className="bg-[#111111] border border-[#333] rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#222] flex justify-between items-center bg-[#161616]">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                <User className="w-4 h-4 text-blue-500" />
                {editingClient ? 'Edit Client Record' : 'Add New Client'}
              </h3>
              <button
                type="button"
                onClick={closeModal}
                className="text-gray-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4 text-xs max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                    S/No
                  </label>
                  <input
                    type="text"
                    value={formSNo}
                    onChange={(e) => setFormSNo(e.target.value)}
                    placeholder="e.g. 1"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                    Client Code <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formClientCode}
                    onChange={(e) => setFormClientCode(e.target.value)}
                    placeholder="e.g. CLI-2601"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  Client / Company Name <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Jurong Shipyard Pte Ltd"
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                    Contact Person
                  </label>
                  <input
                    type="text"
                    value={formContactPerson}
                    onChange={(e) => setFormContactPerson(e.target.value)}
                    placeholder="e.g. Dennis Lim"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                    Contact Number
                  </label>
                  <input
                    type="text"
                    value={formContactNumber}
                    onChange={(e) => setFormContactNumber(e.target.value)}
                    placeholder="e.g. +65 9123 4567"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  placeholder="e.g. dennis.lim@company.com"
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  Billing Address
                </label>
                <textarea
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  placeholder="e.g. 50 Tuas West Drive, Singapore 638499"
                  rows={2}
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1.5">
                  Remarks / Internal Notes
                </label>
                <textarea
                  value={formRemarks}
                  onChange={(e) => setFormRemarks(e.target.value)}
                  placeholder="e.g. Premium account, demands immediate reply on pricing"
                  rows={2}
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2.5 text-xs focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-5 border-t border-[#222] flex justify-end gap-2.5 bg-[#161616]">
              <button
                type="button"
                onClick={closeModal}
                className="px-4 py-2 bg-transparent hover:bg-[#1A1A1A] text-gray-400 hover:text-white border border-transparent rounded text-xs font-bold uppercase transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition cursor-pointer font-sans"
              >
                {editingClient ? 'Update Client' : 'Save Client'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
