import React, { useState } from 'react';
import PlaceholderPanel from '../support/PlaceholderPanel';
import TasksPanel from './TasksPanel';
import ProjectRegisterPanel from './ProjectRegisterPanel';
import ClientRegisterPanel from './ClientRegisterPanel';
import QuotationRegisterPanel from './QuotationRegisterPanel';
import WorkDeploymentSchedulePanel from './WorkDeploymentSchedulePanel';
import METCManagementPanel from '../metc/METCManagementPanel';


export default function OperationsManagementPanel() {
  const [activeTab, setActiveTab] = useState('3.1');
  const [activeSubTab, setActiveSubTab] = useState('3.1.1');
  const [activeProjectsSubTab, setActiveProjectsSubTab] = useState('3.2.1');
  const [activeResourcesSubTab, setActiveResourcesSubTab] = useState('3.3.1');

  const tabs = [
    { 
      id: '3.1', 
      label: '3.1 Sales', 
      component: () => null // Handled specially below to avoid nested state hook issues
    },
    { 
      id: '3.2', 
      label: '3.2 Projects', 
      component: () => null // Handled specially below to avoid nested state hook issues
    },
    { 
      id: '3.3', 
      label: '3.3 Resources Management', 
      component: () => null // Handled specially below to avoid nested state hook issues
    },
    { 
      id: '3.4', 
      label: '3.4 Technical', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">3.4 Technical</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>3.4.1 Product & Technical Information</li>
            <li>3.4.2 Drawings</li>
            <li>3.4.3 Design Calculation & Endorsement</li>
            <li>3.4.4 Maintenance Manual</li>
          </ul>
        </div>
      )
    },
    { 
      id: '3.5', 
      label: '3.5 Purchase Related', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">3.5 Purchase Related</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>3.5.1 Supplier & Vendors Information/Register</li>
            <li>3.5.2 Purchase Requisition</li>
            <li>3.5.3 Purchase Order/ Blanket Order</li>
            <li>3.5.4 Comparison</li>
          </ul>
        </div>
      )
    },
    { 
      id: '3.6', 
      label: '3.6 Work & Delivery Order Related', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">3.6 Work & Delivery Order Related</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>3.6.1 Work Order Related</li>
            <li>3.6.2 Delivery Order Related</li>
          </ul>
        </div>
      )
    },
    { 
      id: '3.7', 
      label: '3.7 Letter Registration', 
      component: () => (
        <div className="space-y-4">
          <h3 className="text-xl font-bold">3.7 Letter Registration</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-400">
            <li>3.7.1 Letters</li>
            <li>3.7.2 Memo</li>
            <li>3.7.3 Minutes of Meeting</li>
          </ul>
        </div>
      )
    },
    { id: '3.8', label: '3.8 Client/Supplier/Vendor List', component: () => <PlaceholderPanel title="Client/Supplier/Vendor List" /> },
    { id: '3.9', label: '3.9 Transportation Related', component: () => <PlaceholderPanel title="Transportation" /> },
    { id: '3.10', label: '3.10 Legal Action', component: () => <PlaceholderPanel title="Legal Action" /> },
    { id: '3.11', label: '3.11 Additional Product & Services', component: () => <PlaceholderPanel title="Additional Product & Services" /> },
    { id: '3.12', label: '3.12 METC Management', component: METCManagementPanel },
  ];

  const ActiveComponent = tabs.find(t => t.id === activeTab)?.component || METCManagementPanel;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold p-6 border-b border-gray-800">3. Operations & Delivery</h2>
      <div className="flex flex-1 overflow-hidden">
        <div className="w-80 border-r border-gray-800 p-4 space-y-2 overflow-y-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left p-3 rounded text-sm ${activeTab === tab.id ? 'bg-blue-600' : 'hover:bg-gray-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          {activeTab === '3.1' ? (
            <div className="space-y-6 font-sans">
               <div className="flex flex-wrap border-b border-gray-800 gap-4 pb-2">
                {[
                  { id: '3.1.1', label: '3.1.1 Client Register' },
                  { id: '3.1.2', label: '3.1.2 Quotation Register' },
                  { id: '3.1.3', label: '3.1.3 Sales Quotations' },
                  { id: '3.1.4', label: '3.1.4 Business Development' },
                  { id: '3.1.5', label: '3.1.5 Supplier & Subcon Quotations' },
                  { id: '3.1.6', label: '3.1.6 Pre-qualification Documents' },
                ].map(subTab => (
                  <button
                    key={subTab.id}
                    onClick={() => setActiveSubTab(subTab.id)}
                    className={`text-xs font-semibold pb-2 border-b-2 transition-all ${
                      activeSubTab === subTab.id 
                        ? 'border-blue-500 text-blue-400 font-bold' 
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    {subTab.label}
                  </button>
                ))}
              </div>
              <div>
                {activeSubTab === '3.1.1' ? (
                  <ClientRegisterPanel />
                ) : activeSubTab === '3.1.2' ? (
                  <QuotationRegisterPanel />
                ) : (
                  <PlaceholderPanel title={
                    activeSubTab === '3.1.3' ? '3.1.3 Sales Quotations' :
                    activeSubTab === '3.1.4' ? '3.1.4 Business Development' :
                    activeSubTab === '3.1.5' ? '3.1.5 Supplier & Subcon Quotations' :
                    '3.1.6 Pre-qualification Documents'
                  } />
                )}
              </div>
            </div>
          ) : activeTab === '3.2' ? (
            <div className="space-y-6 font-sans">
               <div className="flex flex-wrap border-b border-gray-800 gap-4 pb-2">
                {[
                  { id: '3.2.1', label: '3.2.1 Projects Register' },
                  { id: '3.2.2', label: '3.2.2 Projects Reference' },
                  { id: '3.2.3', label: '3.2.3 Progress Claim Register' },
                  { id: '3.2.4', label: '3.2.4 Variation Order (VO) Register' },
                  { id: '3.2.5', label: '3.2.5 Projects List (Main & Quick)' },
                  { id: '3.2.6', label: '3.2.6 Projects Org Chart' },
                ].map(subTab => (
                  <button
                    key={subTab.id}
                    onClick={() => setActiveProjectsSubTab(subTab.id)}
                    className={`text-xs font-semibold pb-2 border-b-2 transition-all ${
                      activeProjectsSubTab === subTab.id 
                        ? 'border-blue-500 text-blue-400 font-bold' 
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    {subTab.label}
                  </button>
                ))}
              </div>
              <div>
                {activeProjectsSubTab === '3.2.1' ? (
                  <ProjectRegisterPanel />
                ) : (
                  <PlaceholderPanel title={
                    activeProjectsSubTab === '3.2.2' ? '3.2.2 Projects Reference' :
                    activeProjectsSubTab === '3.2.3' ? '3.2.3 Progress Claim Register' :
                    activeProjectsSubTab === '3.2.4' ? '3.2.4 Variation Order (VO) Register' :
                    activeProjectsSubTab === '3.2.5' ? '3.2.5 Projects List (Main & Quick)' :
                    '3.2.6 Projects Org Chart'
                  } />
                )}
              </div>
            </div>
          ) : activeTab === '3.3' ? (
            <div className="space-y-6 font-sans">
               <div className="flex flex-wrap border-b border-gray-800 gap-4 pb-2">
                {[
                  { id: '3.3.1', label: '3.3.1 WORK DEPLOYMENT SCHEDULE' },
                  { id: '3.3.2', label: '3.3.2 Project Namelist Submission' },
                  { id: '3.3.3', label: '3.3.3 Project SIC update' },
                  { id: '3.3.4', label: '3.3.4 Project Progress and Work done update' },
                  { id: '3.3.5', label: '3.3.5 Internal & External Supply manpower update' },
                  { id: '3.3.6', label: '3.3.6 Productivity Measures' },
                ].map(subTab => (
                  <button
                    key={subTab.id}
                    onClick={() => setActiveResourcesSubTab(subTab.id)}
                    className={`text-xs font-semibold pb-2 border-b-2 transition-all ${
                      activeResourcesSubTab === subTab.id 
                        ? 'border-blue-500 text-blue-400 font-bold' 
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    {subTab.label}
                  </button>
                ))}
              </div>
              <div>
                {activeResourcesSubTab === '3.3.1' ? (
                  <WorkDeploymentSchedulePanel />
                ) : (
                  <PlaceholderPanel title={
                    activeResourcesSubTab === '3.3.2' ? '3.3.2 Project Namelist Submission' :
                    activeResourcesSubTab === '3.3.3' ? '3.3.3 Project SIC update' :
                    activeResourcesSubTab === '3.3.4' ? '3.3.4 Project Progress and Work done update' :
                    activeResourcesSubTab === '3.3.5' ? '3.3.5 Internal & External Supply manpower update' :
                    '3.3.6 Productivity Measures'
                  } />
                )}
              </div>
            </div>
          ) : (
            <ActiveComponent />
          )}
        </div>
      </div>
    </div>
  );
}
