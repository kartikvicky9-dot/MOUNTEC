import React, { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, addDoc, orderBy } from 'firebase/firestore';
import { Check, X, Clock, CheckCircle2, ListTodo, Plus, Trash2, AlignLeft, Flag, GripVertical } from 'lucide-react';
import { useAppContext } from '../../../context/AppContext';
import { formatDate } from '../../../lib/dateUtils';

export default function TasksPanel() {
  const { isViewOnly } = useAppContext();
  const [tasks, setTasks] = useState<any[]>([]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [newAssignee, setNewAssignee] = useState('');
  const [newAssigneeEmail, setNewAssigneeEmail] = useState('');
  const [newDeadline, setNewDeadline] = useState('');
  const [newPriority, setNewPriority] = useState('medium');
  const [sendEmail, setSendEmail] = useState(false);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'tasks'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTasks(data);
    });
    return () => unsubscribe();
  }, []);

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    
    await addDoc(collection(db, 'tasks'), {
      title: newTaskTitle,
      description: newTaskDescription,
      assignee: newAssignee || 'Unassigned',
      assigneeEmail: newAssigneeEmail || '',
      deadline: newDeadline || null,
      priority: newPriority,
      status: 'todo',
      createdAt: Date.now()
    });
    
    if (sendEmail && newAssigneeEmail) {
      const subject = encodeURIComponent(`New Task Assigned: ${newTaskTitle}`);
      const body = encodeURIComponent(`Hello ${newAssignee || 'Team Member'},\n\nYou have been assigned a new task: "${newTaskTitle}".\n\n${newDeadline ? `Please complete this by: ${formatDate(newDeadline)}\n\n` : ''}Best regards.`);
      window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${newAssigneeEmail}&su=${subject}&body=${body}`, '_blank');
    }

    setNewTaskTitle('');
    setNewTaskDescription('');
    setNewAssignee('');
    setNewAssigneeEmail('');
    setNewDeadline('');
    setNewPriority('medium');
    setSendEmail(false);
  };

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    await updateDoc(doc(db, 'tasks', id), { 
      status: newStatus 
    });
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedTaskId(id);
    e.dataTransfer.setData('taskId', id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDrop = async (e: React.DragEvent, status: string) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('taskId');
    if (taskId) {
      await handleUpdateStatus(taskId, status);
      setDraggedTaskId(null);
    }
  };

  const handleDelete = async (id: string) => {
    await deleteDoc(doc(db, 'tasks', id));
  };

  const columns = [
    { id: 'todo', title: 'To Do', color: 'bg-slate-500' },
    { id: 'in_progress', title: 'In Progress', color: 'bg-blue-500' },
    { id: 'completed', title: 'Completed', color: 'bg-emerald-500' }
  ];

  const getPriorityColor = (priority: string) => {
    switch(priority) {
      case 'high': return 'text-red-400 bg-red-400/10 border-red-400/30';
      case 'medium': return 'text-amber-400 bg-amber-400/10 border-amber-400/30';
      case 'low': return 'text-blue-400 bg-blue-400/10 border-blue-400/30';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/30';
    }
  };

  return (
    <div className={`h-full flex flex-col space-y-6 ${isViewOnly ? "pointer-events-none opacity-90 select-none" : ""}`}>
      <div className="bg-[#141414] p-6 rounded-xl shadow-2xl border border-[#222] shrink-0">
        <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-6 flex items-center">
          <ListTodo className="w-5 h-5 mr-2" />
          Create New Task
        </h2>
        
        <form onSubmit={handleAddTask} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input 
              type="text" 
              placeholder="Task title..."
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-sm focus:outline-none focus:border-blue-500"
            />
            <div className="flex gap-4">
              <input 
                type="text" 
                placeholder="Assignee Name"
                value={newAssignee}
                onChange={(e) => setNewAssignee(e.target.value)}
                className="flex-1 bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-sm focus:outline-none focus:border-blue-500"
              />
              <input 
                type="email" 
                placeholder="Assignee Email"
                value={newAssigneeEmail}
                onChange={(e) => setNewAssigneeEmail(e.target.value)}
                className="flex-1 bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center bg-[#1A1A1A] border border-[#333] rounded px-2 focus-within:border-blue-500">
              <AlignLeft className="w-4 h-4 text-[#777] mr-2 shrink-0" />
              <input 
                type="text" 
                placeholder="Description (optional)"
                value={newTaskDescription}
                onChange={(e) => setNewTaskDescription(e.target.value)}
                className="w-full bg-transparent text-white p-2 text-sm focus:outline-none"
              />
            </div>
            <div className="flex items-center bg-[#1A1A1A] border border-[#333] rounded px-2 focus-within:border-blue-500">
              <Clock className="w-4 h-4 text-[#777] mr-2 shrink-0" />
              <input 
                type="datetime-local" 
                value={newDeadline}
                onChange={(e) => setNewDeadline(e.target.value)}
                className="w-full bg-transparent text-[#777] p-2 text-sm focus:outline-none [color-scheme:dark]"
              />
            </div>
            <div className="flex items-center bg-[#1A1A1A] border border-[#333] rounded px-2 focus-within:border-blue-500">
              <Flag className="w-4 h-4 text-[#777] mr-2 shrink-0" />
              <select 
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value)}
                className="w-full bg-transparent text-white p-2 text-sm focus:outline-none appearance-none"
              >
                <option value="low" className="bg-[#1A1A1A]">Low Priority</option>
                <option value="medium" className="bg-[#1A1A1A]">Medium Priority</option>
                <option value="high" className="bg-[#1A1A1A]">High Priority</option>
              </select>
            </div>
          </div>
          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center space-x-2 text-sm text-[#999] cursor-pointer hover:text-white transition-colors">
              <input 
                type="checkbox" 
                checked={sendEmail}
                onChange={(e) => setSendEmail(e.target.checked)}
                className="w-4 h-4 rounded border-[#333] bg-[#1A1A1A] text-blue-500 focus:ring-blue-500/50 focus:ring-offset-0"
              />
              <span>Send notification via Gmail</span>
            </label>
            <button 
              type="submit" 
              disabled={!newTaskTitle.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-black px-6 py-2 rounded text-xs font-bold uppercase flex items-center transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" /> Add Task
            </button>
          </div>
        </form>
      </div>

      {/* Kanban Board */}
      <div className="flex-1 flex gap-6 overflow-x-auto pb-4">
        {columns.map(column => (
          <div 
            key={column.id} 
            className="flex-1 min-w-[300px] flex flex-col bg-[#0A0A0A] rounded-xl border border-[#222] overflow-hidden shrink-0"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => handleDrop(e, column.id)}
          >
            <div className="p-4 border-b border-[#222] flex items-center justify-between bg-[#111]">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${column.color}`}></div>
                <h3 className="font-bold text-white uppercase tracking-wider text-sm">{column.title}</h3>
              </div>
              <span className="text-[#777] text-xs font-bold bg-[#1A1A1A] px-2 py-1 rounded">
                {tasks.filter(t => t.status === column.id || (column.id === 'todo' && t.status === 'pending')).length}
              </span>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {tasks
                .filter(task => task.status === column.id || (column.id === 'todo' && task.status === 'pending'))
                .map(task => (
                  <div 
                    key={task.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, task.id)}
                    className="bg-[#1A1A1A] border border-[#333] p-4 rounded-lg cursor-grab active:cursor-grabbing hover:border-[#555] transition-colors group"
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-[#555] group-hover:text-[#999] cursor-grab" />
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${getPriorityColor(task.priority)}`}>
                          {task.priority || 'medium'}
                        </span>
                      </div>
                      <button 
                        onClick={() => handleDelete(task.id)}
                        className="text-[#555] hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete Task"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <h4 className={`font-bold mb-1 ${task.status === 'completed' ? 'text-[#777] line-through' : 'text-white'}`}>
                      {task.title}
                    </h4>
                    
                    {task.description && (
                      <p className="text-xs text-[#999] mb-4 line-clamp-3">{task.description}</p>
                    )}
                    
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-[#2A2A2A]">
                      <div className="flex items-center gap-2" title={task.assigneeEmail || task.assignee}>
                        <div className="w-6 h-6 rounded-full bg-blue-500/20 flex items-center justify-center text-[10px] font-bold text-blue-500 shrink-0">
                          {(task.assignee || 'U').charAt(0).toUpperCase()}
                        </div>
                        <span className="text-xs text-[#999] truncate max-w-[100px]">{task.assignee || 'Unassigned'}</span>
                      </div>
                      
                      {task.deadline && (
                        <div className={`flex items-center text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded ${new Date(task.deadline).getTime() < Date.now() && task.status !== 'completed' ? 'text-red-400 bg-red-400/10' : 'text-[#777] bg-[#222]'}`}>
                          <Clock className="w-3 h-3 mr-1 shrink-0" />
                          {formatDate(task.deadline)}
                        </div>
                      )}
                    </div>
                  </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

