import React from 'react';

export default function METManagementPanel() {
  return (
    <div className="p-6 bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold mb-6">Materials, Equipment & Tools (MET) Management</h2>
      <div className="space-y-4">
        <div className="bg-gray-800 p-4 rounded border border-gray-700">Inventory Tracking</div>
        <div className="bg-gray-800 p-4 rounded border border-gray-700">Equipment Maintenance Schedules</div>
        <div className="bg-gray-800 p-4 rounded border border-gray-700">Tool Deployment & Logistics</div>
      </div>
    </div>
  );
}
