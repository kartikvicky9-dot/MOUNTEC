import React from 'react';
import SubFlowChart from '../SubFlowChart';

export default function OperationsFlowChart() {
  const steps = [
    { id: '3.1', title: '3.1 SALES (QUOTATIONS, BUSINESS DEVELOPMENT)' },
    { id: '3.2', title: '3.2 PROJECTS (REGISTER, REFERENCE, CLAIMS, VARIATION ORDERS, LIST)' },
    { id: '3.3', title: '3.3 RESOURCES MANAGEMENT (DEPLOYMENT, NAMELIST, PRODUCTIVITY)' },
    { id: '3.4', title: '3.4 TECHNICAL (DRAWINGS, MAINTENANCE)' },
    { id: '3.5', title: '3.5 PURCHASE RELATED (SUPPLIERS, REQUISITION)' },
    { id: '3.6', title: '3.6 WORK & DELIVERY ORDER RELATED' },
    { id: '3.7', title: '3.7 LETTER REGISTRATION' },
    { id: '3.8', title: '3.8 CLIENT/SUPPLIER/VENDOR LIST' },
    { id: '3.9', title: '3.9 TRANSPORTATION RELATED' },
    { id: '3.10', title: '3.10 LEGAL ACTION' },
    { id: '3.11', title: '3.11 ADDITIONAL PRODUCT & SERVICES' },
    { id: '3.12', title: '3.12 METC MANAGEMENT' },
  ];
  return <SubFlowChart title="OPERATIONS & DELIVERY FLOW" steps={steps} />;
}
