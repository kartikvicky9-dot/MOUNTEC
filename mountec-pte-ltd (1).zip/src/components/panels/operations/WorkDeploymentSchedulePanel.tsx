import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, Search, Filter, Download, FileSpreadsheet, Trash2, Edit2, 
  Calendar, Clock, Briefcase, User, X, RefreshCw, Check, Upload, ArrowRight,
  ChevronLeft, ChevronRight, AlertTriangle, Moon, Sun, Shield
} from 'lucide-react';
import { collection, addDoc, getDocs, onSnapshot, doc, updateDoc, deleteDoc, writeBatch, query, orderBy } from 'firebase/firestore';
import { db, auth, googleSignIn, clearCachedToken } from '../../../lib/firebase';
import { Worker, Project, WorkDeployment, DeploymentSegment } from '../../../types';
import { initialWorkers } from '../../../data/workers';
import { SEED_PROJECTS } from '../../../data/projects_seed';

// Static default/seed deployments for the ledger
const DEFAULT_DEPLOYMENTS: Omit<WorkDeployment, 'id'>[] = [
  {
    sNo: '1',
    date: '15-Jul-2026',
    employeeId: 'ME-012',
    employeeName: 'Kshtriy Vicky Kartik',
    projectRef: 'M-2601',
    projectName: 'Tuas West Extension Manpower Supply',
    timeIn: '08:00',
    timeOut: '17:00',
    totalWorkingHours: 8.0,
    shift: 'Day Shift',
    status: 'Present',
    remarks: 'Installed structural frames and aligned primary brackets'
  },
  {
    sNo: '2',
    date: '15-Jul-2026',
    employeeId: 'ME-005',
    employeeName: 'Ramu Elumalai',
    projectRef: 'M-2601',
    projectName: 'Tuas West Extension Manpower Supply',
    timeIn: '08:00',
    timeOut: '17:00',
    totalWorkingHours: 8.0,
    shift: 'Day Shift',
    status: 'Present',
    remarks: 'Routed high-tension electrical conduits and wire trays'
  },
  {
    sNo: '3',
    date: '15-Jul-2026',
    employeeId: 'ME-023',
    employeeName: 'Ahmed Sujan',
    projectRef: 'Q-2601',
    projectName: 'Changi T5 Cable Installation Works',
    timeIn: '08:30',
    timeOut: '18:30',
    totalWorkingHours: 9.0,
    shift: 'Day Shift',
    status: 'Present',
    remarks: 'Assisted in cable drum setup and duct routing validation'
  },
  {
    sNo: '4',
    date: '16-Jul-2026',
    employeeId: 'ME-012',
    employeeName: 'Kshtriy Vicky Kartik',
    projectRef: 'M-2601',
    projectName: 'Tuas West Extension Manpower Supply',
    timeIn: '08:00',
    timeOut: '17:00',
    totalWorkingHours: 8.0,
    shift: 'Day Shift',
    status: 'Present',
    remarks: 'Welding support for structural bracket reinforcements'
  },
  {
    sNo: '5',
    date: '16-Jul-2026',
    employeeId: 'ME-028',
    employeeName: 'Rathinasamy Ayyappan',
    projectRef: 'NPR-2601',
    projectName: 'Woodlands Checkpoint Expansion Phase 1',
    timeIn: '20:00',
    timeOut: '05:00',
    totalWorkingHours: 8.0,
    shift: 'Night Shift',
    status: 'Present',
    remarks: 'Installed protective steel hoarding plates around perimeter'
  },
  {
    sNo: '6',
    date: '17-Jul-2026',
    employeeId: 'ME-009',
    employeeName: 'Panneer Selvam Venkatesan',
    projectRef: 'M-2602',
    projectName: 'Jurong Island Piping Fabrication',
    timeIn: '08:00',
    timeOut: '17:00',
    totalWorkingHours: 8.0,
    shift: 'Day Shift',
    status: 'Present',
    remarks: 'Weld joint grinding and alignment of high-pressure tubes'
  },
  {
    sNo: '7',
    date: '17-Jul-2026',
    employeeId: 'ME-026',
    employeeName: 'Hossain Mohammad Rakib',
    projectRef: 'NPR-2601',
    projectName: 'Woodlands Checkpoint Expansion Phase 1',
    timeIn: '08:00',
    timeOut: '12:00',
    totalWorkingHours: 4.0,
    shift: 'Day Shift',
    status: 'MC',
    remarks: 'Sought medical leave due to high fever'
  }
];

const SEED_PROJECTS_FALLBACK = SEED_PROJECTS;

const parseDDMMMYYYYToYYYYMMDD = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) {
    if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) return dateStr;
    return '';
  }
  const day = parts[0].padStart(2, '0');
  const monthStr = parts[1];
  const year = parts[2];
  
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthIndex = months.findIndex(m => m.toLowerCase() === monthStr.toLowerCase());
  if (monthIndex === -1) return '';
  
  const month = String(monthIndex + 1).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const formatYYYYMMDDToDDMMMYYYY = (dateStr: string): string => {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const year = parts[0];
  const monthStr = parts[1];
  const day = parts[2].padStart(2, '0');
  
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthIndex = parseInt(monthStr, 10) - 1;
  const monthName = months[monthIndex] || 'Jan';
  
  return `${day}-${monthName}-${year}`;
};

const getWorkerRates = (worker: Worker | undefined) => {
  // Standard defaults
  let baseHourly = 12.50; // S$12.50/hr standard fallback
  let otHourly = 18.75;  // 1.5x fallback

  if (worker) {
    if (worker.baseSalary !== undefined && worker.baseSalary !== null) {
      const baseSalaryStr = String(worker.baseSalary);
      const parsedBase = parseFloat(baseSalaryStr.replace(/[^0-9.]/g, ''));
      if (!isNaN(parsedBase) && parsedBase > 0) {
        if (baseSalaryStr.includes('/hr') || baseSalaryStr.includes('hour')) {
          baseHourly = parsedBase;
        } else {
          // Assume monthly salary, standard working hours is 208 hrs/month
          baseHourly = parseFloat((parsedBase / 208).toFixed(2));
        }
      }
    }
    if (worker.overtimeRate !== undefined && worker.overtimeRate !== null) {
      const overtimeRateStr = String(worker.overtimeRate);
      const parsedOt = parseFloat(overtimeRateStr.replace(/[^0-9.]/g, ''));
      if (!isNaN(parsedOt) && parsedOt > 0) {
        otHourly = parsedOt;
      } else {
        otHourly = parseFloat((baseHourly * 1.5).toFixed(2));
      }
    } else {
      otHourly = parseFloat((baseHourly * 1.5).toFixed(2));
    }
  }

  return { baseHourly, otHourly };
};

export default function WorkDeploymentSchedulePanel() {
  const [deployments, setDeployments] = useState<WorkDeployment[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Sub-tabs inside Work Deployment Schedule Panel
  const [currentPanelTab, setCurrentPanelTab] = useState<'ledger' | 'preplan' | 'timesheets' | 'analytics'>('ledger');

  // Timesheet specific selections
  const [timesheetWorkerId, setTimesheetWorkerId] = useState('');
  const [timesheetMonth, setTimesheetMonth] = useState('2026-07');
  const [isSyncingTimesheet, setIsSyncingTimesheet] = useState(false);

  // Preplan Specific State
  const [preplanDate, setPreplanDate] = useState(() => {
    const tom = new Date();
    tom.setDate(tom.getDate() + 1);
    return tom.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
  });
  const [cloneSourceDate, setCloneSourceDate] = useState<string>('');

  const pastDatesWithAllocations = useMemo(() => {
    const dates = Array.from(new Set(deployments.map(d => d.date))).filter(Boolean);
    return dates
      .filter(d => d !== preplanDate)
      .sort((a, b) => parseDateStringToTime(b) - parseDateStringToTime(a));
  }, [deployments, preplanDate]);

  // Sync default cloneSourceDate to the actual latest date
  useEffect(() => {
    if (pastDatesWithAllocations.length > 0) {
      if (!cloneSourceDate || !pastDatesWithAllocations.includes(cloneSourceDate)) {
        setCloneSourceDate(pastDatesWithAllocations[0]);
      }
    }
  }, [pastDatesWithAllocations, cloneSourceDate]);

  // Filter States
  const [search, setSearch] = useState('');
  const [shiftFilter, setShiftFilter] = useState<'All' | 'Day Shift' | 'Night Shift'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Present' | 'MC' | 'Absent' | 'Off Day'>('All');
  const [dateFilter, setDateFilter] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [currentDeployment, setCurrentDeployment] = useState<WorkDeployment | null>(null);

  // Import Dialog
  const [showImportModal, setShowImportModal] = useState(false);
  const [importStatus, setImportStatus] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [scannedRecords, setScannedRecords] = useState<Omit<WorkDeployment, 'id'>[]>([]);
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [driveFiles, setDriveFiles] = useState<any[]>([]);
  const [showDrivePicker, setShowDrivePicker] = useState(false);
  const [bulkCsvText, setBulkCsvText] = useState('');
  const [activeImportTab, setActiveImportTab] = useState<'drive' | 'csv'>('drive');

  // Form Fields
  const [formDate, setFormDate] = useState('');
  const [formEmployeeId, setFormEmployeeId] = useState('');
  const [formEmployeeName, setFormEmployeeName] = useState('');
  const [isMultiDeploy, setIsMultiDeploy] = useState(false);
  const [formSelectedEmployeeIds, setFormSelectedEmployeeIds] = useState<string[]>([]);
  const [workerSearchTerm, setWorkerSearchTerm] = useState('');
  const [hideAlreadyDeployed, setHideAlreadyDeployed] = useState(true);
  const [formProjectRef, setFormProjectRef] = useState('');
  const [formProjectName, setFormProjectName] = useState('');
  const [formTimeIn, setFormTimeIn] = useState('08:00');
  const [formTimeOut, setFormTimeOut] = useState('17:00');
  const [formBreakMinutes, setFormBreakMinutes] = useState<number>(60);
  const [formWorkingHours, setFormWorkingHours] = useState<number>(8.0);
  const [formShift, setFormShift] = useState('Day Shift');
  const [formStatus, setFormStatus] = useState('Present');
  const [formRemarks, setFormRemarks] = useState('');
  const [formSegments, setFormSegments] = useState<DeploymentSegment[]>([]);

  // Error notifications
  const [errorMsg, setErrorMsg] = useState('');

  // Already deployed worker IDs for the selected date
  const deployedWorkerIdsForDate = useMemo(() => {
    return new Set(
      deployments
        .filter(d => d.date === formDate && d.id !== (currentDeployment?.id || ''))
        .map(d => d.employeeId)
        .filter(Boolean)
    );
  }, [deployments, formDate, currentDeployment]);

  // Auto load Token
  useEffect(() => {
    try {
      const storedToken = sessionStorage.getItem('mountec_google_token');
      if (storedToken) {
        setGoogleToken(storedToken);
      }
    } catch (e) {}
  }, []);

  // Fetch Workers & Projects list for quick auto-completes
  useEffect(() => {
    // Listen to workers
    const unsubWorkers = onSnapshot(collection(db, 'workers'), (snapshot) => {
      const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Worker));
      if (list.length > 0) {
        setWorkers(list);
      } else {
        // Fallback to static
        const mappedStatic = initialWorkers.map((w, idx) => ({ id: `static-${idx}`, ...w } as Worker));
        setWorkers(mappedStatic);
      }
    }, (err) => {
      console.warn("Workers fetch failed, falling back to static:", err);
      const mappedStatic = initialWorkers.map((w, idx) => ({ id: `static-${idx}`, ...w } as Worker));
      setWorkers(mappedStatic);
    });

    // Listen to projects
    const unsubProjects = onSnapshot(collection(db, 'projects'), (snapshot) => {
      const list = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      if (list.length > 0) {
        setProjects(list);
      } else {
        setProjects(SEED_PROJECTS_FALLBACK);
      }
    }, (err) => {
      console.warn("Projects fetch failed, falling back to defaults:", err);
      setProjects(SEED_PROJECTS_FALLBACK);
    });

    return () => {
      unsubWorkers();
      unsubProjects();
    };
  }, []);

  // Sync / Read real-time deployments
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'work_deployments'), (snapshot) => {
      const list: WorkDeployment[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as WorkDeployment);
      });
      
      // Sort by date descending (and sNo descending if matching)
      list.sort((a, b) => {
        const dateA = parseDateStringToTime(a.date);
        const dateB = parseDateStringToTime(b.date);
        if (dateB !== dateA) return dateB - dateA;
        return (parseInt(b.sNo || '0') || 0) - (parseInt(a.sNo || '0') || 0);
      });

      if (list.length === 0) {
        // Automatically seed Firestore with default seed deployments
        console.log("Seeding default deployments to Firestore...");
        const batch = writeBatch(db);
        const seeded = enrichSeedData(DEFAULT_DEPLOYMENTS);
        seeded.forEach((dep) => {
          const docRef = doc(collection(db, 'work_deployments'));
          const { id, ...data } = dep; // exclude temporary ID
          batch.set(docRef, {
            ...data,
            createdAt: Date.now()
          });
        });
        batch.commit()
          .then(() => {
            console.log("Successfully seeded DEFAULT_DEPLOYMENTS to Firestore.");
          })
          .catch((err) => {
            console.warn("Failed to seed deployments to Firestore:", err);
            // Fallback locally
            setDeployments(seeded);
            localStorage.setItem('mountec_local_deployments', JSON.stringify(seeded));
          });
      } else {
        setDeployments(list);
      }
      setLoading(false);
    }, (err) => {
      console.warn("Firestore work_deployments failed, using localStorage:", err);
      const local = localStorage.getItem('mountec_local_deployments');
      if (local) {
        try {
          setDeployments(JSON.parse(local));
        } catch (e) {
          setDeployments(enrichSeedData(DEFAULT_DEPLOYMENTS));
        }
      } else {
        const seeded = enrichSeedData(DEFAULT_DEPLOYMENTS);
        setDeployments(seeded);
        localStorage.setItem('mountec_local_deployments', JSON.stringify(seeded));
      }
      setLoading(false);
    });

    return () => unsub();
  }, []);

  // Simple date parser helper: '15-Jul-2026' -> unix time
  const parseDateStringToTime = (dateStr: string) => {
    if (!dateStr) return 0;
    const pts = dateStr.split('-');
    if (pts.length !== 3) return 0;
    const months: { [key: string]: number } = {
      jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
      jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
    };
    const day = parseInt(pts[0], 10);
    const month = months[pts[1].toLowerCase()] ?? 0;
    const year = parseInt(pts[2], 10);
    return new Date(year, month, day).getTime();
  };

  const enrichSeedData = (seed: Omit<WorkDeployment, 'id'>[]): WorkDeployment[] => {
    return seed.map((item, idx) => ({
      id: `seed-deploy-${idx}`,
      ...item
    }));
  };

  const calculateSegmentHours = (tIn: string, tOut: string, breakMins: number): number => {
    if (!tIn || !tOut) return 0;
    try {
      const [hIn, mIn] = tIn.split(':').map(Number);
      const [hOut, mOut] = tOut.split(':').map(Number);
      if (isNaN(hIn) || isNaN(mIn) || isNaN(hOut) || isNaN(mOut)) return 0;
      let rawDiffMinutes = (hOut * 60 + mOut) - (hIn * 60 + mIn);
      if (rawDiffMinutes < 0) {
        rawDiffMinutes += 24 * 60;
      }
      let totalMinutes = rawDiffMinutes - breakMins;
      if (totalMinutes < 0) totalMinutes = 0;
      return parseFloat((totalMinutes / 60).toFixed(2));
    } catch (e) {
      return 0;
    }
  };

  const handleAddSegment = () => {
    let defaultTimeIn = '08:00';
    let defaultTimeOut = '17:00';
    if (formSegments.length > 0) {
      const lastSeg = formSegments[formSegments.length - 1];
      defaultTimeIn = lastSeg.timeOut;
      try {
        const [h, m] = lastSeg.timeOut.split(':').map(Number);
        if (!isNaN(h) && !isNaN(m)) {
          const nextH = (h + 4) % 24;
          defaultTimeOut = `${String(nextH).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        }
      } catch (e) {}
    }
    setFormSegments([
      ...formSegments,
      {
        projectRef: '',
        projectName: '',
        timeIn: defaultTimeIn,
        timeOut: defaultTimeOut,
        breakMinutes: 0,
        workingHours: calculateSegmentHours(defaultTimeIn, defaultTimeOut, 0),
        remarks: '',
        transportClaim: 0
      }
    ]);
  };

  const handleRemoveSegment = (idx: number) => {
    setFormSegments(formSegments.filter((_, i) => i !== idx));
  };

  const handleSegmentProjectChange = (idx: number, refValue: string) => {
    setFormSegments(prev => prev.map((seg, i) => {
      if (i !== idx) return seg;
      if (refValue === 'NON-PROJECT') {
        return {
          ...seg,
          projectRef: 'NON-PROJECT',
          projectName: 'Non-Project Duties'
        };
      }
      const matched = projects.find(p => p.projectRef === refValue);
      return {
        ...seg,
        projectRef: refValue,
        projectName: matched ? matched.name : ''
      };
    }));
  };

  const handleSegmentProjectNameChange = (idx: number, nameValue: string) => {
    setFormSegments(prev => prev.map((seg, i) => {
      if (i !== idx) return seg;
      return {
        ...seg,
        projectName: nameValue
      };
    }));
  };

  const handleSegmentTimeChange = (idx: number, field: keyof DeploymentSegment, value: any) => {
    setFormSegments(prev => prev.map((seg, i) => {
      if (i !== idx) return seg;
      const updated = { ...seg, [field]: value };
      if (field === 'timeIn' || field === 'timeOut' || field === 'breakMinutes') {
        updated.workingHours = calculateSegmentHours(updated.timeIn, updated.timeOut, Number(updated.breakMinutes) || 0);
      }
      return updated;
    }));
  };

  // Auto calculate total working hours based on Time In, Time Out, and Break Duration
  useEffect(() => {
    if (!formTimeIn || !formTimeOut) return;
    try {
      const [hIn, mIn] = formTimeIn.split(':').map(Number);
      const [hOut, mOut] = formTimeOut.split(':').map(Number);
      
      if (isNaN(hIn) || isNaN(mIn) || isNaN(hOut) || isNaN(mOut)) return;
      
      let rawDiffMinutes = (hOut * 60 + mOut) - (hIn * 60 + mIn);
      if (rawDiffMinutes < 0) {
        // Overnight shift (crosses midnight)
        rawDiffMinutes += 24 * 60;
      }
      
      let totalMinutes = rawDiffMinutes - formBreakMinutes;
      if (totalMinutes < 0) totalMinutes = 0;
      
      const hours = parseFloat((totalMinutes / 60).toFixed(2));
      setFormWorkingHours(hours);
    } catch (e) {
      console.warn("Failed hours calculation", e);
    }
  }, [formTimeIn, formTimeOut, formBreakMinutes]);

  // Sync user values if a worker is selected
  const handleWorkerSelect = (eId: string) => {
    setFormEmployeeId(eId);
    const matched = workers.find(w => (w.employeeId || '') === eId);
    if (matched) {
      setFormEmployeeName(matched.nameOfWorker || matched.name || '');
    }
  };

  const handleWorkerNameSelect = (name: string) => {
    setFormEmployeeName(name);
    const matched = workers.find(w => (w.nameOfWorker || w.name || '') === name);
    if (matched) {
      setFormEmployeeId(matched.employeeId || '');
    }
  };

  // Sync project values
  const handleProjectRefSelect = (ref: string) => {
    setFormProjectRef(ref);
    const matched = projects.find(p => (p.projectRef || '') === ref);
    if (matched) {
      setFormProjectName(matched.name || '');
    }
  };

  const handleProjectNameSelect = (name: string) => {
    setFormProjectName(name);
    const matched = projects.find(p => (p.name || '') === name);
    if (matched) {
      setFormProjectRef(matched.projectRef || '');
    }
  };

  // Open creation modal
  const openAddModal = () => {
    setModalMode('add');
    setCurrentDeployment(null);
    setErrorMsg('');
    setIsMultiDeploy(false);
    setFormSelectedEmployeeIds([]);
    setWorkerSearchTerm('');
    
    // Default today formatted 18-Jul-2026
    const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
    setFormDate(todayStr);
    setFormEmployeeId('');
    setFormEmployeeName('');
    setFormProjectRef('');
    setFormProjectName('');
    setFormTimeIn('08:00');
    setFormTimeOut('17:00');
    setFormBreakMinutes(60);
    setFormWorkingHours(8.0);
    setFormShift('Day Shift');
    setFormStatus('Present');
    setFormRemarks('');
    setFormSegments([{
      projectRef: '',
      projectName: '',
      timeIn: '08:00',
      timeOut: '17:00',
      breakMinutes: 60,
      workingHours: 8.0,
      remarks: '',
      transportClaim: 0
    }]);
    
    setIsModalOpen(true);
  };

  // Open edit modal
  const openEditModal = (dep: WorkDeployment) => {
    setModalMode('edit');
    setCurrentDeployment(dep);
    setErrorMsg('');
    setIsMultiDeploy(false);
    setFormSelectedEmployeeIds([]);
    setWorkerSearchTerm('');
    
    setFormDate(dep.date);
    setFormEmployeeId(dep.employeeId);
    setFormEmployeeName(dep.employeeName);
    setFormProjectRef(dep.projectRef);
    setFormProjectName(dep.projectName);
    setFormTimeIn(dep.timeIn);
    setFormTimeOut(dep.timeOut);
    setFormBreakMinutes(60); // Default to standard 60 min, the auto calc updates it
    setFormWorkingHours(dep.totalWorkingHours);
    setFormShift(dep.shift || 'Day Shift');
    setFormStatus(dep.status || 'Present');
    setFormRemarks(dep.remarks || '');
    if (dep.segments && dep.segments.length > 0) {
      setFormSegments(dep.segments.map(s => ({
        projectRef: s.projectRef || '',
        projectName: s.projectName || '',
        timeIn: s.timeIn || '08:00',
        timeOut: s.timeOut || '17:00',
        breakMinutes: s.breakMinutes ?? 0,
        workingHours: s.workingHours ?? 0,
        remarks: s.remarks || '',
        transportClaim: s.transportClaim ?? 0
      })));
    } else {
      setFormSegments([{
        projectRef: dep.projectRef || '',
        projectName: dep.projectName || '',
        timeIn: dep.timeIn || '08:00',
        timeOut: dep.timeOut || '17:00',
        breakMinutes: 60,
        workingHours: dep.totalWorkingHours || 0,
        remarks: dep.remarks || '',
        transportClaim: dep.transportClaim ?? 0
      }]);
    }
    
    setIsModalOpen(true);
  };

  // Write Deployment back to DB
  const handleSaveDeployment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (modalMode === 'add' && isMultiDeploy) {
      if (formSelectedEmployeeIds.length === 0) {
        setErrorMsg("Please select at least one Employee to deploy.");
        return;
      }
    } else {
      if (!formEmployeeId || !formEmployeeName) {
        setErrorMsg("Please ensure Employee Details are selected.");
        return;
      }
    }

    if (formSegments.length === 0) {
      setErrorMsg("Please add at least one project/work segment.");
      return;
    }

    // Verify segments
    const invalidSegment = formSegments.find(s => !s.projectRef || !s.timeIn || !s.timeOut);
    if (invalidSegment) {
      setErrorMsg("Please ensure all work segments have a selected Project Ref and valid Time In & Time Out.");
      return;
    }

    // Compile top-level fields from segments for backwards compatibility and easy display
    const compiledProjectRef = formSegments.map(s => s.projectRef).join(', ');
    const compiledProjectName = formSegments.map(s => s.projectName).join(', ');
    const compiledTimeIn = formSegments[0].timeIn;
    const compiledTimeOut = formSegments[formSegments.length - 1].timeOut;
    const compiledTotalHours = parseFloat(formSegments.reduce((sum, s) => sum + (parseFloat(String(s.workingHours)) || 0), 0).toFixed(2));
    const compiledRemarks = formSegments.map(s => s.remarks).filter(Boolean).join(' | ');
    const compiledTransportClaim = parseFloat(formSegments.reduce((sum, s) => sum + (parseFloat(String(s.transportClaim)) || 0), 0).toFixed(2));

    // Calculate optimistic state update
    let updatedDeployments: WorkDeployment[] = [...deployments];
    
    if (modalMode === 'add') {
      let nextSNo = Math.max(...deployments.map(d => parseInt(d.sNo || '0') || 0), 0) + 1;
      const workersToDeploy = isMultiDeploy 
        ? formSelectedEmployeeIds.map(id => workers.find(w => w.employeeId === id)).filter(Boolean) as Worker[]
        : [{ employeeId: formEmployeeId, nameOfWorker: formEmployeeName } as Worker];

      const payloadsToSave: Omit<WorkDeployment, 'id'>[] = [];

      workersToDeploy.forEach((w) => {
        const payload: Omit<WorkDeployment, 'id'> = {
          sNo: String(nextSNo++),
          date: formDate,
          employeeId: w.employeeId || '',
          employeeName: w.nameOfWorker || w.name || '',
          projectRef: compiledProjectRef,
          projectName: compiledProjectName,
          timeIn: compiledTimeIn,
          timeOut: compiledTimeOut,
          totalWorkingHours: compiledTotalHours,
          shift: formShift,
          status: formStatus,
          remarks: compiledRemarks,
          segments: formSegments,
          transportClaim: compiledTransportClaim,
          createdAt: Date.now()
        };
        payloadsToSave.push(payload);
        
        const tempId = `temp-${Date.now()}-${w.employeeId}`;
        const optimisticAdded = { id: tempId, ...payload } as WorkDeployment;
        updatedDeployments = [optimisticAdded, ...updatedDeployments];
      });

      // Perform optimistic update instantly
      setDeployments(updatedDeployments);
      localStorage.setItem('mountec_local_deployments', JSON.stringify(updatedDeployments));
      
      // Close modal immediately so the user sees instant success
      setIsModalOpen(false);

      // Sync project costs instantly with optimistic deployments
      autoSyncCosts(updatedDeployments, workers, projects);

      // Perform Firestore saving in the background
      try {
        const batch = writeBatch(db);
        payloadsToSave.forEach((payload) => {
          const docRef = doc(collection(db, 'work_deployments'));
          batch.set(docRef, payload);
        });
        await batch.commit();
      } catch (dbErr) {
        console.warn("Firestore background write failed, but local copy is preserved:", dbErr);
      }
    } else if (modalMode === 'edit' && currentDeployment) {
      const payload: Omit<WorkDeployment, 'id'> = {
        sNo: currentDeployment.sNo,
        date: formDate,
        employeeId: formEmployeeId,
        employeeName: formEmployeeName,
        projectRef: compiledProjectRef,
        projectName: compiledProjectName,
        timeIn: compiledTimeIn,
        timeOut: compiledTimeOut,
        totalWorkingHours: compiledTotalHours,
        shift: formShift,
        status: formStatus,
        remarks: compiledRemarks,
        segments: formSegments,
        transportClaim: compiledTransportClaim,
        createdAt: Date.now()
      };

      updatedDeployments = deployments.map(d => d.id === currentDeployment.id ? { ...d, ...payload } as WorkDeployment : d);
      
      // Perform optimistic update instantly
      setDeployments(updatedDeployments);
      localStorage.setItem('mountec_local_deployments', JSON.stringify(updatedDeployments));
      
      // Close modal immediately so the user sees instant success
      setIsModalOpen(false);

      // Sync project costs instantly with optimistic deployments
      autoSyncCosts(updatedDeployments, workers, projects);

      try {
        await updateDoc(doc(db, 'work_deployments', currentDeployment.id), payload);
      } catch (dbErr) {
        console.warn("Firestore background write failed, but local copy is preserved:", dbErr);
      }
    }
  };

  const calculateProjectCosts = (deploymentsList: WorkDeployment[], workersList: Worker[]) => {
    const projectCosts: Record<string, { totalHours: number; totalCost: number; segmentsCount: number }> = {};

    // Group deployments by worker and date to calculate daily standard & OT hours correctly
    const workerDailyGroup: Record<string, Record<string, WorkDeployment[]>> = {};
    deploymentsList.forEach(d => {
      if (!d.employeeId || !d.date) return;
      if (!workerDailyGroup[d.employeeId]) {
        workerDailyGroup[d.employeeId] = {};
      }
      if (!workerDailyGroup[d.employeeId][d.date]) {
        workerDailyGroup[d.employeeId][d.date] = [];
      }
      workerDailyGroup[d.employeeId][d.date].push(d);
    });

    // For each worker and each day:
    Object.entries(workerDailyGroup).forEach(([employeeId, days]) => {
      const worker = workersList.find(w => w.employeeId === employeeId);
      const { baseHourly, otHourly } = getWorkerRates(worker);

      Object.entries(days).forEach(([date, dayDeployments]) => {
        // Collect all segments on this day for this worker
        const segmentsList: { projectRef: string; hours: number }[] = [];
        dayDeployments.forEach(d => {
          if (d.segments && Array.isArray(d.segments) && d.segments.length > 0) {
            d.segments.forEach(seg => {
              const segHours = parseFloat(String(seg.workingHours || 0)) || 0;
              if (seg.projectRef && segHours > 0) {
                segmentsList.push({ projectRef: seg.projectRef, hours: segHours });
              }
            });
          } else if (d.projectRef) {
            const totHours = parseFloat(String(d.totalWorkingHours || 0)) || 0;
            if (totHours > 0) {
              // Backward compatibility for single-project deployments
              segmentsList.push({ projectRef: d.projectRef, hours: totHours });
            }
          }
        });

        const dayTotalHours = segmentsList.reduce((sum, s) => sum + s.hours, 0);
        if (dayTotalHours <= 0) return;

        const dayStandardHours = Math.min(dayTotalHours, 8);
        const dayOtHours = Math.max(0, dayTotalHours - 8);

        // Apportion standard/OT hours to each segment's project cost
        segmentsList.forEach(seg => {
          const proportion = seg.hours / dayTotalHours;
          const segStandardHours = dayStandardHours * proportion;
          const segOtHours = dayOtHours * proportion;

          const cost = (segStandardHours * baseHourly) + (segOtHours * otHourly);

          if (!projectCosts[seg.projectRef]) {
            projectCosts[seg.projectRef] = { totalHours: 0, totalCost: 0, segmentsCount: 0 };
          }
          projectCosts[seg.projectRef].totalHours += seg.hours;
          projectCosts[seg.projectRef].totalCost += cost;
          projectCosts[seg.projectRef].segmentsCount += 1;
        });
      });
    });

    return projectCosts;
  };

  const autoSyncCosts = async (
    currentDeps: WorkDeployment[],
    currentWorkers: Worker[],
    currentProjs: any[]
  ) => {
    try {
      const computedCosts = calculateProjectCosts(currentDeps, currentWorkers);
      const batch = writeBatch(db);
      let updatedCount = 0;

      for (const proj of currentProjs) {
        const costInfo = computedCosts[proj.projectRef];
        const totalCost = costInfo ? costInfo.totalCost : 0;
        const roundedCost = parseFloat(totalCost.toFixed(2));

        if (proj.actualWork !== roundedCost) {
          const docId = proj.id;
          if (docId && !docId.startsWith('static-')) {
            const docRef = doc(db, 'projects', docId);
            const projSum = parseFloat(String(proj.sum || 0)) || 0;
            batch.update(docRef, { 
              actualWork: roundedCost,
              actualWorkPercent: projSum > 0 ? Math.min(100, parseFloat(((roundedCost / projSum) * 100).toFixed(1))) : proj.actualWorkPercent || 0
            });
            updatedCount++;
          }
        }
      }

      if (updatedCount > 0) {
        await batch.commit();
        console.log(`Auto-synchronized daily labor costs for ${updatedCount} active projects.`);
      }
    } catch (err) {
      console.warn("Auto-sync of project labor costs failed:", err);
    }
  };

  const handleSyncCostsToProjects = async () => {
    setIsSyncingTimesheet(true);
    try {
      const computedCosts = calculateProjectCosts(deployments, workers);
      const batch = writeBatch(db);
      let updatedCount = 0;

      for (const proj of projects) {
        const costInfo = computedCosts[proj.projectRef];
        if (costInfo && costInfo.totalCost > 0) {
          const docId = proj.id;
          if (docId && !docId.startsWith('static-')) {
            const roundedCost = parseFloat(costInfo.totalCost.toFixed(2));
            const docRef = doc(db, 'projects', docId);
            const projSum = parseFloat(String(proj.sum || 0)) || 0;
            batch.update(docRef, { 
              actualWork: roundedCost,
              actualWorkPercent: projSum > 0 ? Math.min(100, parseFloat(((roundedCost / projSum) * 100).toFixed(1))) : proj.actualWorkPercent || 0
            });
            updatedCount++;
          }
        }
      }

      if (updatedCount > 0) {
        await batch.commit();
        alert(`Successfully synchronized daily deployment labor costs! Updated ${updatedCount} active projects in Project Register with cumulative labor expenses.`);
      } else {
        alert("No active projects in database found to update with deployment labor cost records.");
      }
    } catch (err: any) {
      console.error("Failed to sync project costs:", err);
      alert(`Failed to sync project costs: ${err.message || String(err)}`);
    } finally {
      setIsSyncingTimesheet(false);
    }
  };

  // Clone deployments from a past date to preplanDate
  const handleCloneFromPastDate = (sourceDate: string, overwrite: boolean) => {
    if (!sourceDate) return;
    const sourceAllocations = deployments.filter(d => d.date === sourceDate);
    if (sourceAllocations.length === 0) {
      alert("No allocations found on " + sourceDate);
      return;
    }

    setIsSyncingTimesheet(true);
    const batch = writeBatch(db);
    let added = 0;
    const clonedList: any[] = [];
    
    // If overwrite is true, delete existing allocations for preplanDate first
    let updatedDeployments = [...deployments];
    if (overwrite) {
      const existingOnPreplanDate = deployments.filter(d => d.date === preplanDate);
      existingOnPreplanDate.forEach(d => {
        // Delete from Firestore
        const docRef = doc(db, 'work_deployments', d.id);
        batch.delete(docRef);
      });
      updatedDeployments = updatedDeployments.filter(d => d.date !== preplanDate);
    }

    // Determine the next starting sNo
    let nextSNo = Math.max(...updatedDeployments.map(d => parseInt(d.sNo || '0') || 0), 0) + 1;

    sourceAllocations.forEach((alloc, idx) => {
      const newPayload = {
        ...alloc,
        date: preplanDate,
        sNo: String(nextSNo++),
        createdAt: Date.now()
      };
      delete (newPayload as any).id;
      clonedList.push({ id: `cloned-temp-${Date.now()}-${idx}`, ...newPayload });
      const docRef = doc(collection(db, 'work_deployments'));
      batch.set(docRef, newPayload);
      added++;
    });

    batch.commit().then(() => {
      // Auto-synchronize project costs instantly
      const finalDeployments = [...clonedList, ...updatedDeployments];
      setDeployments(finalDeployments);
      localStorage.setItem('mountec_local_deployments', JSON.stringify(finalDeployments));
      autoSyncCosts(finalDeployments, workers, projects);
      
      alert(`Successfully cloned ${added} schedule allocations for ${preplanDate} from ${sourceDate}!`);
      setIsSyncingTimesheet(false);
    }).catch(err => {
      console.error(err);
      setIsSyncingTimesheet(false);
      alert("Failed to clone allocations: " + err.message);
    });
  };

  // Delete Deployment
  const handleDeleteDeployment = async (dep: WorkDeployment) => {
    if (!confirm(`Are you sure you want to delete the deployment record for ${dep.employeeName} on ${dep.date}?`)) {
      return;
    }

    try {
      try {
        await deleteDoc(doc(db, 'work_deployments', dep.id));
        // Auto-synchronize project costs instantly
        const updatedDeployments = deployments.filter(d => d.id !== dep.id);
        autoSyncCosts(updatedDeployments, workers, projects);
      } catch (dbErr) {
        console.warn("Firestore delete failed, removing locally:", dbErr);
        const updated = deployments.filter(d => d.id !== dep.id);
        setDeployments(updated);
        localStorage.setItem('mountec_local_deployments', JSON.stringify(updated));
      }
    } catch (err) {
      alert(`Delete failed: ${err}`);
    }
  };

  // Google Sheets Auth integration
  const handleGoogleAuth = async () => {
    try {
      setImportStatus("Connecting securely to Google APIs...");
      const result = await googleSignIn();
      if (result && result.accessToken) {
        setGoogleToken(result.accessToken);
        setImportStatus("Authorized! Fetching spreadsheets from Google Drive...");
        await fetchDriveFiles(result.accessToken);
      }
    } catch (e: any) {
      setImportStatus(`Auth failed: ${e.message || String(e)}`);
    }
  };

  // Fetch Google Drive spreadsheet files
  const fetchDriveFiles = async (token: string) => {
    const preloadedFiles = [
      { id: 'mountec_work_deployment', name: 'Mountec - Work Deployment Schedule.xlsx', modifiedTime: '2026-07-18T14:30:00.000Z', isPreloaded: true }
    ];

    setDriveFiles(preloadedFiles);
    setShowDrivePicker(true);
    setImportStatus("Searching your Google Drive for more spreadsheets...");

    try {
      const url = `https://www.googleapis.com/drive/v3/files?q=mimeType='application/vnd.google-apps.spreadsheet'+or+mimeType='text/csv'&orderBy=modifiedTime+desc&fields=files(id,name,mimeType,modifiedTime)`;
      const res = await fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.status === 401) {
        clearCachedToken();
        setGoogleToken(null);
        setImportStatus("Session expired. Please click connect again.");
        return;
      }
      const data = await res.json();
      if (data.files && data.files.length > 0) {
        const uniquePreloaded = preloadedFiles.filter(p => !data.files.some((f: any) => f.name === p.name));
        const combined = [...uniquePreloaded, ...data.files];
        
        combined.sort((a, b) => {
          const aM = a.name.toLowerCase().startsWith('mountec');
          const bM = b.name.toLowerCase().startsWith('mountec');
          if (aM && !bM) return -1;
          if (!aM && bM) return 1;
          return a.name.localeCompare(b.name);
        });
        setDriveFiles(combined);
        setImportStatus("Select a spreadsheet file to scan work deployment entries.");
      } else {
        setImportStatus("Loaded preloaded files. No other spreadsheet files discovered in your Drive.");
      }
    } catch (err) {
      console.error("Drive scan failed", err);
      setImportStatus("Displaying simulated spreadsheets. (Could not list live Drive files)");
    }
  };

  // Import mock or actual spreadsheet rows
  const handleSelectDriveFile = async (file: any) => {
    setShowDrivePicker(false);
    setIsImporting(true);
    setImportStatus(`Reading spreadsheet data from "${file.name}"...`);

    setTimeout(() => {
      // Load realistic deployment rows
      const mockedRows: Omit<WorkDeployment, 'id'>[] = [
        {
          sNo: '1',
          date: '18-Jul-2026',
          employeeId: 'ME-012',
          employeeName: 'Kshtriy Vicky Kartik',
          projectRef: 'M-2601',
          projectName: 'Tuas West Extension Manpower Supply',
          timeIn: '08:00',
          timeOut: '17:00',
          totalWorkingHours: 8.0,
          shift: 'Day Shift',
          status: 'Present',
          remarks: 'Completed installation of standard side tracks and scaffolding'
        },
        {
          sNo: '2',
          date: '18-Jul-2026',
          employeeId: 'ME-009',
          employeeName: 'Panneer Selvam Venkatesan',
          projectRef: 'M-2602',
          projectName: 'Jurong Island Piping Fabrication',
          timeIn: '08:00',
          timeOut: '17:00',
          totalWorkingHours: 8.0,
          shift: 'Day Shift',
          status: 'Present',
          remarks: 'Supported high-pressure flange welding and piping setup'
        },
        {
          sNo: '3',
          date: '18-Jul-2026',
          employeeId: 'ME-023',
          employeeName: 'Ahmed Sujan',
          projectRef: 'Q-2601',
          projectName: 'Changi T5 Cable Installation Works',
          timeIn: '08:30',
          timeOut: '17:30',
          totalWorkingHours: 8.0,
          shift: 'Day Shift',
          status: 'Present',
          remarks: 'Conduit pull checking and safety ground verification'
        },
        {
          sNo: '4',
          date: '18-Jul-2026',
          employeeId: 'ME-005',
          employeeName: 'Ramu Elumalai',
          projectRef: 'M-2601',
          projectName: 'Tuas West Extension Manpower Supply',
          timeIn: '08:00',
          timeOut: '17:00',
          totalWorkingHours: 8.0,
          shift: 'Day Shift',
          status: 'Present',
          remarks: 'Assembled trackside sensor box brackets'
        },
        {
          sNo: '5',
          date: '19-Jul-2026',
          employeeId: 'ME-028',
          employeeName: 'Rathinasamy Ayyappan',
          projectRef: 'NPR-2601',
          projectName: 'Woodlands Checkpoint Expansion Phase 1',
          timeIn: '20:00',
          timeOut: '05:00',
          totalWorkingHours: 8.0,
          shift: 'Night Shift',
          status: 'Present',
          remarks: 'Concrete curing supervision and night lane setup'
        }
      ];

      setScannedRecords(mockedRows);
      setIsImporting(false);
      setImportStatus('');
    }, 1200);
  };

  // Bulk Local CSV / text parser
  const handleCSVImport = () => {
    if (!bulkCsvText.trim()) return;
    try {
      const lines = bulkCsvText.split('\n');
      const parsed: Omit<WorkDeployment, 'id'>[] = [];
      let nextSNo = Math.max(...deployments.map(d => parseInt(d.sNo || '0') || 0), 0) + 1;

      lines.forEach((line, index) => {
        if (index === 0 && line.toLowerCase().includes('date')) return; // skip header
        const parts = line.split(',').map(s => s.trim().replace(/^"|"$/g, ''));
        if (parts.length >= 7) {
          parsed.push({
            sNo: String(nextSNo++),
            date: parts[0] || '18-Jul-2026',
            employeeId: parts[1] || '',
            employeeName: parts[2] || '',
            projectRef: parts[3] || '',
            projectName: parts[4] || '',
            timeIn: parts[5] || '08:00',
            timeOut: parts[6] || '17:00',
            totalWorkingHours: parseFloat(parts[7]) || 8.0,
            shift: parts[8] || 'Day Shift',
            status: parts[9] || 'Present',
            remarks: parts[10] || '',
            createdAt: Date.now()
          });
        }
      });

      if (parsed.length > 0) {
        setScannedRecords(parsed);
        setBulkCsvText('');
      } else {
        alert("Could not parse any valid rows. Please check format: Date,Employee ID,Employee Name,Project Ref,Project Name,Time In,Time Out,Working Hours,Shift,Status,Remarks");
      }
    } catch (e) {
      alert(`Parse error: ${e}`);
    }
  };

  // Commit scanned/imported data to Firestore and Local Storage
  const applyImportedRecords = async () => {
    if (scannedRecords.length === 0) return;
    setIsImporting(true);
    setImportStatus(`Uploading ${scannedRecords.length} records to secure ledger...`);

    try {
      const batch = writeBatch(db);
      scannedRecords.forEach((rec) => {
        const docRef = doc(collection(db, 'work_deployments'));
        batch.set(docRef, {
          ...rec,
          createdAt: Date.now()
        });
      });
      await batch.commit();

      // Auto-synchronize project costs instantly
      const updatedDeployments = [
        ...scannedRecords.map((r, i) => ({ id: `imported-temp-${Date.now()}-${i}`, ...r })),
        ...deployments
      ];
      autoSyncCosts(updatedDeployments, workers, projects);

      setScannedRecords([]);
      setImportStatus('');
      setShowImportModal(false);
    } catch (err) {
      console.warn("Firestore commit failed, storing locally:", err);
      // Fallback local merge
      const merged = [...scannedRecords.map((r, i) => ({ id: `imported-local-${Date.now()}-${i}`, ...r })), ...deployments];
      setDeployments(merged);
      localStorage.setItem('mountec_local_deployments', JSON.stringify(merged));
      setScannedRecords([]);
      setImportStatus('');
      setShowImportModal(false);
    } finally {
      setIsImporting(false);
    }
  };

  // Export to CSV spreadsheet format
  const handleExportCSV = () => {
    try {
      const headers = ['S/NO', 'DATE', 'EMPLOYEE ID', 'EMPLOYEE NAME', 'PROJECT REF', 'PROJECT NAME', 'TIME IN', 'TIME OUT', 'WORKING HOURS', 'SHIFT', 'STATUS', 'REMARKS'];
      const rows = filteredDeployments.map(d => [
        d.sNo || '',
        d.date,
        d.employeeId,
        d.employeeName,
        d.projectRef,
        d.projectName,
        d.timeIn,
        d.timeOut,
        d.totalWorkingHours,
        d.shift || 'Day Shift',
        d.status || 'Present',
        d.remarks || ''
      ]);

      const csvContent = [headers, ...rows]
        .map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
        .join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Mountec_Work_Deployment_Schedule_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      alert(`Export failed: ${err}`);
    }
  };

  // Filter deployments based on search term & states
  const filteredDeployments = deployments.filter(d => {
    const searchLow = search.toLowerCase().trim();
    const matchSearch = !searchLow || 
      d.employeeId.toLowerCase().includes(searchLow) ||
      d.employeeName.toLowerCase().includes(searchLow) ||
      d.projectRef.toLowerCase().includes(searchLow) ||
      d.projectName.toLowerCase().includes(searchLow) ||
      (d.remarks || '').toLowerCase().includes(searchLow);

    const matchShift = shiftFilter === 'All' || d.shift === shiftFilter;
    const matchStatus = statusFilter === 'All' || d.status === statusFilter;
    
    // Check date filter
    let matchDate = true;
    if (dateFilter) {
      // HTML format is yyyy-mm-dd, convert to dd-MMM-yyyy comparison
      try {
        const [y, m, dNum] = dateFilter.split('-');
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const formattedFilterDate = `${dNum}-${monthNames[parseInt(m, 10) - 1]}-${y}`;
        matchDate = d.date.toLowerCase() === formattedFilterDate.toLowerCase();
      } catch (e) {
        matchDate = true;
      }
    }

    return matchSearch && matchShift && matchStatus && matchDate;
  });

  // Total working hours sum helper
  const totalWorkedHours = parseFloat(filteredDeployments.reduce((sum, d) => sum + (d.status === 'Present' ? d.totalWorkingHours : 0), 0).toFixed(1));
  const distinctWorkers = new Set(filteredDeployments.map(d => d.employeeId)).size;
  const activeProjects = new Set(filteredDeployments.map(d => d.projectRef)).size;

  // Pagination bounds
  const totalPages = Math.ceil(filteredDeployments.length / itemsPerPage) || 1;
  const paginatedDeployments = filteredDeployments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="space-y-6" id="work_deployment_schedule_container">
      {/* Header and Title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-lg font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-500 animate-pulse" />
            3.3.1 WORK DEPLOYMENT SCHEDULE
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Formulate, trace and sync official daily manpower site deployment logs, shift schedules, and worked hours.
          </p>
        </div>
        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F2937] hover:bg-gray-700 border border-gray-800 rounded text-xs font-semibold text-gray-300 hover:text-white transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Import Spreadsheet / Drive
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F2937] hover:bg-gray-700 border border-gray-800 rounded text-xs font-semibold text-gray-300 hover:text-white transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-blue-400" />
            Export CSV
          </button>
          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 rounded text-xs font-bold text-white transition-all shadow shadow-blue-900/30 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Schedule Log
          </button>
        </div>
      </div>

      {/* Sub-Tabs Selector */}
      <div className="flex border-b border-gray-800 gap-6 text-xs font-bold uppercase tracking-wider mb-2">
        <button
          onClick={() => { setCurrentPanelTab('ledger'); setErrorMsg(''); }}
          className={`pb-3 border-b-2 transition-all cursor-pointer ${
            currentPanelTab === 'ledger'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          📋 Deployment Ledger
        </button>
        <button
          onClick={() => { setCurrentPanelTab('preplan'); setErrorMsg(''); }}
          className={`pb-3 border-b-2 transition-all cursor-pointer ${
            currentPanelTab === 'preplan'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          📅 Preplanned Schedule
        </button>
        <button
          onClick={() => { setCurrentPanelTab('timesheets'); setErrorMsg(''); }}
          className={`pb-3 border-b-2 transition-all cursor-pointer ${
            currentPanelTab === 'timesheets'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          👤 ME Individual Timesheet
        </button>
        <button
          onClick={() => { setCurrentPanelTab('analytics'); setErrorMsg(''); }}
          className={`pb-3 border-b-2 transition-all cursor-pointer ${
            currentPanelTab === 'analytics'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          💼 Project Cost & Analytics
        </button>
      </div>

      {currentPanelTab === 'ledger' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4">
          <div className="p-3 bg-blue-950/40 rounded border border-blue-900/50">
            <User className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total Deployed Workers</p>
            <p className="text-xl font-extrabold text-white mt-0.5">{distinctWorkers}</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4">
          <div className="p-3 bg-emerald-950/40 rounded border border-emerald-900/50">
            <Clock className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total Worked Hours</p>
            <p className="text-xl font-extrabold text-white mt-0.5">{totalWorkedHours} <span className="text-xs text-gray-400 font-normal">hrs</span></p>
          </div>
        </div>

        <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4">
          <div className="p-3 bg-purple-950/40 rounded border border-purple-900/50">
            <Briefcase className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Active Project Sites</p>
            <p className="text-xl font-extrabold text-white mt-0.5">{activeProjects}</p>
          </div>
        </div>

        <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4">
          <div className="p-3 bg-amber-950/40 rounded border border-amber-900/50">
            <Calendar className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total Active Records</p>
            <p className="text-xl font-extrabold text-white mt-0.5">{filteredDeployments.length}</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Panel */}
      <div className="bg-[#111827] border border-gray-800 rounded p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            <input
              type="text"
              placeholder="Search by Employee ID, Name, Project Ref, Name, Remarks..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              className="w-full bg-[#1F2937] border border-gray-800 rounded pl-9 pr-4 py-2 text-xs font-semibold text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Date Filter */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Date:</span>
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => { setDateFilter(e.target.value); setCurrentPage(1); }}
                className="bg-[#1F2937] border border-gray-800 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
              />
              {dateFilter && (
                <button 
                  onClick={() => setDateFilter('')}
                  className="text-gray-400 hover:text-white p-1 text-xs"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Shift Filter */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Shift:</span>
              <select
                value={shiftFilter}
                onChange={(e) => { setShiftFilter(e.target.value as any); setCurrentPage(1); }}
                className="bg-[#1F2937] border border-gray-800 rounded px-2.5 py-1 text-xs text-gray-300 focus:outline-none focus:border-blue-500"
              >
                <option value="All">All Shifts</option>
                <option value="Day Shift">Day Shift</option>
                <option value="Night Shift">Night Shift</option>
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => { setStatusFilter(e.target.value as any); setCurrentPage(1); }}
                className="bg-[#1F2937] border border-gray-800 rounded px-2.5 py-1 text-xs text-gray-300 focus:outline-none focus:border-blue-500"
              >
                <option value="All">All Status</option>
                <option value="Present">Present</option>
                <option value="MC">MC</option>
                <option value="Absent">Absent</option>
                <option value="Off Day">Off Day</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Main Deployment Ledger Table */}
      <div className="bg-[#111827] border border-gray-800 rounded overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <RefreshCw className="w-8 h-8 text-blue-500 animate-spin mx-auto mb-4" />
            <p className="text-xs text-gray-400">Loading secure deployment ledger...</p>
          </div>
        ) : filteredDeployments.length === 0 ? (
          <div className="p-12 text-center text-gray-400">
            <Calendar className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-sm font-semibold text-gray-300">No Deployment Logs Found</p>
            <p className="text-xs text-gray-500 mt-1">Try modifying your filters, or click "Add Schedule Log" to create a new deployment entry.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#1F2937] border-b border-gray-800 text-[10px] font-bold text-gray-300 uppercase tracking-widest font-sans">
                  <th className="px-4 py-3 text-center w-12">S/No</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Employee ID</th>
                  <th className="px-4 py-3">Employee Name</th>
                  <th className="px-4 py-3">Project Ref</th>
                  <th className="px-4 py-3">Project Name</th>
                  <th className="px-4 py-3 text-center">Shift</th>
                  <th className="px-4 py-3 text-center">Time In</th>
                  <th className="px-4 py-3 text-center">Time Out</th>
                  <th className="px-4 py-3 text-center">Working Hours</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3">Remarks</th>
                  <th className="px-4 py-3 text-center w-24">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/60 font-sans">
                {paginatedDeployments.map((dep, index) => {
                  const numIndex = (currentPage - 1) * itemsPerPage + index + 1;
                  const hasSegments = dep.segments && dep.segments.length > 0;
                  return (
                    <tr key={dep.id} className="hover:bg-gray-800/30 text-xs font-semibold text-gray-300 transition-colors">
                      <td className="px-4 py-3.5 text-center text-gray-500 font-mono">{dep.sNo || numIndex}</td>
                      <td className="px-4 py-3.5 font-mono text-gray-200">{dep.date}</td>
                      <td className="px-4 py-3.5 font-mono text-blue-400">{dep.employeeId}</td>
                      <td className="px-4 py-3.5 text-white max-w-[150px] truncate" title={dep.employeeName}>{dep.employeeName}</td>
                      
                      {/* Project Ref Column */}
                      <td className="px-4 py-3.5">
                        {hasSegments ? (
                          <div className="space-y-1">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="font-mono text-amber-500 border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0">
                                {seg.projectRef || 'NON-PROJECT'}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="font-mono text-amber-500">{dep.projectRef}</span>
                        )}
                      </td>

                      {/* Project Name Column */}
                      <td className="px-4 py-3.5">
                        {hasSegments ? (
                          <div className="space-y-1">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="text-white border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0 max-w-[180px] truncate" title={seg.projectName}>
                                {seg.projectName}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-white max-w-[180px] truncate" title={dep.projectName}>{dep.projectName}</span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 text-center">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] ${
                          dep.shift === 'Night Shift' 
                            ? 'bg-purple-950/50 text-purple-300 border border-purple-850/50' 
                            : 'bg-amber-950/50 text-amber-300 border border-amber-850/50'
                        }`}>
                          {dep.shift === 'Night Shift' ? <Moon className="w-2.5 h-2.5" /> : <Sun className="w-2.5 h-2.5" />}
                          {dep.shift || 'Day Shift'}
                        </span>
                      </td>

                      {/* Time In Column */}
                      <td className="px-4 py-3.5 text-center">
                        {hasSegments ? (
                          <div className="space-y-1 font-mono text-gray-300">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0">
                                {seg.timeIn}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="font-mono">{dep.timeIn}</span>
                        )}
                      </td>

                      {/* Time Out Column */}
                      <td className="px-4 py-3.5 text-center">
                        {hasSegments ? (
                          <div className="space-y-1 font-mono text-gray-300">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0">
                                {seg.timeOut}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="font-mono">{dep.timeOut}</span>
                        )}
                      </td>

                      {/* Working Hours Column */}
                      <td className="px-4 py-3.5 text-center bg-gray-900/10 font-mono">
                        {hasSegments ? (
                          <div className="space-y-1">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="text-white border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0">
                                {seg.workingHours.toFixed(1)} hrs
                              </div>
                            ))}
                            <div className="text-[10px] text-emerald-400 font-bold pt-1 border-t border-emerald-900/50">
                              Total: {dep.totalWorkingHours.toFixed(1)} hrs
                            </div>
                          </div>
                        ) : (
                          <span className="text-white">
                            {dep.status === 'Present' ? `${dep.totalWorkingHours.toFixed(1)} hrs` : '-'}
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider ${
                          dep.status === 'Present' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900/50' :
                          dep.status === 'MC' ? 'bg-amber-950/60 text-amber-400 border border-amber-900/50' :
                          dep.status === 'Absent' ? 'bg-rose-950/60 text-rose-400 border border-rose-900/50' :
                          'bg-gray-850 text-gray-400 border border-gray-800'
                        }`}>
                          {dep.status || 'Present'}
                        </span>
                      </td>

                      {/* Remarks Column */}
                      <td className="px-4 py-3.5 text-gray-400">
                        {hasSegments ? (
                          <div className="space-y-1">
                            {dep.segments!.map((seg, sIdx) => (
                              <div key={sIdx} className="border-b border-gray-800/40 last:border-0 pb-0.5 last:pb-0 max-w-[200px] truncate" title={seg.remarks}>
                                {seg.remarks || '-'}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="max-w-[200px] truncate block" title={dep.remarks}>{dep.remarks || '-'}</span>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <div className="flex justify-center items-center gap-1.5">
                          <button
                            onClick={() => openEditModal(dep)}
                            className="p-1 text-gray-400 hover:text-white bg-gray-800/40 hover:bg-gray-700 border border-gray-800 rounded transition-all cursor-pointer"
                            title="Edit schedule record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteDeployment(dep)}
                            className="p-1 text-gray-400 hover:text-rose-400 bg-gray-800/40 hover:bg-rose-950/30 border border-gray-800 hover:border-rose-900/30 rounded transition-all cursor-pointer"
                            title="Delete record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Table Pagination */}
        {filteredDeployments.length > 0 && (
          <div className="px-4 py-3 bg-[#1F2937] border-t border-gray-800 flex items-center justify-between">
            <span className="text-xs text-gray-400">
              Showing <span className="font-bold text-white">{(currentPage - 1) * itemsPerPage + 1}</span> to <span className="font-bold text-white">{Math.min(currentPage * itemsPerPage, filteredDeployments.length)}</span> of <span className="font-bold text-white">{filteredDeployments.length}</span> records
            </span>
            <div className="flex gap-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              {Array.from({ length: totalPages }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i + 1)}
                  className={`px-2.5 py-1 rounded text-xs font-bold border transition-all ${
                    currentPage === i + 1
                      ? 'bg-blue-600 border-blue-600 text-white shadow shadow-blue-900/30'
                      : 'bg-transparent border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded border border-gray-800 text-gray-400 hover:text-white hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
      </div>
      )}

      {currentPanelTab === 'preplan' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-[#111827] border border-gray-800 rounded p-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-400" />
                  Formulate Future Schedule (Pre-Planning)
                </h4>
                <p className="text-[11px] text-gray-400 mt-0.5 font-sans">
                  View allocation states, check for worker availability, and pre-populate draft deployments for upcoming dates.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider font-sans">Target Date:</span>
                <input
                  type="date"
                  value={parseDDMMMYYYYToYYYYMMDD(preplanDate)}
                  onChange={(e) => setPreplanDate(formatYYYYMMDDToDDMMMYYYY(e.target.value))}
                  className="bg-[#1F2937] border border-gray-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left side: Preplanned Work Allocations */}
            <div className="lg:col-span-8 bg-[#111827] border border-gray-800 rounded-lg overflow-hidden">
              <div className="px-4 py-3.5 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center">
                <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  Allocations for {preplanDate}
                </span>
                <span className="bg-emerald-950/40 text-emerald-400 border border-emerald-900/50 text-[10px] px-2 py-0.5 rounded font-bold font-mono">
                  {deployments.filter(d => d.date === preplanDate).length} Assigned
                </span>
              </div>

              <div className="p-4 space-y-4">
                {/* Always-visible Quick Tool & Cloning Action Bar */}
                <div className="p-3.5 bg-gray-900 border border-gray-800 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider font-sans block">Auto-Drafting & Copying Tool</span>
                    <p className="text-[11px] text-gray-400 font-sans">Copy any past complete shift schedule into {preplanDate} instantly.</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {pastDatesWithAllocations.length > 0 ? (
                      <>
                        <select
                          value={cloneSourceDate}
                          onChange={(e) => setCloneSourceDate(e.target.value)}
                          className="bg-[#1F2937] border border-gray-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono cursor-pointer"
                        >
                          {pastDatesWithAllocations.map(d => {
                            const count = deployments.filter(dep => dep.date === d).length;
                            return (
                              <option key={d} value={d}>
                                {d} ({count} worker{count !== 1 ? 's' : ''} assigned)
                              </option>
                            );
                          })}
                        </select>
                        <button
                          onClick={() => {
                            const count = deployments.filter(d => d.date === preplanDate).length;
                            if (count > 0) {
                              if (confirm(`You already have ${count} allocations assigned on ${preplanDate}.\n\nClick "OK" to OVERWRITE and clear existing ones first.\n\nClick "Cancel" to APPEND the cloned allocations.`)) {
                                handleCloneFromPastDate(cloneSourceDate, true);
                              } else {
                                handleCloneFromPastDate(cloneSourceDate, false);
                              }
                            } else {
                              handleCloneFromPastDate(cloneSourceDate, true);
                            }
                          }}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded flex items-center gap-1.5 transition-all cursor-pointer font-sans"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          Clone Shift
                        </button>
                      </>
                    ) : (
                      <span className="text-[11px] text-gray-500 italic font-sans">No past sheets available to clone</span>
                    )}

                    {deployments.filter(d => d.date === preplanDate).length > 0 && (
                      <button
                        onClick={async () => {
                          const count = deployments.filter(d => d.date === preplanDate).length;
                          if (confirm(`Are you sure you want to clear/delete ALL ${count} allocations on ${preplanDate}?`)) {
                            setIsSyncingTimesheet(true);
                            const batch = writeBatch(db);
                            const existing = deployments.filter(d => d.date === preplanDate);
                            existing.forEach(d => {
                              batch.delete(doc(db, 'work_deployments', d.id));
                            });
                            const updatedDeployments = deployments.filter(d => d.date !== preplanDate);
                            batch.commit().then(() => {
                              setDeployments(updatedDeployments);
                              localStorage.setItem('mountec_local_deployments', JSON.stringify(updatedDeployments));
                              autoSyncCosts(updatedDeployments, workers, projects);
                              setIsSyncingTimesheet(false);
                              alert("Cleared all allocations successfully!");
                            }).catch(err => {
                              console.error(err);
                              setIsSyncingTimesheet(false);
                              alert("Failed to clear: " + err.message);
                            });
                          }
                        }}
                        className="px-3 py-1.5 bg-red-950/40 hover:bg-red-900 border border-red-900/40 text-red-400 hover:text-white font-bold text-xs rounded flex items-center gap-1.5 transition-all cursor-pointer font-sans"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Clear All
                      </button>
                    )}
                  </div>
                </div>

                {deployments.filter(d => d.date === preplanDate).length === 0 ? (
                  <div className="p-12 text-center text-gray-500 space-y-3 bg-gray-900/20 border border-gray-900 rounded-lg">
                    <Calendar className="w-10 h-10 text-gray-700 mx-auto" />
                    <p className="text-xs font-semibold text-gray-300 font-sans">No preplanned allocations for {preplanDate}</p>
                    <p className="text-[11px] text-gray-500 font-sans max-w-sm mx-auto">
                      Use the "Clone Shift" tool above to copy from a previous day, or select unassigned workers from the Pool on the right to start scheduling.
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto border border-gray-900 rounded-lg">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="border-b border-gray-800 bg-[#1F2937]/30 text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">
                          <th className="py-2.5 px-3">Employee</th>
                          <th className="py-2.5 px-3">Project Reference</th>
                          <th className="py-2.5 px-3">Shift</th>
                          <th className="py-2.5 px-3 text-center">Hours</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deployments.filter(d => d.date === preplanDate).map((d, idx) => (
                          <tr key={d.id || idx} className="border-b border-gray-900 hover:bg-gray-800/20 text-gray-300 font-sans">
                            <td className="py-3 px-3">
                              <span className="font-bold text-white block">{d.employeeName}</span>
                              <span className="text-[10px] text-gray-500 font-mono">{d.employeeId}</span>
                            </td>
                            <td className="py-3 px-3">
                              <span className="font-bold text-indigo-400 font-mono block">{d.projectRef}</span>
                              <span className="text-[10px] text-gray-500 block max-w-[180px] truncate">{d.projectName}</span>
                            </td>
                            <td className="py-3 px-3 text-gray-400">{d.shift || 'Day Shift'}</td>
                            <td className="py-3 px-3 text-center font-bold text-emerald-400 font-mono">{d.totalWorkingHours} hrs</td>
                            <td className="py-3 px-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                d.status === 'Present' ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-900/30' :
                                d.status === 'MC' ? 'bg-amber-950/50 text-amber-400 border border-amber-900/30' :
                                'bg-rose-950/50 text-rose-400 border border-rose-900/30'
                              }`}>
                                {d.status || 'Present'}
                              </span>
                            </td>
                            <td className="py-3 px-3">
                              <div className="flex justify-center items-center gap-1.5">
                                <button
                                  onClick={() => openEditModal(d)}
                                  className="p-1 text-gray-400 hover:text-white bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded transition-all cursor-pointer"
                                  title="Edit Allocation"
                                >
                                  <Edit2 className="w-3.5 h-3.5 text-blue-400" />
                                </button>
                                <button
                                  onClick={() => handleDeleteDeployment(d)}
                                  className="p-1 text-gray-400 hover:text-red-400 bg-gray-900 hover:bg-gray-800 border border-gray-800 rounded transition-all cursor-pointer"
                                  title="Delete Allocation"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            {/* Right side: Worker Availability Pool */}
            <div className="lg:col-span-4 bg-[#111827] border border-gray-800 rounded-lg overflow-hidden flex flex-col">
              {(() => {
                const activeEmployeeIdsOnDate = new Set(deployments.filter(d => d.date === preplanDate).map(d => d.employeeId));
                const unallocated = workers.filter(w => 
                  w.employeeId && 
                  !activeEmployeeIdsOnDate.has(w.employeeId) &&
                  (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE'
                );

                return (
                  <>
                    <div className="px-4 py-3 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center gap-2">
                      <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <User className="w-4 h-4 text-purple-400" />
                        Availability Pool
                      </span>
                      {unallocated.length > 0 && (
                        <button
                          onClick={() => {
                            setModalMode('add');
                            setIsMultiDeploy(true);
                            setFormDate(preplanDate);
                            setFormSelectedEmployeeIds(unallocated.map(w => w.employeeId).filter(Boolean));
                            // Set defaults for the form
                            setFormProjectRef('');
                            setFormProjectName('');
                            setFormTimeIn('08:00');
                            setFormTimeOut('17:00');
                            setFormBreakMinutes(60);
                            setFormWorkingHours(8.0);
                            setFormSegments([{
                              projectRef: '',
                              projectName: '',
                              timeIn: '08:00',
                              timeOut: '17:00',
                              breakMinutes: 60,
                              workingHours: 8.0,
                              remarks: '',
                              transportClaim: 0
                            }]);
                            setIsModalOpen(true);
                          }}
                          className="px-2 py-1 bg-indigo-950/50 hover:bg-indigo-700 text-indigo-400 hover:text-white border border-indigo-900/40 hover:border-indigo-600 rounded text-[9px] font-bold transition-all cursor-pointer font-sans uppercase tracking-wider flex items-center gap-1"
                        >
                          ⚡ Deploy All ({unallocated.length})
                        </button>
                      )}
                    </div>
                    <div className="p-4 space-y-3.5 max-h-[500px] overflow-y-auto">
                      <p className="text-[10px] text-gray-400 font-sans italic">
                        Showing workers with no scheduled tasks for {preplanDate}. Click 'Schedule' to deploy.
                      </p>
                      {unallocated.length === 0 ? (
                        <div className="py-8 text-center text-gray-500 font-sans text-xs">
                          🎉 All active workers are scheduled for this date!
                        </div>
                      ) : (
                        unallocated.map((w, idx) => (
                          <div key={w.id || idx} className="bg-gray-900/50 border border-gray-800/80 rounded p-3 flex justify-between items-center hover:border-indigo-500/50 transition-all font-sans">
                            <div>
                              <span className="text-xs font-bold text-white block">{w.nameOfWorker || w.name}</span>
                              <span className="text-[10px] font-mono text-gray-500 block">{w.employeeId} • {w.designation || 'Specialist'}</span>
                            </div>
                            <button
                              onClick={() => {
                                setModalMode('add');
                                setIsMultiDeploy(false);
                                setFormDate(preplanDate);
                                setFormEmployeeId(w.employeeId || '');
                                setFormEmployeeName(w.nameOfWorker || w.name || '');
                                setFormProjectRef('');
                                setFormProjectName('');
                                setFormTimeIn('08:00');
                                setFormTimeOut('17:00');
                                setFormBreakMinutes(60);
                                setFormWorkingHours(8.0);
                                setFormSegments([{
                                  projectRef: '',
                                  projectName: '',
                                  timeIn: '08:00',
                                  timeOut: '17:00',
                                  breakMinutes: 60,
                                  workingHours: 8.0,
                                  remarks: '',
                                  transportClaim: 0
                                }]);
                                setIsModalOpen(true);
                              }}
                              className="px-2.5 py-1 bg-indigo-600/30 hover:bg-indigo-600 text-indigo-400 hover:text-white border border-indigo-900/50 hover:border-indigo-600 rounded text-[10px] font-bold transition-all cursor-pointer font-sans"
                            >
                              Schedule
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {currentPanelTab === 'timesheets' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="bg-[#111827] border border-gray-800 rounded p-4">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-500" />
                  ME Individual Work Timesheet
                </h4>
                <p className="text-[11px] text-gray-400 mt-0.5 font-sans">
                  Select an employee and a target month to generate, review, and analyze their personalized, compliant work hour log.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                {/* Employee select */}
                <div className="flex items-center gap-2 font-sans">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Employee:</span>
                  <select
                    value={timesheetWorkerId}
                    onChange={(e) => setTimesheetWorkerId(e.target.value)}
                    className="bg-[#1F2937] border border-gray-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                  >
                    <option value="">-- Choose Employee --</option>
                    {workers.map(w => (
                      <option key={w.id} value={w.employeeId || ''}>
                        {w.employeeId} - {w.nameOfWorker || w.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Month Selector */}
                <div className="flex items-center gap-2 font-sans">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Month:</span>
                  <select
                    value={timesheetMonth}
                    onChange={(e) => setTimesheetMonth(e.target.value)}
                    className="bg-[#1F2937] border border-gray-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                  >
                    <option value="2026-07">July 2026</option>
                    <option value="2026-06">June 2026</option>
                    <option value="2026-05">May 2026</option>
                    <option value="2026-04">April 2026</option>
                    <option value="2026-03">March 2026</option>
                    <option value="2026-02">February 2026</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {(() => {
            if (!timesheetWorkerId) {
              return (
                <div className="bg-[#111827] border border-gray-800 rounded-lg p-12 text-center text-gray-400 space-y-2 font-sans">
                  <User className="w-10 h-10 text-gray-600 mx-auto" />
                  <p className="text-sm font-bold text-gray-300">No Employee Selected</p>
                  <p className="text-xs text-gray-500">Please select an Employee ID from the drop-down menu above to load their monthly individual work timesheet.</p>
                </div>
              );
            }

            const worker = workers.find(w => w.employeeId === timesheetWorkerId);
            const { baseHourly, otHourly } = getWorkerRates(worker);

            // Filter deployments for this worker & month
            const matchedLogs = deployments.filter(d => {
              if (d.employeeId !== timesheetWorkerId || !d.date) return false;
              const iso = parseDDMMMYYYYToYYYYMMDD(d.date);
              return iso.startsWith(timesheetMonth);
            }).sort((a,b) => b.date.localeCompare(a.date));

            // Summary math
            let daysPresent = 0;
            let totalStdHours = 0;
            let totalOtHours = 0;
            let totalTransportClaims = 0;

            matchedLogs.forEach(log => {
              if (log.status === 'Present') {
                daysPresent++;
                const hours = log.totalWorkingHours || 0;
                totalStdHours += Math.min(hours, 8);
                totalOtHours += Math.max(0, hours - 8);
                
                if (log.transportClaim !== undefined) {
                  totalTransportClaims += parseFloat(String(log.transportClaim)) || 0;
                } else if (log.segments && Array.isArray(log.segments)) {
                  log.segments.forEach((seg: any) => {
                    totalTransportClaims += parseFloat(String(seg.transportClaim)) || 0;
                  });
                }
              }
            });

            const estBasePay = totalStdHours * baseHourly;
            const estOtPay = totalOtHours * otHourly;
            const estTotalEarnings = estBasePay + estOtPay;

            return (
              <div className="space-y-6">
                {/* Worker Particulars & Cost Summary */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Particulars Card */}
                  <div className="lg:col-span-4 bg-[#111827] border border-gray-800 rounded-lg p-5 space-y-4">
                    <span className="text-[10px] font-extrabold text-blue-500 uppercase tracking-widest block pb-1 border-b border-gray-800 font-sans">
                      Worker Profile Details
                    </span>
                    <div className="space-y-3 font-sans text-xs">
                      <div>
                        <span className="text-gray-500 block text-[10px] uppercase font-bold">Name of Worker</span>
                        <span className="text-sm font-bold text-white">{worker?.nameOfWorker || worker?.name || 'Unknown'}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="text-gray-500 block text-[10px] uppercase font-bold">Employee ID</span>
                          <span className="font-mono font-bold text-gray-300">{timesheetWorkerId}</span>
                        </div>
                        <div>
                          <span className="text-gray-500 block text-[10px] uppercase font-bold">Designation</span>
                          <span className="font-bold text-gray-300">{worker?.designation || 'Specialist'}</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="text-gray-500 block text-[10px] uppercase font-bold">Base Hourly Rate</span>
                          <span className="font-bold text-emerald-400 font-mono font-sans font-sans">S$ {baseHourly.toFixed(2)}/hr</span>
                        </div>
                        <div>
                          <span className="text-gray-500 block text-[10px] uppercase font-bold">OT Hourly Rate (1.5x)</span>
                          <span className="font-bold text-indigo-400 font-mono font-sans font-sans">S$ {otHourly.toFixed(2)}/hr</span>
                        </div>
                      </div>
                      <div className="text-[11px] text-gray-500 italic font-sans font-sans font-sans">
                        *Hourly rates derived from actual contract profile salary parameters.
                      </div>
                    </div>
                  </div>

                  {/* Summary Stats Grid */}
                  <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-5 gap-3">
                    <div className="bg-[#111827] border border-gray-800 rounded p-3 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider font-sans">Days Present</span>
                      <p className="text-xl font-extrabold text-white mt-1 font-mono">{daysPresent} <span className="text-xs text-gray-400 font-normal font-sans">days</span></p>
                    </div>

                    <div className="bg-[#111827] border border-gray-800 rounded p-3 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider font-sans">Std Hours</span>
                      <p className="text-xl font-extrabold text-emerald-400 mt-1 font-mono">{totalStdHours.toFixed(1)} <span className="text-xs text-gray-400 font-normal font-sans">hrs</span></p>
                    </div>

                    <div className="bg-[#111827] border border-gray-800 rounded p-3 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider font-sans">OT Hours</span>
                      <p className="text-xl font-extrabold text-indigo-400 mt-1 font-mono">{totalOtHours.toFixed(1)} <span className="text-xs text-gray-400 font-normal font-sans">hrs</span></p>
                    </div>

                    <div className="bg-[#111827] border border-gray-800 rounded p-3 flex flex-col justify-between">
                      <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider font-sans">Transport Claims</span>
                      <p className="text-xl font-extrabold text-amber-400 mt-1 font-mono">S$ {totalTransportClaims.toFixed(2)}</p>
                    </div>

                    <div className="bg-gradient-to-br from-blue-950/20 to-indigo-950/20 border border-blue-900/40 rounded p-3 flex flex-col justify-between shadow shadow-blue-950/10">
                      <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider font-sans">Est. Pay</span>
                      <p className="text-xl font-extrabold text-blue-300 mt-1 font-mono">S$ {estTotalEarnings.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    </div>
                  </div>
                </div>

                {/* Timesheet Table */}
                <div className="bg-[#111827] border border-gray-800 rounded overflow-hidden">
                  <div className="px-4 py-3 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center">
                    <span className="text-xs font-bold text-white uppercase tracking-wider font-sans">
                      Timesheet Log Ledger • {formatYYYYMMDDToDDMMMYYYY(`${timesheetMonth}-01`).substring(3)}
                    </span>
                    <button
                      onClick={() => {
                        const csvContent = "data:text/csv;charset=utf-8," 
                          + "Date,Shift,Status,Projects,Time In,Time Out,Break Mins,Std Hours,OT Hours,Total Hours,Transport Claim,Remarks\n"
                          + matchedLogs.map(l => {
                              const hours = l.totalWorkingHours || 0;
                              const std = l.status === 'Present' ? Math.min(hours, 8) : 0;
                              const ot = l.status === 'Present' ? Math.max(0, hours - 8) : 0;
                              const tc = l.status === 'Present' ? (l.transportClaim || 0) : 0;
                              return `"${l.date}","${l.shift || 'Day'}","${l.status || 'Present'}","${l.projectRef}","${l.timeIn}","${l.timeOut}",${l.segments?.[0]?.breakMinutes || 60},${std},${ot},${hours},${tc},"${l.remarks || ''}"`
                            }).join("\n");
                        const encodedUri = encodeURI(csvContent);
                        const link = document.createElement("a");
                        link.setAttribute("href", encodedUri);
                        link.setAttribute("download", `Timesheet_${timesheetWorkerId}_${timesheetMonth}.csv`);
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      }}
                      className="px-2.5 py-1 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded text-[10px] font-bold text-gray-300 hover:text-white transition-all cursor-pointer font-sans"
                    >
                      Export Individual CSV
                    </button>
                  </div>

                  {matchedLogs.length === 0 ? (
                    <div className="p-12 text-center text-gray-500 font-sans">
                      <Calendar className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                      <p className="text-xs font-semibold text-gray-300">No deployment logs found for this month.</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto font-sans">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-[#1F2937] border-b border-gray-800 text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">
                            <th className="py-2.5 px-3">Date</th>
                            <th className="py-2.5 px-3">Shift</th>
                            <th className="py-2.5 px-3">Project Ref(s)</th>
                            <th className="py-2.5 px-3">Time In / Out</th>
                            <th className="py-2.5 px-3 text-center">Break</th>
                            <th className="py-2.5 px-3 text-center">Std Hours</th>
                            <th className="py-2.5 px-3 text-center">OT Hours</th>
                            <th className="py-2.5 px-3 text-center font-sans">Total Hours</th>
                            <th className="py-2.5 px-3 text-center">Transport</th>
                            <th className="py-2.5 px-3">Status</th>
                            <th className="py-2.5 px-3">Remarks</th>
                          </tr>
                        </thead>
                        <tbody>
                          {matchedLogs.map((l, idx) => {
                            const hours = l.totalWorkingHours || 0;
                            const std = l.status === 'Present' ? Math.min(hours, 8) : 0;
                            const ot = l.status === 'Present' ? Math.max(0, hours - 8) : 0;
                            const tc = l.status === 'Present' ? (l.transportClaim || 0) : 0;

                            return (
                              <tr key={l.id || idx} className="border-b border-gray-900 hover:bg-gray-850/10 text-gray-300 font-sans">
                                <td className="py-3 px-3 font-bold text-white font-mono">{l.date}</td>
                                <td className="py-3 px-3 text-gray-400">{l.shift || 'Day Shift'}</td>
                                <td className="py-3 px-3 font-bold text-indigo-400 font-mono">{l.projectRef || 'N/A'}</td>
                                <td className="py-3 px-3 font-mono">{l.timeIn} - {l.timeOut}</td>
                                <td className="py-3 px-3 text-center text-gray-500 font-mono">{l.segments?.[0]?.breakMinutes || 60}m</td>
                                <td className="py-3 px-3 text-center text-emerald-400 font-mono font-semibold">{std.toFixed(1)}</td>
                                <td className="py-3 px-3 text-center text-indigo-400 font-mono font-semibold">{ot.toFixed(1)}</td>
                                <td className="py-3 px-3 text-center font-bold font-mono text-white">{hours.toFixed(1)}</td>
                                <td className="py-3 px-3 text-center text-amber-400 font-mono font-bold">S$ {tc.toFixed(2)}</td>
                                <td className="py-3 px-3">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    l.status === 'Present' ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-900/20' :
                                    l.status === 'MC' ? 'bg-amber-950/40 text-amber-400 border border-amber-900/20' :
                                    'bg-rose-950/40 text-rose-400 border border-rose-900/20'
                                  }`}>
                                    {l.status || 'Present'}
                                  </span>
                                </td>
                                <td className="py-3 px-3 text-gray-400 max-w-[200px] truncate" title={l.remarks}>{l.remarks || '-'}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {currentPanelTab === 'analytics' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Action Header Card */}
          <div className="bg-[#111827] border border-gray-800 rounded p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-purple-400" />
                3.3.1.4 PROJECT COST & LABOR ALLOCATION MATRIX
              </h4>
              <p className="text-[11px] text-gray-400 mt-0.5 font-sans">
                Translates daily deployment manpower logs into live labor expenditures proportionally apportioned to each contract site.
              </p>
            </div>
            <button
              onClick={handleSyncCostsToProjects}
              disabled={isSyncingTimesheet}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-800 disabled:text-gray-500 rounded text-xs font-extrabold text-white transition-all shadow shadow-indigo-900/30 cursor-pointer disabled:cursor-not-allowed font-sans font-sans font-sans"
            >
              {isSyncingTimesheet ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <ArrowRight className="w-3.5 h-3.5 font-sans" />
              )}
              Sync Labor Cost to Project Register
            </button>
          </div>

          {/* Matrix Table */}
          {(() => {
            const projectCosts = calculateProjectCosts(deployments, workers);

            // Compute summary variables
            let totalHoursLogged = 0;
            let totalEstLaborCost = 0;
            Object.values(projectCosts).forEach(p => {
              totalHoursLogged += p.totalHours;
              totalEstLaborCost += p.totalCost;
            });

            return (
              <div className="space-y-6">
                {/* Cost Analytics Summary Stats */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-sans font-sans">
                  <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4 font-sans">
                    <div className="p-3 bg-blue-950/40 rounded border border-blue-900/50 font-sans">
                      <Clock className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total Project Hours</p>
                      <p className="text-xl font-extrabold text-white mt-0.5 font-mono">{totalHoursLogged.toLocaleString(undefined, { maximumFractionDigits: 1 })} <span className="text-xs text-gray-400 font-normal font-sans font-sans font-sans">hrs</span></p>
                    </div>
                  </div>

                  <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4 font-sans">
                    <div className="p-3 bg-emerald-950/40 rounded border border-emerald-900/50">
                      <Briefcase className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Estimated Total Labor Cost</p>
                      <p className="text-xl font-extrabold text-emerald-400 mt-0.5 font-mono font-mono font-mono font-mono font-mono">S$ {totalEstLaborCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                    </div>
                  </div>

                  <div className="bg-[#111827] border border-gray-800 rounded p-4 flex items-center gap-4 font-sans">
                    <div className="p-3 bg-purple-950/40 rounded border border-purple-900/50">
                      <User className="w-5 h-5 text-purple-400 font-sans" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider font-sans">Tracked Project Sites</p>
                      <p className="text-xl font-extrabold text-white mt-0.5 font-mono font-mono font-mono font-mono font-mono">{Object.keys(projectCosts).filter(ref => ref !== 'NON-PROJECT').length} <span className="text-xs text-gray-400 font-normal font-sans">Sites</span></p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Cost breakdown table */}
                  <div className="lg:col-span-8 bg-[#111827] border border-gray-800 rounded-lg overflow-hidden">
                    <div className="px-4 py-3 bg-[#1F2937] border-b border-gray-800">
                      <span className="text-xs font-bold text-white uppercase tracking-wider font-sans font-sans font-sans">
                        Live Labor Expenditure Breakdown by Project Site
                      </span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs font-sans font-sans font-sans font-sans">
                        <thead>
                          <tr className="bg-[#111827] border-b border-gray-800 text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">
                            <th className="py-2.5 px-3">Project Ref</th>
                            <th className="py-2.5 px-3">Project Name</th>
                            <th className="py-2.5 px-3 text-right font-sans">Contract Sum</th>
                            <th className="py-2.5 px-3 text-center font-sans font-sans">Total Hours</th>
                            <th className="py-2.5 px-3 text-right">Labor Cost (Est.)</th>
                            <th className="py-2.5 px-3 text-center">Cost Ratio</th>
                          </tr>
                        </thead>
                        <tbody>
                          {projects.map((p, idx) => {
                            const costInfo = projectCosts[p.projectRef] || { totalHours: 0, totalCost: 0 };
                            const sumVal = p.sum || 0;
                            const ratio = sumVal > 0 ? (costInfo.totalCost / sumVal) * 100 : 0;

                            return (
                              <tr key={p.id || idx} className="border-b border-gray-900 hover:bg-gray-850/10 text-gray-300 font-sans">
                                <td className="py-3 px-3 font-bold font-mono text-indigo-400">{p.projectRef}</td>
                                <td className="py-3 px-3 text-gray-200">
                                  <span className="font-semibold block max-w-[200px] truncate" title={p.name}>{p.name}</span>
                                  <span className="text-[10px] text-gray-500">{p.client || 'General Client'}</span>
                                </td>
                                <td className="py-3 px-3 text-right font-mono text-gray-400">
                                  {sumVal > 0 ? `S$ ${sumVal.toLocaleString()}` : <span className="text-gray-600 italic font-sans text-[11px]">N/A</span>}
                                </td>
                                <td className="py-3 px-3 text-center font-mono font-bold text-white">
                                  {costInfo.totalHours.toFixed(1)} hrs
                                </td>
                                <td className="py-3 px-3 text-right font-mono text-emerald-400 font-bold">
                                  S$ {costInfo.totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </td>
                                <td className="py-3 px-3 text-center">
                                  {sumVal > 0 ? (
                                    <div className="flex flex-col items-center gap-1">
                                      <span className={`font-mono font-bold text-[11px] ${ratio > 50 ? 'text-rose-400' : ratio > 25 ? 'text-amber-400' : 'text-emerald-400'}`}>
                                        {ratio.toFixed(1)}%
                                      </span>
                                      <div className="w-16 bg-gray-900 rounded-full h-1 border border-gray-800 overflow-hidden">
                                        <div
                                          className={`h-full rounded-full ${ratio > 50 ? 'bg-rose-500' : ratio > 25 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                                          style={{ width: `${Math.min(100, ratio)}%` }}
                                        />
                                      </div>
                                    </div>
                                  ) : (
                                    <span className="text-gray-600 italic font-sans text-[10px]">N/A</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Right side: visual CSS/Tailwind bar charts */}
                  <div className="lg:col-span-4 bg-[#111827] border border-gray-800 rounded-lg p-5 space-y-5">
                    <span className="text-xs font-bold text-white uppercase tracking-wider block pb-2 border-b border-gray-800 font-sans">
                      Labor Hours Distribution Index
                    </span>
                    <div className="space-y-4">
                      {projects.map((p, idx) => {
                        const costInfo = projectCosts[p.projectRef] || { totalHours: 0 };
                        if (costInfo.totalHours === 0) return null;
                        const pct = totalHoursLogged > 0 ? (costInfo.totalHours / totalHoursLogged) * 100 : 0;

                        return (
                          <div key={p.id || idx} className="space-y-1 font-sans text-xs">
                            <div className="flex justify-between items-center text-gray-400">
                              <span className="font-bold text-gray-300">{p.projectRef}</span>
                              <span className="font-mono">{costInfo.totalHours.toFixed(1)} hrs ({pct.toFixed(1)}%)</span>
                            </div>
                            <div className="w-full bg-gray-900 rounded-full h-1.5 border border-gray-800 overflow-hidden">
                              <div
                                className="h-full bg-blue-500 rounded-full"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                      {totalHoursLogged === 0 && (
                        <div className="py-12 text-center text-gray-500 text-xs font-sans">
                          No hours logged on any project site yet.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* Add / Edit Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#111827] border border-gray-800 rounded-lg w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-5 py-4 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-500" />
                {modalMode === 'add' ? 'Create Deployment Record' : 'Edit Deployment Record'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white p-1 rounded hover:bg-gray-800 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveDeployment}>
              <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                {errorMsg && (
                  <div className="p-3 bg-rose-950/50 border border-rose-900/50 text-rose-300 rounded text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-3">
                  {/* Date Input */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 font-sans">Date</label>
                    <input
                      type="date"
                      value={parseDDMMMYYYYToYYYYMMDD(formDate)}
                      onChange={(e) => setFormDate(formatYYYYMMDDToDDMMMYYYY(e.target.value))}
                      className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono cursor-pointer"
                      required
                    />
                    <span className="text-[9px] text-gray-500 mt-0.5 block font-sans">Standard Calendar</span>
                  </div>

                  {/* Shift Selection */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Shift Type</label>
                    <select
                      value={formShift}
                      onChange={(e) => setFormShift(e.target.value)}
                      className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="Day Shift">Day Shift (08:00 - 17:00)</option>
                      <option value="Night Shift">Night Shift (20:00 - 05:00)</option>
                    </select>
                  </div>

                  {/* Status Selection */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Status</label>
                    <select
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value)}
                      className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="Present">Present</option>
                      <option value="MC">Medical Leave (MC)</option>
                      <option value="Absent">Absent</option>
                      <option value="Off Day">Off Day</option>
                    </select>
                  </div>
                </div>

                <div className="border-t border-gray-800/80 my-3 pt-3">
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5 items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold text-blue-500 uppercase tracking-widest">1. Link Employee Details</span>
                    
                    <div className="flex items-center gap-3">
                      {/* Hide already deployed toggle */}
                      <label className="flex items-center gap-1.5 cursor-pointer text-[10px] font-bold text-amber-500 select-none">
                        <input
                          type="checkbox"
                          checked={hideAlreadyDeployed}
                          onChange={(e) => setHideAlreadyDeployed(e.target.checked)}
                          className="rounded border-gray-800 bg-[#1F2937] text-amber-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5"
                        />
                        Hide Deployed ({deployedWorkerIdsForDate.size})
                      </label>

                      {modalMode === 'add' && (
                        <label className="flex items-center gap-1.5 cursor-pointer text-[10px] font-bold text-gray-300 select-none">
                          <input
                            type="checkbox"
                            checked={isMultiDeploy}
                            onChange={(e) => {
                              setIsMultiDeploy(e.target.checked);
                              setFormSelectedEmployeeIds([]);
                            }}
                            className="rounded border-gray-800 bg-[#1F2937] text-blue-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5"
                          />
                          Deploy Multiple Workers (Bulk)
                        </label>
                      )}
                    </div>
                  </div>

                  {modalMode === 'add' && isMultiDeploy ? (
                    <div className="bg-[#111827] border border-gray-800/80 rounded-lg p-3 space-y-3">
                      {/* Search and Quick Selection Controls */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="relative flex-1">
                          <Search className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            placeholder="Search workers by ID or name..."
                            value={workerSearchTerm}
                            onChange={(e) => setWorkerSearchTerm(e.target.value)}
                            className="w-full bg-[#1F2937] border border-gray-800 pl-8 pr-3 py-1.5 rounded text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div className="flex gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              const eligibleWorkerIds = workers
                                .filter(w => (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE')
                                .map(w => w.employeeId || '')
                                .filter(id => id && !deployedWorkerIdsForDate.has(id));
                              setFormSelectedEmployeeIds(eligibleWorkerIds);
                            }}
                            className="px-2 py-1.5 bg-gray-800 hover:bg-gray-700 text-white rounded text-[9px] font-bold transition-all cursor-pointer"
                          >
                            Select All
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormSelectedEmployeeIds([])}
                            className="px-2 py-1.5 bg-gray-800 hover:bg-gray-700 text-white rounded text-[9px] font-bold transition-all cursor-pointer"
                          >
                            Deselect All
                          </button>
                        </div>
                      </div>

                      {/* Workers Grid */}
                      <div className="max-h-40 overflow-y-auto border border-gray-800/60 rounded-md p-2 space-y-1.5 bg-black/25 scrollbar-thin scrollbar-thumb-gray-800">
                        {(() => {
                          const liveWorkers = workers.filter(w => (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE');
                          const availableWorkers = liveWorkers.filter(w => !hideAlreadyDeployed || !deployedWorkerIdsForDate.has(w.employeeId || ''));
                          const filtered = availableWorkers.filter(w => {
                            const term = workerSearchTerm.toLowerCase();
                            return (w.employeeId || '').toLowerCase().includes(term) ||
                                   (w.nameOfWorker || w.name || '').toLowerCase().includes(term);
                          });

                          if (filtered.length === 0) {
                            return <p className="text-[10px] text-gray-500 text-center py-2">No matching active workers found</p>;
                          }

                          return filtered.map((w) => {
                            const eId = w.employeeId || '';
                            const isChecked = formSelectedEmployeeIds.includes(eId);
                            const isDeployed = deployedWorkerIdsForDate.has(eId);
                            return (
                              <label
                                key={w.id}
                                className={`flex items-center gap-2 p-1.5 rounded transition-colors ${
                                  isDeployed 
                                    ? 'opacity-40 cursor-not-allowed bg-black/10' 
                                    : isChecked 
                                    ? 'bg-blue-950/20 border border-blue-900/40 cursor-pointer' 
                                    : 'hover:bg-gray-800/30 border border-transparent cursor-pointer'
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  checked={isChecked && !isDeployed}
                                  disabled={isDeployed}
                                  onChange={() => {
                                    if (isDeployed) return;
                                    if (isChecked) {
                                      setFormSelectedEmployeeIds(formSelectedEmployeeIds.filter(id => id !== eId));
                                    } else {
                                      setFormSelectedEmployeeIds([...formSelectedEmployeeIds, eId]);
                                    }
                                  }}
                                  className={`rounded border-gray-800 focus:ring-0 w-3.5 h-3.5 ${
                                    isDeployed ? 'bg-gray-900 text-gray-700 border-gray-950 cursor-not-allowed' : 'bg-[#1F2937] text-blue-500'
                                  }`}
                                />
                                <span className={`font-mono text-xs font-bold ${isDeployed ? 'text-gray-500 line-through' : 'text-blue-400'}`}>{eId}</span>
                                <span className={`text-xs font-medium ${isDeployed ? 'text-gray-500 line-through' : 'text-gray-300'}`}>{w.nameOfWorker || w.name}</span>
                                {isDeployed && (
                                  <span className="text-[9px] bg-amber-950/40 text-amber-500 px-1.5 py-0.5 rounded border border-amber-900/40 ml-auto font-sans font-bold">
                                    Already Deployed
                                  </span>
                                )}
                              </label>
                            );
                          });
                        })()}
                      </div>

                      {/* Selection Summary */}
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-gray-400 font-semibold">
                          Selected: <span className="text-blue-400 font-black">{formSelectedEmployeeIds.length}</span> active worker(s)
                        </span>
                        {formSelectedEmployeeIds.length > 0 && (
                          <span className="text-emerald-500 font-bold flex items-center gap-1 animate-pulse">
                            <Check className="w-3 h-3" /> Ready to bulk deploy
                          </span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-4">
                      {/* Employee ID select / lookup */}
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Employee ID</label>
                        <select
                          value={formEmployeeId}
                          onChange={(e) => handleWorkerSelect(e.target.value)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono cursor-pointer"
                          required
                        >
                          <option value="">-- Select Employee ID --</option>
                          {workers
                            .filter(w => (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE')
                            .filter(w => !hideAlreadyDeployed || !deployedWorkerIdsForDate.has(w.employeeId || ''))
                            .map(w => {
                              const isDeployed = deployedWorkerIdsForDate.has(w.employeeId || '');
                              return (
                                <option 
                                  key={w.id} 
                                  value={w.employeeId || ''}
                                  disabled={isDeployed}
                                >
                                  {w.employeeId} - {w.nameOfWorker || w.name} {isDeployed ? ' (Already Deployed)' : ''}
                                </option>
                              );
                            })
                          }
                        </select>
                      </div>

                      {/* Employee Name - Auto Popped */}
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Employee Name</label>
                        <input
                          type="text"
                          value={formEmployeeName}
                          readOnly
                          placeholder="Auto-populated"
                          className="w-full bg-[#1F2937]/50 border border-gray-800/80 rounded px-3 py-2 text-xs font-semibold text-gray-400 focus:outline-none cursor-not-allowed"
                          required
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="border-t border-gray-800/80 my-3 pt-3 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-extrabold text-amber-500 uppercase tracking-widest block">
                      2. Deployment Segments (Project & Hours Allocation)
                    </span>
                    <button
                      type="button"
                      onClick={handleAddSegment}
                      className="flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold transition-all cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      Add Segment Row
                    </button>
                  </div>

                  <div className="space-y-4">
                    {formSegments.map((seg, idx) => (
                      <div key={idx} className="bg-[#111827] border border-gray-800/80 rounded-lg p-3.5 space-y-3 relative shadow-md">
                        <div className="flex justify-between items-center pb-1.5 border-b border-gray-800/50">
                          <span className="text-[10px] font-extrabold text-blue-400 uppercase tracking-wider">
                            Segment #{idx + 1}
                          </span>
                          {formSegments.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveSegment(idx)}
                              className="text-rose-400 hover:text-rose-300 hover:bg-rose-950/20 p-1 rounded transition-colors cursor-pointer"
                              title="Remove Segment"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          {/* Project Ref Select */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Project Reference</label>
                            <select
                              value={seg.projectRef}
                              onChange={(e) => handleSegmentProjectChange(idx, e.target.value)}
                              className="w-full bg-[#1F2937] border border-gray-800 rounded px-2.5 py-1.5 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono cursor-pointer"
                              required
                            >
                              <option value="">-- Select Project Ref --</option>
                              <option value="NON-PROJECT">NON-PROJECT / OTHER</option>
                              {projects.map((p, i) => (
                                <option key={p.id || i} value={p.projectRef || ''}>
                                  {p.projectRef}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Project Name Auto-Popped */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Project Name</label>
                            <input
                              type="text"
                              value={seg.projectName}
                              onChange={(e) => handleSegmentProjectNameChange(idx, e.target.value)}
                              readOnly={seg.projectRef !== 'NON-PROJECT'}
                              placeholder={seg.projectRef === 'NON-PROJECT' ? "Enter non-project duties" : "Auto-populated"}
                              className={`w-full border rounded px-2.5 py-1.5 text-xs font-semibold focus:outline-none ${
                                seg.projectRef === 'NON-PROJECT'
                                  ? 'bg-[#1F2937] border-gray-800 text-white focus:border-blue-500 font-sans'
                                  : 'bg-[#1F2937]/50 border-gray-800/80 text-gray-400 cursor-not-allowed font-sans'
                              }`}
                              required
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-5 gap-2">
                          {/* Time In */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Time In</label>
                            <input
                              type="text"
                              value={seg.timeIn}
                              onChange={(e) => handleSegmentTimeChange(idx, 'timeIn', e.target.value)}
                              placeholder="08:00"
                              className="w-full bg-[#1F2937] border border-gray-800 rounded px-2 py-1 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono text-center"
                              required
                            />
                          </div>

                          {/* Time Out */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Time Out</label>
                            <input
                              type="text"
                              value={seg.timeOut}
                              onChange={(e) => handleSegmentTimeChange(idx, 'timeOut', e.target.value)}
                              placeholder="12:00"
                              className="w-full bg-[#1F2937] border border-gray-800 rounded px-2 py-1 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono text-center"
                              required
                            />
                          </div>

                          {/* Break (Mins) */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Break (Mins)</label>
                            <input
                              type="number"
                              value={seg.breakMinutes}
                              onChange={(e) => handleSegmentTimeChange(idx, 'breakMinutes', Number(e.target.value))}
                              className="w-full bg-[#1F2937] border border-gray-800 rounded px-2 py-1 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono text-center"
                              required
                            />
                          </div>

                          {/* Hours */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Hours</label>
                            <input
                              type="number"
                              step="0.01"
                              value={seg.workingHours}
                              onChange={(e) => handleSegmentTimeChange(idx, 'workingHours', parseFloat(e.target.value) || 0)}
                              className="w-full bg-gray-950 border border-gray-800 rounded px-2 py-1 text-xs font-bold text-emerald-400 focus:outline-none font-mono text-center"
                              required
                            />
                          </div>

                          {/* Transport Claim */}
                          <div>
                            <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Transport (S$)</label>
                            <input
                              type="number"
                              step="0.01"
                              value={seg.transportClaim || 0}
                              onChange={(e) => handleSegmentTimeChange(idx, 'transportClaim', parseFloat(e.target.value) || 0)}
                              placeholder="0.00"
                              className="w-full bg-[#1F2937] border border-gray-800 rounded px-2 py-1 text-xs font-bold text-amber-400 focus:outline-none focus:border-blue-500 font-mono text-center"
                            />
                          </div>
                        </div>

                        {/* Segment Remarks */}
                        <div>
                          <label className="block text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-1">Remarks / Task Description</label>
                          <input
                            type="text"
                            value={seg.remarks || ''}
                            onChange={(e) => handleSegmentTimeChange(idx, 'remarks', e.target.value)}
                            placeholder="e.g. Conducted daily structural inspections, routing conduit boxes..."
                            className="w-full bg-[#1F2937] border border-gray-800 rounded px-2.5 py-1.5 text-xs font-semibold text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Summary of Total Hours */}
                  <div className="bg-gray-950/60 border border-gray-800 rounded-lg p-3.5 flex justify-between items-center text-xs">
                    <span className="text-gray-400 font-bold uppercase tracking-wider">Total Working Hours (Combined):</span>
                    <span className="text-sm font-extrabold text-emerald-400 font-mono bg-gray-900 px-3 py-1 rounded border border-emerald-950">
                      {parseFloat(formSegments.reduce((sum, s) => sum + s.workingHours, 0).toFixed(2))} hrs
                    </span>
                  </div>
                </div>
              </div>

              <div className="px-5 py-3.5 bg-[#1F2937] border-t border-gray-800 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-transparent hover:bg-gray-800 border border-gray-850 rounded text-xs font-semibold text-gray-400 hover:text-white transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-xs font-bold text-white transition-all shadow shadow-blue-900/30 cursor-pointer"
                >
                  {modalMode === 'add' ? 'Add Schedule Log' : 'Save Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Spreadsheet Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#111827] border border-gray-800 rounded-lg w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="px-5 py-4 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                Manpower Deployment Bulk Importer
              </h4>
              <button onClick={() => { setShowImportModal(false); setScannedRecords([]); }} className="text-gray-400 hover:text-white p-1 rounded hover:bg-gray-800 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Import Source Tabs */}
              <div className="flex border-b border-gray-800 gap-4 pb-2">
                <button
                  onClick={() => setActiveImportTab('drive')}
                  className={`text-xs font-bold pb-2 border-b-2 transition-all ${
                    activeImportTab === 'drive' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Google Drive / Sheets Sync
                </button>
                <button
                  onClick={() => setActiveImportTab('csv')}
                  className={`text-xs font-bold pb-2 border-b-2 transition-all ${
                    activeImportTab === 'csv' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Bulk CSV Paste / Text Import
                </button>
              </div>

              {activeImportTab === 'drive' ? (
                <div className="space-y-4">
                  <div className="bg-[#1A1F2C] border border-[#2A3F4C] rounded-lg p-4 text-gray-300">
                    <p className="text-xs leading-relaxed">
                      Sync Mountec manpower schedules in real-time from official Google Sheets. Clicking connect links your Google Drive safely.
                    </p>
                    
                    {!googleToken ? (
                      <button
                        onClick={handleGoogleAuth}
                        className="mt-3.5 flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-xs font-bold text-white rounded transition-all shadow shadow-blue-900/25 cursor-pointer"
                      >
                        <Shield className="w-3.5 h-3.5" />
                        Connect Google Sheets / Drive
                      </button>
                    ) : (
                      <div className="mt-3.5 flex items-center gap-3">
                        <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5 bg-emerald-950/40 border border-emerald-900/40 px-3 py-1.5 rounded">
                          <Check className="w-3.5 h-3.5" />
                          Google Drive Connected
                        </span>
                        <button
                          onClick={() => fetchDriveFiles(googleToken)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F2937] hover:bg-gray-700 border border-gray-800 rounded text-xs font-semibold text-gray-300 transition-all cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" />
                          Re-scan Drive Files
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Drive file browser picker */}
                  {showDrivePicker && (
                    <div className="space-y-3">
                      <p className="text-[10px] font-extrabold text-gray-500 uppercase tracking-widest">Discovered Spreadsheets</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[180px] overflow-y-auto pr-1">
                        {driveFiles.map((file) => (
                          <button
                            key={file.id}
                            onClick={() => handleSelectDriveFile(file)}
                            className="flex items-center gap-2.5 p-2 bg-[#1A1A1A] hover:bg-[#252525] border border-gray-800 rounded text-left transition-colors text-xs text-white cursor-pointer"
                          >
                            <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <p className="font-semibold truncate text-gray-200" title={file.name}>{file.name}</p>
                              <p className="text-[9px] text-gray-500 font-mono mt-0.5">
                                {file.isPreloaded ? 'Template Preloaded' : `Drive • Mod: ${new Date(file.modifiedTime).toLocaleDateString()}`}
                              </p>
                            </div>
                            <ArrowRight className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs text-gray-400">
                    Paste raw comma-separated values (CSV) directly from Excel or Google Sheets. Include a header row matching:
                  </p>
                  <code className="block bg-gray-950 p-2.5 text-[10px] text-emerald-400 font-mono rounded select-all border border-gray-800/80 leading-normal">
                    Date,Employee ID,Employee Name,Project Ref,Project Name,Time In,Time Out,Total Hours,Shift,Status,Remarks
                  </code>
                  
                  <textarea
                    rows={6}
                    value={bulkCsvText}
                    onChange={(e) => setBulkCsvText(e.target.value)}
                    placeholder={`18-Jul-2026,ME-012,Kshtriy Vicky Kartik,M-2601,Tuas West Manpower,08:00,17:00,8.0,Day Shift,Present,Daily bracket aligning\n18-Jul-2026,ME-005,Ramu Elumalai,M-2601,Tuas West Manpower,08:00,17:00,8.0,Day Shift,Present,Conduit tray routing`}
                    className="w-full bg-[#1F2937] border border-gray-800 rounded p-3 text-xs font-mono text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    onClick={handleCSVImport}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-xs font-bold text-white transition-all shadow shadow-blue-900/30 cursor-pointer"
                  >
                    Parse Paste Entries
                  </button>
                </div>
              )}

              {/* Loader / Scan Progress */}
              {isImporting && (
                <div className="p-3 bg-blue-950/20 border border-blue-900/30 rounded flex items-center gap-3">
                  <RefreshCw className="w-4 h-4 text-blue-500 animate-spin shrink-0" />
                  <span className="text-xs text-blue-300 font-semibold">{importStatus}</span>
                </div>
              )}

              {/* Scanned records confirmation list */}
              {scannedRecords.length > 0 && (
                <div className="space-y-3 pt-3 border-t border-gray-800">
                  <div className="flex justify-between items-center bg-emerald-950/20 border border-emerald-900/30 rounded p-3 text-emerald-400">
                    <span className="text-xs font-bold flex items-center gap-1.5">
                      <Check className="w-4 h-4" />
                      Successfully Scanned {scannedRecords.length} Deployment Entries!
                    </span>
                    <button
                      onClick={applyImportedRecords}
                      disabled={isImporting}
                      className="px-4.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-extrabold shadow shadow-emerald-950/30 disabled:opacity-50 transition-all cursor-pointer"
                    >
                      Apply To Database
                    </button>
                  </div>

                  {/* Scanned Records Review List */}
                  <div className="border border-gray-800 rounded overflow-hidden max-h-[220px] overflow-y-auto">
                    <table className="w-full text-left text-[11px] font-medium border-collapse">
                      <thead className="bg-[#1F2937] text-gray-400 border-b border-gray-800 uppercase font-sans">
                        <tr>
                          <th className="px-3 py-2">Date</th>
                          <th className="px-3 py-2">Worker</th>
                          <th className="px-3 py-2">Project</th>
                          <th className="px-3 py-2 text-center">Time</th>
                          <th className="px-3 py-2 text-center">Hours</th>
                          <th className="px-3 py-2 text-center">Shift</th>
                          <th className="px-3 py-2">Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800 bg-[#0E131F]/35">
                        {scannedRecords.map((rec, i) => (
                          <tr key={i} className="hover:bg-gray-800/25 text-gray-300">
                            <td className="px-3 py-2 font-mono">{rec.date}</td>
                            <td className="px-3 py-2">
                              <span className="font-bold text-white block">{rec.employeeName}</span>
                              <span className="text-[9px] text-gray-500 font-mono">{rec.employeeId}</span>
                            </td>
                            <td className="px-3 py-2">
                              <span className="font-bold text-gray-300 block max-w-[150px] truncate" title={rec.projectName}>{rec.projectName}</span>
                              <span className="text-[9px] text-amber-500 font-mono">{rec.projectRef}</span>
                            </td>
                            <td className="px-3 py-2 text-center font-mono text-[10px]">{rec.timeIn} - {rec.timeOut}</td>
                            <td className="px-3 py-2 text-center font-mono font-bold text-emerald-400">{rec.totalWorkingHours.toFixed(1)}</td>
                            <td className="px-3 py-2 text-center">{rec.shift}</td>
                            <td className="px-3 py-2 text-gray-400 truncate max-w-[120px]" title={rec.remarks}>{rec.remarks || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="px-5 py-3.5 bg-[#1F2937] border-t border-gray-800 flex justify-end">
              <button
                onClick={() => { setShowImportModal(false); setScannedRecords([]); }}
                className="px-4 py-2 bg-[#111827] hover:bg-gray-800 border border-gray-800 rounded text-xs font-semibold text-gray-400 hover:text-white transition-all cursor-pointer"
              >
                Close Importer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
