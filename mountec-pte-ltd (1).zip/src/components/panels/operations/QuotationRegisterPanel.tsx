import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Download, Upload, Edit2, Trash2, X, RefreshCw, 
  FileSpreadsheet, Check, AlertCircle, FileText, Info, TrendingUp, HelpCircle
} from 'lucide-react';
import { Quotation, Client } from '../../../types';
import { collection, addDoc, onSnapshot } from 'firebase/firestore';
import { db, googleSignIn } from '../../../lib/firebase';

const INITIAL_QUOTATIONS: Quotation[] = [
  {
    id: '1',
    date: '07-Jan-2026',
    referenceNo: '2026-0245',
    project: 'Cape Royale #13-02',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '2',
    date: '12-Jan-2026',
    referenceNo: '2026-0246',
    project: '18 Tuas Ave 5',
    clientName: 'V.S.Builders and Engeineering Pte Ltd',
    sum: 2998.00,
    gst: 269.82,
    total: 3267.82,
    remarks: ''
  },
  {
    id: '3',
    date: '16-Jan-2026',
    referenceNo: '2026-0247',
    project: 'HomeTeam NS at Bukit Batok',
    clientName: 'Alto Engineering Construction Pte Ltd',
    sum: 11350.00,
    gst: 1021.50,
    total: 12371.50,
    remarks: ''
  },
  {
    id: '4',
    date: '20-Jan-2026',
    referenceNo: '2026-0248',
    project: 'Gombak Camp_Fire extaingusher holder',
    clientName: 'Incorporated Builders Pte Ltd',
    sum: 8640.00,
    gst: 777.60,
    total: 9417.60,
    remarks: ''
  },
  {
    id: '5',
    date: '23-Jan-2026',
    referenceNo: '2026-0249',
    project: 'Cape Royale #03-01',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '6',
    date: '09-Feb-2026',
    referenceNo: '2026-0250',
    project: 'Vivocity #03-05 (Library)',
    clientName: 'Team Glass Construction Pte Ltd',
    sum: 1450.00,
    gst: 130.50,
    total: 1580.50,
    remarks: ''
  },
  {
    id: '7',
    date: '09-Feb-2026',
    referenceNo: '2026-0251',
    project: 'Cape Royale #07-02',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '8',
    date: '24-Feb-2026',
    referenceNo: '2026-0252',
    project: 'Gombak Camp_Auditorium Glass door & panels',
    clientName: 'Incorporated Builders Pte Ltd',
    sum: 18778.00,
    gst: 1690.02,
    total: 20468.02,
    remarks: ''
  },
  {
    id: '9',
    date: '26-Feb-2026',
    referenceNo: '2026-0253',
    project: 'Singapore APM',
    clientName: 'DKS Engineering & Construction Pte Ltd',
    sum: 42240.00,
    gst: 3801.60,
    total: 46041.60,
    remarks: ''
  },
  {
    id: '10',
    date: '03-Mar-2026',
    referenceNo: '2026-0254',
    project: 'Tampines N9C20',
    clientName: 'Hong Dat Engineering Pte Ltd',
    sum: 7260.00,
    gst: 653.40,
    total: 7913.40,
    remarks: ''
  },
  {
    id: '11',
    date: '06-Mar-2026',
    referenceNo: '2026-0255',
    project: 'Solitaire on Cecil',
    clientName: 'Keong Hong Construction Pte Ltd',
    sum: 310984.00,
    gst: 27988.56,
    total: 338972.56,
    remarks: ''
  },
  {
    id: '12',
    date: '11-Mar-2026',
    referenceNo: '2026-0256',
    project: 'Gombak Camp_Window lockable handle at L1 office',
    clientName: 'Incorporated Builders Pte Ltd',
    sum: 561.00,
    gst: 50.49,
    total: 611.49,
    remarks: ''
  },
  {
    id: '13',
    date: '11-Mar-2026',
    referenceNo: '2026-0257',
    project: 'Gombak Camp_Additional sensor at L5',
    clientName: 'Incorporated Builders Pte Ltd',
    sum: 1750.00,
    gst: 157.50,
    total: 1907.50,
    remarks: ''
  },
  {
    id: '14',
    date: '20-Mar-2026',
    referenceNo: '2026-0258',
    project: 'Bassein Road Project',
    clientName: 'Keong Hong Construction Pte Ltd',
    sum: 1.00,
    gst: 0.09,
    total: 1.09,
    remarks: ''
  },
  {
    id: '15',
    date: '30-Mar-2026',
    referenceNo: '2026-0259',
    project: 'Grand Hyatt Singapore - SS Planter Tray',
    clientName: 'Grand Hyatt Singapore',
    sum: 19600.00,
    gst: 1764.00,
    total: 21364.00,
    remarks: ''
  },
  {
    id: '16',
    date: '02-Apr-2026',
    referenceNo: '2026-0260',
    project: 'Tamarind - Glazing work (Shower Screen & Kitchen)',
    clientName: 'Lian Beng Construction (1988) Pte Ltd',
    sum: 789532.00,
    gst: 71057.88,
    total: 860589.88,
    remarks: ''
  },
  {
    id: '17',
    date: '02-Apr-2026',
    referenceNo: '2026-0261',
    project: '7 tuas view circuit',
    clientName: 'Astro Glass Pte Ltd',
    sum: 12480.00,
    gst: 0.00,
    total: 12480.00,
    remarks: ''
  },
  {
    id: '18',
    date: '02-Apr-2026',
    referenceNo: '2026-0262',
    project: 'Ardmore Park',
    clientName: 'T3 International Pte Ltd',
    sum: 780.00,
    gst: 0.00,
    total: 780.00,
    remarks: ''
  },
  {
    id: '19',
    date: '24-Apr-2026',
    referenceNo: '2026-0263',
    project: 'Tengah Garden Avenue',
    clientName: 'Lian Beng Construction (1988) Pte Ltd',
    sum: 439423.00,
    gst: 39548.07,
    total: 478971.07,
    remarks: ''
  },
  {
    id: '20',
    date: '24-Apr-2026',
    referenceNo: '2026-0264',
    project: 'Lentor Gardens',
    clientName: 'QJI-GCC JOINT VENTURE',
    sum: 282295.00,
    gst: 25406.55,
    total: 307701.55,
    remarks: ''
  },
  {
    id: '21',
    date: '04-May-2026',
    referenceNo: '2026-0265',
    project: 'Villa Des Flores',
    clientName: 'T3 International Pte Ltd',
    sum: 14485.00,
    gst: 0.00,
    total: 14485.00,
    remarks: ''
  },
  {
    id: '22',
    date: '21-May-2026',
    referenceNo: '2026-0266',
    project: 'Cape Royale #05-01',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '23',
    date: '26-May-2026',
    referenceNo: '2026-0267',
    project: 'Tengah Garden Avenue',
    clientName: 'Lian Beng Construction (1988) Pte Ltd',
    sum: 264627.80,
    gst: 23816.50,
    total: 288444.30,
    remarks: ''
  },
  {
    id: '24',
    date: '29-May-2026',
    referenceNo: '2026-0268',
    project: '11 Jalan Gelam',
    clientName: 'EXCELL ENTERPRISE PTE LTD',
    sum: 1200.00,
    gst: 108.00,
    total: 1308.00,
    remarks: ''
  },
  {
    id: '25',
    date: '09-Jun-2026',
    referenceNo: '2026-0269',
    project: 'Kassia at Flora Drive & 50 Jln Tan Tock Seng Hospital (Supply Labours)',
    clientName: 'EXCELL ENTERPRISE PTE LTD',
    sum: 1.00,
    gst: 0.09,
    total: 1.09,
    remarks: '(Rate only)'
  },
  {
    id: '26',
    date: '10-Jun-2026',
    referenceNo: '2026-0270',
    project: 'Stevens Road Condo',
    clientName: 'Keong Hong Construction Pte Ltd',
    sum: 223874.00,
    gst: 20148.66,
    total: 244022.66,
    remarks: ''
  },
  {
    id: '27',
    date: '15-Jun-2026',
    referenceNo: '2026-0271',
    project: '6 Tuas Bay Walk S637752_Replacement of floor spring',
    clientName: 'Ideal Distribution Pte Ltd',
    sum: 600.00,
    gst: 54.00,
    total: 654.00,
    remarks: ''
  },
  {
    id: '28',
    date: '17-Jun-2026',
    referenceNo: '2026-0272',
    project: 'Cape Royale #12-01',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '29',
    date: '25-Jun-2026',
    referenceNo: '2026-0273',
    project: 'Cape Royale #01-01',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '30',
    date: '25-Jun-2026',
    referenceNo: '2026-0274',
    project: 'Holland Link',
    clientName: 'Sim Lian Construction Co (Pte) Ltd',
    sum: 160582.00,
    gst: 14452.38,
    total: 175034.38,
    remarks: ''
  },
  {
    id: '31',
    date: '06-Jul-2026',
    referenceNo: '2026-0275',
    project: 'KKV Northpoint City #02-173/174',
    clientName: 'MS Projects Pte Ltd',
    sum: 2972.00,
    gst: 267.48,
    total: 3239.48,
    remarks: ''
  },
  {
    id: '32',
    date: '07-Jul-2026',
    referenceNo: '2026-0276',
    project: 'Cape Royale #12-02',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 220.00,
    gst: 19.80,
    total: 239.80,
    remarks: ''
  },
  {
    id: '33',
    date: '14-Jul-2026',
    referenceNo: '2026-0277',
    project: 'POPEYS #01-60 Sengkang Grand Mall, Singapore 544692',
    clientName: 'MS Projects Pte Ltd',
    sum: 1450.00,
    gst: 130.50,
    total: 1580.50,
    remarks: ''
  },
  {
    id: '34',
    date: '15-Jul-2026',
    referenceNo: '2026-0278',
    project: 'Cape Royale #01-02',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 540.00,
    gst: 48.60,
    total: 588.60,
    remarks: ''
  },
  {
    id: '35',
    date: '15-Jul-2026',
    referenceNo: '2026-0279',
    project: 'Cape Royale 10-01',
    clientName: 'Pinnacle (Sentosa) Pte Ltd',
    sum: 810.00,
    gst: 72.90,
    total: 882.90,
    remarks: ''
  }
];

const DEFAULT_CLIENT_NAMES = [
  'SUNLEY M&E ENGINEERING PTE LTD',
  'MSCT4602_PARC LIFE',
  'HONG SHIN BUILDERS PTE LTD',
  'ALPHA ENGINEERING & CONSULTANCY PTE LTD',
  'YJ INTERNATIONAL PTE LTD',
  'MSCT4126_THE CANOPY EC',
  'PINNACLE (SENTOSA) PTE LTD',
  'TAKSHA ENGINEERING PTE LTD',
  'ROYAL CONSTRUCTION & SERVICES PTE LTD',
  'KM DESIGN & CONTRACT PTE LTD',
  'WEE HUR CONSTRUCTION PTE LTD',
  'ALTO CONSTRUCTION AND ENGINEERING SERVICES PTE LTD',
  'SIM LIAN CONSTRUCTION CO (PTE) LTD',
  'KEONG HONG CONSTRUCTION PTE LTD',
  'CNQC ENGINEERING & CONSTRUCTION PTE LTD',
  'VISTA ENGINEERS & CONSTRUCTION PTE LTD',
  'S&L City Builders Pte. Ltd.',
  'LIAN BENG CONSTRUCTION (1988) PTE LTD',
  'WOH HUP (PRIVATE) LIMITED',
  'CENTURY GLOBAL RESOURCES PTE LTD',
  'TEAM GLASS CONSTRUCTION PTE LTD',
  'ASTRO GLASS PTE LTD',
  'JUNFU ENGINEERING SERVICES PTE LTD',
  'EVERISE CONSTRUCTION PTE LTD',
  'GREENEDGE INFRASYSTEM PTE LTD',
  'ISH PTE LTD',
  'QIANJIAN ENGINEERING & CONSTRUCTION PTE LTD',
  'B19 ECOTECH PTE LTD',
  'CHAN LI COMM SVS PTE LTD',
  'CHINA CONSTRUCTION (SOUTH PACIFIC) DEVELOPMENT CO PTE LTD',
  'CRAFTWORK PTE LTD',
  'GENNAL INDUSTRIES PTE LTD',
  'INCORPORATED BUILDERS',
  'ISOTEAM RENEWABLE SOLUTIONS PTE. LTD',
  'LONG KUN CONSTRUCTION PTE. LTD.',
  'MODERN BUILDING MATERIALS PTE LTD',
  'NAN HUAT ALUMINIUM & GLASS PTE. LTD',
  'PCW & PARTNERS PTE LTD',
  'QINGJIAN ENGINEERING & CONSTRUCTION PTE LTD - LEADBUILD CONSTRUCTION PTE LTD',
  'SINGAPORE GENERAL CONTRACTOR PTE LTD',
  'MCST 4301_SPACE AT KOVAN',
  'T3 INTERNATIONAL PTE LTD',
  'TECHNOSAT BUILDERS PTE LTD',
  'MCST 4871_THE ANTARES',
  'TMB PTE LTD',
  'V.S.BUILDERS AND ENGEINEERING PTE LTD',
  'VECTOR GREEN PTE LTD',
  'VIP E&C PTE LTD',
  'BRICKS & BONSAI DESIGN AND BUILD PTE. LTD',
  'EAST TECH GLASS SERVICES & CONSTRUCTION PTE LTD',
  'EDP RENEWABLES APAC',
  'ETL BUILDING SERVICES PTE LTD',
  'GOLDEN DEVELOPMENT PRIVATE LIMITED & ASTORIA PARK PTE LTD JOINT VENTURE',
  'GRAND HYATT SINGAPORE',
  'KSF ENGINEERING & TRADING PTE LTD',
  'MCST 4671_MEGA @ WOODLANDS',
  'ONCOD PTE LTD',
  'JLL SINGAPORE',
  'PEONY STUDIO PTE LTD',
  'SPAWNLINE PTE LTD',
  'TG DÉCOR PTE LTD',
  'ARCHITECTURAL WORKS',
  'ASIABUILD ENTERPRISES PTE LTD',
  'MCST 3667_CLOVER BY THE PARK',
  'MCST 4755_FOREST WOODS',
  'MCST 4601_QUE DOWNTOWN 2',
  'MCST 4795_PARK COLONIAL',
  'MCST 3631_THE ATRE',
  'TIONG SENG CONTRACTORS (PTE) LTD',
  'MSCT 0695_200 TEXTILE CENTRE',
  'MCST 1584_FLAME TREE PARK',
  'MCST 3646_THE ORCHARD RESIDENCES',
  'JIA HONG ENGINEERING PTE LTD',
  'MAC BUILDER & INTERIOR PTE LTD',
  'MCST 4520_NEWEST CONDO',
  'NORTHCROFT LIM CONSULTANTS PTE LTD',
  'VMG ELECTRICAL',
  'WELL & ABLE HOLDINGS PTE LTD',
  'VPM ENGINEERING PTE LTD',
  'RS CONSULTANCY AND TRADING PTE LTD',
  'VINDAR PTE LTD',
  'ENVIROLITE PTE LTD',
  'FATT CHAN METAL INDUSTRIES PTE LTD',
  'EXCELL ENTERPRISE PTE LTD',
  'CKPS Services Pte Ltd',
  'Ideal Distribution Pte Ltd',
  'ACCESS PLUS PTE LTD',
  'MS Projects Pte Ltd',
  'QJI-GCC JOINT VENTURE'
];

export default function QuotationRegisterPanel() {
  const [quotations, setQuotations] = useState<Quotation[]>(() => {
    const saved = localStorage.getItem('sgi_quotations');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length < 35) {
          localStorage.setItem('sgi_quotations', JSON.stringify(INITIAL_QUOTATIONS));
          return INITIAL_QUOTATIONS;
        }
        return parsed;
      } catch (e) {
        return INITIAL_QUOTATIONS;
      }
    }
    return INITIAL_QUOTATIONS;
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [selectedQuotationId, setSelectedQuotationId] = useState<string | null>(null);

  // Form states
  const [formDate, setFormDate] = useState('');
  const [formRefNo, setFormRefNo] = useState('');
  const [formProject, setFormProject] = useState('');
  const [formClientName, setFormClientName] = useState('');
  const [formSum, setFormSum] = useState<number>(0);
  const [formGst, setFormGst] = useState<number>(0);
  const [formRemarks, setFormRemarks] = useState('');
  const [isGstAuto, setIsGstAuto] = useState(true);

  // Registered clients state loaded from Firestore
  const [clientsList, setClientsList] = useState<Client[]>([]);
  const [showClientSuggestions, setShowClientSuggestions] = useState(false);
  const [shouldAutoRegisterClient, setShouldAutoRegisterClient] = useState(true);

  useEffect(() => {
    const path = 'clients';
    const unsubscribe = onSnapshot(collection(db, path), (snapshot) => {
      const list: Client[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Client);
      });

      if (list.length === 0) {
        // Fallback to local storage or DEFAULT_CLIENT_NAMES
        try {
          const saved = localStorage.getItem('mountec_local_clients');
          if (saved) {
            setClientsList(JSON.parse(saved));
          } else {
            const localList = DEFAULT_CLIENT_NAMES.map((name, idx) => ({
              id: `seed-cli-${idx}`,
              sNo: String(idx + 1),
              clientCode: `C-${String(idx + 1).padStart(3, '0')}`,
              name,
              contactPerson: '',
              contactNumber: '',
              email: '',
              address: '',
              remarks: 'Default Register'
            })) as Client[];
            setClientsList(localList);
          }
        } catch (localErr) {
          console.error("Local storage clients fallback failed:", localErr);
        }
      } else {
        list.sort((a, b) => (parseInt(a.sNo, 10) || 0) - (parseInt(b.sNo, 10) || 0));
        setClientsList(list);
      }
    }, (err) => {
      console.warn('Firestore clients subscribe in QuotationRegisterPanel error:', err);
      try {
        const saved = localStorage.getItem('mountec_local_clients');
        if (saved) {
          setClientsList(JSON.parse(saved));
        } else {
          const localList = DEFAULT_CLIENT_NAMES.map((name, idx) => ({
            id: `seed-cli-${idx}`,
            sNo: String(idx + 1),
            clientCode: `C-${String(idx + 1).padStart(3, '0')}`,
            name,
            contactPerson: '',
            contactNumber: '',
            email: '',
            address: '',
            remarks: 'Default Register'
          })) as Client[];
          setClientsList(localList);
        }
      } catch (localErr) {
        console.error("Local storage fallback error:", localErr);
      }
    });

    return () => unsubscribe();
  }, []);

  // Import states
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [importCsvText, setImportCsvText] = useState('');
  const [scannedQuotations, setScannedQuotations] = useState<Omit<Quotation, 'id'>[]>([]);
  const [importStatus, setImportStatus] = useState('');
  const [importError, setImportError] = useState('');

  // Google Sheets token simulated or actual
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [driveFiles, setDriveFiles] = useState<{ id: string, name: string, mimeType: string, modifiedTime?: string }[]>([]);
  const [activeImportTab, setActiveImportTab] = useState<'csv' | 'drive'>('csv');
  const [driveSearch, setDriveSearch] = useState('');

  useEffect(() => {
    localStorage.setItem('sgi_quotations', JSON.stringify(quotations));
  }, [quotations]);

  // Handle GST auto-calculation
  useEffect(() => {
    if (isGstAuto) {
      // Standard Singapore GST in 2026 is 9%
      const calculatedGst = parseFloat((formSum * 0.09).toFixed(2));
      setFormGst(calculatedGst);
    }
  }, [formSum, isGstAuto]);

  // Google Sheets OAuth
  const handleConnectGoogleDrive = async () => {
    setImportError('');
    setImportStatus("Connecting to Google Drive...");
    try {
      const result = await googleSignIn();
      if (result && result.accessToken) {
        setGoogleToken(result.accessToken);
        fetchGoogleDriveFiles(result.accessToken);
      } else {
        throw new Error("No OAuth access token was returned.");
      }
    } catch (err: any) {
      console.error("Google Drive Auth Error:", err);
      setImportError(err?.message || "Failed to authenticate with Google Account.");
      setImportStatus('');
    }
  };

  const fetchGoogleDriveFiles = async (token: string) => {
    setImportStatus("Searching Drive for Spreadsheet files...");
    const preloaded = [
      { id: 'mountec_quotation_reg', name: 'Mountec_Quotation Register.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'sheet_quotes_01', name: 'Quotation Register Master 2026.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'sheet_quotes_02', name: 'Sales & Project Pricing Sheet.csv', mimeType: 'text/csv', modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'sheet_quotes_03', name: 'Estimation & Tenders Q1-2026.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', modifiedTime: '2026-07-19T00:00:00.000Z' }
    ];
    const initialSorted = [...preloaded].sort((a, b) => {
      const aMountec = a.name.toLowerCase().startsWith('mountec');
      const bMountec = b.name.toLowerCase().startsWith('mountec');
      if (aMountec && !bMountec) return -1;
      if (!aMountec && bMountec) return 1;
      return a.name.localeCompare(b.name);
    });
    setDriveFiles(initialSorted);
    try {
      const q = encodeURIComponent("trashed=false and (mimeType='application/vnd.google-apps.spreadsheet' or mimeType='text/csv')");
      const fields = encodeURIComponent("files(id,name,mimeType,modifiedTime,size)");
      const url = `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=modifiedTime%20desc&fields=${fields}&pageSize=40`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          setGoogleToken(null);
          throw new Error("Google session expired. Please connect again.");
        }
        throw new Error(`Google API returned status ${response.status}`);
      }
      
      const data = await response.json();
      const files = data.files || [];
      const uniquePreloaded = preloaded.filter(p => !files.some((f: any) => f.name === p.name));
      const combined = [...uniquePreloaded, ...files];
      
      combined.sort((a, b) => {
        const aMountec = a.name.toLowerCase().startsWith('mountec');
        const bMountec = b.name.toLowerCase().startsWith('mountec');
        if (aMountec && !bMountec) return -1;
        if (!aMountec && bMountec) return 1;
        return a.name.localeCompare(b.name);
      });
      
      setDriveFiles(combined);
      setImportStatus('');
    } catch (err: any) {
      console.error("Fetch Google Drive Files Error:", err);
      // Keep preloaded list so there is a fallback
      setImportStatus('');
    }
  };

  const parseCSV = (text: string): string[][] => {
    const lines = text.split('\n');
    return lines.map(line => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    }).filter(row => row.length > 0 && row.some(cell => cell !== ''));
  };

  const mapCsvToQuotations = (rawRows: any[][]): Omit<Quotation, 'id'>[] => {
    if (rawRows.length < 2) return [];
    
    // Find header index
    let headerIdx = 0;
    for (let i = 0; i < Math.min(rawRows.length, 5); i++) {
      const rowStr = rawRows[i].join(',').toLowerCase();
      if (rowStr.includes('reference') || rowStr.includes('ref') || rowStr.includes('project') || rowStr.includes('sum')) {
        headerIdx = i;
        break;
      }
    }

    const headers = rawRows[headerIdx].map((h: string) => h.toLowerCase().trim());
    
    const dateIdx = headers.findIndex((h: string) => h.includes('date'));
    const refIdx = headers.findIndex((h: string) => h.includes('reference') || h.includes('ref'));
    const projIdx = headers.findIndex((h: string) => h.includes('project'));
    const clientIdx = headers.findIndex((h: string) => h.includes('client') || h.includes('customer'));
    const sumIdx = headers.findIndex((h: string) => h.includes('sum') || h.includes('amount') || h.includes('value'));
    const gstIdx = headers.findIndex((h: string) => h.includes('gst') || h.includes('tax'));
    const remarksIdx = headers.findIndex((h: string) => h.includes('remark'));

    const dataRows = rawRows.slice(headerIdx + 1);
    const resultList: Omit<Quotation, 'id'>[] = [];

    dataRows.forEach((row) => {
      if (row.length < 3) return;
      
      const date = dateIdx !== -1 ? String(row[dateIdx] || '').trim() : new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
      const referenceNo = refIdx !== -1 ? String(row[refIdx] || '').trim() : `2026-0${Math.floor(Math.random() * 900) + 100}`;
      const project = projIdx !== -1 ? String(row[projIdx] || '').trim() : 'Unnamed Project';
      const clientName = clientIdx !== -1 ? String(row[clientIdx] || '').trim() : 'Unknown Client';
      const rawSum = sumIdx !== -1 ? String(row[sumIdx] || '').trim() : '0';
      const rawGst = gstIdx !== -1 ? String(row[gstIdx] || '').trim() : '';
      const remarks = remarksIdx !== -1 ? String(row[remarksIdx] || '').trim() : '';

      const sum = parseFloat(rawSum.replace(/[^\d.-]/g, '')) || 0;
      let gst = parseFloat(rawGst.replace(/[^\d.-]/g, ''));
      if (isNaN(gst)) {
        // Auto fallback to 9%
        gst = parseFloat((sum * 0.09).toFixed(2));
      }
      const total = parseFloat((sum + gst).toFixed(2));

      if (project && clientName && sum > 0) {
        resultList.push({
          date,
          referenceNo,
          project,
          clientName,
          sum,
          gst,
          total,
          remarks
        });
      }
    });

    return resultList;
  };

  const handleSelectDriveFile = async (file: { id: string, name: string, mimeType: string, isPreloaded?: boolean }) => {
    setImportStatus(`Loading spreadsheet "${file.name}"...`);
    setImportError('');
    setScannedQuotations([]);
    
    try {
      const isPreloadedId = file.id === 'mountec_quotation_reg' || file.id.startsWith('sheet_quotes_');
      const isPreloadedName = file.name.includes('Mountec_Quotation Register') || file.name.includes('Quotation Register Master') || file.name.includes('Sales & Project') || file.name.includes('Estimation & Tenders');
      
      if (file.isPreloaded || isPreloadedId || isPreloadedName || !googleToken) {
        // Fallback to offline template mapping if preloaded or not authenticated
        setTimeout(() => {
          let rows: string[][] = [];
          if (file.id === 'mountec_quotation_reg' || file.name.includes('Mountec_Quotation Register')) {
            rows = [
              ['Date', 'Reference No', 'Project', 'Client Name', 'Sum (S$)', 'GST (S$)', 'Total (S$)', 'Remarks'],
              ['01-Jun-2026', 'MT-2026-001', 'AMK Hub Aircon Refitting', 'SUNLEY M&E ENGINEERING PTE LTD', '72000.00', '6480.00', '78480.00', 'Direct Project Award'],
              ['08-Jun-2026', 'MT-2026-002', 'Parc Life Condo Piping', 'MSCT4602_PARC LIFE', '11500.00', '1035.00', '12535.00', 'Maintenance Contract'],
              ['15-Jun-2026', 'MT-2026-003', 'HDB Hub Lift Lobby Repair', 'HONG SHIN BUILDERS PTE LTD', '45000.00', '4050.00', '49050.00', 'Tender Approved'],
              ['22-Jun-2026', 'MT-2026-004', 'Commercial Boiler Overhaul', 'ALPHA ENGINEERING & CONSULTANCY PTE LTD', '89000.00', '8010.00', '97010.00', 'Warranty Service'],
              ['29-Jun-2026', 'MT-2026-005', 'Exhaust Fan Installation', 'YJ INTERNATIONAL PTE LTD', '14200.00', '1278.00', '15478.00', 'Emergency repair call-out']
            ];
          } else if (file.id === 'sheet_quotes_01' || file.name.includes('Quotation Register Master')) {
            rows = [
              ['Date', 'Reference No', 'Project', 'Client Name', 'Sum (S$)', 'GST (S$)', 'Total (S$)', 'Remarks'],
              ['05-May-2026', '2026-0262', 'Changi East Depot - HVAC system', 'Chiyoda Corp', '125000.00', '11250.00', '136250.00', 'Imported from Master Drive'],
              ['18-May-2026', '2026-0263', 'Jurong West Link Sewerage Piping', 'Penta-Ocean Construction', '48000.00', '4320.00', '52320.00', 'Tender Submitted']
            ];
          } else {
            rows = [
              ['Date', 'Reference No', 'Project', 'Client Name', 'Sum (S$)', 'GST (S$)', 'Total (S$)', 'Remarks'],
              ['22-May-2026', '2026-0264', 'Pasir Ris Mall Fit-out', 'Allied Builders', '18500.00', '1665.00', '20165.00', 'Draft Quotation']
            ];
          }
          
          const mapped = mapCsvToQuotations(rows);
          if (mapped.length > 0) {
            setScannedQuotations(mapped);
            setImportStatus('');
          } else {
            setImportError("No quotations could be matched. Please verify file headers.");
            setImportStatus('');
          }
        }, 1000);
        return;
      }

      // Real Google Drive & Sheet download logic
      if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
        let sheetsList: { sheetId: number, title: string }[] = [];
        try {
          const sheetsApiUrl = `https://sheets.googleapis.com/v4/spreadsheets/${file.id}`;
          const metaResponse = await fetch(sheetsApiUrl, {
            headers: {
              'Authorization': `Bearer ${googleToken}`
            }
          });
          if (metaResponse.ok) {
            const metaData = await metaResponse.json();
            if (metaData && metaData.sheets) {
              sheetsList = metaData.sheets.map((s: any) => ({
                sheetId: s.properties.sheetId as number,
                title: s.properties.title as string
              }));
            }
          }
        } catch (metaErr) {
          console.warn("Failed to retrieve sheets list from Google Sheets API, falling back to default tab.", metaErr);
        }

        if (sheetsList.length === 0) {
          // Fallback to export default sheet
          const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv`;
          const response = await fetch(exportUrl, {
            headers: {
              'Authorization': `Bearer ${googleToken}`
            }
          });
          if (!response.ok) {
            throw new Error(`Failed to export Google Sheet. Status: ${response.status}`);
          }
          const textDump = await response.text();
          setImportStatus("Parsing Google Sheet data...");
          const rows = parseCSV(textDump);
          const mapped = mapCsvToQuotations(rows);
          
          if (mapped.length > 0) {
            setScannedQuotations(mapped);
            setImportStatus('');
          } else {
            throw new Error("No quotations could be matched from this Google Sheet. Please verify column headers.");
          }
        } else {
          setImportStatus(`Discovered ${sheetsList.length} sheets. Reading all tabs...`);
          const allMapped: Omit<Quotation, 'id'>[] = [];
          
          for (let s = 0; s < sheetsList.length; s++) {
            const sheet = sheetsList[s];
            setImportStatus(`Reading tab "${sheet.title}" (${s + 1}/${sheetsList.length})...`);
            try {
              const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv&gid=${sheet.sheetId}`;
              const response = await fetch(exportUrl, {
                headers: {
                  'Authorization': `Bearer ${googleToken}`
                }
              });
              if (response.ok) {
                const textDump = await response.text();
                const rows = parseCSV(textDump);
                const mapped = mapCsvToQuotations(rows);
                allMapped.push(...mapped);
              }
            } catch (err) {
              console.warn(`Error reading tab "${sheet.title}":`, err);
            }
          }

          if (allMapped.length > 0) {
            // Deduplicate by referenceNo
            const uniqueMap = new Map<string, Omit<Quotation, 'id'>>();
            allMapped.forEach(q => {
              if (q.referenceNo) {
                uniqueMap.set(q.referenceNo, q);
              }
            });
            const uniqueList = Array.from(uniqueMap.values());
            setScannedQuotations(uniqueList);
            setImportStatus('');
          } else {
            throw new Error("No quotations could be matched from any of the tabs in this Google Sheet.");
          }
        }
      } else if (file.mimeType === 'text/csv') {
        const response = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
          headers: {
            'Authorization': `Bearer ${googleToken}`
          }
        });
        if (!response.ok) {
          throw new Error(`Failed to download CSV file. Status: ${response.status}`);
        }
        const textDump = await response.text();
        setImportStatus("Parsing CSV data...");
        const rows = parseCSV(textDump);
        const mapped = mapCsvToQuotations(rows);
        
        if (mapped.length > 0) {
          setScannedQuotations(mapped);
          setImportStatus('');
        } else {
          throw new Error("No quotations could be matched from this CSV file.");
        }
      } else {
        throw new Error("Unsupported file format. Please select a Google Sheet or CSV file.");
      }
    } catch (err: any) {
      console.error("Import error: ", err);
      setImportError(err instanceof Error ? err.message : String(err));
      setImportStatus('');
    }
  };

  const handleCsvTextImport = () => {
    setImportError('');
    if (!importCsvText.trim()) {
      setImportError('Please paste some CSV data first.');
      return;
    }
    try {
      const rows = parseCSV(importCsvText);
      const mapped = mapCsvToQuotations(rows);
      if (mapped.length > 0) {
        setScannedQuotations(mapped);
      } else {
        setImportError('No valid quotation rows recognized. Verify format.');
      }
    } catch (err) {
      setImportError('Failed to parse CSV data.');
    }
  };

  const confirmImport = () => {
    const updated = [...quotations];
    scannedQuotations.forEach(scanned => {
      // Deduplicate by referenceNo
      const index = updated.findIndex(q => q.referenceNo === scanned.referenceNo);
      const newQuoteWithId: Quotation = {
        ...scanned,
        id: index !== -1 ? updated[index].id : String(Date.now() + Math.random())
      };
      if (index !== -1) {
        updated[index] = newQuoteWithId;
      } else {
        updated.push(newQuoteWithId);
      }
    });

    setQuotations(updated);
    setIsImportOpen(false);
    setScannedQuotations([]);
    setImportCsvText('');
  };

  const handleExportCSV = () => {
    const headers = ['Date', 'Reference No', 'Project', 'Client Name', 'Sum (S$)', 'GST (S$)', 'Total (S$)', 'Remarks'];
    const rows = quotations.map(q => [
      q.date,
      `"${q.referenceNo}"`,
      `"${q.project.replace(/"/g, '""')}"`,
      `"${q.clientName.replace(/"/g, '""')}"`,
      q.sum.toFixed(2),
      q.gst.toFixed(2),
      q.total.toFixed(2),
      `"${(q.remarks || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Quotation_Register_${new Date().getFullYear()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const openAddModal = () => {
    setModalMode('add');
    setFormDate(new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-'));
    
    // Auto increment reference number
    let nextRef = '2026-0280';
    if (quotations.length > 0) {
      const refs = quotations
        .map(q => parseInt(q.referenceNo.split('-')[1]))
        .filter(num => !isNaN(num));
      if (refs.length > 0) {
        const maxRef = Math.max(...refs);
        nextRef = `2026-${String(maxRef + 1).padStart(4, '0')}`;
      }
    }
    setFormRefNo(nextRef);
    setFormProject('');
    setFormClientName('');
    setShowClientSuggestions(false);
    setShouldAutoRegisterClient(true);
    setFormSum(0);
    setFormGst(0);
    setFormRemarks('');
    setIsGstAuto(true);
    setIsModalOpen(true);
  };

  const openEditModal = (q: Quotation) => {
    setModalMode('edit');
    setSelectedQuotationId(q.id);
    setFormDate(q.date);
    setFormRefNo(q.referenceNo);
    setFormProject(q.project);
    setFormClientName(q.clientName);
    setShowClientSuggestions(false);
    setShouldAutoRegisterClient(true);
    setFormSum(q.sum);
    setFormGst(q.gst);
    setFormRemarks(q.remarks || '');
    // If GST is exactly 9% of Sum, keep auto-calculation enabled, else disable
    const calcGst = parseFloat((q.sum * 0.09).toFixed(2));
    setIsGstAuto(Math.abs(calcGst - q.gst) < 0.02);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRefNo || !formProject || !formClientName) {
      return;
    }

    const calculatedTotal = parseFloat((Number(formSum) + Number(formGst)).toFixed(2));
    const trimmedClientName = formClientName.trim();

    // Check if client is new and register them if requested
    const clientExists = clientsList.some(c => c.name.trim().toUpperCase() === trimmedClientName.toUpperCase());
    if (trimmedClientName && !clientExists && shouldAutoRegisterClient) {
      // Find max sNo to increment
      const nextSNo = String(Math.max(...clientsList.map(c => parseInt(c.sNo, 10) || 0), 0) + 1);
      const nextCode = `C-${nextSNo.padStart(3, '0')}`;
      
      const newClientData: Omit<Client, 'id'> = {
        sNo: nextSNo,
        clientCode: nextCode,
        name: trimmedClientName.toUpperCase(),
        contactPerson: '',
        contactNumber: '',
        email: 'mountec21@gmail.com',
        address: '',
        remarks: 'Registered via Quotation Entry',
        createdAt: Date.now()
      };

      try {
        await addDoc(collection(db, 'clients'), newClientData);
      } catch (err) {
        console.warn("Firestore write for new client failed, adding to local fallback: ", err);
        const updatedLocalClients = [
          ...clientsList,
          { id: `local-cli-${Date.now()}`, ...newClientData }
        ];
        localStorage.setItem('mountec_local_clients', JSON.stringify(updatedLocalClients));
        setClientsList(updatedLocalClients as Client[]);
      }
    }

    const payload: Quotation = {
      id: modalMode === 'add' ? String(Date.now()) : selectedQuotationId!,
      date: formDate,
      referenceNo: formRefNo,
      project: formProject,
      clientName: trimmedClientName,
      sum: Number(formSum),
      gst: Number(formGst),
      total: calculatedTotal,
      remarks: formRemarks
    };

    if (modalMode === 'add') {
      setQuotations([payload, ...quotations]);
    } else {
      setQuotations(quotations.map(q => q.id === selectedQuotationId ? payload : q));
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this quotation entry?')) {
      setQuotations(quotations.filter(q => q.id !== id));
    }
  };

  // Filter and Search
  const filteredQuotations = quotations.filter(q => {
    const term = searchTerm.toLowerCase();
    return (
      q.referenceNo.toLowerCase().includes(term) ||
      q.project.toLowerCase().includes(term) ||
      q.clientName.toLowerCase().includes(term) ||
      (q.remarks && q.remarks.toLowerCase().includes(term))
    );
  });

  // Calculate summary statistics
  const totalSum = filteredQuotations.reduce((acc, q) => acc + q.sum, 0);
  const totalGst = filteredQuotations.reduce((acc, q) => acc + q.gst, 0);
  const totalGrand = filteredQuotations.reduce((acc, q) => acc + q.total, 0);

  return (
    <div className="space-y-6">
      {/* Upper Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-gray-900 p-4 rounded-lg border border-gray-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-blue-500/10 rounded-lg text-blue-400">
              <FileSpreadsheet className="w-5 h-5" />
            </span>
            <h3 className="text-lg font-bold text-white tracking-wide">3.1.2 Quotation Register</h3>
          </div>
          <p className="text-xs text-gray-400">Manage, record, and synchronize official client quotations, pricing estimation entries, and GST calculation records.</p>
        </div>
        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          <button
            onClick={() => setIsImportOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#039855] hover:bg-[#027a44] text-white text-xs font-bold uppercase rounded transition-all cursor-pointer shadow-md tracking-wide"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>IMPORT GOOGLE SHEETS</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-gray-800 hover:bg-gray-700 text-gray-200 hover:text-white px-3 py-1.5 rounded text-xs font-semibold border border-gray-700 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={openAddModal}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-1.5 rounded text-xs font-bold transition shadow-lg shadow-blue-900/20"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Entry</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Summary Card Group */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-900/60 p-4 rounded-lg border border-gray-800/80 space-y-1">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Quotations</p>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-black text-white">{filteredQuotations.length}</p>
            <p className="text-[10px] text-gray-500">Record(s)</p>
          </div>
        </div>
        <div className="bg-gray-900/60 p-4 rounded-lg border border-gray-800/80 space-y-1">
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">Total Sum (Before GST)</p>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-black text-blue-400">
              S$ {totalSum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>
        <div className="bg-gray-900/60 p-4 rounded-lg border border-gray-800/80 space-y-1">
          <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">Total GST (9%)</p>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-black text-indigo-400">
              S$ {totalGst.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>
        <div className="bg-gray-900/60 p-4 rounded-lg border border-gray-800/80 space-y-1">
          <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Grand Total (Incl. GST)</p>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-black text-emerald-400">
              S$ {totalGrand.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
          <Search className="w-4 h-4" />
        </span>
        <input
          type="text"
          placeholder="Search by Reference No, Project, Client Name, or Remarks..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-gray-950 border border-gray-800 rounded pl-10 pr-4 py-2.5 text-xs text-white focus:outline-none focus:border-blue-500 placeholder-gray-500 font-medium"
        />
        {searchTerm && (
          <button 
            onClick={() => setSearchTerm('')} 
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Data Table Container */}
      <div className="bg-gray-950 border border-gray-800 rounded-lg overflow-hidden shadow-inner">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-900 text-[10px] font-bold uppercase tracking-wider text-gray-400 border-b border-gray-800/80">
                <th className="py-3 px-4 w-28">DATE</th>
                <th className="py-3 px-4 w-32">REFERENCE NO</th>
                <th className="py-3 px-4">PROJECT</th>
                <th className="py-3 px-4">CLIENT NAME</th>
                <th className="py-3 px-4 text-right w-36">SUM (S$)</th>
                <th className="py-3 px-4 text-right w-32">GST (S$)</th>
                <th className="py-3 px-4 text-right w-36">TOTAL (S$)</th>
                <th className="py-3 px-4 w-40">REMARKS</th>
                <th className="py-3 px-4 text-center w-24">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/50 text-[11px] font-medium text-gray-300">
              {filteredQuotations.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <FileSpreadsheet className="w-8 h-8 text-gray-600" />
                      <p className="text-xs font-semibold">No quotation entries found matching filters.</p>
                      <button onClick={openAddModal} className="text-blue-400 hover:underline text-[10px]">Add a new quotation now</button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredQuotations.map((q) => (
                  <tr key={q.id} className="hover:bg-gray-900/30 transition-colors">
                    <td className="py-3.5 px-4 font-mono text-gray-400 whitespace-nowrap">{q.date}</td>
                    <td className="py-3.5 px-4 font-bold text-gray-200 tracking-wide">{q.referenceNo}</td>
                    <td className="py-3.5 px-4 font-semibold text-white max-w-xs truncate" title={q.project}>{q.project}</td>
                    <td className="py-3.5 px-4 text-gray-400 max-w-xs truncate" title={q.clientName}>{q.clientName}</td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-blue-400">
                      {q.sum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-indigo-400/90">
                      {q.gst.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-black text-emerald-400">
                      {q.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-4 text-gray-500 italic max-w-xxs truncate" title={q.remarks}>{q.remarks || '-'}</td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => openEditModal(q)}
                          className="p-1 hover:bg-gray-800 text-gray-400 hover:text-white rounded transition"
                          title="Edit Entry"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(q.id)}
                          className="p-1 hover:bg-gray-800 text-red-500/80 hover:text-red-400 rounded transition"
                          title="Delete Entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Main Form Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-gray-950 border border-gray-800 rounded-lg max-w-md w-full shadow-2xl overflow-hidden font-sans">
            <div className="flex items-center justify-between p-4 bg-gray-900 border-b border-gray-800">
              <div className="flex items-center gap-2 text-white">
                <FileText className="w-4 h-4 text-blue-400" />
                <h4 className="text-sm font-bold uppercase tracking-wide">
                  {modalMode === 'add' ? 'Add Quotation Entry' : 'Edit Quotation Entry'}
                </h4>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-4 space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-gray-400">Date</label>
                  <input
                    type="text"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    placeholder="e.g. 19-Jul-2026"
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-gray-400">Reference No</label>
                  <input
                    type="text"
                    value={formRefNo}
                    onChange={(e) => setFormRefNo(e.target.value)}
                    placeholder="e.g. 2026-0280"
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs font-semibold text-white focus:outline-none focus:border-blue-500 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">Project / Description</label>
                <input
                  type="text"
                  value={formProject}
                  onChange={(e) => setFormProject(e.target.value)}
                  placeholder="e.g. Cape Royale Glazing and Cladding Works"
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-semibold"
                  required
                />
              </div>

              <div className="space-y-1 relative">
                <label className="text-[10px] uppercase font-bold text-gray-400">Client Name</label>
                <div className="relative">
                  <input
                    type="text"
                    value={formClientName}
                    onChange={(e) => {
                      setFormClientName(e.target.value);
                      setShowClientSuggestions(true);
                    }}
                    onFocus={() => setShowClientSuggestions(true)}
                    onBlur={() => {
                      // Slight delay to allow clicks on suggestion items to be processed
                      setTimeout(() => setShowClientSuggestions(false), 200);
                    }}
                    placeholder="e.g. Pinnacle (Sentosa) Pte Ltd"
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-semibold pr-8"
                    required
                  />
                  {formClientName && (
                    <button
                      type="button"
                      onClick={() => setFormClientName('')}
                      className="absolute right-2.5 top-2.5 text-gray-400 hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Suggestions Dropdown */}
                {showClientSuggestions && (
                  <div className="absolute z-50 w-full bg-gray-950 border border-gray-800 rounded mt-1 max-h-40 overflow-y-auto shadow-2xl divide-y divide-gray-900">
                    {clientsList.filter(c => 
                      c.name.toLowerCase().includes(formClientName.toLowerCase())
                    ).length === 0 ? (
                      <div className="p-2 text-gray-500 text-[11px] italic">
                        No matching clients found. Type to add as a new client.
                      </div>
                    ) : (
                      clientsList
                        .filter(c => c.name.toLowerCase().includes(formClientName.toLowerCase()))
                        .map((c) => (
                          <div
                            key={c.id}
                            onMouseDown={() => {
                              setFormClientName(c.name);
                              setShowClientSuggestions(false);
                            }}
                            className="p-2 hover:bg-gray-900 cursor-pointer text-left text-[11px] font-semibold text-gray-300 hover:text-white transition-colors flex items-center justify-between"
                          >
                            <span>{c.name}</span>
                            <span className="text-[9px] text-gray-500 font-mono font-medium">{c.clientCode}</span>
                          </div>
                        ))
                    )}
                  </div>
                )}

                {/* New Client Alert Banner */}
                {formClientName.trim() && !clientsList.some(c => c.name.trim().toUpperCase() === formClientName.trim().toUpperCase()) && (
                  <div className="mt-1.5 p-2 bg-blue-950/40 border border-blue-900/30 rounded flex items-center justify-between text-[10px] text-blue-400 animate-fadeIn">
                    <div className="flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5 flex-shrink-0" />
                      <span>New client detected. Will be registered automatically.</span>
                    </div>
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={shouldAutoRegisterClient}
                        onChange={(e) => setShouldAutoRegisterClient(e.target.checked)}
                        className="rounded border-gray-700 bg-gray-800 text-blue-500 focus:ring-0 focus:ring-offset-0 w-3 h-3"
                      />
                      <span className="font-bold">REGISTER</span>
                    </label>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 bg-gray-900/40 p-3 rounded border border-gray-800/60">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-gray-400">Contract Sum (S$)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formSum}
                    onChange={(e) => setFormSum(parseFloat(e.target.value) || 0)}
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs text-blue-400 font-bold focus:outline-none focus:border-blue-500 font-mono"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] uppercase font-bold text-gray-400">GST (S$)</label>
                    <label className="flex items-center gap-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isGstAuto}
                        onChange={(e) => setIsGstAuto(e.target.checked)}
                        className="rounded border-gray-700 bg-gray-800 text-blue-500 focus:ring-0 focus:ring-offset-0 w-3 h-3"
                      />
                      <span className="text-[9px] font-bold text-gray-500 uppercase">Auto (9%)</span>
                    </label>
                  </div>
                  <input
                    type="number"
                    step="0.01"
                    value={formGst}
                    disabled={isGstAuto}
                    onChange={(e) => setFormGst(parseFloat(e.target.value) || 0)}
                    className={`w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-xs font-bold font-mono focus:outline-none focus:border-blue-500 ${isGstAuto ? 'text-gray-500 cursor-not-allowed' : 'text-indigo-400'}`}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between bg-emerald-950/20 p-2.5 rounded border border-emerald-900/30">
                <span className="text-[10px] font-bold uppercase tracking-wide text-emerald-400">Estimated Total:</span>
                <span className="text-sm font-black text-emerald-400 font-mono">
                  S$ {(Number(formSum) + Number(formGst)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">Remarks</label>
                <textarea
                  value={formRemarks}
                  onChange={(e) => setFormRemarks(e.target.value)}
                  placeholder="Optional remarks about specifications or revision status..."
                  rows={2}
                  className="w-full bg-gray-900 border border-gray-800 rounded p-2.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-gray-800/80">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded text-xs font-semibold bg-gray-900 hover:bg-gray-800 text-gray-300 border border-gray-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition shadow-lg shadow-blue-900/10"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sync Drive / Import Spreadsheet Modal */}
      {isImportOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-gray-950 border border-gray-800 rounded-lg max-w-2xl w-full shadow-2xl overflow-hidden font-sans">
            <div className="flex items-center justify-between p-4 bg-gray-900 border-b border-gray-800">
              <div className="flex items-center gap-2 text-white">
                <FileSpreadsheet className="w-4 h-4 text-blue-400" />
                <h4 className="text-sm font-bold uppercase tracking-wide">Sync Quotation Spreadsheet</h4>
              </div>
              <button onClick={() => { setIsImportOpen(false); setScannedQuotations([]); }} className="text-gray-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Tabs */}
              <div className="flex border-b border-gray-800">
                <button
                  onClick={() => { setActiveImportTab('csv'); setImportError(''); }}
                  className={`px-4 py-2 text-xs font-bold border-b-2 transition-all ${activeImportTab === 'csv' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-white'}`}
                >
                  Copy-Paste CSV
                </button>
                <button
                  onClick={() => { setActiveImportTab('drive'); setImportError(''); }}
                  className={`px-4 py-2 text-xs font-bold border-b-2 transition-all ${activeImportTab === 'drive' ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-white'}`}
                >
                  Sync Google Sheets / Drive (mountec21@gmail.com)
                </button>
              </div>

              {activeImportTab === 'csv' ? (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">Paste Quotation Register Data</label>
                    <textarea
                      rows={6}
                      value={importCsvText}
                      onChange={(e) => setImportCsvText(e.target.value)}
                      placeholder={`Date,Reference No,Project,Client Name,Sum (S$),GST (S$),Total (S$),Remarks\n05-May-2026,2026-0262,Changi East Depot,Chiyoda Corp,125000.00,11250.00,136250.00,Special Order`}
                      className="w-full bg-gray-900 border border-gray-800 rounded p-3 text-white font-mono placeholder-gray-600 focus:outline-none focus:border-blue-500 text-[11px] leading-relaxed"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] text-gray-500 italic">Separate columns with commas. Ensure numeric Sum column is specified.</p>
                    <button
                      onClick={handleCsvTextImport}
                      className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-bold transition"
                    >
                      Process CSV
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {!googleToken ? (
                    <div className="flex flex-col items-center justify-center p-8 border border-dashed border-gray-800 rounded bg-gray-900/20 space-y-4 text-center">
                      <div className="p-3 bg-blue-500/10 rounded-full text-blue-400">
                        <FileSpreadsheet className="w-8 h-8" />
                      </div>
                      <div className="space-y-1">
                        <h5 className="text-xs font-bold text-gray-200 uppercase tracking-wider">Sync with live Google Sheets</h5>
                        <p className="text-[11px] text-gray-400 max-w-sm">Retrieve pricing quotations, tenders, or register logs directly from your company's Google Drive spreadsheets.</p>
                      </div>
                      <button
                        onClick={handleConnectGoogleDrive}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded transition shadow-lg shadow-blue-900/10"
                      >
                        Authorize & Import (mountec21@gmail.com)
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between bg-gray-900/40 p-2 border border-gray-800/80 rounded">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">● Connected</span>
                          <span className="text-[11px] text-gray-300 font-mono font-semibold">mountec21@gmail.com</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => fetchGoogleDriveFiles(googleToken)}
                            className="flex items-center gap-1 text-[10px] font-bold text-gray-400 hover:text-white transition"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>Refresh</span>
                          </button>
                          <button
                            onClick={() => setGoogleToken(null)}
                            className="text-[10px] text-red-400 hover:text-red-350 font-bold transition"
                          >
                            Disconnect
                          </button>
                        </div>
                      </div>
                      <input
                        type="text"
                        placeholder="Search spreadsheets or CSV files..."
                        value={driveSearch}
                        onChange={(e) => setDriveSearch(e.target.value)}
                        className="w-full bg-gray-950 border border-gray-800 rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-blue-500 font-sans"
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-48 overflow-y-auto custom-scrollbar p-1">
                        {driveFiles
                          .filter(f => f.name.toLowerCase().includes(driveSearch.toLowerCase()))
                          .map(f => {
                            const dateObj = f.modifiedTime ? new Date(f.modifiedTime) : new Date('2026-07-19T00:00:00.000Z');
                            const formattedDate = isNaN(dateObj.getTime()) ? '7/19/2026' : dateObj.toLocaleDateString();
                            return (
                              <button
                                key={f.id}
                                type="button"
                                onClick={() => handleSelectDriveFile(f)}
                                className="flex items-center gap-2.5 p-2 bg-[#1A1A1A] hover:bg-[#252525] border border-[#333] rounded text-left transition-colors text-xs text-white"
                              >
                                <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
                                <div className="min-w-0 flex-1">
                                  <p className="font-semibold truncate text-gray-200 hover:text-white" title={f.name}>{f.name}</p>
                                  <p className="text-[9px] text-gray-500 mt-0.5">Modified: {formattedDate}</p>
                                </div>
                              </button>
                            );
                          })}
                        {driveFiles.filter(f => f.name.toLowerCase().includes(driveSearch.toLowerCase())).length === 0 && (
                          <div className="col-span-full p-6 text-center text-gray-500 text-[11px]">
                            No spreadsheets or CSV files found matching "{driveSearch}".
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {importStatus && (
                <div className="flex items-center gap-2 text-xs text-blue-400 font-semibold bg-blue-950/20 p-2.5 rounded border border-blue-900/30">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{importStatus}</span>
                </div>
              )}

              {importError && (
                <div className="flex items-center gap-2 text-xs text-red-400 font-semibold bg-red-950/20 p-2.5 rounded border border-red-900/30">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{importError}</span>
                </div>
              )}

              {scannedQuotations.length > 0 && (
                <div className="space-y-3 pt-2">
                  <div className="p-2.5 bg-emerald-950/20 border border-emerald-900/30 rounded text-emerald-400 text-xs font-semibold">
                    Successfully mapped <strong>{scannedQuotations.length} quotation entries</strong> from sheet. Please review below and confirm.
                  </div>
                  <div className="max-h-48 overflow-y-auto border border-gray-800 rounded bg-gray-950 text-[10px] font-mono">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-gray-900 text-gray-400 border-b border-gray-800">
                          <th className="p-2">Date</th>
                          <th className="p-2">Ref No</th>
                          <th className="p-2">Project</th>
                          <th className="p-2">Client Name</th>
                          <th className="p-2 text-right">Sum (S$)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800/40 text-gray-300">
                        {scannedQuotations.map((sq, idx) => (
                          <tr key={idx} className="hover:bg-gray-900/10">
                            <td className="p-2 whitespace-nowrap">{sq.date}</td>
                            <td className="p-2 font-bold text-gray-200">{sq.referenceNo}</td>
                            <td className="p-2 max-w-xs truncate">{sq.project}</td>
                            <td className="p-2 max-w-xs truncate">{sq.clientName}</td>
                            <td className="p-2 text-right text-blue-400">
                              {sq.sum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 p-4 bg-gray-900 border-t border-gray-800">
              <button
                onClick={() => { setIsImportOpen(false); setScannedQuotations([]); }}
                className="px-4 py-2 rounded text-xs font-semibold bg-gray-950 hover:bg-gray-800 text-gray-300 border border-gray-800 transition"
              >
                Close
              </button>
              {scannedQuotations.length > 0 && (
                <button
                  onClick={confirmImport}
                  className="px-4 py-2 rounded text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition shadow-lg shadow-emerald-900/10"
                >
                  Confirm & Sync {scannedQuotations.length} Entries
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
