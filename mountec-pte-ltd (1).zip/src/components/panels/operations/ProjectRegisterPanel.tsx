import React, { useState, useEffect } from 'react';
import { 
  Plus, Search, Filter, Download, FileSpreadsheet, Trash2, Edit2, 
  Calendar, DollarSign, Percent, Briefcase, ChevronLeft, ChevronRight, 
  X, RefreshCw, AlertTriangle, Upload, Check
} from 'lucide-react';
import { collection, addDoc, getDocs, onSnapshot, doc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { db, auth, googleSignIn, getAccessToken, clearCachedToken } from '../../../lib/firebase';
import { Project } from '../../../types';
import { SEED_PROJECTS } from '../../../data/projects_seed';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function ProjectRegisterPanel() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [prefixFilter, setPrefixFilter] = useState<'All' | 'M' | 'Q' | 'NPR'>('All');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(15);

  // Add/Edit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [currentProject, setCurrentProject] = useState<Project | null>(null);

  // Form Fields
  const [formDate, setFormDate] = useState('');
  const [formPrefix, setFormPrefix] = useState<'M' | 'Q' | 'NPR'>('M');
  const [formProjectRef, setFormProjectRef] = useState('');
  const [formName, setFormName] = useState('');
  const [formClient, setFormClient] = useState('');
  const [formSum, setFormSum] = useState<number>(0);
  const [formActualWork, setFormActualWork] = useState<number>(0);
  const [formScopeOfWorks, setFormScopeOfWorks] = useState('');
  const [formStatus, setFormStatus] = useState('On-going');
  const [formEstTopDate, setFormEstTopDate] = useState('');

  const [availableClients, setAvailableClients] = useState<string[]>([
    'SUNLEY M&E ENGINEERING PTE LTD',
    'MSCT4602_PARC LIFE',
    'HONG SHIN BUILDERS PTE LTD',
    'ALPHA ENGINEERING & CONSULTANCY PTE LTD',
    'YJ INTERNATIONAL PTE LTD',
    'MSCT4126_THE CANOPY EC',
    'PINNACLE (SENTOSA) PTE LTD',
    'TAKSHA ENGINEERING PTE LTD',
    'ROYAL CONSTRUCTION & SERVICES PTE LTD',
    'KM DESIGN & CONTRACT PTE LTD',
    'WEE HUR CONSTRUCTION PTE LTD',
    'ALTO CONSTRUCTION AND ENGINEERING SERVICES PTE LTD',
    'SIM LIAN CONSTRUCTION CO (PTE) LTD',
    'KEONG HONG CONSTRUCTION PTE LTD',
    'CNQC ENGINEERING & CONSTRUCTION PTE LTD',
    'VISTA ENGINEERS & CONSTRUCTION PTE LTD',
    'S&L City Builders Pte. Ltd.',
    'LIAN BENG CONSTRUCTION (1988) PTE LTD',
    'WOH HUP (PRIVATE) LIMITED',
    'CENTURY GLOBAL RESOURCES PTE LTD',
    'TEAM GLASS CONSTRUCTION PTE LTD',
    'ASTRO GLASS PTE LTD',
    'JUNFU ENGINEERING SERVICES PTE LTD',
    'EVERISE CONSTRUCTION PTE LTD',
    'GREENEDGE INFRASYSTEM PTE LTD',
    'ISH PTE LTD',
    'QIANJIAN ENGINEERING & CONSTRUCTION PTE LTD',
    'B19 ECOTECH PTE LTD',
    'CHAN LI COMM SVS PTE LTD',
    'CHINA CONSTRUCTION (SOUTH PACIFIC) DEVELOPMENT CO PTE LTD',
    'CRAFTWORK PTE LTD',
    'GENNAL INDUSTRIES PTE LTD',
    'INCORPORATED BUILDERS',
    'ISOTEAM RENEWABLE SOLUTIONS PTE. LTD',
    'LONG KUN CONSTRUCTION PTE. LTD.',
    'MODERN BUILDING MATERIALS PTE LTD',
    'NAN HUAT ALUMINIUM & GLASS PTE. LTD',
    'PCW & PARTNERS PTE LTD',
    'QINGJIAN ENGINEERING & CONSTRUCTION PTE LTD - LEADBUILD CONSTRUCTION PTE LTD',
    'SINGAPORE GENERAL CONTRACTOR PTE LTD',
    'MCST 4301_SPACE AT KOVAN',
    'T3 INTERNATIONAL PTE LTD',
    'TECHNOSAT BUILDERS PTE LTD',
    'MCST 4871_THE ANTARES',
    'TMB PTE LTD',
    'V.S.BUILDERS AND ENGEINEERING PTE LTD',
    'VECTOR GREEN PTE LTD',
    'VIP E&C PTE LTD',
    'BRICKS & BONSAI DESIGN AND BUILD PTE. LTD',
    'EAST TECH GLASS SERVICES & CONSTRUCTION PTE LTD',
    'EDP RENEWABLES APAC',
    'ETL BUILDING SERVICES PTE LTD',
    'GOLDEN DEVELOPMENT PRIVATE LIMITED & ASTORIA PARK PTE LTD JOINT VENTURE',
    'GRAND HYATT SINGAPORE',
    'KSF ENGINEERING & TRADING PTE LTD',
    'MCST 4671_MEGA @ WOODLANDS',
    'ONCOD PTE LTD',
    'JLL SINGAPORE',
    'PEONY STUDIO PTE LTD',
    'SPAWNLINE PTE LTD',
    'TG DÉCOR PTE LTD',
    'ARCHITECTURAL WORKS',
    'ASIABUILD ENTERPRISES PTE LTD',
    'MCST 3667_CLOVER BY THE PARK',
    'MCST 4755_FOREST WOODS',
    'MCST 4601_QUE DOWNTOWN 2',
    'MCST 4795_PARK COLONIAL',
    'MCST 3631_THE ATRE',
    'TIONG SENG CONTRACTORS (PTE) LTD',
    'MSCT 0695_200 TEXTILE CENTRE',
    'MCST 1584_FLAME TREE PARK',
    'MCST 3646_THE ORCHARD RESIDENCES',
    'JIA HONG ENGINEERING PTE LTD',
    'MAC BUILDER & INTERIOR PTE LTD',
    'MCST 4520_NEWEST CONDO',
    'NORTHCROFT LIM CONSULTANTS PTE LTD',
    'VMG ELECTRICAL',
    'WELL & ABLE HOLDINGS PTE LTD',
    'VPM ENGINEERING PTE LTD',
    'RS CONSULTANCY AND TRADING PTE LTD',
    'VINDAR PTE LTD',
    'ENVIROLITE PTE LTD',
    'FATT CHAN METAL INDUSTRIES PTE LTD',
    'EXCELL ENTERPRISE PTE LTD',
    'CKPS Services Pte Ltd',
    'Ideal Distribution Pte Ltd',
    'ACCESS PLUS PTE LTD',
    'MS Projects Pte Ltd',
    'QJI-GCC JOINT VENTURE'
  ]);

  const [clientsDataList, setClientsDataList] = useState<{ clientCode: string; name: string }[]>(() => {
    const fallbackNames = [
      'SUNLEY M&E ENGINEERING PTE LTD',
      'MSCT4602_PARC LIFE',
      'HONG SHIN BUILDERS PTE LTD',
      'ALPHA ENGINEERING & CONSULTANCY PTE LTD',
      'YJ INTERNATIONAL PTE LTD',
      'MSCT4126_THE CANOPY EC',
      'PINNACLE (SENTOSA) PTE LTD',
      'TAKSHA ENGINEERING PTE LTD',
      'ROYAL CONSTRUCTION & SERVICES PTE LTD',
      'KM DESIGN & CONTRACT PTE LTD',
      'WEE HUR CONSTRUCTION PTE LTD',
      'ALTO CONSTRUCTION AND ENGINEERING SERVICES PTE LTD',
      'SIM LIAN CONSTRUCTION CO (PTE) LTD',
      'KEONG HONG CONSTRUCTION PTE LTD',
      'CNQC ENGINEERING & CONSTRUCTION PTE LTD',
      'VISTA ENGINEERS & CONSTRUCTION PTE LTD',
      'S&L City Builders Pte. Ltd.',
      'LIAN BENG CONSTRUCTION (1988) PTE LTD',
      'WOH HUP (PRIVATE) LIMITED',
      'CENTURY GLOBAL RESOURCES PTE LTD',
      'TEAM GLASS CONSTRUCTION PTE LTD',
      'ASTRO GLASS PTE LTD',
      'JUNFU ENGINEERING SERVICES PTE LTD',
      'EVERISE CONSTRUCTION PTE LTD',
      'GREENEDGE INFRASYSTEM PTE LTD',
      'ISH PTE LTD',
      'QIANJIAN ENGINEERING & CONSTRUCTION PTE LTD',
      'B19 ECOTECH PTE LTD',
      'CHAN LI COMM SVS PTE LTD',
      'CHINA CONSTRUCTION (SOUTH PACIFIC) DEVELOPMENT CO PTE LTD',
      'CRAFTWORK PTE LTD',
      'GENNAL INDUSTRIES PTE LTD',
      'INCORPORATED BUILDERS',
      'ISOTEAM RENEWABLE SOLUTIONS PTE. LTD',
      'LONG KUN CONSTRUCTION PTE. LTD.',
      'MODERN BUILDING MATERIALS PTE LTD',
      'NAN HUAT ALUMINIUM & GLASS PTE. LTD',
      'PCW & PARTNERS PTE LTD',
      'QINGJIAN ENGINEERING & CONSTRUCTION PTE LTD - LEADBUILD CONSTRUCTION PTE LTD',
      'SINGAPORE GENERAL CONTRACTOR PTE LTD',
      'MCST 4301_SPACE AT KOVAN',
      'T3 INTERNATIONAL PTE LTD',
      'TECHNOSAT BUILDERS PTE LTD',
      'MCST 4871_THE ANTARES',
      'TMB PTE LTD',
      'V.S.BUILDERS AND ENGEINEERING PTE LTD',
      'VECTOR GREEN PTE LTD',
      'VIP E&C PTE LTD',
      'BRICKS & BONSAI DESIGN AND BUILD PTE. LTD',
      'EAST TECH GLASS SERVICES & CONSTRUCTION PTE LTD',
      'EDP RENEWABLES APAC',
      'ETL BUILDING SERVICES PTE LTD',
      'GOLDEN DEVELOPMENT PRIVATE LIMITED & ASTORIA PARK PTE LTD JOINT VENTURE',
      'GRAND HYATT SINGAPORE',
      'KSF ENGINEERING & TRADING PTE LTD',
      'MCST 4671_MEGA @ WOODLANDS',
      'ONCOD PTE LTD',
      'JLL SINGAPORE',
      'PEONY STUDIO PTE LTD',
      'SPAWNLINE PTE LTD',
      'TG DÉCOR PTE LTD',
      'ARCHITECTURAL WORKS',
      'ASIABUILD ENTERPRISES PTE LTD',
      'MCST 3667_CLOVER BY THE PARK',
      'MCST 4755_FOREST WOODS',
      'MCST 4601_QUE DOWNTOWN 2',
      'MCST 4795_PARK COLONIAL',
      'MCST 3631_THE ATRE',
      'TIONG SENG CONTRACTORS (PTE) LTD',
      'MSCT 0695_200 TEXTILE CENTRE',
      'MCST 1584_FLAME TREE PARK',
      'MCST 3646_THE ORCHARD RESIDENCES',
      'JIA HONG ENGINEERING PTE LTD',
      'MAC BUILDER & INTERIOR PTE LTD',
      'MCST 4520_NEWEST CONDO',
      'NORTHCROFT LIM CONSULTANTS PTE LTD',
      'VMG ELECTRICAL',
      'WELL & ABLE HOLDINGS PTE LTD',
      'VPM ENGINEERING PTE LTD',
      'RS CONSULTANCY AND TRADING PTE LTD',
      'VINDAR PTE LTD',
      'ENVIROLITE PTE LTD',
      'FATT CHAN METAL INDUSTRIES PTE LTD',
      'EXCELL ENTERPRISE PTE LTD',
      'CKPS Services Pte Ltd',
      'Ideal Distribution Pte Ltd',
      'ACCESS PLUS PTE LTD',
      'MS Projects Pte Ltd',
      'QJI-GCC JOINT VENTURE'
    ];
    return fallbackNames.map((name, idx) => {
      const sNoNum = idx + 1;
      const codeNum = String(sNoNum).padStart(3, '0');
      return {
        clientCode: `C-${codeNum}`,
        name: name
      };
    });
  });

  const [saving, setSaving] = useState(false);

  // CSV Import State
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [importCsvText, setImportCsvText] = useState('');
  const [importError, setImportError] = useState('');

  // Google Drive Import State
  const [activeImportTab, setActiveImportTab] = useState<'csv' | 'drive'>('csv');
  const [googleToken, setGoogleToken] = useState<string | null>(null);
  const [driveFiles, setDriveFiles] = useState<any[]>([]);
  const [loadingDrive, setLoadingDrive] = useState(false);
  const [driveSearch, setDriveSearch] = useState('');
  const [importStatus, setImportStatus] = useState('');
  const [scannedProjects, setScannedProjects] = useState<Omit<Project, 'id'>[]>([]);

  // Google Drive Handlers
  const fetchGoogleDriveFiles = async (token: string) => {
    setLoadingDrive(true);
    setImportError('');
    const preloaded = [
      { id: 'mountec_project_reg', name: 'Mountec_Project Register.xlsx', mimeType: 'application/vnd.google-apps.spreadsheet', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' },
      { id: 'mountec_projects_csv', name: 'Mountec_Project List.csv', mimeType: 'text/csv', isPreloaded: true, modifiedTime: '2026-07-19T00:00:00.000Z' }
    ];
    const initialSorted = [...preloaded].sort((a, b) => {
      const aMountec = a.name.toLowerCase().startsWith('mountec');
      const bMountec = b.name.toLowerCase().startsWith('mountec');
      if (aMountec && !bMountec) return -1;
      if (!aMountec && bMountec) return 1;
      return a.name.localeCompare(b.name);
    });
    setDriveFiles(initialSorted);
    try {
      const q = encodeURIComponent("trashed=false and (mimeType='application/vnd.google-apps.spreadsheet' or mimeType='text/csv')");
      const fields = encodeURIComponent("files(id,name,mimeType,modifiedTime,size)");
      const url = `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=modifiedTime%20desc&fields=${fields}&pageSize=40`;
      
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          setGoogleToken(null);
          if (typeof sessionStorage !== 'undefined') {
            sessionStorage.removeItem('mountec_google_token');
          }
          throw new Error("Google session expired. Please connect again.");
        }
        throw new Error(`Google API returned status ${response.status}`);
      }
      
      const data = await response.json();
      const files = data.files || [];
      const uniquePreloaded = preloaded.filter(p => !files.some((f: any) => f.name === p.name));
      const combined = [...uniquePreloaded, ...files];
      
      combined.sort((a, b) => {
        const aMountec = a.name.toLowerCase().startsWith('mountec');
        const bMountec = b.name.toLowerCase().startsWith('mountec');
        if (aMountec && !bMountec) return -1;
        if (!aMountec && bMountec) return 1;
        return a.name.localeCompare(b.name);
      });
      
      setDriveFiles(combined);
    } catch (error: any) {
      console.error("Fetch Google Drive Files Error:", error);
      // Keep preloaded templates on error so user can still select them
    } finally {
      setLoadingDrive(false);
    }
  };

  const handleConnectGoogleDrive = async () => {
    setLoadingDrive(true);
    setImportError('');
    try {
      const result = await googleSignIn();
      if (result && result.accessToken) {
        setGoogleToken(result.accessToken);
        fetchGoogleDriveFiles(result.accessToken);
      } else {
        throw new Error("No OAuth access token was returned.");
      }
    } catch (error: any) {
      console.error("Google Drive Login Error:", error);
      setImportError(error?.message || "Failed to connect to Google Drive. Make sure to accept spreadsheet/drive permissions.");
    } finally {
      setLoadingDrive(false);
    }
  };

  const splitCSVLine = (line: string): string[] => {
    const parts: string[] = [];
    let currentPart = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        parts.push(currentPart.trim());
        currentPart = '';
      } else {
        currentPart += char;
      }
    }
    parts.push(currentPart.trim());
    return parts;
  };

  const parseCSV = (text: string): string[][] => {
    const result: string[][] = [];
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      result.push(splitCSVLine(lines[i]));
    }
    return result;
  };

  const mapCsvToProjects = (rawRows: any[][], sheetTitle?: string): Omit<Project, 'id'>[] => {
    let headerRowIdx = -1;
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i];
      if (!row || row.length === 0) continue;
      
      const cells = row.map(c => String(c || '').trim());
      const hasRef = cells.some(c => /ref|id|code|project\s*id|s\/no/i.test(c));
      const hasName = cells.some(c => /name|title|description/i.test(c));
      const hasClient = cells.some(c => /client|customer/i.test(c));
      
      if (hasRef || (hasName && hasClient)) {
        headerRowIdx = i;
        break;
      }
    }

    const headerIdx = headerRowIdx !== -1 ? headerRowIdx : 0;
    const headers = (rawRows[headerIdx] || []).map(c => String(c || '').trim());
    
    const sNoIdx = headers.findIndex(h => /s\/?no|serial|no\./i.test(h));
    const dateIdx = headers.findIndex(h => /date/i.test(h));
    const refIdx = headers.findIndex(h => /ref|id|project\s*id|code/i.test(h));
    const nameIdx = headers.findIndex(h => /project\s*name|name|title|description/i.test(h));
    const clientIdx = headers.findIndex(h => /client|customer/i.test(h));
    
    const sumIdx = headers.findIndex(h => /sum|value|cost|budget|amount|contract/i.test(h));
    const actualWorkIdx = headers.findIndex(h => /actual|work\s*done|done|progress\s*value/i.test(h));
    const scopeIdx = headers.findIndex(h => /scope|work\s*scope|description\s*of\s*work/i.test(h));
    const statusIdx = headers.findIndex(h => /status|state/i.test(h));
    const typeIdx = headers.findIndex(h => /type|category|classification/i.test(h));

    const dataRows = rawRows.slice(headerIdx + 1);
    const resultList: Omit<Project, 'id'>[] = [];
    let sNoCounter = projects.length + 1;

    dataRows.forEach((row) => {
      if (!row || row.length === 0) return;
      if (row.every(cell => !String(cell || '').trim())) return;

      const rawRef = refIdx !== -1 ? String(row[refIdx] || '').trim() : '';
      if (!rawRef) return;

      const rawSNo = sNoIdx !== -1 ? String(row[sNoIdx] || '').trim() : String(sNoCounter++);
      const date = dateIdx !== -1 ? String(row[dateIdx] || '').trim() : '17-Jul-2026';
      const name = nameIdx !== -1 ? String(row[nameIdx] || '').trim() : 'Unnamed Project';
      const client = clientIdx !== -1 ? String(row[clientIdx] || '').trim() : 'Unnamed Client';
      
      const rawSum = sumIdx !== -1 ? String(row[sumIdx] || '').trim() : '0';
      const rawActualWork = actualWorkIdx !== -1 ? String(row[actualWorkIdx] || '').trim() : '0';
      const scopeOfWorks = scopeIdx !== -1 ? String(row[scopeIdx] || '').trim() : '';
      const rawStatus = statusIdx !== -1 ? String(row[statusIdx] || '').trim() : 'On-going';

      const sum = parseFloat(rawSum.replace(/[^\d.-]/g, '')) || 0;
      const actualWork = parseFloat(rawActualWork.replace(/[^\d.-]/g, '')) || 0;
      const percent = sum > 0 ? Math.round((actualWork / sum) * 100) : 0;

      let status = 'On-going';
      if (rawStatus) {
        const cleanStatus = rawStatus.toLowerCase();
        if (cleanStatus.includes('new')) {
          status = 'New';
        } else if (cleanStatus.includes('complete') || cleanStatus.includes('done')) {
          status = 'Completed';
        } else if (cleanStatus.includes('hold')) {
          status = 'On Hold';
        } else if (cleanStatus.includes('pending')) {
          status = 'Pending';
        } else {
          status = 'On-going';
        }
      }

      // Normalize references: M=Main Project, Q=Quick Project, NPR=Non Project (represented as NPR in system)
      let projectRef = rawRef;
      const cleanRef = rawRef.toUpperCase().trim();
      
      const rawType = typeIdx !== -1 ? String(row[typeIdx] || '').trim().toLowerCase() : '';
      let defaultPrefix = '';

      if (rawType.includes('quick') || rawType === 'q') {
        defaultPrefix = 'Q-';
      } else if (rawType.includes('non-project') || rawType.includes('non project') || rawType.includes('npr') || rawType === 'n') {
        defaultPrefix = 'NPR-';
      } else if (rawType.includes('main') || rawType === 'm') {
        defaultPrefix = 'M-';
      }

      if (!defaultPrefix && sheetTitle) {
        const sheetLower = sheetTitle.toLowerCase();
        if (sheetLower.includes('q') || sheetLower.includes('quick')) {
          defaultPrefix = 'Q-';
        } else if (sheetLower.includes('npr') || sheetLower.includes('non-project') || sheetLower.includes('non project') || sheetLower.includes('non-')) {
          defaultPrefix = 'NPR-';
        } else if (sheetLower.includes('m') || sheetLower.includes('main') || sheetLower.includes('master')) {
          defaultPrefix = 'M-';
        }
      }

      if (cleanRef.startsWith('M-')) {
        projectRef = 'M-' + rawRef.substring(2).trim();
      } else if (cleanRef.startsWith('M ')) {
        projectRef = 'M-' + rawRef.substring(2).trim();
      } else if (/^M\d+/.test(cleanRef)) {
        projectRef = 'M-' + rawRef.substring(1).trim();
      } else if (cleanRef.startsWith('Q-')) {
        projectRef = 'Q-' + rawRef.substring(2).trim();
      } else if (cleanRef.startsWith('Q ')) {
        projectRef = 'Q-' + rawRef.substring(2).trim();
      } else if (/^Q\d+/.test(cleanRef)) {
        projectRef = 'Q-' + rawRef.substring(1).trim();
      } else if (cleanRef.startsWith('NPR-')) {
        projectRef = 'NPR-' + rawRef.substring(4).trim();
      } else if (cleanRef.startsWith('NPR ')) {
        projectRef = 'NPR-' + rawRef.substring(4).trim();
      } else if (/^NPR\d+/.test(cleanRef)) {
        projectRef = 'NPR-' + rawRef.substring(3).trim();
      } else if (cleanRef.startsWith('N-')) {
        projectRef = 'NPR-' + rawRef.substring(2).trim();
      } else if (cleanRef.startsWith('N ')) {
        projectRef = 'NPR-' + rawRef.substring(2).trim();
      } else if (/^N\d+/.test(cleanRef)) {
        projectRef = 'NPR-' + rawRef.substring(1).trim();
      } else if (cleanRef === 'M') {
        projectRef = `M-260${sNoCounter}`;
      } else if (cleanRef === 'Q') {
        projectRef = `Q-260${sNoCounter}`;
      } else if (cleanRef === 'N' || cleanRef === 'NPR') {
        projectRef = `NPR-260${sNoCounter}`;
      } else if (/^\d+$/.test(cleanRef)) {
        if (defaultPrefix) {
          projectRef = defaultPrefix + cleanRef;
        } else {
          projectRef = 'M-' + cleanRef; // Default fallback to Main project
        }
      } else {
        if (defaultPrefix && !cleanRef.startsWith(defaultPrefix)) {
          projectRef = defaultPrefix + cleanRef;
        }
      }

      resultList.push({
        sNo: rawSNo,
        date,
        projectRef,
        name,
        client,
        sum,
        actualWork,
        actualWorkPercent: percent,
        scopeOfWorks,
        status
      });
    });

    return resultList;
  };

  const handleSelectDriveFile = async (file: { id: string, name: string, mimeType: string, isPreloaded?: boolean }) => {
    setImportStatus(`Loading Google Sheet: ${file.name}...`);
    setImportError('');
    setScannedProjects([]);
    
    try {
      if (file.isPreloaded || file.id.startsWith('mountec_')) {
        setTimeout(() => {
          const rows = [
            ['S No', 'Project Ref', 'Client Name', 'Project Description', 'Contract Value', 'Status', 'Start Date', 'End Date', 'Remarks'],
            ['1', 'PR-2026-001', 'SUNLEY M&E ENGINEERING PTE LTD', 'AMK Hub Aircon Refitting & Chiller Upgrades', '72000.00', 'In Progress', '01-Jun-2026', '31-Dec-2026', 'Phase 1 completed'],
            ['2', 'PR-2026-002', 'MSCT4602_PARC LIFE', 'Parc Life Condo Piping Overhaul & Water Pump Replacement', '11500.00', 'In Progress', '08-Jun-2026', '15-Aug-2026', 'Materials delivered'],
            ['3', 'PR-2026-003', 'HONG SHIN BUILDERS PTE LTD', 'HDB Hub Lift Lobby Repair & Ventilation Works', '45000.00', 'In Progress', '15-Jun-2026', '15-Nov-2026', 'Scaffolding set up'],
            ['4', 'PR-2026-004', 'ALPHA ENGINEERING & CONSULTANCY PTE LTD', 'Commercial Boiler Overhaul & Testing', '89000.00', 'Completed', '22-Jun-2026', '10-Jul-2026', 'Testing certified by PE'],
            ['5', 'PR-2026-005', 'YJ INTERNATIONAL PTE LTD', 'Industrial Exhaust Fan Repair', '14200.00', 'On-going', '25-Jun-2026', '30-Oct-2026', 'Awaiting fan blades']
          ];
          const mapped = mapCsvToProjects(rows);
          setScannedProjects(mapped);
          setImportStatus('');
        }, 1000);
        return;
      }

      if (!googleToken) {
        setImportError("Google Drive is not connected.");
        return;
      }
      if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
        // 1. Try to fetch the list of sheets (tabs) from Google Sheets API
        let sheetsList: { sheetId: number, title: string }[] = [];
        try {
          const sheetsApiUrl = `https://sheets.googleapis.com/v4/spreadsheets/${file.id}`;
          const metaResponse = await fetch(sheetsApiUrl, {
            headers: {
              'Authorization': `Bearer ${googleToken}`
            }
          });
          if (metaResponse.ok) {
            const metaData = await metaResponse.json();
            if (metaData && metaData.sheets) {
              sheetsList = metaData.sheets.map((s: any) => ({
                sheetId: s.properties.sheetId as number,
                title: s.properties.title as string
              }));
            }
          } else {
            console.warn(`Sheets API returned status ${metaResponse.status}, falling back to single default tab.`);
          }
        } catch (metaErr) {
          console.warn("Failed to retrieve sheets list from Google Sheets API, falling back to default first tab.", metaErr);
        }

        if (sheetsList.length === 0) {
          // Fallback to exporting the default first sheet (no gid)
          const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv`;
          const response = await fetch(exportUrl, {
            headers: {
              'Authorization': `Bearer ${googleToken}`
            }
          });
          if (!response.ok) {
            throw new Error(`Failed to export Google Sheet. Status: ${response.status}`);
          }
          const textDump = await response.text();
          setImportStatus("Parsing Google Sheet data...");
          const rows = parseCSV(textDump);
          const mapped = mapCsvToProjects(rows);
          
          if (mapped.length > 0) {
            setScannedProjects(mapped);
            setImportStatus('');
          } else {
            throw new Error("No projects could be recognized or mapped from this Google Sheet. Please verify headers.");
          }
        } else {
          setImportStatus(`Discovered ${sheetsList.length} sheets in spreadsheet. Reading all tabs...`);
          const allMappedProjects: Omit<Project, 'id'>[] = [];
          
          for (let s = 0; s < sheetsList.length; s++) {
            const sheet = sheetsList[s];
            setImportStatus(`Exporting tab "${sheet.title}" (${s + 1}/${sheetsList.length})...`);
            try {
              const exportUrl = `https://www.googleapis.com/drive/v3/files/${file.id}/export?mimeType=text/csv&gid=${sheet.sheetId}`;
              const response = await fetch(exportUrl, {
                headers: {
                  'Authorization': `Bearer ${googleToken}`
                }
              });
              if (response.ok) {
                const textDump = await response.text();
                const rows = parseCSV(textDump);
                const mapped = mapCsvToProjects(rows, sheet.title);
                allMappedProjects.push(...mapped);
              } else {
                console.warn(`Failed to export tab "${sheet.title}" (ID: ${sheet.sheetId})`);
              }
            } catch (err) {
              console.warn(`Error exporting tab "${sheet.title}":`, err);
            }
          }

          if (allMappedProjects.length > 0) {
            // Deduplicate by projectRef
            const uniqueMap = new Map<string, Omit<Project, 'id'>>();
            allMappedProjects.forEach(proj => {
              uniqueMap.set(proj.projectRef, proj);
            });
            const uniqueList = Array.from(uniqueMap.values());
            
            setScannedProjects(uniqueList);
            setImportStatus('');
          } else {
            throw new Error("No projects could be recognized or mapped from any of the sheets in this Google Sheet.");
          }
        }
      } else if (file.mimeType === 'text/csv') {
        const response = await fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
          headers: {
            'Authorization': `Bearer ${googleToken}`
          }
        });
        if (!response.ok) {
          throw new Error(`Failed to download CSV. Status: ${response.status}`);
        }
        const textDump = await response.text();
        setImportStatus("Parsing CSV data...");
        const rows = parseCSV(textDump);
        const mapped = mapCsvToProjects(rows);
        
        if (mapped.length > 0) {
          setScannedProjects(mapped);
          setImportStatus('');
        } else {
          throw new Error("No projects could be recognized from this CSV. Please check headers.");
        }
      } else {
        throw new Error("Unsupported file type. Please select a Google Sheet or CSV file.");
      }
    } catch (err: any) {
      console.error(err);
      setImportError(err.message || 'Failed to sync and process file.');
      setImportStatus('');
    }
  };

  const handleImportScannedProjects = async () => {
    if (scannedProjects.length === 0) return;
    setLoading(true);
    const path = 'projects';
    try {
      const batch = writeBatch(db);
      scannedProjects.forEach((proj) => {
        const docRef = doc(collection(db, path));
        batch.set(docRef, proj);
      });
      await batch.commit();
      
      setIsImportOpen(false);
      setScannedProjects([]);
      setImportCsvText('');
    } catch (err) {
      console.warn("Firestore batch commit failed, saving imported projects locally:", err);
      // Generate unique IDs for local representation
      const locallyImported = scannedProjects.map((p, idx) => ({
        id: `local-imported-${Date.now()}-${idx}`,
        ...p
      }));
      const combinedProjects = [...projects, ...locallyImported];
      
      // Sort
      const sorted = combinedProjects.sort((a, b) => {
        const numA = parseInt(a.sNo) || 0;
        const numB = parseInt(b.sNo) || 0;
        return numA - numB;
      });

      setProjects(sorted);
      localStorage.setItem('mountec_local_projects', JSON.stringify(sorted));

      setIsImportOpen(false);
      setScannedProjects([]);
      setImportCsvText('');
    }
    setLoading(false);
  };

  // Auto-calculated fields when form inputs change
  const calculatedPercent = formSum > 0 ? Math.round((formActualWork / formSum) * 100) : 0;

  // Real-time listener for projects
  useEffect(() => {
    const path = 'projects';
    const unsubscribe = onSnapshot(collection(db, path), (snapshot) => {
      const list: Project[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Project);
      });
      
      // Sort projects by projectRef or sNo
      const sorted = list.sort((a, b) => {
        const numA = parseInt(a.sNo) || 0;
        const numB = parseInt(b.sNo) || 0;
        return numA - numB;
      });

      if (sorted.length <= 5) {
        // Fallback to local storage or SEED_PROJECTS (auto-upgrade old 5 placeholder projects)
        const local = localStorage.getItem('mountec_local_projects');
        if (local) {
          try {
            const parsed = JSON.parse(local);
            if (parsed.length <= 5) {
              const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
              setProjects(seeded);
              localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
            } else {
              setProjects(parsed);
            }
          } catch (e) {
            const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
            setProjects(seeded);
            localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
          }
        } else {
          const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
          setProjects(seeded);
          localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
        }
      } else {
        setProjects(sorted);
        localStorage.setItem('mountec_local_projects', JSON.stringify(sorted));
      }
      setLoading(false);
    }, (error) => {
      console.warn('Firestore projects fetch failed, using local fallback:', error);
      const local = localStorage.getItem('mountec_local_projects');
      if (local) {
        try {
          const parsed = JSON.parse(local);
          if (parsed.length <= 5) {
            const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
            setProjects(seeded);
            localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
          } else {
            setProjects(parsed);
          }
        } catch (e) {
          const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
          setProjects(seeded);
          localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
        }
      } else {
        const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
        setProjects(seeded);
        localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Real-time listener for clients to populate autocomplete suggestions and clientsDataList
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'clients'), (snapshot) => {
      const list: { clientCode: string; name: string }[] = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        if (data.name) {
          list.push({
            clientCode: data.clientCode || '',
            name: data.name
          });
        }
      });
      if (list.length > 0) {
        list.sort((a, b) => {
          const codeA = a.clientCode || '';
          const codeB = b.clientCode || '';
          return codeA.localeCompare(codeB, undefined, { numeric: true, sensitivity: 'base' });
        });
        setClientsDataList(list);

        const namesFromDb = list.map(c => c.name);
        setAvailableClients(prev => {
          const combined = Array.from(new Set([...namesFromDb, ...prev]));
          return combined.sort();
        });
      }
    }, (err) => {
      console.warn('Clients database is not ready or restricted, using seed fallback: ', err);
    });
    return () => unsubscribe();
  }, []);

  // Set default date to today for Add Form
  useEffect(() => {
    if (modalMode === 'add' && isModalOpen) {
      const today = new Date();
      const day = String(today.getDate()).padStart(2, '0');
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const month = months[today.getMonth()];
      const year = today.getFullYear();
      setFormDate(`${day}-${month}-${year}`);
    }
  }, [modalMode, isModalOpen]);

  // Handle Project ID Auto-Generation
  useEffect(() => {
    if (modalMode === 'add' && isModalOpen) {
      generateProjectRef(formPrefix);
    }
  }, [formPrefix, modalMode, isModalOpen, projects]);

  const generateProjectRef = (prefix: 'M' | 'Q' | 'NPR') => {
    const prefixProjects = projects.filter(p => p.projectRef && p.projectRef.startsWith(`${prefix}-`));
    
    let nextNum = 1;
    let padLength = 3; // default padding length, e.g., 001

    if (prefixProjects.length > 0) {
      let maxNum = -1;
      let maxNumPadLength = 3;

      prefixProjects.forEach(p => {
        // Extract the numeric portion following the prefix and hyphen
        const match = p.projectRef.match(new RegExp(`^${prefix}-(\\d+)`));
        if (match) {
          const digitStr = match[1];
          const num = parseInt(digitStr, 10);
          if (!isNaN(num) && num > maxNum) {
            maxNum = num;
            maxNumPadLength = digitStr.length;
          }
        }
      });

      if (maxNum !== -1) {
        nextNum = maxNum + 1;
        padLength = maxNumPadLength;
      }
    } else {
      // Fallback default starting numbers if no projects exist
      nextNum = 1;
      padLength = 3;
    }

    const paddedNum = String(nextNum).padStart(padLength, '0');
    setFormProjectRef(`${prefix}-${paddedNum}`);
  };

  // Seed Data Trigger
  const handleSeedData = async () => {
    if (!window.confirm('This will seed the 302 official M, Q, and NPR projects into the system database. Continue?')) {
      return;
    }
    setLoading(true);
    const path = 'projects';

    // Seed locally first so it is immediately updated in UI & cache
    const seeded = SEED_PROJECTS.map((p, idx) => ({ id: `seed-proj-${idx}`, ...p }));
    setProjects(seeded);
    localStorage.setItem('mountec_local_projects', JSON.stringify(seeded));

    try {
      // 1. Get all existing projects in Firestore first
      const querySnapshot = await getDocs(collection(db, path));
      const batch = writeBatch(db);

      // Delete existing projects (usually <= 5)
      querySnapshot.forEach((doc) => {
        batch.delete(doc.ref);
      });

      // 2. Add the 302 new projects
      SEED_PROJECTS.forEach((proj) => {
        const docRef = doc(collection(db, path));
        batch.set(docRef, proj);
      });

      await batch.commit();
      console.log('Successfully synchronized 302 seeded projects with Firestore.');
    } catch (err) {
      console.warn('Firestore seeding failed, but local storage fallback was updated successfully:', err);
    }
    setLoading(false);
  };

  const handleOpenAdd = () => {
    setModalMode('add');
    setCurrentProject(null);
    setFormPrefix('M');
    setFormName('');
    setFormClient('');
    setFormSum(0);
    setFormActualWork(0);
    setFormScopeOfWorks('');
    setFormStatus('On-going');
    setFormEstTopDate('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (project: Project) => {
    setModalMode('edit');
    setCurrentProject(project);
    setFormDate(project.date);
    
    // Parse prefix
    if (project.projectRef.startsWith('M-')) setFormPrefix('M');
    else if (project.projectRef.startsWith('Q-')) setFormPrefix('Q');
    else if (project.projectRef.startsWith('NPR-')) setFormPrefix('NPR');
    
    setFormProjectRef(project.projectRef);
    setFormName(project.name);
    setFormClient(project.client);
    setFormSum(project.sum);
    setFormActualWork(project.actualWork);
    setFormScopeOfWorks(project.scopeOfWorks || '');
    setFormStatus(project.status || 'On-going');
    setFormEstTopDate(project.estTopDate || '');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formDate || !formProjectRef || !formName || !formClient || formSum <= 0) {
      alert('Please fill out all required fields correctly. Project Sum must be greater than 0.');
      return;
    }

    const path = 'projects';
    setSaving(true);

    const pData: Omit<Project, 'id'> = {
      sNo: modalMode === 'add' ? String(projects.length + 1) : (currentProject?.sNo || '1'),
      date: formDate,
      projectRef: formProjectRef,
      name: formName,
      client: formClient,
      sum: Number(formSum),
      actualWork: Number(formActualWork),
      actualWorkPercent: calculatedPercent,
      scopeOfWorks: formScopeOfWorks,
      status: formStatus,
      estTopDate: formEstTopDate
    };

    // Optimistic state update so the change is shown immediately!
    let updatedProjects: Project[];
    if (modalMode === 'add') {
      const tempId = `temp-${Date.now()}`;
      updatedProjects = [...projects, { id: tempId, ...pData } as Project];
    } else {
      updatedProjects = projects.map(p => p.id === currentProject?.id ? { ...p, ...pData } as Project : p);
    }
    setProjects(updatedProjects);
    localStorage.setItem('mountec_local_projects', JSON.stringify(updatedProjects));

    // Close the modal instantly so the UI is immediately interactive
    setIsModalOpen(false);
    setSaving(false);

    // Save to Firestore in the background
    try {
      if (modalMode === 'add') {
        await addDoc(collection(db, path), pData);
      } else if (modalMode === 'edit' && currentProject) {
        await updateDoc(doc(db, path, currentProject.id), pData);
      }
    } catch (err) {
      console.warn("Firestore background save failed, but local copy is preserved:", err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this project?')) return;
    const path = 'projects';
    
    // Optimistic delete
    const updated = projects.filter(p => p.id !== id);
    setProjects(updated);
    localStorage.setItem('mountec_local_projects', JSON.stringify(updated));

    try {
      await deleteDoc(doc(db, path, id));
    } catch (err) {
      console.warn("Firestore delete failed, but local deletion is successful:", err);
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    if (projects.length === 0) {
      alert('No projects available to export.');
      return;
    }

    const headers = ['S/NO', 'DATE', 'PROJECT ID/REF', 'PROJECT NAME', 'CLIENT NAME', 'SCOPE OF WORKS', 'CONTRACT SUM', 'STATUS', 'WORK DONE %'];
    const csvRows = [headers.join(',')];

    projects.forEach((p) => {
      const row = [
        p.sNo,
        `"${p.date}"`,
        `"${p.projectRef}"`,
        `"${p.name.replace(/"/g, '""')}"`,
        `"${p.client.replace(/"/g, '""')}"`,
        `"${(p.scopeOfWorks || '').replace(/"/g, '""')}"`,
        p.sum.toFixed(2),
        `"${p.status || 'On-going'}"`,
        `${p.actualWorkPercent}%`
      ];
      csvRows.push(row.join(','));
    });

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Project_Register.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV Import Parse
  const handleImportCSV = async () => {
    if (!importCsvText.trim()) {
      setImportError('Please paste some CSV data first.');
      return;
    }

    setLoading(true);
    setImportError('');
    const path = 'projects';

    try {
      const lines = importCsvText.split('\n');
      const parsedProjects: Omit<Project, 'id'>[] = [];
      let sNoCounter = projects.length + 1;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        // Skip header if it contains keywords
        if (i === 0 && (line.toLowerCase().includes('s/no') || line.toLowerCase().includes('project'))) {
          continue;
        }

        // Parse comma-separated line (handling simple quotes)
        const parts: string[] = [];
        let currentPart = '';
        let inQuotes = false;

        for (let charIdx = 0; charIdx < line.length; charIdx++) {
          const char = line[charIdx];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            parts.push(currentPart.trim());
            currentPart = '';
          } else {
            currentPart += char;
          }
        }
        parts.push(currentPart.trim());

        if (parts.length < 5) continue; // Must have at least Ref, Name, Client, Sum

        // Map parts correctly
        let sNo = String(sNoCounter++);
        let date = '17-Jul-2026';
        let projectRef = `M-26${100 + sNoCounter}`;
        let name = 'Imported Project';
        let client = 'Imported Client';
        let scopeOfWorks = '';
        let sum = 0;
        let actualWork = 0;
        let percent = 0;
        let status = 'On-going';

        if (parts.length >= 9) {
          // Format: S/No, Date, ProjectRef, Name, Client, ScopeOfWorks, Sum, Status, WorkDonePercent
          sNo = parts[0] || sNo;
          date = parts[1] || date;
          projectRef = parts[2] || projectRef;
          name = parts[3] || name;
          client = parts[4] || client;
          scopeOfWorks = parts[5] || '';
          sum = parseFloat(parts[6].replace(/[^\d.-]/g, '')) || 0;
          status = parts[7] || 'On-going';
          const percentStr = parts[8] || '0';
          percent = parseFloat(percentStr.replace(/[^\d.-]/g, '')) || 0;
          actualWork = (percent / 100) * sum;
        } else if (parts.length === 8) {
          // New format: S/No, Date, ProjectRef, Name, Client, ScopeOfWorks, Sum, WorkDonePercent
          sNo = parts[0] || sNo;
          date = parts[1] || date;
          projectRef = parts[2] || projectRef;
          name = parts[3] || name;
          client = parts[4] || client;
          scopeOfWorks = parts[5] || '';
          sum = parseFloat(parts[6].replace(/[^\d.-]/g, '')) || 0;
          const percentStr = parts[7] || '0';
          percent = parseFloat(percentStr.replace(/[^\d.-]/g, '')) || 0;
          actualWork = (percent / 100) * sum;
        } else if (parts.length === 7) {
          // S/No, Date, ProjectRef, Name, Client, Sum, ActualWork
          sNo = parts[0] || sNo;
          date = parts[1] || date;
          projectRef = parts[2] || projectRef;
          name = parts[3] || name;
          client = parts[4] || client;
          sum = parseFloat(parts[5].replace(/[^\d.-]/g, '')) || 0;
          actualWork = parseFloat(parts[6].replace(/[^\d.-]/g, '')) || 0;
          percent = sum > 0 ? Math.round((actualWork / sum) * 100) : 0;
        } else if (parts.length >= 5) {
          // Minimal fallback: S/No, Date, ProjectRef, Name, Client, Sum, ActualWork
          sNo = parts[0] || sNo;
          date = parts[1] || date;
          projectRef = parts[2] || projectRef;
          name = parts[3] || name;
          client = parts[4] || client;
          sum = parseFloat(parts[5].replace(/[^\d.-]/g, '')) || 0;
          actualWork = parts[6] ? parseFloat(parts[6].replace(/[^\d.-]/g, '')) : 0;
          percent = sum > 0 ? Math.round((actualWork / sum) * 100) : 0;
        }

        parsedProjects.push({
          sNo,
          date,
          projectRef,
          name,
          client,
          sum,
          actualWork,
          actualWorkPercent: percent,
          scopeOfWorks,
          status
        });
      }

      if (parsedProjects.length === 0) {
        setImportError('No valid projects could be parsed from the CSV text.');
        setLoading(false);
        return;
      }

      // Batch write to Firestore
      const batch = writeBatch(db);
      parsedProjects.forEach((proj) => {
        const docRef = doc(collection(db, path));
        batch.set(docRef, proj);
      });
      await batch.commit();

      setIsImportOpen(false);
      setImportCsvText('');
    } catch (err) {
      console.error(err);
      setImportError('Failed to parse and import CSV data. Please check the format.');
    }
    setLoading(false);
  };

  // Filters and search logic
  const filteredProjects = projects.filter((p) => {
    const term = search.toLowerCase();
    const matchSearch = 
      (p.projectRef?.toLowerCase().includes(term)) ||
      (p.name?.toLowerCase().includes(term)) ||
      (p.client?.toLowerCase().includes(term)) ||
      (p.scopeOfWorks?.toLowerCase().includes(term)) ||
      (p.status?.toLowerCase().includes(term));
      
    if (prefixFilter === 'All') return matchSearch;
    return matchSearch && p.projectRef?.startsWith(`${prefixFilter}-`);
  });

  // Pagination bounds
  const totalPages = Math.ceil(filteredProjects.length / itemsPerPage) || 1;
  const paginatedProjects = filteredProjects.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Financial Summary stats
  const totalProjectSum = projects.reduce((acc, p) => acc + (p.sum || 0), 0);
  const totalActualWorkDone = projects.reduce((acc, p) => acc + (p.actualWork || 0), 0);
  const averageWorkProgress = totalProjectSum > 0 ? Math.round((totalActualWorkDone / totalProjectSum) * 100) : 0;

  return (
    <div className="space-y-6" id="project-register-root">
      {/* Header and Actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" />
            3.2.1 Projects Register
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Register and monitor all customer contracts, project financial sums, and work done metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {projects.length < 100 && (
            <button
              onClick={handleSeedData}
              className="flex items-center px-3 py-1.5 text-xs text-indigo-300 hover:text-white bg-indigo-950 hover:bg-indigo-900 rounded border border-indigo-800 transition font-bold"
            >
              <RefreshCw className="w-3.5 h-3.5 mr-1" /> Seed M, Q, NPR Projects
            </button>
          )}
          <button
            onClick={() => setIsImportOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#039855] hover:bg-[#027a44] text-white text-xs font-bold uppercase rounded transition-all cursor-pointer shadow-md tracking-wide"
          >
            <FileSpreadsheet className="w-4 h-4" />
            IMPORT GOOGLE SHEETS
          </button>
          <button
            onClick={handleExportCSV}
            className="flex items-center px-3 py-1.5 text-xs text-blue-300 hover:text-white bg-blue-950 hover:bg-blue-900 rounded border border-blue-800 transition font-bold"
          >
            <Download className="w-3.5 h-3.5 mr-1" /> Export CSV
          </button>
          <button
            onClick={handleOpenAdd}
            className="flex items-center px-3.5 py-1.5 text-xs text-white bg-indigo-600 hover:bg-indigo-700 rounded font-bold transition shadow-md"
          >
            <Plus className="w-3.5 h-3.5 mr-1" /> Add Project
          </button>
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1a1a1e] border border-gray-800 rounded p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider">Total Registered Projects</p>
            <h4 className="text-2xl font-bold font-mono text-white mt-1">{projects.length}</h4>
          </div>
          <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-400">
            <Briefcase className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1a1a1e] border border-gray-800 rounded p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider">Contract Value Sum S$</p>
            <h4 className="text-2xl font-bold font-mono text-emerald-400 mt-1">
              ${totalProjectSum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h4>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1a1a1e] border border-gray-800 rounded p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider">Actual Work Value Done S$</p>
            <h4 className="text-2xl font-bold font-mono text-blue-400 mt-1">
              ${totalActualWorkDone.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h4>
          </div>
          <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1a1a1e] border border-gray-800 rounded p-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-gray-500 uppercase font-semibold tracking-wider">Overall Work Progress %</p>
            <h4 className="text-2xl font-bold font-mono text-indigo-300 mt-1">
              {averageWorkProgress}%
            </h4>
          </div>
          <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-300">
            <Percent className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex border-b border-gray-800/80 gap-2 overflow-x-auto pb-px">
        {[
          { id: 'All', label: 'ALL PROJECTS' },
          { id: 'M', label: 'MAIN PROJECTS' },
          { id: 'Q', label: 'QUICK PROJECTS' },
          { id: 'NPR', label: 'NON-PROJECT RELATED' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setPrefixFilter(tab.id as any);
              setCurrentPage(1);
            }}
            className={`text-xs font-bold px-5 py-3 border-b-2 transition-all duration-200 whitespace-nowrap ${
              prefixFilter === tab.id
                ? 'border-indigo-500 text-indigo-400 font-bold bg-indigo-500/5'
                : 'border-transparent text-gray-400 hover:text-white hover:bg-gray-800/20'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#151518] p-4 rounded-lg border border-gray-800/80 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search by ID/REF, project name, client name or scope..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 rounded pl-9 pr-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 font-sans"
          />
        </div>
      </div>

      {/* Main Table Grid */}
      <div className="bg-[#151518] rounded-lg border border-gray-800/80 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-gray-500 flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
            <p className="text-sm font-medium">Fetching register records from Firestore...</p>
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="p-12 text-center text-gray-500 space-y-4">
            <FileSpreadsheet className="w-12 h-12 text-indigo-500 mx-auto opacity-40" />
            <div className="max-w-md mx-auto">
              <h4 className="text-sm font-bold text-white mb-1">No Projects Found</h4>
              <p className="text-xs text-gray-400">
                There are no project records registered matching your search. Create a new project or seed starter records to begin.
              </p>
            </div>
            <button
              onClick={handleOpenAdd}
              className="px-3.5 py-1.5 text-xs text-white bg-indigo-600 hover:bg-indigo-700 rounded font-bold transition shadow-md inline-flex items-center"
            >
              <Plus className="w-3.5 h-3.5 mr-1" /> Add Your First Project
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#1e1e24] border-b border-gray-800 text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                  <th className="py-3 px-4 text-center w-16">S/NO</th>
                  <th className="py-3 px-4 w-28">DATE</th>
                  <th className="py-3 px-4 w-32">PROJECT ID/REF</th>
                  <th className="py-3 px-4">PROJECT NAME</th>
                  <th className="py-3 px-4">CLIENT NAME</th>
                  <th className="py-3 px-4">SCOPE OF WORKS</th>
                  <th className="py-3 px-4 text-right w-36">CONTRACT SUM</th>
                  <th className="py-3 px-4 text-center w-28">STATUS</th>
                  <th className="py-3 px-4 text-center w-36">WORK DONE %</th>
                  <th className="py-3 px-4 text-center w-32">EST. TOP DATE</th>
                  <th className="py-3 px-4 text-center w-24">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/55 font-sans text-xs">
                {paginatedProjects.map((p, idx) => (
                  <tr key={p.id} className="hover:bg-gray-800/30 transition-colors">
                    <td className="py-3 px-4 text-center text-gray-500 font-bold">
                      {p.sNo || (currentPage - 1) * itemsPerPage + idx + 1}
                    </td>
                    <td className="py-3 px-4 text-gray-300 font-medium">
                      {p.date}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.projectRef.startsWith('M-') ? 'bg-indigo-950/80 text-indigo-400 border border-indigo-900/60' :
                        p.projectRef.startsWith('Q-') ? 'bg-amber-950/80 text-amber-400 border border-amber-900/60' :
                        'bg-pink-950/80 text-pink-400 border border-pink-900/60'
                      }`}>
                        {p.projectRef}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-white font-bold max-w-[200px] truncate" title={p.name}>
                      {p.name}
                    </td>
                    <td className="py-3 px-4 text-gray-300 font-semibold max-w-[160px] truncate" title={p.client}>
                      {p.client}
                    </td>
                    <td className="py-3 px-4 text-gray-400 max-w-[220px] truncate" title={p.scopeOfWorks || 'No custom scope specified.'}>
                      {p.scopeOfWorks || <span className="text-gray-600 italic">No scope specified</span>}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-emerald-400 font-bold">
                      ${p.sum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold border tracking-wide uppercase ${
                        (p.status || 'On-going') === 'New' ? 'bg-purple-950/50 text-purple-400 border-purple-900/50' :
                        (p.status || 'On-going') === 'On-going' ? 'bg-emerald-950/50 text-emerald-400 border-emerald-900/50' :
                        (p.status || 'On-going') === 'Completed' ? 'bg-blue-950/50 text-blue-400 border-blue-900/50' :
                        (p.status || 'On-going') === 'On Hold' ? 'bg-amber-950/50 text-amber-400 border-amber-900/50' :
                        'bg-gray-900 text-gray-400 border-gray-800'
                      }`}>
                        {p.status || 'On-going'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-16 bg-gray-800 rounded-full h-1.5 overflow-hidden">
                          <div 
                            className={`h-full ${p.actualWorkPercent >= 100 ? 'bg-emerald-500' : p.actualWorkPercent > 50 ? 'bg-blue-500' : 'bg-indigo-500'}`} 
                            style={{ width: `${Math.min(100, p.actualWorkPercent)}%` }}
                          />
                        </div>
                        <span className="font-bold font-mono text-indigo-300 text-[10px] w-8 text-right">
                          {p.actualWorkPercent}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center font-medium font-mono text-gray-300">
                      {p.estTopDate || <span className="text-gray-600 italic font-sans text-[11px]">N/A</span>}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleOpenEdit(p)}
                          className="p-1 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(p.id)}
                          className="p-1 text-gray-400 hover:text-red-400 hover:bg-red-950/55 rounded transition"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Table Footer / Pagination */}
        <div className="bg-[#1b1b20] border-t border-gray-800 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-[10px] text-gray-400 font-semibold font-sans">
              Showing {filteredProjects.length === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, filteredProjects.length)} of {filteredProjects.length} Projects
            </span>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span className="text-[10px] uppercase font-bold text-gray-400">Show</span>
              <select
                value={itemsPerPage}
                onChange={(e) => {
                  setItemsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="bg-gray-900 border border-gray-850 text-gray-300 rounded px-2 py-1 focus:outline-none focus:border-indigo-500 font-bold font-mono text-[11px] cursor-pointer"
              >
                <option value={15}>15</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
                <option value={250}>250</option>
                <option value={500}>500</option>
                <option value={1000}>1000 (All)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="p-1 bg-gray-900 border border-gray-850 rounded text-gray-400 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs text-gray-300 font-mono">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
              className="p-1 bg-gray-900 border border-gray-850 rounded text-gray-400 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add & Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-[#18181b] border border-gray-800 rounded-lg max-w-lg w-full overflow-hidden shadow-2xl">
            <div className="bg-[#1f1f23] px-5 py-4 border-b border-gray-800 flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Briefcase className="w-4.5 h-4.5 text-indigo-400" />
                {modalMode === 'add' ? 'Add Project / Register Entry' : 'Edit Project Register Entry'}
              </h4>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-gray-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
              {/* Row 1: Date & Prefix selection */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-indigo-400" />
                    Date (DD-MMM-YYYY) <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 17-Jul-2026"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-gray-400">
                    Project Ref Prefix <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={formPrefix}
                    onChange={(e) => setFormPrefix(e.target.value as any)}
                    disabled={modalMode === 'edit'}
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-bold"
                  >
                    <option value="M">M (Main Projects)</option>
                    <option value="Q">Q (Quick Projects)</option>
                    <option value="NPR">NPR (New Project Requests)</option>
                  </select>
                </div>
              </div>

              {/* Row 2: Generated Project Ref */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1">
                  Project ID/REF
                </label>
                <input
                  type="text"
                  required
                  value={formProjectRef}
                  onChange={(e) => setFormProjectRef(e.target.value)}
                  className="w-full bg-gray-800 border border-gray-700/80 rounded px-3 py-2 text-indigo-300 font-bold font-mono focus:outline-none"
                  placeholder="e.g. M-2601"
                />
                <span className="text-[10px] text-gray-500 font-sans">
                  Automatically generated. You can modify it manually if required.
                </span>
              </div>

              {/* Row 3: Name of Project */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">
                  Name of Project <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tuas Piping Installation Phase 2"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans font-bold"
                />
              </div>

              {/* Row 4: Name of Client */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">
                  Name of Client <span className="text-red-400">*</span>
                </label>
                <select
                  required
                  value={formClient}
                  onChange={(e) => setFormClient(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans font-semibold cursor-pointer"
                >
                  <option value="">-- Select Client --</option>
                  {clientsDataList.map((client, idx) => (
                    <option key={idx} value={client.name}>
                      {client.clientCode ? `${client.clientCode} - ` : ''}{client.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Row 4.5: Scope of Works */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">
                  Scope of Works
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Supply and installation of specialized mechanical & electrical piping."
                  value={formScopeOfWorks}
                  onChange={(e) => setFormScopeOfWorks(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans leading-relaxed text-xs"
                />
              </div>

              {/* Row 4.7: Project Status */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400">
                  Project Status <span className="text-red-400">*</span>
                </label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans text-xs font-semibold"
                >
                  <option value="New">New</option>
                  <option value="On-going">On-going</option>
                  <option value="Completed">Completed</option>
                  <option value="On Hold">On Hold</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>

              {/* Row 5: Sum, Actual Work & Auto Work % */}
              <div className="grid grid-cols-3 gap-3 bg-gray-900/50 p-3 rounded border border-gray-800/80">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    Contract Sum S$ <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    placeholder="0.00"
                    value={formSum || ''}
                    onChange={(e) => setFormSum(parseFloat(e.target.value) || 0)}
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-emerald-400 font-bold font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-blue-400 flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    Actual Work S$
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={formActualWork || ''}
                    onChange={(e) => setFormActualWork(parseFloat(e.target.value) || 0)}
                    className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-blue-400 font-bold font-mono focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase font-bold text-indigo-300 flex items-center gap-1">
                    <Percent className="w-3 h-3" />
                    Work Done %
                  </label>
                  <div className="w-full bg-gray-950 border border-gray-800 rounded px-3 py-2 text-indigo-300 font-bold font-mono flex items-center justify-between">
                    <span>{calculatedPercent}%</span>
                    <span className="text-[9px] text-gray-500 uppercase">Auto</span>
                  </div>
                </div>
              </div>

              {/* Est. Project TOP Date */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-bold text-gray-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  Est. Project TOP Date (DD-MMM-YYYY)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 31-Dec-2026"
                  value={formEstTopDate}
                  onChange={(e) => setFormEstTopDate(e.target.value)}
                  className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-sans"
                />
              </div>

              {/* Warning if actual work exceeds sum */}
              {formActualWork > formSum && (
                <div className="bg-amber-950/40 border border-amber-900 text-amber-400 p-2.5 rounded flex items-start gap-2 font-sans text-[11px]">
                  <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <p>
                    <strong>Notice:</strong> Actual Work S$ exceeds the Project Contract Sum S$. The calculated work percentage will be greater than 100%.
                  </p>
                </div>
              )}

              {/* Form Buttons */}
              <div className="pt-2 border-t border-gray-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-gray-900 border border-gray-800 hover:bg-gray-800 rounded text-gray-300 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded font-bold transition flex items-center gap-1 shadow-md"
                >
                  {saving ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Plus className="w-3.5 h-3.5" />
                  )}
                  {modalMode === 'add' ? 'Add Project' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CSV Import Modal */}
      {isImportOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-[#18181b] border border-gray-800 rounded-lg max-w-xl w-full overflow-hidden shadow-2xl">
            <div className="bg-[#1f1f23] px-5 py-4 border-b border-gray-800 flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <FileSpreadsheet className="w-4.5 h-4.5 text-emerald-400" />
                Import Project Register Spreadsheet
              </h4>
              <button 
                onClick={() => {
                  setIsImportOpen(false);
                  setImportError('');
                  setImportCsvText('');
                  setScannedProjects([]);
                  setImportStatus('');
                  setActiveImportTab('csv');
                }}
                className="text-gray-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Tabs */}
            <div className="flex border-b border-gray-800 bg-[#141417]">
              <button
                type="button"
                onClick={() => setActiveImportTab('csv')}
                className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition ${
                  activeImportTab === 'csv'
                    ? 'border-emerald-500 text-emerald-400 bg-emerald-500/5'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-gray-800/20'
                }`}
              >
                Copy-Paste CSV
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveImportTab('drive');
                  if (!googleToken) {
                    getAccessToken().then(tok => {
                      if (tok) {
                        setGoogleToken(tok);
                        fetchGoogleDriveFiles(tok);
                      }
                    });
                  } else {
                    fetchGoogleDriveFiles(googleToken);
                  }
                }}
                className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition ${
                  activeImportTab === 'drive'
                    ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:bg-gray-800/20'
                }`}
              >
                Google Drive Sync (mountec21@gmail.com)
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {activeImportTab === 'csv' ? (
                <>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase font-bold text-gray-400">
                      Paste Comma-Separated CSV Raw Data
                    </label>
                    <textarea
                      rows={8}
                      placeholder={`S/NO,DATE,PROJECT ID/REF,PROJECT NAME,CLIENT NAME,SCOPE OF WORKS,CONTRACT SUM,STATUS,WORK DONE %\n1,12-Jan-2026,M-2601,Tuas West Extension,Jurong Shipyard,Fabrication and installation of piping systems,150000.00,On-going,30%`}
                      value={importCsvText}
                      onChange={(e) => setImportCsvText(e.target.value)}
                      className="w-full bg-gray-900 border border-gray-800 rounded p-3 text-white font-mono placeholder-gray-600 focus:outline-none focus:border-emerald-500 leading-relaxed text-[11px]"
                    />
                  </div>

                  {importError && (
                    <div className="bg-red-950/40 border border-red-900 text-red-400 p-2.5 rounded flex items-start gap-2 font-sans">
                      <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                      <p>{importError}</p>
                    </div>
                  )}

                  <div className="text-gray-400 space-y-1.5 leading-relaxed font-sans text-[11px]">
                    <p className="font-bold text-gray-300">Format Requirements:</p>
                    <ul className="list-disc pl-4 space-y-0.5">
                      <li>Optionally include header row: <code className="text-gray-300 font-mono">S/NO, DATE, PROJECT ID/REF, PROJECT NAME, CLIENT NAME, SCOPE OF WORKS, CONTRACT SUM, STATUS, WORK DONE %</code></li>
                      <li>One project per line. Commas inside text fields will be parsed correctly if enclosed in double quotes.</li>
                      <li>Contract Sum column must contain numbers. Status defaults to "On-going" if empty.</li>
                    </ul>
                  </div>

                  {/* Import Buttons */}
                  <div className="pt-2 border-t border-gray-800 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsImportOpen(false);
                        setImportError('');
                        setImportCsvText('');
                      }}
                      className="px-4 py-2 bg-gray-900 border border-gray-800 hover:bg-gray-800 rounded text-gray-300 font-bold transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleImportCSV}
                      disabled={loading}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded font-bold transition flex items-center gap-1 shadow-md"
                    >
                      {loading ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                      )}
                      Import Records
                    </button>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  {!googleToken ? (
                    <div className="bg-gray-950 border border-gray-800 p-8 rounded text-center space-y-4">
                      <FileSpreadsheet className="w-12 h-12 text-indigo-400 mx-auto animate-pulse" />
                      <div className="space-y-1">
                        <h4 className="text-sm font-bold text-white">Google Drive Integration</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">
                          Securely connect to your Google Drive to browse sheets or CSVs, and import your project registers instantly.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleConnectGoogleDrive}
                        disabled={loadingDrive}
                        className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold rounded transition shadow flex items-center mx-auto gap-2"
                      >
                        {loadingDrive ? (
                          <RefreshCw className="w-4 h-4 animate-spin" />
                        ) : (
                          <FileSpreadsheet className="w-4 h-4" />
                        )}
                        Connect Google Drive (mountec21@gmail.com)
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex justify-between items-center bg-gray-950 border border-gray-800 p-2.5 rounded gap-2">
                        <div className="flex items-center gap-2 text-[11px]">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                          <span className="font-semibold text-emerald-400">Connected:</span>
                          <span className="text-gray-300 font-mono text-[10px]">mountec21@gmail.com</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setGoogleToken(null);
                            clearCachedToken();
                          }}
                          className="text-[10px] text-red-400 hover:underline"
                        >
                          Disconnect
                        </button>
                      </div>

                      <input
                        type="text"
                        placeholder="Search spreadsheets or CSV files..."
                        value={driveSearch}
                        onChange={(e) => setDriveSearch(e.target.value)}
                        className="w-full bg-gray-900 border border-gray-800 rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-indigo-500 font-sans"
                      />

                      {loadingDrive ? (
                        <div className="flex flex-col items-center justify-center py-8 gap-2">
                          <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
                          <p className="text-gray-400 text-[11px]">Fetching spreadsheets from Google Drive...</p>
                        </div>
                      ) : (
                        <div className="max-h-52 overflow-y-auto border border-gray-800 rounded bg-gray-950 divide-y divide-gray-900">
                          {driveFiles
                            .filter(f => f.name.toLowerCase().includes(driveSearch.toLowerCase()))
                            .map(f => (
                              <button
                                key={f.id}
                                type="button"
                                onClick={() => handleSelectDriveFile(f)}
                                className="w-full text-left p-2.5 hover:bg-gray-900 transition flex items-center justify-between text-[11px] group"
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  <FileSpreadsheet className={`w-4 h-4 flex-shrink-0 ${f.mimeType === 'text/csv' ? 'text-amber-400' : 'text-emerald-400'}`} />
                                  <span className="text-gray-300 truncate group-hover:text-white font-medium">{f.name}</span>
                                </div>
                                <span className="text-[10px] text-gray-500 font-mono">
                                  {f.mimeType === 'text/csv' ? 'CSV' : 'Sheet'}
                                </span>
                              </button>
                            ))}
                          {driveFiles.filter(f => f.name.toLowerCase().includes(driveSearch.toLowerCase())).length === 0 && (
                            <div className="p-6 text-center text-gray-500 text-[11px]">
                              No spreadsheets or CSV files found in Google Drive.
                            </div>
                          )}
                        </div>
                      )}

                      {importStatus && (
                        <div className="bg-indigo-950/40 border border-indigo-900 text-indigo-300 p-2.5 rounded flex items-center gap-2 text-[11px]">
                          <RefreshCw className="w-3.5 h-3.5 text-indigo-400 animate-spin flex-shrink-0" />
                          <p className="font-sans">{importStatus}</p>
                        </div>
                      )}

                      {importError && (
                        <div className="bg-red-950/40 border border-red-900 text-red-400 p-2.5 rounded flex items-start gap-2 font-sans">
                          <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                          <p>{importError}</p>
                        </div>
                      )}

                      {scannedProjects.length > 0 && (
                        <div className="space-y-2">
                          <div className="bg-emerald-950/40 border border-emerald-900 text-emerald-400 p-2.5 rounded text-[11px] flex items-center gap-2">
                            <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                            <p>
                              Parsed <strong>{scannedProjects.length} projects</strong> from Sheet! Review details and confirm below.
                            </p>
                          </div>

                          {/* List preview */}
                          <div className="max-h-40 overflow-y-auto border border-gray-800 rounded bg-gray-950 divide-y divide-gray-900 font-mono text-[10px]">
                            {scannedProjects.map((p, idx) => (
                              <div key={idx} className="p-2 flex items-center justify-between text-gray-400 hover:bg-gray-900">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-gray-600">#{p.sNo}</span>
                                  <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                    p.projectRef.startsWith('M-') ? 'bg-indigo-500/10 text-indigo-400' :
                                    p.projectRef.startsWith('Q-') ? 'bg-emerald-500/10 text-emerald-400' :
                                    'bg-amber-500/10 text-amber-400'
                                  }`}>
                                    {p.projectRef}
                                  </span>
                                  <span className="truncate text-gray-300 font-sans max-w-[150px]">{p.name}</span>
                                </div>
                                <span className="text-emerald-500 font-bold font-mono">S${p.sum.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                              </div>
                            ))}
                          </div>

                          <button
                            type="button"
                            onClick={handleImportScannedProjects}
                            disabled={loading}
                            className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded transition flex items-center justify-center gap-1.5 shadow"
                          >
                            {loading ? (
                              <RefreshCw className="w-4 h-4 animate-spin" />
                            ) : (
                              <Plus className="w-4 h-4" />
                            )}
                            Confirm and Import {scannedProjects.length} Projects to Firestore
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="pt-2 border-t border-gray-800 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsImportOpen(false);
                        setImportError('');
                        setImportCsvText('');
                        setScannedProjects([]);
                        setImportStatus('');
                      }}
                      className="px-4 py-2 bg-gray-900 border border-gray-800 hover:bg-gray-800 rounded text-gray-300 font-bold transition"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
