import React from 'react';
import SubFlowChart from '../SubFlowChart';

export default function HRFlowChart() {
  const steps = [
    { id: '2.1', title: '2.1 STAFF & WORKERS WELFARE MANAGEMENT' },
    { id: '2.2', title: '2.2 RECRUITMENT/LOA' },
    { id: '2.3', title: '2.3 PARTICULAR & INFORMATIONS' },
    { id: '2.4', title: '2.4 PAYROLL' },
    { id: '2.5', title: '2.5 LEAVE & MC RECORD' },
    { id: '2.6', title: '2.6 INSURANCES' },
    { id: '2.7', title: '2.7 DEVELOPMENT' },
    { id: '2.8', title: '2.8 UNIFORM' },
    { id: '2.9', title: '2.9 INCENTIVE & BONUS' },
    { id: '2.10', title: '2.10 PERFORMANCE INDICATOR' },
    { id: '2.11', title: '2.11 DORMITORY & ROOMS AGREEMENTS' },
  ];
  return <SubFlowChart title="HUMAN CAPITAL MANAGEMENT FLOW" steps={steps} />;
}
