import React, { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, orderBy } from 'firebase/firestore';
import { Check, X, Clock, ShieldAlert } from 'lucide-react';
import { useAppContext } from '../../../context/AppContext';
import { formatDate } from '../../../lib/dateUtils';

export default function AccessRequestsPanel() {
  const [requests, setRequests] = useState<any[]>([]);
  const { isUserAdmin } = useAppContext();

  useEffect(() => {
    const q = query(collection(db, 'accessRequests'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRequests(data);
    });
    return () => unsubscribe();
  }, []);

  const handleApprove = async (id: string) => {
    await updateDoc(doc(db, 'accessRequests', id), { status: 'approved' });
  };

  const handleReject = async (id: string) => {
    await deleteDoc(doc(db, 'accessRequests', id));
  };

  return (
    <div className={`space-y-6 ${!isUserAdmin ? "pointer-events-none opacity-90 select-none" : ""}`}>
      <div className="bg-[#141414] p-6 rounded-xl shadow-2xl border border-[#222]">
        <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-6 flex items-center">
          <ShieldAlert className="w-5 h-5 mr-2" />
          Access Requests
        </h2>
        
        {requests.length === 0 ? (
          <p className="text-[#777] text-sm">No access requests at the moment.</p>
        ) : (
          <div className="space-y-3">
            {requests.map(req => (
              <div key={req.id} className="bg-[#1A1A1A] border border-[#333] p-4 rounded-lg flex items-center justify-between">
                <div>
                  <h3 className="text-white font-bold">{req.name}</h3>
                  <p className="text-xs text-[#777] flex items-center mt-1">
                    <Clock className="w-3 h-3 mr-1" />
                    {formatDate(req.timestamp)}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  {req.status === 'pending' ? (
                    <>
                      <button 
                        onClick={() => handleApprove(req.id)}
                        className="p-2 bg-green-500/20 text-green-400 hover:bg-green-500/30 rounded-lg transition-colors border border-green-500/30"
                        title="Approve"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleReject(req.id)}
                        className="p-2 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-colors border border-red-500/30"
                        title="Reject"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <span className="text-xs font-bold text-green-500 uppercase tracking-wider px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full">
                      Approved
                    </span>
                  )}
                  {req.status === 'approved' && (
                     <button 
                        onClick={() => handleReject(req.id)}
                        className="text-xs text-[#777] hover:text-red-400 ml-4 underline"
                      >
                        Revoke Access
                      </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
