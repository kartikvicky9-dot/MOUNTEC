import React, { useState, useEffect } from 'react';
import HRAdminPanel from './HRAdminPanel';
import HRPlaceholderPanel from './HRPlaceholderPanel';
import StaffParticularsPanel from './StaffParticularsPanel';
import PayrollPanel from './PayrollPanel';
import SalaryProfileMasterPanel from './SalaryProfileMasterPanel';
import { useAppContext } from '../../../context/AppContext';

export default function HRManagementPanel() {
  const { selectedEmployeeIdFor23 } = useAppContext();
  const [activeTab, setActiveTab] = useState('2.1');

  useEffect(() => {
    if (selectedEmployeeIdFor23) {
      setActiveTab('2.3');
    }
  }, [selectedEmployeeIdFor23]);

  const tabs = [
    { id: '2.1', label: '2.1 Staff & Workers Welfare Management', component: HRAdminPanel },
    { id: '2.2', label: '2.2 Recruitment/LOA', component: () => <HRPlaceholderPanel title="Recruitment/LOA" /> },
    { id: '2.3', label: '2.3 Particular & Informations', component: StaffParticularsPanel },
    { id: '2.4', label: '2.4 Payroll', component: PayrollPanel },
    { id: '2.5', label: '2.5 Leave & MC Record', component: () => <HRPlaceholderPanel title="Leave & MC Record" /> },
    { id: '2.6', label: '2.6 Insurances', component: () => <HRPlaceholderPanel title="Insurances" /> },
    { id: '2.7', label: '2.7 Development', component: () => <HRPlaceholderPanel title="Development" /> },
    { id: '2.8', label: '2.8 Uniform', component: () => <HRPlaceholderPanel title="Uniform" /> },
    { id: '2.9', label: '2.9 Incentive & Bonus', component: () => <HRPlaceholderPanel title="Incentive & Bonus" /> },
    { id: '2.10', label: '2.10 Performance Indicator', component: () => <HRPlaceholderPanel title="Performance Indicator" /> },
    { id: '2.11', label: '2.11 Dormitory & Rooms Agreements', component: () => <HRPlaceholderPanel title="Dormitory & Rooms Agreements" /> },
    { id: '2.12', label: '2.12 Worker Salary Profile Master', component: SalaryProfileMasterPanel },
  ];

  const ActiveComponent = tabs.find(t => t.id === activeTab)?.component || HRAdminPanel;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold p-6 border-b border-gray-800">2. Human Capital Management</h2>
      <div className="flex flex-1">
        <div className="w-64 border-r border-gray-800 p-4 space-y-2 overflow-y-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left p-3 rounded ${activeTab === tab.id ? 'bg-blue-600' : 'hover:bg-gray-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
}
