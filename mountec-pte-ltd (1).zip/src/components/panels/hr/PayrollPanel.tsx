import React, { useState, useEffect, useMemo } from 'react';
import { collection, query, onSnapshot, addDoc, updateDoc, doc, writeBatch, getDocs, where } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { 
  FileSpreadsheet, 
  Loader2, 
  Plus, 
  Search, 
  Download, 
  RefreshCw, 
  Save, 
  FileText, 
  DollarSign, 
  Users, 
  TrendingUp, 
  Percent, 
  CheckCircle, 
  Edit, 
  Trash2, 
  Eye, 
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Building,
  Clock
} from 'lucide-react';
import { Worker } from '../../../types';
import jsPDF from 'jspdf';

interface TimesheetOverride {
  projectRef?: string;
  projectName?: string;
  timeIn?: string;
  timeOut?: string;
  regularHours?: number;
  otHours?: number;
  transportCharge?: number;
  status?: string;
}

interface PayrollRecord {
  id?: string;
  employeeId: string;
  nameOfWorker: string;
  nationality: string;
  monthYear: string; // e.g. "2026-07"
  
  // Earnings
  basicSalary: number;
  otHours: number;
  otRate: number; // e.g. 1.5 or 2.0
  otPay: number;
  allowanceHousing: number;
  allowanceTransport: number;
  allowanceOther: number;
  
  // Deductions
  deductionUnpaidLeave: number;
  deductionDorm: number;
  deductionAdvance: number;
  deductionOther: number;
  
  // CPF & Levies (SG Specific)
  isSgPr: boolean;
  cpfEmployeeRate: number; // e.g. 20 (%)
  cpfEmployerRate: number; // e.g. 17 (%)
  cpfEmployeeAmount: number;
  cpfEmployerAmount: number;
  cdacSindaMbmf: number; // Self-help group fund
  fwlAmount: number; // Foreign Worker Levy
  
  // Totals
  grossSalary: number;
  netPayable: number;
  totalCostToCompany: number;
  
  // Payment info
  bankName: string;
  bankAccountNo: string;
  paymentStatus: 'Draft' | 'Approved' | 'Paid';
  paymentDate: string;
  notes: string;
  
  // Timesheet Daily Overrides
  timesheetOverrides?: { [date: string]: TimesheetOverride };
}

export default function PayrollPanel() {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-07');
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  
  // Modal / Detail States
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isPayslipModalOpen, setIsPayslipModalOpen] = useState<boolean>(false);
  const [isTimesheetModalOpen, setIsTimesheetModalOpen] = useState<boolean>(false);
  const [allDeployments, setAllDeployments] = useState<any[]>([]);
  const [projects, setProjects] = useState<any[]>([]);
  
  // Quick-edit single record state
  const [editForm, setEditForm] = useState<PayrollRecord | null>(null);
  const [salaryProfiles, setSalaryProfiles] = useState<any[]>([]);

  // Helper to check match: "18-Jul-2026" matches "2026-07"
  const doesDateMatchMonthYear = (dateStr: string, monthYear: string) => {
    if (!dateStr || !monthYear) return false;
    const parts = dateStr.split('-');
    if (parts.length !== 3) return false;
    const monthMap: { [key: string]: string } = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
    };
    const dMonth = monthMap[parts[1].toLowerCase()];
    const dYear = parts[2];
    const [myYear, myMonth] = monthYear.split('-');
    return dMonth === myMonth && dYear === myYear;
  };

  // Load all salary profiles on mount in real-time
  useEffect(() => {
    const qProfiles = query(collection(db, 'salaryProfiles'));
    const unsubscribe = onSnapshot(qProfiles, (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setSalaryProfiles(list);
      localStorage.setItem('mountec_local_salary_profiles', JSON.stringify(list));
    }, (err) => {
      console.warn("Could not fetch salaryProfiles via snapshot, trying local:", err);
      const local = localStorage.getItem('mountec_local_salary_profiles');
      if (local) {
        setSalaryProfiles(JSON.parse(local));
      }
    });
    return () => unsubscribe();
  }, []);

  // Load all deployments on mount and month change in real-time
  useEffect(() => {
    const qDeployments = query(collection(db, 'work_deployments'));
    const unsubscribe = onSnapshot(qDeployments, (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setAllDeployments(list);
      localStorage.setItem('mountec_local_deployments', JSON.stringify(list));
    }, (err) => {
      console.warn("Could not fetch work_deployments via snapshot, falling back to local:", err);
      const local = localStorage.getItem('mountec_local_deployments');
      if (local) {
        setAllDeployments(JSON.parse(local));
      }
    });
    return () => unsubscribe();
  }, [selectedMonth]);

  // Load all projects in real-time
  useEffect(() => {
    const qProjects = query(collection(db, 'projects'));
    const unsubscribe = onSnapshot(qProjects, (snapshot) => {
      const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setProjects(list);
      localStorage.setItem('mountec_local_projects', JSON.stringify(list));
    }, (err) => {
      console.warn("Could not fetch projects via snapshot, falling back to local:", err);
      const local = localStorage.getItem('mountec_local_projects');
      if (local) {
        setProjects(JSON.parse(local));
      }
    });
    return () => unsubscribe();
  }, []);

  // 1. Fetch Workers Master List
  useEffect(() => {
    const qWorkers = query(collection(db, 'workers'));
    const unsubscribe = onSnapshot(qWorkers, (snapshot) => {
      const firestoreWorkers = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Worker));
      let localWorkers: Worker[] = [];
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        localWorkers = stored ? JSON.parse(stored) : [];
      } catch (e) {
        // ignore
      }
      
      const firestoreIds = new Set(firestoreWorkers.map(w => w.id));
      const firestoreSpreadsheetIds = new Set(
        firestoreWorkers.map(w => w.spreadsheetId).filter(Boolean) as string[]
      );
      
      const firestoreStintKeys = new Set(
        firestoreWorkers.map(w => {
          const empId = (w.employeeId || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return empId && sNo ? `${empId}-${sNo}` : '';
        }).filter(Boolean)
      );

      const firestoreNameKeys = new Set(
        firestoreWorkers.map(w => {
          const name = (w.nameOfWorker || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return name && sNo ? `${name}-${sNo}` : '';
        }).filter(Boolean)
      );
      
      const uniqueLocal = localWorkers.filter(w => {
        if (firestoreIds.has(w.id)) return false;
        if (w.id && firestoreSpreadsheetIds.has(w.id)) return false;
        
        const empId = (w.employeeId || '').trim().toUpperCase();
        const sNo = (w.sNo || '').trim().toUpperCase();
        if (empId && sNo) {
          const stintKey = `${empId}-${sNo}`;
          if (firestoreStintKeys.has(stintKey)) return false;
        }

        const name = (w.nameOfWorker || '').trim().toUpperCase();
        if (name && sNo) {
          const nameKey = `${name}-${sNo}`;
          if (firestoreNameKeys.has(nameKey)) return false;
        }
        
        return true;
      });
      setWorkers([...firestoreWorkers, ...uniqueLocal]);
    }, (err) => {
      console.warn("Error reading workers for payroll:", err);
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        if (stored) {
          setWorkers(JSON.parse(stored));
        }
      } catch (localErr) {
        console.warn("Error falling back to local workers on payroll error:", localErr);
      }
    });
    return () => unsubscribe();
  }, []);

  // 2. Fetch Payroll Records for selected month
  useEffect(() => {
    setLoading(true);
    const qPayroll = query(
      collection(db, 'payrollRecords'),
      where('monthYear', '==', selectedMonth)
    );
    
    const unsubscribe = onSnapshot(qPayroll, (snapshot) => {
      const records = snapshot.docs.map(d => ({ ...d.data(), id: d.id } as PayrollRecord));
      if (records.length === 0) {
        const local = localStorage.getItem(`mountec_local_payroll_${selectedMonth}`);
        if (local) {
          try {
            setPayrollRecords(JSON.parse(local));
          } catch (e) {
            setPayrollRecords([]);
          }
        } else {
          setPayrollRecords([]);
        }
      } else {
        setPayrollRecords(records);
        localStorage.setItem(`mountec_local_payroll_${selectedMonth}`, JSON.stringify(records));
      }
      setLoading(false);
    }, (err) => {
      console.warn("Error loading payroll records from firestore, trying local:", err);
      const local = localStorage.getItem(`mountec_local_payroll_${selectedMonth}`);
      if (local) {
        try {
          setPayrollRecords(JSON.parse(local));
        } catch (e) {
          setPayrollRecords([]);
        }
      } else {
        setPayrollRecords([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [selectedMonth]);

  // Sync OT Hours from Work Deployments
  const handleSyncFromDeployments = async () => {
    setLoading(true);
    try {
      // 1. Fetch all work deployments
      let deploymentsList: any[] = [];
      try {
        const snap = await getDocs(collection(db, 'work_deployments'));
        deploymentsList = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      } catch (err) {
        console.warn("Could not fetch work_deployments from firestore, trying local:", err);
        const localDeps = localStorage.getItem('mountec_local_deployments');
        if (localDeps) {
          deploymentsList = JSON.parse(localDeps);
        }
      }

      if (deploymentsList.length === 0) {
        alert("No work deployment records found to sync hours from.");
        setLoading(false);
        return;
      }

      // 2. Iterate through currently shown payroll records and update otHours
      let updatedRecordsCount = 0;
      const batch = writeBatch(db);
      const updatedLocalRecords = [...payrollRecords];

      for (let i = 0; i < updatedLocalRecords.length; i++) {
        const record = updatedLocalRecords[i];
        
        // Find matching deployments
        const workerDeployments = deploymentsList.filter(d => 
          d.employeeId === record.employeeId && 
          doesDateMatchMonthYear(d.date, selectedMonth)
        );

        // Look up worker's salary profile master
        const profile = salaryProfiles.find(p => p.employeeId === record.employeeId);
        let standardWorkingHours = 8;
        if (profile) {
          const startStr = profile.standardHoursStart || '08:00';
          const endStr = profile.standardHoursEnd || '17:00';
          const [sH, sM] = startStr.split(':').map(Number);
          const [eH, eM] = endStr.split(':').map(Number);
          if (!isNaN(sH) && !isNaN(eH)) {
            const diffHr = eH - sH + (eM - sM) / 60;
            standardWorkingHours = Math.max(0, diffHr - 1); // minus 1 hr break
          }
        }

        // Sum OT hours and transport claims
        let totalOtHours = 0;
        let totalTransportClaim = 0;
        let daysPresent = 0;
        const hasDeploymentLogs = workerDeployments.length > 0;

        workerDeployments.forEach(d => {
          if (d.status === 'Present') {
            daysPresent++;
            if (d.totalWorkingHours > standardWorkingHours) {
              totalOtHours += (d.totalWorkingHours - standardWorkingHours);
            }
            if (d.transportClaim !== undefined) {
              totalTransportClaim += parseFloat(String(d.transportClaim)) || 0;
            } else if (d.segments && Array.isArray(d.segments)) {
              d.segments.forEach((seg: any) => {
                if (seg.transportClaim !== undefined) {
                  totalTransportClaim += parseFloat(String(seg.transportClaim)) || 0;
                }
              });
            }
          }
        });

        // Update record
        const roundedOt = parseFloat(totalOtHours.toFixed(1));
        const roundedTransport = parseFloat(totalTransportClaim.toFixed(2));
        
        // Determine basic pay changes for Daily Rated employees
        let basicChanged = false;
        if (profile && profile.rateType === 'Daily Rated') {
          const newBasic = (profile.rateValue || 100) * daysPresent;
          if (record.basicSalary !== newBasic) {
            record.basicSalary = newBasic;
            basicChanged = true;
          }
        }

        const transportChanged = hasDeploymentLogs && (record.allowanceTransport !== roundedTransport);

        if (record.otHours !== roundedOt || basicChanged || transportChanged) {
          record.otHours = roundedOt;
          if (hasDeploymentLogs) {
            record.allowanceTransport = roundedTransport;
          }
          // Add sync note
          const cleanNotes = (record.notes || '').replace(/\(Auto-synced from Work Deployment:.*?\)/g, '').trim();
          record.notes = `${cleanNotes} (Auto-synced from Work Deployment: ${daysPresent} days present, ${roundedOt} hrs OT, S$ ${record.allowanceTransport.toFixed(2)} transport${basicChanged ? `, daily-rated basic recalculated to $${record.basicSalary}` : ''})`.trim();
          calculatePayrollValues(record);
          updatedRecordsCount++;

          // Try to stage in batch if we have IDs
          if (record.id && !record.id.startsWith('local-')) {
            const docRef = doc(db, 'payrollRecords', record.id);
            batch.update(docRef, { 
              basicSalary: record.basicSalary,
              otHours: record.otHours, 
              otPay: record.otPay,
              allowanceTransport: record.allowanceTransport,
              grossSalary: record.grossSalary,
              netPayable: record.netPayable,
              totalCostToCompany: record.totalCostToCompany,
              notes: record.notes
            } as any);
          }
        }
      }

      if (updatedRecordsCount > 0) {
        try {
          await batch.commit();
        } catch (dbErr) {
          console.warn("Firestore batch update failed, saving locally:", dbErr);
        }
        setPayrollRecords(updatedLocalRecords);
        localStorage.setItem(`mountec_local_payroll_${selectedMonth}`, JSON.stringify(updatedLocalRecords));
        alert(`Successfully synchronized timesheets! Updated ${updatedRecordsCount} worker payroll drafts for ${selectedMonth} with actual overtime hours from deployment logs.`);
      } else {
        alert(`All ${payrollRecords.length} worker payroll drafts are already fully in sync with their daily work deployment schedules.`);
      }
    } catch (err: any) {
      console.error("Error syncing timesheet to payroll:", err);
      alert(`Failed to sync timesheet: ${err.message || String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  // 3. Auto-populate/Sync Payroll drafts for all active workers
  const handleGeneratePayroll = async () => {
    if (workers.length === 0) {
      alert("No workers found in HR master list to generate payroll.");
      return;
    }

    const activeWorkers = workers.filter(w => {
      const status = (w.wpsPassStatus || w.status || 'LIVE').trim().toUpperCase();
      return status !== 'CANCELLED';
    });

    if (activeWorkers.length === 0) {
      alert("No active workers (status not Cancelled) are currently available.");
      return;
    }

    setLoading(true);
    try {
      const batch = writeBatch(db);
      let count = 0;

      for (const worker of activeWorkers) {
        // Check if a record already exists to prevent duplicate insertion
        const exists = payrollRecords.some(r => r.employeeId === worker.employeeId);
        if (exists) continue;

        // Look up worker's salary profile master
        const profile = salaryProfiles.find(p => p.employeeId === worker.employeeId);

        // Auto-detect SG / PR nationality for default CPF
        const isSg = profile ? !!profile.isSgPr : ((worker.nationality || '').toLowerCase().includes('singapore') || 
                     (worker.nationality || '').toLowerCase().includes('local') ||
                     (worker.nationality || '').toLowerCase().includes('pr'));

        // Estimate basic salary
        let basic = 2200;
        let otRateMultiplier = 1.5;
        let allowanceHousing = isSg ? 0 : 150;
        let allowanceTransport = 50;
        let allowanceOther = 0;
        let fwl = isSg ? 0 : 350; // default average levy
        let withholding = 0;

        // Count actual deployments in this month to calculate actual transport claims
        const monthDeployments = allDeployments.filter(d => 
          d.employeeId === worker.employeeId && 
          doesDateMatchMonthYear(d.date, selectedMonth)
        );
        let actualTransportClaim = 0;
        let hasDeploymentLogs = monthDeployments.length > 0;
        monthDeployments.forEach(d => {
          if (d.status === 'Present') {
            if (d.transportClaim !== undefined) {
              actualTransportClaim += parseFloat(String(d.transportClaim)) || 0;
            } else if (d.segments && Array.isArray(d.segments)) {
              d.segments.forEach((seg: any) => {
                if (seg.transportClaim !== undefined) {
                  actualTransportClaim += parseFloat(String(seg.transportClaim)) || 0;
                }
              });
            }
          }
        });

        if (profile) {
          otRateMultiplier = profile.otRateMultiplier || 1.5;
          allowanceHousing = profile.allowanceHousing || 0;
          allowanceTransport = hasDeploymentLogs ? actualTransportClaim : (profile.allowanceTransport || 0);
          allowanceOther = (profile.allowancePhone || 0) + (profile.allowanceOther || 0);
          fwl = profile.fwlAmount !== undefined ? profile.fwlAmount : (isSg ? 0 : 350);
          withholding = profile.withholdingAmount || 0;

          if (profile.rateType === 'Daily Rated') {
            const presentDaysCount = monthDeployments.filter(d => d.status === 'Present').length;
            basic = (profile.rateValue || 100) * presentDaysCount;
          } else {
            basic = profile.rateValue || 2400;
          }
        } else {
          // Fallback old rules
          if (hasDeploymentLogs) {
            allowanceTransport = actualTransportClaim;
          }
          if (worker.employeeId?.startsWith('ME-0')) basic = 2500;
          if (worker.employeeId === 'ME-029') basic = 2400; // Chinniah Rengasamy default
        }

        const newRecord: PayrollRecord = {
          employeeId: worker.employeeId || `EMP-${Math.floor(1000 + Math.random() * 9000)}`,
          nameOfWorker: worker.nameOfWorker || worker.name || 'Unknown Worker',
          nationality: worker.nationality || 'Foreigner',
          monthYear: selectedMonth,
          
          basicSalary: basic,
          otHours: 0,
          otRate: otRateMultiplier,
          otPay: 0,
          allowanceHousing: allowanceHousing,
          allowanceTransport: allowanceTransport,
          allowanceOther: allowanceOther,
          
          deductionUnpaidLeave: 0,
          deductionDorm: 0,
          deductionAdvance: 0,
          deductionOther: withholding, // savings withholding
          
          isSgPr: isSg,
          cpfEmployeeRate: isSg ? 20 : 0,
          cpfEmployerRate: isSg ? 17 : 0,
          cpfEmployeeAmount: 0,
          cpfEmployerAmount: 0,
          cdacSindaMbmf: isSg ? 1.50 : 0,
          fwlAmount: fwl,
          
          grossSalary: 0,
          netPayable: 0,
          totalCostToCompany: 0,
          
          bankName: worker.bankName || 'DBS/POSB',
          bankAccountNo: worker.bankAccountNo || '-',
          paymentStatus: 'Draft',
          paymentDate: '',
          notes: profile ? `Generated using Salary Profile (${profile.rateType})` : ''
        };

        // Recalculate calculated values
        calculatePayrollValues(newRecord);

        const newDocRef = doc(collection(db, 'payrollRecords'));
        batch.set(newDocRef, newRecord);
        count++;
      }

      if (count > 0) {
        await batch.commit();
        alert(`Successfully initialized ${count} worker payroll drafts for ${selectedMonth}!`);
      } else {
        alert("All active workers already have payroll records generated for this month.");
      }
    } catch (err) {
      console.error("Error generating payroll drafts:", err);
      alert("Failed to auto-seed payroll records.");
    } finally {
      setLoading(false);
    }
  };

  // Helper calculation function
  const calculatePayrollValues = (r: PayrollRecord) => {
    // 1. Overtime Pay
    const hourlyRate = (r.basicSalary / 2288) * 1.5; // Custom standard construction OT hour formula or standard (basic/2288)
    const otAmount = Math.round((r.otHours * r.otRate * (r.basicSalary / 176)) * 100) / 100; // Standard 44 hours/week formula or customized basic/176
    r.otPay = r.otHours > 0 ? otAmount : 0;

    // 2. Gross Salary (Basic + OT + Allowances - Unpaid Leave)
    r.grossSalary = r.basicSalary + r.otPay + r.allowanceHousing + r.allowanceTransport + r.allowanceOther - r.deductionUnpaidLeave;
    
    // 3. CPF Calculations
    if (r.isSgPr) {
      r.cpfEmployeeAmount = Math.round(r.grossSalary * (r.cpfEmployeeRate / 100) * 100) / 100;
      r.cpfEmployerAmount = Math.round(r.grossSalary * (r.cpfEmployerRate / 100) * 100) / 100;
    } else {
      r.cpfEmployeeAmount = 0;
      r.cpfEmployerAmount = 0;
      r.cdacSindaMbmf = 0;
    }

    // 4. Net Payable Salary (Gross - Employee CPF - other deductions)
    r.netPayable = Math.round((r.grossSalary - r.cpfEmployeeAmount - r.cdacSindaMbmf - r.deductionDorm - r.deductionAdvance - r.deductionOther) * 100) / 100;

    // 5. Total cost to company (Gross + Employer CPF + FWL)
    r.totalCostToCompany = Math.round((r.grossSalary + r.cpfEmployerAmount + r.fwlAmount) * 100) / 100;
  };

  // 4. Handle Edit / Update Field values
  const handleFieldChange = (field: keyof PayrollRecord, value: any) => {
    if (!editForm) return;
    
    const updated = { ...editForm, [field]: value };
    
    // Auto-recalculate dependencies
    if ([
      'basicSalary', 'otHours', 'otRate', 'allowanceHousing', 'allowanceTransport', 
      'allowanceOther', 'deductionUnpaidLeave', 'deductionDorm', 'deductionAdvance', 
      'deductionOther', 'isSgPr', 'cpfEmployeeRate', 'cpfEmployerRate', 'cdacSindaMbmf', 'fwlAmount'
    ].includes(field as string)) {
      calculatePayrollValues(updated);
    }
    
    setEditForm(updated);
  };

  // 5. Save edited record back to Firestore
  const saveRecord = async () => {
    if (!editForm || !editForm.id) return;
    try {
      const docRef = doc(db, 'payrollRecords', editForm.id);
      await updateDoc(docRef, { ...editForm } as any);
      setIsEditModalOpen(false);
      setSelectedRecord(editForm);
    } catch (err) {
      console.error("Error updating payroll record:", err);
      alert("Failed to save payroll record updates.");
    }
  };

  // Handle updates to timesheet daily entries dynamically
  const handleTimesheetCellChange = (entryKey: string, fieldOrFields: string | { [key: string]: any }, val?: any) => {
    if (!editForm) return;

    const timesheetOverrides = { ...(editForm.timesheetOverrides || {}) };
    const currentOverride = { ...(timesheetOverrides[entryKey] || {}) };
    
    if (typeof fieldOrFields === 'string') {
      const field = fieldOrFields;
      // Convert numbers correctly
      if (['regularHours', 'otHours', 'transportCharge'].includes(field)) {
        currentOverride[field] = isNaN(parseFloat(val)) ? 0 : parseFloat(val);
      } else {
        currentOverride[field] = val;
      }
    } else {
      // Multiple fields passed as an object
      Object.entries(fieldOrFields).forEach(([field, value]) => {
        if (['regularHours', 'otHours', 'transportCharge'].includes(field)) {
          currentOverride[field] = isNaN(parseFloat(value)) ? 0 : parseFloat(value);
        } else {
          currentOverride[field] = value;
        }
      });
    }
    
    timesheetOverrides[entryKey] = currentOverride as any;

    const updated = { ...editForm, timesheetOverrides };

    // Dynamically recalculate Overtime Hours & Transport Charges across all timesheet entries
    const entries = getTimesheetEntries(updated);
    let totalOt = 0;
    let totalTransport = 0;

    entries.forEach(entry => {
      const keyMatch = entry.key === entryKey;
      const oH = keyMatch ? currentOverride.otHours : entry.otHours;
      const tC = keyMatch ? currentOverride.transportCharge : entry.transportCharge;

      totalOt += parseFloat(String(oH !== undefined ? oH : 0)) || 0;
      totalTransport += parseFloat(String(tC !== undefined ? tC : 0)) || 0;
    });

    updated.otHours = totalOt;
    updated.allowanceTransport = totalTransport;

    // Recalculate payroll values (Gross Salary, Net Payable, Total Cost to Company)
    calculatePayrollValues(updated);
    setEditForm(updated);
  };

  const saveTimesheet = async () => {
    if (!editForm || !editForm.id) return;
    try {
      const docRef = doc(db, 'payrollRecords', editForm.id);
      await updateDoc(docRef, { ...editForm } as any);
      setIsTimesheetModalOpen(false);
      setSelectedRecord(editForm);
    } catch (err) {
      console.error("Error saving timesheet:", err);
      alert("Failed to sync timesheet updates.");
    }
  };

  // 6. Bulk update status (Approved / Paid)
  const handleBulkStatusChange = async (targetStatus: 'Approved' | 'Paid') => {
    if (payrollRecords.length === 0) return;
    if (!confirm(`Are you sure you want to mark all shown payroll records for ${selectedMonth} as ${targetStatus}?`)) return;

    setLoading(true);
    try {
      const batch = writeBatch(db);
      filteredRecords.forEach(r => {
        if (r.id) {
          const docRef = doc(db, 'payrollRecords', r.id);
          batch.update(docRef, { 
            paymentStatus: targetStatus,
            paymentDate: targetStatus === 'Paid' ? new Date().toISOString().split('T')[0] : ''
          });
        }
      });
      await batch.commit();
      alert(`Bulk updated records to ${targetStatus} successfully!`);
    } catch (err) {
      console.error("Failed to bulk update status:", err);
      alert("Error performing bulk status update.");
    } finally {
      setLoading(false);
    }
  };

  // Filter and search
  const filteredRecords = useMemo(() => {
    return payrollRecords.filter(r => {
      const matchesSearch = 
        r.nameOfWorker.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.nationality.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = statusFilter === 'ALL' || r.paymentStatus === statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }, [payrollRecords, searchQuery, statusFilter]);

  // Totals calculations
  const totalStats = useMemo(() => {
    let basic = 0;
    let gross = 0;
    let net = 0;
    let companyCost = 0;
    let employeeCpf = 0;
    let employerCpf = 0;
    let totalLevy = 0;

    filteredRecords.forEach(r => {
      basic += r.basicSalary || 0;
      gross += r.grossSalary || 0;
      net += r.netPayable || 0;
      companyCost += r.totalCostToCompany || 0;
      employeeCpf += r.cpfEmployeeAmount || 0;
      employerCpf += r.cpfEmployerAmount || 0;
      totalLevy += r.fwlAmount || 0;
    });

    return { basic, gross, net, companyCost, employeeCpf, employerCpf, totalLevy };
  }, [filteredRecords]);

  // Export to standard Payroll Excel format (CSV)
  const handleExportCSV = () => {
    if (filteredRecords.length === 0) {
      alert("No data to export.");
      return;
    }

    const headers = [
      'S/No', 'Employee ID', 'Name of Employee', 'Nationality', 'Month-Year',
      'Basic Salary ($)', 'OT Hours', 'OT Rate', 'OT Pay ($)', 
      'Housing Allowance ($)', 'Transport Allowance ($)', 'Other Allowance ($)',
      'Unpaid Leave Ded. ($)', 'Dormitory Ded. ($)', 'Salary Advance Ded. ($)', 'Other Ded. ($)',
      'Gross Salary ($)', 'Is SG/PR', 'Employee CPF ($)', 'Employer CPF ($)', 'Net Payable ($)', 
      'Bank Name', 'Bank Account No', 'Status', 'Payment Date'
    ];

    const rows = filteredRecords.map((r, i) => [
      i + 1,
      r.employeeId,
      r.nameOfWorker,
      r.nationality,
      r.monthYear,
      r.basicSalary,
      r.otHours,
      r.otRate,
      r.otPay,
      r.allowanceHousing,
      r.allowanceTransport,
      r.allowanceOther,
      r.deductionUnpaidLeave,
      r.deductionDorm,
      r.deductionAdvance,
      r.deductionOther,
      r.grossSalary,
      r.isSgPr ? 'Yes' : 'No',
      r.cpfEmployeeAmount,
      r.cpfEmployerAmount,
      r.netPayable,
      r.bankName,
      `"${r.bankAccountNo}"`,
      r.paymentStatus,
      r.paymentDate || 'N/A'
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `MOUNTEC_Payroll_Export_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export Bank GIRO Batch File
  const handleExportGiro = () => {
    if (filteredRecords.length === 0) {
      alert("No data to export.");
      return;
    }

    const headers = [
      'Record Type', 'Beneficiary Name', 'Beneficiary Bank Code', 'Beneficiary Account No', 
      'Amount ($)', 'Payment Reference', 'Transaction Type', 'Notification Email'
    ];

    // standard clean bank mapping helper
    const getBankCode = (bankName: string) => {
      const lower = bankName.toLowerCase();
      if (lower.includes('dbs') || lower.includes('posb')) return '7171';
      if (lower.includes('uob')) return '7378';
      if (lower.includes('ocbc')) return '7339';
      if (lower.includes('standard') || lower.includes('stanchart')) return '7214';
      if (lower.includes('maybank')) return '7302';
      if (lower.includes('hsbc')) return '7162';
      return '9999'; // default general
    };

    const rows = filteredRecords.map(r => [
      'TRANSFER',
      r.nameOfWorker.toUpperCase().replace(/,/g, ''),
      getBankCode(r.bankName),
      r.bankAccountNo.replace(/[^0-9]/g, ''),
      r.netPayable.toFixed(2),
      `SALARY_${selectedMonth.replace('-', '')}`,
      'SALA',
      ''
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `MOUNTEC_GIRO_BankBatch_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Generate beautiful, structured Payslip with jsPDF
  const generatePayslipPDF = (r: PayrollRecord) => {
    const doc = new jsPDF();

    // 1. Professional Header styling
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(22);
    doc.setTextColor(30, 41, 59); // Slate-800
    doc.text("MOUNTEC ENGINEERING PTE. LTD.", 14, 24);
    
    doc.setFontSize(9);
    doc.setFont("Helvetica", "normal");
    doc.setTextColor(100, 116, 139); // Slate-500
    doc.text("10 Admiralty Street, #02-18 North Link Building, Singapore 757695", 14, 30);
    doc.text("Co. Reg. No: 201827402M | Tel: +65 6755 2740", 14, 35);
    
    // Payslip Title Accent Banner
    doc.setFillColor(241, 245, 249); // light blue-gray
    doc.rect(14, 42, 182, 10, "F");
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42); // Slate-900
    doc.text(`ITEMIZED PAY SLIP FOR THE PERIOD: ${selectedMonth}`, 18, 48);

    // 2. Employee Info Grid
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text("EMPLOYEE PARTICULARS", 14, 60);
    
    doc.setDrawColor(226, 232, 240);
    doc.line(14, 62, 196, 62);
    
    doc.setFont("Helvetica", "normal");
    doc.setTextColor(15, 23, 42);
    doc.text("Employee Name:", 14, 69);
    doc.setFont("Helvetica", "bold");
    doc.text(r.nameOfWorker.toUpperCase(), 45, 69);
    
    doc.setFont("Helvetica", "normal");
    doc.text("Employee ID:", 14, 75);
    doc.setFont("Helvetica", "bold");
    doc.text(r.employeeId, 45, 75);
    
    doc.setFont("Helvetica", "normal");
    doc.text("Nationality:", 14, 81);
    doc.text(r.nationality, 45, 81);

    // Right Column of particulars
    doc.text("Payment Date:", 115, 69);
    doc.text(r.paymentDate || new Date().toISOString().split('T')[0], 150, 69);
    
    doc.text("Bank Name:", 115, 75);
    doc.text(r.bankName, 150, 75);
    
    doc.text("Bank Account No:", 115, 81);
    doc.text(r.bankAccountNo, 150, 81);

    // 3. Salary Breakdowns
    doc.setFont("Helvetica", "bold");
    doc.setTextColor(71, 85, 105);
    doc.text("EARNING DETAILS ($)", 14, 95);
    doc.text("DEDUCTION DETAILS ($)", 115, 95);
    doc.line(14, 97, 100, 97);
    doc.line(115, 97, 196, 97);

    doc.setFont("Helvetica", "normal");
    doc.setTextColor(15, 23, 42);
    
    // Earnings Column
    let y = 104;
    doc.text("Basic Salary:", 14, y);
    doc.text(r.basicSalary.toFixed(2), 75, y, { align: "right" });
    
    y += 7;
    doc.text(`Overtime Pay (${r.otHours} hrs @ ${r.otRate}x):`, 14, y);
    doc.text(r.otPay.toFixed(2), 75, y, { align: "right" });
    
    y += 7;
    doc.text("Housing Allowance:", 14, y);
    doc.text(r.allowanceHousing.toFixed(2), 75, y, { align: "right" });
    
    y += 7;
    doc.text("Transport Allowance:", 14, y);
    doc.text(r.allowanceTransport.toFixed(2), 75, y, { align: "right" });

    y += 7;
    doc.text("Other Allowances:", 14, y);
    doc.text(r.allowanceOther.toFixed(2), 75, y, { align: "right" });

    // Deductions Column
    let yd = 104;
    doc.text("Unpaid Leave Deductions:", 115, yd);
    doc.text(r.deductionUnpaidLeave.toFixed(2), 196, yd, { align: "right" });
    
    yd += 7;
    doc.text("Dormitory Rental Deductions:", 115, yd);
    doc.text(r.deductionDorm.toFixed(2), 196, yd, { align: "right" });
    
    yd += 7;
    doc.text("Salary Advance Deductions:", 115, yd);
    doc.text(r.deductionAdvance.toFixed(2), 196, yd, { align: "right" });
    
    yd += 7;
    doc.text("Other Deductions:", 115, yd);
    doc.text(r.deductionOther.toFixed(2), 196, yd, { align: "right" });

    if (r.isSgPr) {
      yd += 7;
      doc.text(`Employee CPF Contribution (${r.cpfEmployeeRate}%):`, 115, yd);
      doc.text(r.cpfEmployeeAmount.toFixed(2), 196, yd, { align: "right" });
      
      yd += 7;
      doc.text("CDAC/SINDA/MBMF Fund:", 115, yd);
      doc.text(r.cdacSindaMbmf.toFixed(2), 196, yd, { align: "right" });
    }

    // Line break before Totals
    const bottomY = Math.max(y, yd) + 12;
    doc.setDrawColor(148, 163, 184); // Slate-400
    doc.line(14, bottomY, 196, bottomY);

    // 4. Totals Block
    doc.setFont("Helvetica", "bold");
    doc.text("Gross Earnings:", 14, bottomY + 8);
    doc.text(`$${r.grossSalary.toFixed(2)}`, 75, bottomY + 8, { align: "right" });
    
    doc.text("Total Deductions:", 115, bottomY + 8);
    const totalDeductions = r.deductionUnpaidLeave + r.deductionDorm + r.deductionAdvance + r.deductionOther + r.cpfEmployeeAmount + r.cdacSindaMbmf;
    doc.text(`$${totalDeductions.toFixed(2)}`, 196, bottomY + 8, { align: "right" });

    // Net Payable highlight banner
    const bannerY = bottomY + 16;
    doc.setFillColor(30, 41, 59); // Dark slate
    doc.rect(14, bannerY, 182, 12, "F");
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(11);
    doc.text("NET SALARY PAYABLE (A - B):", 18, bannerY + 8);
    doc.text(`$${r.netPayable.toFixed(2)}`, 192, bannerY + 8, { align: "right" });

    // 5. CPF Contributions display if local
    if (r.isSgPr) {
      doc.setTextColor(15, 23, 42);
      doc.setFontSize(9);
      doc.setFont("Helvetica", "bold");
      doc.text("Employer CPF Contribution:", 14, bannerY + 38);
      doc.setFont("Helvetica", "normal");
      doc.text(`$${r.cpfEmployerAmount.toFixed(2)} (${r.cpfEmployerRate}%)`, 65, bannerY + 38);
    }

    // 6. Signatures block
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    
    doc.text("Authorized Signature", 14, bannerY + 68);
    doc.line(14, bannerY + 65, 75, bannerY + 65);
    
    doc.text("Employee's Signature (Acknowledgment)", 115, bannerY + 68);
    doc.line(115, bannerY + 65, 185, bannerY + 65);

    doc.setFontSize(8);
    doc.text("This is a computer-generated document. No physical signature is required.", 14, bannerY + 85);

    doc.save(`MOUNTEC_Payslip_${r.employeeId}_${selectedMonth}.pdf`);
  };

  // Helper to compile timesheet daily entries dynamically
  const getTimesheetEntries = (record: PayrollRecord) => {
    if (!record || !record.monthYear) return [];
    const [yearStr, monthStr] = record.monthYear.split('-');
    const year = parseInt(yearStr);
    const month = parseInt(monthStr);
    const daysInMonth = new Date(year, month, 0).getDate();
    
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthLabel = monthNames[month - 1];

    const entries: any[] = [];

    // Look up worker's salary profile master
    const profile = salaryProfiles.find(p => p.employeeId === record.employeeId);
    let standardWorkingHours = 8;
    if (profile) {
      const startStr = profile.standardHoursStart || '08:00';
      const endStr = profile.standardHoursEnd || '17:00';
      const [sH, sM] = startStr.split(':').map(Number);
      const [eH, eM] = endStr.split(':').map(Number);
      if (!isNaN(sH) && !isNaN(eH)) {
        const diffHr = eH - sH + (eM - sM) / 60;
        standardWorkingHours = Math.max(0, diffHr - 1); // minus 1 hr break
      }
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
      const dd = String(day).padStart(2, '0');
      const standardDate = `${dd}-${monthLabel}-${year}`;
      const cleanStandard = `${day}-${monthLabel}-${year}`;

      const matchDate = (dateStr: string) => {
        if (!dateStr) return false;
        const clean = dateStr.trim().toLowerCase().replace(/ /g, '-');
        const cleanNoZero = clean.startsWith('0') ? clean.substring(1) : clean;
        const normStandard = standardDate.toLowerCase();
        const normCleanStandard = cleanStandard.toLowerCase();
        return clean === normStandard || clean === normCleanStandard || cleanNoZero === normCleanStandard;
      };

      const dailyDeps = allDeployments.filter(d => 
        d.employeeId === record.employeeId && 
        matchDate(d.date)
      );

      const dayOfWeek = new Date(year, month - 1, day).getDay();
      const isSunday = dayOfWeek === 0;

      if (dailyDeps.length > 0) {
        dailyDeps.forEach((dep, index) => {
          if (dep.segments && dep.segments.length > 0) {
            dep.segments.forEach((seg: any, segIndex: number) => {
              const entryKey = `${standardDate}-dep-${dep.id || index}-seg-${segIndex}`;
              const segOverride = record.timesheetOverrides?.[entryKey];

              const defaultRegHours = segOverride?.regularHours !== undefined 
                ? segOverride.regularHours 
                : Math.min(standardWorkingHours, parseFloat(seg.workingHours) || 0);

              const defaultOtHours = segOverride?.otHours !== undefined 
                ? segOverride.otHours 
                : Math.max(0, (parseFloat(seg.workingHours) || 0) - standardWorkingHours);

              const defaultTransport = segOverride?.transportCharge !== undefined 
                ? segOverride.transportCharge 
                : 0;

              entries.push({
                key: entryKey,
                date: standardDate,
                day,
                projectRef: segOverride?.projectRef || seg.projectRef || dep.projectRef || '',
                projectName: segOverride?.projectName || seg.projectName || dep.projectName || '',
                timeIn: segOverride?.timeIn || seg.timeIn || dep.timeIn || '07:00',
                timeOut: segOverride?.timeOut || seg.timeOut || dep.timeOut || '18:00',
                regularHours: defaultRegHours,
                otHours: defaultOtHours,
                transportCharge: defaultTransport,
                status: segOverride?.status || dep.status || 'Present',
                isSunday,
                deploymentId: dep.id,
                segmentIndex: segIndex
              });
            });
          } else {
            const entryKey = `${standardDate}-dep-${dep.id || index}`;
            const depOverride = record.timesheetOverrides?.[entryKey];

            const defaultRegHours = depOverride?.regularHours !== undefined 
              ? depOverride.regularHours 
              : Math.min(standardWorkingHours, parseFloat(dep.totalWorkingHours) || 0);

            const defaultOtHours = depOverride?.otHours !== undefined 
              ? depOverride.otHours 
              : Math.max(0, (parseFloat(dep.totalWorkingHours) || 0) - standardWorkingHours);

            const defaultTransport = depOverride?.transportCharge !== undefined 
              ? depOverride.transportCharge 
              : 0;

            entries.push({
              key: entryKey,
              date: standardDate,
              day,
              projectRef: depOverride?.projectRef || dep.projectRef || '',
              projectName: depOverride?.projectName || dep.projectName || '',
              timeIn: depOverride?.timeIn || dep.timeIn || '07:00',
              timeOut: depOverride?.timeOut || dep.timeOut || '18:00',
              regularHours: defaultRegHours,
              otHours: defaultOtHours,
              transportCharge: defaultTransport,
              status: depOverride?.status || dep.status || 'Present',
              isSunday,
              deploymentId: dep.id
            });
          }
        });
      } else {
        const entryKey = `${standardDate}-none`;
        const depOverride = record.timesheetOverrides?.[entryKey];

        const defaultRegHours = depOverride?.regularHours !== undefined ? depOverride.regularHours : 0;
        const defaultOtHours = depOverride?.otHours !== undefined ? depOverride.otHours : 0;
        const defaultTransport = depOverride?.transportCharge !== undefined ? depOverride.transportCharge : 0;
        const defaultStatus = depOverride?.status || (isSunday ? 'Sunday' : 'NPR-001_No-Work');

        entries.push({
          key: entryKey,
          date: standardDate,
          day,
          projectRef: depOverride?.projectRef || (isSunday ? 'NPR-001_No-Work' : ''),
          projectName: depOverride?.projectName || (isSunday ? 'Sunday / No Work' : 'No Work'),
          timeIn: depOverride?.timeIn || '0.00',
          timeOut: depOverride?.timeOut || '0.00',
          regularHours: defaultRegHours,
          otHours: defaultOtHours,
          transportCharge: defaultTransport,
          status: defaultStatus,
          isSunday,
          deploymentId: null
        });
      }
    }

    return entries;
  };

  // Generate high-fidelity Mountec timesheet / salary voucher PDF
  const generateTimesheetPDF = (r: PayrollRecord) => {
    const doc = new jsPDF('p', 'mm', 'a4');
    const entries = getTimesheetEntries(r);

    // Header Company Name
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59); // Slate-800
    doc.text("MOUNTEC PTE. LTD.", 14, 12);
    
    doc.setFontSize(10);
    doc.text("TIME SHEET/SALARY VOUCHER", 14, 17);

    // Employee Particulars Box
    doc.setDrawColor(200, 200, 200);
    doc.setFillColor(250, 250, 250);
    doc.rect(14, 20, 182, 16, "FD");

    doc.setFontSize(7.5);
    doc.setFont("Helvetica", "normal");
    doc.setTextColor(50, 50, 50);

    // Left particulars
    doc.setFont("Helvetica", "bold"); doc.text("EMPLOYEE NAME:", 16, 24); doc.setFont("Helvetica", "normal"); doc.text(r.nameOfWorker.toUpperCase(), 45, 24);
    doc.setFont("Helvetica", "bold"); doc.text("EMPLOYEE ID NO:", 16, 29); doc.setFont("Helvetica", "normal"); doc.text(r.employeeId, 45, 29);
    doc.setFont("Helvetica", "bold"); doc.text("DATE OF EMPLOYMENT:", 16, 34); doc.setFont("Helvetica", "normal");
    const workerDetail = workers.find(w => w.employeeId === r.employeeId);
    doc.text(workerDetail?.dateOfEmployment || '20-10-2022', 45, 34);

    // Right particulars
    doc.setFont("Helvetica", "bold"); doc.text("POSITION:", 110, 24); doc.setFont("Helvetica", "normal"); doc.text(workerDetail?.designation || 'General Worker', 140, 24);
    doc.setFont("Helvetica", "bold"); doc.text("DEPARTMENT:", 110, 29); doc.setFont("Helvetica", "normal"); doc.text('Project', 140, 29);
    doc.setFont("Helvetica", "bold"); doc.text("TIME SHEET PERIOD:", 110, 34); doc.setFont("Helvetica", "normal"); doc.text(`01/${r.monthYear.split('-')[1]}/${r.monthYear.split('-')[0]} TO ${new Date(parseInt(r.monthYear.split('-')[0]), parseInt(r.monthYear.split('-')[1]), 0).getDate()}/${r.monthYear.split('-')[1]}/${r.monthYear.split('-')[0]}`, 140, 34);

    // Daily Table Headers
    const headers = ["NAME OF PROJECT", "DATE", "TIME IN", "TIME OUT", "REGULAR HOURS", "OT HOURS", "TRANSPORT", "SIGNATURE"];
    const colWidths = [50, 22, 15, 15, 24, 16, 20, 20]; // Total: 182mm
    const startX = 14;
    let startY = 39;
    
    // Draw Header Row
    doc.setFillColor(240, 240, 240);
    doc.rect(startX, startY, 182, 5, "F");
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(7);
    doc.setDrawColor(200, 200, 200);

    let currentX = startX;
    headers.forEach((h, idx) => {
      doc.rect(currentX, startY, colWidths[idx], 5, "D");
      const textX = currentX + colWidths[idx] / 2;
      doc.text(h, textX, startY + 3.5, { align: "center" });
      currentX += colWidths[idx];
    });

    // Draw Daily rows
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(6.5);
    startY += 5;

    let totalReg = 0;
    let totalOt = 0;
    let totalTrans = 0;

    entries.forEach((entry, idx) => {
      // Row Background for alternate or Sundays
      if (entry.isSunday) {
        doc.setFillColor(254, 243, 199); // light amber for Sundays
        doc.rect(startX, startY, 182, 4.2, "F");
      } else if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(startX, startY, 182, 4.2, "F");
      }

      totalReg += parseFloat(entry.regularHours) || 0;
      totalOt += parseFloat(entry.otHours) || 0;
      totalTrans += parseFloat(entry.transportCharge) || 0;

      currentX = startX;
      
      // Project Name
      doc.rect(currentX, startY, colWidths[0], 4.2, "D");
      let prName = entry.projectName || entry.projectRef || 'NPR-001_No-Work';
      if (prName.length > 35) prName = prName.substring(0, 33) + '...';
      doc.text(prName, currentX + 2, startY + 3);
      currentX += colWidths[0];

      // Date
      doc.rect(currentX, startY, colWidths[1], 4.2, "D");
      doc.text(entry.date, currentX + colWidths[1] / 2, startY + 3, { align: "center" });
      currentX += colWidths[1];

      // Time In
      doc.rect(currentX, startY, colWidths[2], 4.2, "D");
      doc.text(entry.timeIn, currentX + colWidths[2] / 2, startY + 3, { align: "center" });
      currentX += colWidths[2];

      // Time Out
      doc.rect(currentX, startY, colWidths[3], 4.2, "D");
      doc.text(entry.timeOut, currentX + colWidths[3] / 2, startY + 3, { align: "center" });
      currentX += colWidths[3];

      // Regular Hours
      doc.rect(currentX, startY, colWidths[4], 4.2, "D");
      const rH = parseFloat(entry.regularHours);
      doc.text(rH > 0 ? rH.toFixed(2) : '0.00', currentX + colWidths[4] / 2, startY + 3, { align: "center" });
      currentX += colWidths[4];

      // Overtime Hours
      doc.rect(currentX, startY, colWidths[5], 4.2, "D");
      const oH = parseFloat(entry.otHours);
      doc.text(oH > 0 ? oH.toFixed(2) : '0', currentX + colWidths[5] / 2, startY + 3, { align: "center" });
      currentX += colWidths[5];

      // Daily Transport Charge
      doc.rect(currentX, startY, colWidths[6], 4.2, "D");
      const tC = parseFloat(entry.transportCharge);
      doc.text(tC > 0 ? `$${tC.toFixed(2)}` : '$0.00', currentX + colWidths[6] / 2, startY + 3, { align: "center" });
      currentX += colWidths[6];

      // Signature
      doc.rect(currentX, startY, colWidths[7], 4.2, "D");
      doc.text("Admin", currentX + colWidths[7] / 2, startY + 3, { align: "center" });

      startY += 4.2;
    });

    // Total Row
    doc.setFillColor(240, 240, 240);
    doc.rect(startX, startY, 182, 4.5, "F");
    doc.setFont("Helvetica", "bold");
    doc.rect(startX, startY, colWidths[0] + colWidths[1] + colWidths[2] + colWidths[3], 4.5, "D");
    doc.text("TOTAL", startX + 5, startY + 3.2);

    let totX = startX + colWidths[0] + colWidths[1] + colWidths[2] + colWidths[3];
    // Reg Hours total
    doc.rect(totX, startY, colWidths[4], 4.5, "D");
    doc.text(totalReg.toFixed(1), totX + colWidths[4] / 2, startY + 3.2, { align: "center" });
    totX += colWidths[4];

    // OT Hours total
    doc.rect(totX, startY, colWidths[5], 4.5, "D");
    doc.text(totalOt.toFixed(1), totX + colWidths[5] / 2, startY + 3.2, { align: "center" });
    totX += colWidths[5];

    // Transport Total
    doc.rect(totX, startY, colWidths[6], 4.5, "D");
    doc.text(`$${totalTrans.toFixed(2)}`, totX + colWidths[6] / 2, startY + 3.2, { align: "center" });
    totX += colWidths[6];

    // Blank total
    doc.rect(totX, startY, colWidths[7], 4.5, "D");

    startY += 7;

    // A- EARNINGS Box & B- DEDUCTION Box
    const boxWidth = 88;
    const boxHeight = 40;
    
    // Left Box: Earnings
    doc.setFillColor(245, 247, 250);
    doc.rect(startX, startY, boxWidth, boxHeight, "F");
    doc.rect(startX, startY, boxWidth, boxHeight, "D");

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text("A- EARNINGS:", startX + 3, startY + 4);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(6.5);
    let earnY = startY + 8;
    
    const drawEarnRow = (label: string, rate: string, qty: string, amt: string) => {
      doc.setFont("Helvetica", "normal");
      doc.text(label, startX + 3, earnY);
      doc.text(rate, startX + 45, earnY);
      doc.text(qty, startX + 65, earnY);
      doc.setFont("Helvetica", "bold");
      doc.text(amt, startX + 85, earnY, { align: "right" });
      earnY += 3.5;
    };

    drawEarnRow("THIS PAY PERIOD (BASIC)", `$${r.basicSalary.toFixed(2)}`, "1", `$${r.basicSalary.toFixed(2)}`);
    drawEarnRow(`OVER-TIME ALLOWANCE`, `$${r.otRate > 0 ? (r.basicSalary / 228 * r.otRate).toFixed(2) : '4.88'}`, totalOt.toFixed(1), `$${r.otPay.toFixed(2)}`);
    drawEarnRow("MONTHLY ALLOWANCE", `$${r.allowanceHousing.toFixed(2)}`, "1", `$${r.allowanceHousing.toFixed(2)}`);
    drawEarnRow("TRANSPORT ALLOWANCE", "-", "-", `$${totalTrans.toFixed(2)}`);
    drawEarnRow("HAND PHONE ALLOWANCE", "$11.67", "1", "$11.67");
    drawEarnRow("MONTHLY WITH-HOLD AMOUNT", "-$100.00", "1", "-$100.00");
    
    earnY = startY + boxHeight - 3.5;
    doc.line(startX, earnY - 1, startX + boxWidth, earnY - 1);
    doc.setFont("Helvetica", "bold");
    doc.text("GROSS PAY (A):", startX + 3, earnY + 2.5);
    doc.text(`$${r.grossSalary.toFixed(2)}`, startX + boxWidth - 3, earnY + 2.5, { align: "right" });

    // Right Box: Deductions & Other Info
    const rightStartX = startX + boxWidth + 6;
    doc.setFillColor(245, 247, 250);
    doc.rect(rightStartX, startY, boxWidth, boxHeight, "F");
    doc.rect(rightStartX, startY, boxWidth, boxHeight, "D");

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text("B- DEDUCTION:", rightStartX + 3, startY + 4);

    doc.setFont("Helvetica", "normal");
    doc.setFontSize(6.5);
    let dedY = startY + 8;

    const drawDedRow = (label: string, amt: string) => {
      doc.text(label, rightStartX + 3, dedY);
      doc.setFont("Helvetica", "bold");
      doc.text(amt, rightStartX + boxWidth - 3, dedY, { align: "right" });
      doc.setFont("Helvetica", "normal");
      dedY += 4.0;
    };

    const totalDeductions = r.deductionUnpaidLeave + r.deductionDorm + r.deductionAdvance + r.deductionOther + r.cpfEmployeeAmount + r.cdacSindaMbmf;

    drawDedRow("DORMITORY RENTAL DEDUCTION", `$${r.deductionDorm.toFixed(2)}`);
    drawDedRow("SALARY ADVANCE DEDUCTION", `$${r.deductionAdvance.toFixed(2)}`);
    drawDedRow("CPF (EMPLOYEE)", `$${r.cpfEmployeeAmount.toFixed(2)}`);
    drawDedRow("CDAC / SINDA / MBMF", `$${r.cdacSindaMbmf.toFixed(2)}`);
    drawDedRow("OTHER DEDUCTIONS", `$${r.deductionOther.toFixed(2)}`);

    dedY = startY + boxHeight - 3.5;
    doc.line(rightStartX, dedY - 1, rightStartX + boxWidth, dedY - 1);
    doc.setFont("Helvetica", "bold");
    doc.text("TOTAL DEDUCTION (B):", rightStartX + 3, dedY + 2.5);
    doc.text(`$${totalDeductions.toFixed(2)}`, rightStartX + boxWidth - 3, dedY + 2.5, { align: "right" });

    // Total Payable Row
    startY += boxHeight + 3;
    doc.setFillColor(30, 41, 59); // dark slate background
    doc.rect(startX, startY, 182, 6, "F");
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text("TOTAL PAYABLE AMOUNT (A - B):", startX + 4, startY + 4.2);
    doc.text(`$${r.netPayable.toFixed(2)}`, startX + 182 - 4, startY + 4.2, { align: "right" });

    // Other Info and Payment Details
    startY += 9;
    doc.setTextColor(50, 50, 50);
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text("C- OTHER INFORMATION:", startX, startY);
    
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(6.5);
    doc.text(`PAYMENT METHOD: INTERBANK (${r.bankName || 'DBS/POSB'} ${r.bankAccountNo || '450-18873-5'})`, startX, startY + 3.8);
    doc.text(`PAY DATE: ${r.paymentDate || new Date().toISOString().split('T')[0]}`, startX, startY + 7.2);

    // Signature boxes
    doc.setDrawColor(200, 200, 200);
    doc.line(startX + 10, startY + 18, startX + 70, startY + 18);
    doc.text("Authorized Signature", startX + 25, startY + 21);

    doc.line(startX + 110, startY + 18, startX + 170, startY + 18);
    doc.text("Employee's Signature (Acknowledgment)", startX + 115, startY + 21);

    // Save
    doc.save(`MOUNTEC_Timesheet_Voucher_${r.employeeId}_${r.monthYear}.pdf`);
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Header section with month selectors & primary CTA */}
      <div className="p-6 bg-gradient-to-r from-slate-900 to-gray-900 border-b border-gray-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-emerald-400" />
            2.4 Worker Payroll Formats & Registers
          </h3>
          <p className="text-xs text-gray-400 mt-1">
            Singapore construction-compliant itemized monthly salary processing, CPF summaries, and GIRO bank exports.
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 px-3 py-1.5 rounded-lg">
            <span className="text-xs font-semibold text-gray-300">Select Month:</span>
            <input 
              type="month" 
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent border-none text-white text-xs focus:ring-0 cursor-pointer uppercase font-bold"
            />
          </div>

          <button
            onClick={handleGeneratePayroll}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-md transition-all disabled:opacity-50"
            title="Auto-generate draft payroll worksheets for all active workers in the selected month"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Sync & Seed Drafts
          </button>

          <button
            onClick={handleSyncFromDeployments}
            disabled={loading || payrollRecords.length === 0}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-md transition-all disabled:opacity-50"
            title="Import and calculate overtime hours directly from daily site deployment timesheets"
          >
            <Clock className="w-3.5 h-3.5" />
            Sync Deployed Timesheets
          </button>

          <button
            onClick={handleExportCSV}
            disabled={filteredRecords.length === 0}
            className="bg-slate-800 hover:bg-slate-700 text-gray-200 border border-gray-700 text-xs font-bold px-3 py-2 rounded-lg flex items-center gap-1.5 transition-all"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Excel Export
          </button>

          <button
            onClick={handleExportGiro}
            disabled={filteredRecords.length === 0}
            className="bg-slate-800 hover:bg-slate-700 text-gray-200 border border-gray-700 text-xs font-bold px-3 py-2 rounded-lg flex items-center gap-1.5 transition-all"
          >
            <CreditCard className="w-3.5 h-3.5 text-blue-400" />
            Bank GIRO File
          </button>
        </div>
      </div>

      {/* Statistics / Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-6 border-b border-gray-800 bg-gray-900/50">
        <div className="bg-gray-800/40 border border-gray-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Monthly Company Cost</span>
            <h4 className="text-xl font-bold text-white mt-1">${totalStats.companyCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h4>
            <span className="text-[9px] text-emerald-400 font-semibold mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> Includes CPF + Levies
            </span>
          </div>
          <div className="w-10 h-10 bg-emerald-500/10 rounded-lg flex items-center justify-center text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-gray-800/40 border border-gray-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Net Salary Payable</span>
            <h4 className="text-xl font-bold text-white mt-1">${totalStats.net.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h4>
            <span className="text-[9px] text-blue-400 font-semibold mt-1 flex items-center gap-1">
              <CreditCard className="w-3 h-3" /> Direct bank transfers
            </span>
          </div>
          <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-gray-800/40 border border-gray-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total CPF (Employee + Employer)</span>
            <h4 className="text-xl font-bold text-white mt-1">${(totalStats.employeeCpf + totalStats.employerCpf).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h4>
            <span className="text-[9px] text-purple-400 font-semibold mt-1">
              Emp: ${totalStats.employeeCpf.toFixed(2)} | Empr: ${totalStats.employerCpf.toFixed(2)}
            </span>
          </div>
          <div className="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center text-purple-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-gray-800/40 border border-gray-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Foreign Worker Levies</span>
            <h4 className="text-xl font-bold text-white mt-1">${totalStats.totalLevy.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h4>
            <span className="text-[9px] text-amber-400 font-semibold mt-1">
              {filteredRecords.filter(r => !r.isSgPr).length} foreign work permit holders
            </span>
          </div>
          <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-400">
            <Building className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-6 bg-gray-950/40 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, ID, nationality..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 text-white rounded-lg pl-9 pr-4 py-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-gray-400 font-medium">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-gray-800 border border-gray-700 text-white text-xs px-2.5 py-1.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Draft">Draft</option>
              <option value="Approved">Approved</option>
              <option value="Paid">Paid</option>
            </select>
          </div>

          <div className="border-l border-gray-800 h-6 mx-1 hidden md:block"></div>

          <button
            onClick={() => handleBulkStatusChange('Approved')}
            disabled={filteredRecords.length === 0}
            className="bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 text-xs px-3 py-1.5 rounded-lg font-bold transition-all"
          >
            Approve All Shown
          </button>

          <button
            onClick={() => handleBulkStatusChange('Paid')}
            disabled={filteredRecords.length === 0}
            className="bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/30 text-xs px-3 py-1.5 rounded-lg font-bold transition-all"
          >
            Mark Paid
          </button>
        </div>
      </div>

      {/* Main Table View */}
      <div className="overflow-x-auto">
        {loading ? (
          <div className="p-12 text-center flex flex-col items-center justify-center gap-2">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
            <p className="text-xs text-gray-400">Loading payroll registry...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <p className="text-sm font-semibold">No payroll records found for {selectedMonth}.</p>
            <p className="text-xs text-gray-600 mt-1">Click "Sync & Seed Drafts" to initialize records from active HR profiles.</p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-950 border-b border-gray-800 text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                <th className="p-4">Emp ID / Name</th>
                <th className="p-4">Basic Pay</th>
                <th className="p-4">OT (Hrs)</th>
                <th className="p-4">Allowances</th>
                <th className="p-4">Deductions</th>
                <th className="p-4">Gross Salary</th>
                <th className="p-4">CPF (Emp/Empr)</th>
                <th className="p-4">Net Payable</th>
                <th className="p-4">Bank Detail</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filteredRecords.map((r) => {
                const totalAllowances = (r.allowanceHousing || 0) + (r.allowanceTransport || 0) + (r.allowanceOther || 0);
                const totalDeductions = (r.deductionUnpaidLeave || 0) + (r.deductionDorm || 0) + (r.deductionAdvance || 0) + (r.deductionOther || 0);

                return (
                  <tr key={r.id} className="hover:bg-gray-800/30 text-xs text-gray-300 transition-colors">
                    <td className="p-4">
                      <div className="font-bold text-white">{r.nameOfWorker}</div>
                      <div className="text-[10px] text-gray-500 font-mono mt-0.5 flex items-center gap-1.5">
                        <span>{r.employeeId}</span>
                        <span className="w-1 h-1 bg-gray-700 rounded-full"></span>
                        <span className="capitalize">{r.nationality}</span>
                      </div>
                    </td>
                    <td className="p-4 font-mono">${r.basicSalary.toFixed(2)}</td>
                    <td className="p-4 font-mono">
                      {r.otHours > 0 ? (
                        <span className="text-emerald-400 font-semibold">
                          {r.otHours}h ({r.otRate}x)
                        </span>
                      ) : (
                        <span className="text-gray-600">-</span>
                      )}
                    </td>
                    <td className="p-4 font-mono">
                      {totalAllowances > 0 ? (
                        <span className="text-emerald-400">+${totalAllowances.toFixed(2)}</span>
                      ) : (
                        <span className="text-gray-600">$0.00</span>
                      )}
                    </td>
                    <td className="p-4 font-mono">
                      {totalDeductions > 0 ? (
                        <span className="text-rose-400">-${totalDeductions.toFixed(2)}</span>
                      ) : (
                        <span className="text-gray-600">$0.00</span>
                      )}
                    </td>
                    <td className="p-4 font-bold font-mono text-white">${r.grossSalary.toFixed(2)}</td>
                    <td className="p-4 font-mono text-[11px]">
                      {r.isSgPr ? (
                        <div className="text-purple-400 font-semibold">
                          -${r.cpfEmployeeAmount.toFixed(2)} / +${r.cpfEmployerAmount.toFixed(2)}
                        </div>
                      ) : (
                        <span className="text-gray-600">Non-SG</span>
                      )}
                    </td>
                    <td className="p-4 font-extrabold font-mono text-emerald-400 text-sm">
                      ${r.netPayable.toFixed(2)}
                    </td>
                    <td className="p-4 text-[11px]">
                      <div className="text-gray-400 truncate max-w-[120px]">{r.bankName}</div>
                      <div className="text-[10px] text-gray-500 font-mono">{r.bankAccountNo}</div>
                    </td>
                    <td className="p-4">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded border uppercase ${
                        r.paymentStatus === 'Paid' 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : r.paymentStatus === 'Approved'
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                          : 'bg-gray-800 text-gray-400 border-gray-700'
                      }`}>
                        {r.paymentStatus}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setEditForm(r);
                            setIsEditModalOpen(true);
                          }}
                          className="p-1.5 hover:bg-gray-700 text-blue-400 rounded transition-colors"
                          title="Edit Earnings & Deductions"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        
                        <button
                          onClick={() => {
                            setEditForm(r);
                            setIsTimesheetModalOpen(true);
                          }}
                          className="p-1.5 hover:bg-gray-700 text-amber-400 rounded transition-colors"
                          title="View / Edit ME Individual Timesheet & Salary Voucher"
                        >
                          <Clock className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => generatePayslipPDF(r)}
                          className="p-1.5 hover:bg-gray-700 text-emerald-400 rounded transition-colors"
                          title="Generate Itemized PDF Payslip"
                        >
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Edit Payroll Form Modal */}
      {isEditModalOpen && editForm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl w-full max-w-4xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-gray-800 bg-slate-950 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-white text-base">Adjust Monthly Payroll Details</h4>
                <div className="text-xs text-gray-400 mt-1 flex items-center gap-2">
                  <span>Worker: <strong>{editForm.nameOfWorker}</strong></span>
                  <span className="w-1 h-1 bg-gray-700 rounded-full"></span>
                  <span>ID: <strong>{editForm.employeeId}</strong></span>
                </div>
              </div>
              <button 
                onClick={() => setIsEditModalOpen(false)}
                className="text-gray-400 hover:text-white font-bold text-lg"
              >
                &times;
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              
              {/* Basic and OT Info Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="bg-gray-950/40 p-4 rounded-lg border border-gray-800">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Base Compensation</label>
                  <div className="space-y-3">
                    <div>
                      <span className="text-[11px] text-gray-400">Basic Monthly Salary ($)</span>
                      <input
                        type="number"
                        value={editForm.basicSalary}
                        onChange={(e) => handleFieldChange('basicSalary', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={editForm.isSgPr}
                          onChange={(e) => handleFieldChange('isSgPr', e.target.checked)}
                          className="rounded bg-gray-800 border-gray-700 text-blue-500 text-xs"
                        />
                        <span className="text-[11px] text-gray-300 font-semibold">Is Singaporean / PR</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-950/40 p-4 rounded-lg border border-gray-800">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Overtime Earnings</label>
                  <div className="space-y-3">
                    <div>
                      <span className="text-[11px] text-gray-400">OT Hours Logged</span>
                      <input
                        type="number"
                        value={editForm.otHours}
                        onChange={(e) => handleFieldChange('otHours', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-gray-400">OT Multiplier Rate</span>
                      <select
                        value={editForm.otRate}
                        onChange={(e) => handleFieldChange('otRate', parseFloat(e.target.value) || 1.5)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white mt-1"
                      >
                        <option value="1.5">1.5x Standard OT</option>
                        <option value="2.0">2.0x Rest Day / Public Holiday</option>
                        <option value="1.0">1.0x Flat Rate</option>
                      </select>
                    </div>
                    <div className="text-[11px] text-emerald-400 font-bold">
                      Calculated OT Pay: ${editForm.otPay.toFixed(2)}
                    </div>
                  </div>
                </div>

                <div className="bg-gray-950/40 p-4 rounded-lg border border-gray-800">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Singapore CPF Settings</label>
                  <div className="space-y-3 disabled:opacity-40">
                    <div>
                      <span className="text-[11px] text-gray-400">Employee Share (%)</span>
                      <input
                        type="number"
                        value={editForm.cpfEmployeeRate}
                        disabled={!editForm.isSgPr}
                        onChange={(e) => handleFieldChange('cpfEmployeeRate', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-gray-400">Employer Share (%)</span>
                      <input
                        type="number"
                        value={editForm.cpfEmployerRate}
                        disabled={!editForm.isSgPr}
                        onChange={(e) => handleFieldChange('cpfEmployerRate', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div className="text-[11px] text-purple-400 font-semibold">
                      Ded. Emp: ${editForm.cpfEmployeeAmount.toFixed(2)} | Co: ${editForm.cpfEmployerAmount.toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Allowances and Deductions Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-gray-950/20 p-4 rounded-lg border border-gray-800/80">
                  <h5 className="text-xs font-bold text-emerald-400 mb-3 uppercase tracking-wider">Itemized Monthly Allowances</h5>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <span className="text-[10px] text-gray-400">Housing ($)</span>
                      <input
                        type="number"
                        value={editForm.allowanceHousing}
                        onChange={(e) => handleFieldChange('allowanceHousing', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-400">Transport ($)</span>
                      <input
                        type="number"
                        value={editForm.allowanceTransport}
                        onChange={(e) => handleFieldChange('allowanceTransport', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-400">Other / Incentive ($)</span>
                      <input
                        type="number"
                        value={editForm.allowanceOther}
                        onChange={(e) => handleFieldChange('allowanceOther', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-gray-950/20 p-4 rounded-lg border border-gray-800/80">
                  <h5 className="text-xs font-bold text-rose-400 mb-3 uppercase tracking-wider">Salary Deductions</h5>
                  <div className="grid grid-cols-4 gap-2">
                    <div>
                      <span className="text-[9px] text-gray-400">Unpaid Lve ($)</span>
                      <input
                        type="number"
                        value={editForm.deductionUnpaidLeave}
                        onChange={(e) => handleFieldChange('deductionUnpaidLeave', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-1.5 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400">Dorm Fee ($)</span>
                      <input
                        type="number"
                        value={editForm.deductionDorm}
                        onChange={(e) => handleFieldChange('deductionDorm', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-1.5 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400">Advance ($)</span>
                      <input
                        type="number"
                        value={editForm.deductionAdvance}
                        onChange={(e) => handleFieldChange('deductionAdvance', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-1.5 text-xs text-white font-mono mt-1"
                      />
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400">Other ($)</span>
                      <input
                        type="number"
                        value={editForm.deductionOther}
                        onChange={(e) => handleFieldChange('deductionOther', parseFloat(e.target.value) || 0)}
                        className="w-full bg-gray-800 border border-gray-700 rounded p-1.5 text-xs text-white font-mono mt-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Bank & Payment Information */}
              <div className="bg-gray-950/30 p-4 rounded-lg border border-gray-800">
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Banking & Status Details</label>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <span className="text-[11px] text-gray-400">Bank Name</span>
                    <input
                      type="text"
                      value={editForm.bankName}
                      onChange={(e) => handleFieldChange('bankName', e.target.value)}
                      className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white mt-1"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-gray-400">Bank Account No.</span>
                    <input
                      type="text"
                      value={editForm.bankAccountNo}
                      onChange={(e) => handleFieldChange('bankAccountNo', e.target.value)}
                      className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white font-mono mt-1"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-gray-400">Payment Status</span>
                    <select
                      value={editForm.paymentStatus}
                      onChange={(e) => handleFieldChange('paymentStatus', e.target.value)}
                      className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white mt-1"
                    >
                      <option value="Draft">Draft</option>
                      <option value="Approved">Approved</option>
                      <option value="Paid">Paid</option>
                    </select>
                  </div>
                  <div>
                    <span className="text-[11px] text-gray-400">Payment Date</span>
                    <input
                      type="date"
                      value={editForm.paymentDate}
                      onChange={(e) => handleFieldChange('paymentDate', e.target.value)}
                      className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white mt-1"
                    />
                  </div>
                </div>
                
                <div className="mt-3">
                  <span className="text-[11px] text-gray-400">Internal Audit Notes</span>
                  <input
                    type="text"
                    value={editForm.notes}
                    onChange={(e) => handleFieldChange('notes', e.target.value)}
                    placeholder="E.g. OT approved by PM; includes outstanding transport claims"
                    className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-xs text-white mt-1"
                  />
                </div>
              </div>

              {/* Dynamic Totals Banner inside modal */}
              <div className="bg-slate-950 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4 border border-gray-800 text-sm">
                <div>
                  <span className="text-[10px] uppercase text-gray-400 tracking-wide block">Gross Earnings (A)</span>
                  <span className="text-white font-bold font-mono">${editForm.grossSalary.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-gray-400 tracking-wide block">Employee CPF + Ded. (B)</span>
                  <span className="text-rose-400 font-bold font-mono">
                    ${(editForm.cpfEmployeeAmount + editForm.cdacSindaMbmf + editForm.deductionDorm + editForm.deductionAdvance + editForm.deductionOther).toFixed(2)}
                  </span>
                </div>
                <div className="border-l border-gray-800 h-8 hidden md:block"></div>
                <div>
                  <span className="text-[11px] uppercase text-emerald-400 tracking-wide font-extrabold block">Net Payable Salary (A - B)</span>
                  <span className="text-emerald-400 font-extrabold font-mono text-base">${editForm.netPayable.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase text-gray-400 tracking-wide block">Total Cost to Company</span>
                  <span className="text-white font-bold font-mono">${editForm.totalCostToCompany.toFixed(2)}</span>
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-800 bg-slate-950 flex items-center justify-end gap-3">
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-bold px-4 py-2 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={saveRecord}
                className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 py-2 rounded-lg flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                Save Changes
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ME Individual Timesheet & Salary Voucher Modal */}
      {isTimesheetModalOpen && editForm && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl w-full max-w-7xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-gray-800 bg-slate-950 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-white text-base flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-400" />
                  ME Individual Timesheet & Salary Voucher
                </h4>
                <p className="text-[11px] text-gray-400 mt-0.5">
                  Worker: <strong className="text-white">{editForm.nameOfWorker} ({editForm.employeeId})</strong> &bull; Period: <strong className="text-white">{editForm.monthYear}</strong> &bull; Customize daily hours, projects, or transport charges below. Changes sync instantly to the monthly payroll registry.
                </p>
              </div>
              <button 
                onClick={() => setIsTimesheetModalOpen(false)}
                className="text-gray-400 hover:text-white font-bold text-lg p-1"
              >
                &times;
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto flex-1 bg-gray-900/50 space-y-6">
              
              {/* Employee & Company Header Banner */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-950 p-4 rounded-xl border border-gray-800/80">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase text-gray-400 tracking-wider block">Company Employer</span>
                  <span className="text-white font-bold text-sm block">MOUNTEC PTE. LTD.</span>
                  <span className="text-[10px] text-gray-500 block">Co. Reg: 201827402M &bull; North Link Building</span>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase text-gray-400 tracking-wider block">Employee Details</span>
                  <span className="text-white font-bold text-sm block">{editForm.nameOfWorker.toUpperCase()}</span>
                  <span className="text-[11px] text-gray-300 font-mono block">ID: {editForm.employeeId} &bull; Nationality: {editForm.nationality}</span>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase text-gray-400 tracking-wider block">Designation & Department</span>
                  <span className="text-white font-bold text-sm block">
                    {workers.find(w => w.employeeId === editForm.employeeId)?.designation || 'General Worker'}
                  </span>
                  <span className="text-[11px] text-gray-300 block">Department: Project</span>
                </div>
              </div>

              {/* Timesheet Daily Table */}
              <div className="border border-gray-800 rounded-xl overflow-hidden shadow-lg bg-slate-950">
                <div className="p-3 bg-slate-900 border-b border-gray-800 flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-gray-300 tracking-wider">Daily Deployment Attendance Logs</span>
                  <div className="flex items-center gap-4 text-[11px] text-gray-400">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-500/20 rounded border border-amber-500/30"></span> Sunday</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-gray-800 rounded border border-gray-700"></span> Weekday</span>
                  </div>
                </div>
                
                <div className="max-h-[38vh] overflow-y-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-900/80 sticky top-0 border-b border-gray-800 text-[10px] uppercase font-bold text-gray-400 tracking-wider z-10">
                      <tr>
                        <th className="p-3 pl-4">Date</th>
                        <th className="p-3">Project / Jobsite (Worksite)</th>
                        <th className="p-3 text-center">Time In</th>
                        <th className="p-3 text-center">Time Out</th>
                        <th className="p-3 text-center">Regular Hours</th>
                        <th className="p-3 text-center">OT Hours</th>
                        <th className="p-3 text-center">Daily Transport ($)</th>
                        <th className="p-3 text-center">Status</th>
                        <th className="p-3 text-right pr-4">Signature</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-800/80">
                      {(() => {
                        const entries = getTimesheetEntries(editForm);
                        
                        // Sum calculations for display
                        let sumReg = 0;
                        let sumOt = 0;
                        let sumTrans = 0;
                        
                        return (
                          <>
                            {entries.map((entry) => {
                              sumReg += parseFloat(String(entry.regularHours)) || 0;
                              sumOt += parseFloat(String(entry.otHours)) || 0;
                              sumTrans += parseFloat(String(entry.transportCharge)) || 0;
                              
                              return (
                                <tr 
                                  key={entry.key} 
                                  className={`text-xs text-gray-300 transition-colors hover:bg-gray-800/20 ${
                                    entry.isSunday ? 'bg-amber-500/5 hover:bg-amber-500/10' : ''
                                  }`}
                                >
                                  {/* Date */}
                                  <td className="p-2 pl-4 font-mono font-semibold">
                                    {entry.date}
                                    {entry.isSunday && <span className="text-[8px] font-bold text-amber-400 ml-1.5 uppercase bg-amber-400/10 px-1 py-0.2 rounded">SUN</span>}
                                  </td>
                                  
                                  {/* Project / Jobsite */}
                                  <td className="p-1.5">
                                    <div className="flex flex-col gap-1">
                                      <select
                                        value={entry.projectRef || ''}
                                        onChange={(e) => {
                                          const val = e.target.value;
                                          const selectedProj = projects.find(p => p.projectRef === val);
                                          handleTimesheetCellChange(entry.key, {
                                            projectRef: val,
                                            projectName: selectedProj ? selectedProj.projectName : (val ? val : 'No Work')
                                          });
                                        }}
                                        className="bg-gray-900 border border-gray-800 hover:border-gray-700 text-gray-200 text-[11px] rounded px-1.5 py-1 w-48 font-medium focus:ring-1 focus:ring-amber-500"
                                      >
                                        <option value="">-- No Work / Sunday --</option>
                                        {projects.map((p) => (
                                          <option key={p.id} value={p.projectRef}>
                                            {p.projectRef} - {p.projectName}
                                          </option>
                                        ))}
                                        {entry.projectRef && !projects.some(p => p.projectRef === entry.projectRef) && (
                                          <option value={entry.projectRef}>
                                            {entry.projectRef} - {entry.projectName || entry.projectRef}
                                          </option>
                                        )}
                                      </select>
                                    </div>
                                  </td>
                                  
                                  {/* Time In */}
                                  <td className="p-1 text-center">
                                    <input 
                                      type="text" 
                                      value={entry.timeIn}
                                      onChange={(e) => handleTimesheetCellChange(entry.key, 'timeIn', e.target.value)}
                                      className="bg-gray-900 border border-gray-800 hover:border-gray-700 focus:border-amber-500 rounded px-1.5 py-1 text-center font-mono text-xs text-white w-14 mx-auto focus:ring-1 focus:ring-amber-500"
                                    />
                                  </td>
                                  
                                  {/* Time Out */}
                                  <td className="p-1 text-center">
                                    <input 
                                      type="text" 
                                      value={entry.timeOut}
                                      onChange={(e) => handleTimesheetCellChange(entry.key, 'timeOut', e.target.value)}
                                      className="bg-gray-900 border border-gray-800 hover:border-gray-700 focus:border-amber-500 rounded px-1.5 py-1 text-center font-mono text-xs text-white w-14 mx-auto focus:ring-1 focus:ring-amber-500"
                                    />
                                  </td>
                                  
                                  {/* Regular Hours */}
                                  <td className="p-1 text-center">
                                    <input 
                                      type="number" 
                                      step="0.5"
                                      min="0"
                                      max="24"
                                      value={entry.regularHours}
                                      onChange={(e) => handleTimesheetCellChange(entry.key, 'regularHours', parseFloat(e.target.value) || 0)}
                                      className="bg-gray-900 border border-gray-800 hover:border-gray-700 focus:border-amber-500 rounded px-1.5 py-1 text-center font-mono text-xs text-white w-16 mx-auto font-semibold focus:ring-1 focus:ring-amber-500"
                                    />
                                  </td>
                                  
                                  {/* Overtime Hours */}
                                  <td className="p-1 text-center">
                                    <input 
                                      type="number" 
                                      step="0.5"
                                      min="0"
                                      max="24"
                                      value={entry.otHours}
                                      onChange={(e) => handleTimesheetCellChange(entry.key, 'otHours', parseFloat(e.target.value) || 0)}
                                      className="bg-gray-900 border border-gray-800 hover:border-gray-700 focus:border-amber-500 rounded px-1.5 py-1 text-center font-mono text-xs text-emerald-400 w-14 mx-auto font-bold focus:ring-1 focus:ring-amber-500"
                                    />
                                  </td>
                                  
                                  {/* Daily Transport Charge */}
                                  <td className="p-1 text-center">
                                    <div className="relative inline-block">
                                      <span className="absolute left-1.5 top-1/2 -translate-y-1/2 text-[10px] text-gray-500 font-mono">$</span>
                                      <input 
                                        type="number" 
                                        step="0.1"
                                        min="0"
                                        value={entry.transportCharge}
                                        onChange={(e) => handleTimesheetCellChange(entry.key, 'transportCharge', parseFloat(e.target.value) || 0)}
                                        className="bg-gray-900 border border-gray-800 hover:border-gray-700 focus:border-amber-500 rounded pl-4 pr-1 py-1 text-center font-mono text-xs text-blue-400 w-16 mx-auto font-semibold focus:ring-1 focus:ring-amber-500"
                                      />
                                    </div>
                                  </td>
                                  
                                  {/* Status */}
                                  <td className="p-1 text-center">
                                    <select
                                      value={entry.status}
                                      onChange={(e) => handleTimesheetCellChange(entry.key, 'status', e.target.value)}
                                      className="bg-gray-900 border border-gray-800 hover:border-gray-700 rounded px-1.5 py-1 text-xs text-gray-300 focus:ring-0 w-24 mx-auto focus:ring-1 focus:ring-amber-500"
                                    >
                                      <option value="Present">Present</option>
                                      <option value="Absent">Absent</option>
                                      <option value="Leave">Leave</option>
                                      <option value="MC">MC</option>
                                      <option value="Sunday">Sunday</option>
                                      <option value="Public Holiday">PH</option>
                                      <option value="NPR-001_No-Work">No-Work</option>
                                    </select>
                                  </td>
                                  
                                  {/* Signature Column */}
                                  <td className="p-2 text-right pr-4 font-mono text-[9px] text-gray-500">
                                    Admin (ME)
                                  </td>
                                </tr>
                              );
                            })}
                            
                            {/* Totals Summary Row */}
                            <tr className="bg-slate-900 font-bold text-gray-200 border-t border-gray-700 sticky bottom-0 z-10 shadow-md">
                              <td className="p-3 pl-4 text-xs uppercase font-extrabold tracking-wider" colSpan={4}>
                                Timesheet Summary Totals
                              </td>
                              <td className="p-3 text-center font-mono text-sm text-white">
                                {sumReg.toFixed(1)} <span className="text-[10px] text-gray-400 font-sans font-normal">hrs</span>
                              </td>
                              <td className="p-3 text-center font-mono text-sm text-emerald-400">
                                {sumOt.toFixed(1)} <span className="text-[10px] text-gray-400 font-sans font-normal">hrs</span>
                              </td>
                              <td className="p-3 text-center font-mono text-sm text-blue-400">
                                ${sumTrans.toFixed(2)}
                              </td>
                              <td className="p-3" colSpan={2}></td>
                            </tr>
                          </>
                        );
                      })()}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Interlinked Interactive Salary Voucher Breakdown / Preview */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Earnings (A) Panel */}
                <div className="bg-slate-950 p-5 rounded-xl border border-gray-800/80">
                  <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-4">
                    <span className="text-xs uppercase font-extrabold text-white tracking-wider flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-emerald-400" />
                      A- Earnings Summary (This Period)
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase font-bold">Auto-calculated</span>
                  </div>
                  
                  <div className="space-y-2.5 text-xs text-gray-300">
                    <div className="flex items-center justify-between p-2 rounded bg-gray-900/40 border border-gray-800/40">
                      <span className="text-gray-400">Basic Rate (This Pay Period)</span>
                      <div className="font-mono text-white flex items-center gap-2">
                        <span>$ {editForm.basicSalary.toFixed(2)}</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Qty: 1)</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-2 rounded bg-gray-900/40 border border-gray-800/40">
                      <span className="text-gray-400">Overtime Allowance ({editForm.otHours} hrs @ {editForm.otRate}x)</span>
                      <div className="font-mono text-white flex items-center gap-2">
                        <span className="text-emerald-400 font-bold">$ {editForm.otPay.toFixed(2)}</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Rate: ${editForm.otRate > 0 ? (editForm.basicSalary / 228 * editForm.otRate).toFixed(2) : '4.88'})</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded bg-gray-900/40 border border-gray-800/40">
                      <span className="text-gray-400">Monthly Housing Allowance</span>
                      <div className="font-mono text-white flex items-center gap-2">
                        <span>$ {editForm.allowanceHousing.toFixed(2)}</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Qty: 1)</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded bg-gray-900/40 border border-gray-800/40">
                      <span className="text-gray-400">Daily Transport Allowance (Sum of Daily Charges)</span>
                      <div className="font-mono text-blue-400 font-semibold flex items-center gap-2">
                        <span>$ {editForm.allowanceTransport.toFixed(2)}</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Linked to Timesheet)</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded bg-gray-900/40 border border-gray-800/40">
                      <span className="text-gray-400">Hand Phone Allowance</span>
                      <div className="font-mono text-white flex items-center gap-2">
                        <span>$ 11.67</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Qty: 1)</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded bg-rose-500/5 border border-rose-500/10">
                      <span className="text-rose-400">Monthly With-Hold Amount ($100/Mth)</span>
                      <div className="font-mono text-rose-400 flex items-center gap-2 font-semibold">
                        <span>-$ 100.00</span>
                        <span className="text-[10px] text-gray-500 font-sans">(Qty: 1)</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-800 flex items-center justify-between text-sm font-bold text-white">
                    <span>GROSS PAY (A):</span>
                    <span className="font-mono text-base text-emerald-400">${editForm.grossSalary.toFixed(2)}</span>
                  </div>
                </div>

                {/* Deductions (B) & Other Info Panel */}
                <div className="bg-slate-950 p-5 rounded-xl border border-gray-800/80 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-4">
                      <span className="text-xs uppercase font-extrabold text-white tracking-wider flex items-center gap-1.5">
                        <CreditCard className="w-4 h-4 text-rose-400" />
                        B- Deductions & Overheads
                      </span>
                      <span className="text-[10px] text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2 py-0.5 rounded uppercase font-bold">Configurable</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3.5 text-xs text-gray-300">
                      <div>
                        <span className="text-[10px] text-gray-400 block mb-1 uppercase tracking-wide">Dorm Fee Deduction ($)</span>
                        <input 
                          type="number"
                          value={editForm.deductionDorm}
                          onChange={(e) => handleFieldChange('deductionDorm', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-900 border border-gray-800 focus:border-rose-500 rounded p-2 font-mono text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-gray-400 block mb-1 uppercase tracking-wide">Salary Advance / Loan ($)</span>
                        <input 
                          type="number"
                          value={editForm.deductionAdvance}
                          onChange={(e) => handleFieldChange('deductionAdvance', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-900 border border-gray-800 focus:border-rose-500 rounded p-2 font-mono text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-gray-400 block mb-1 uppercase tracking-wide">Unpaid Leave Deduction ($)</span>
                        <input 
                          type="number"
                          value={editForm.deductionUnpaidLeave}
                          onChange={(e) => handleFieldChange('deductionUnpaidLeave', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-900 border border-gray-800 focus:border-rose-500 rounded p-2 font-mono text-xs text-white"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-gray-400 block mb-1 uppercase tracking-wide">Other Deductions ($)</span>
                        <input 
                          type="number"
                          value={editForm.deductionOther}
                          onChange={(e) => handleFieldChange('deductionOther', parseFloat(e.target.value) || 0)}
                          className="w-full bg-gray-900 border border-gray-800 focus:border-rose-500 rounded p-2 font-mono text-xs text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-gray-800">
                    <div className="flex items-center justify-between text-base font-black text-emerald-400">
                      <span className="uppercase tracking-wider">Net Payable Amount (A - B):</span>
                      <span className="font-mono text-lg">${editForm.netPayable.toFixed(2)}</span>
                    </div>
                    <p className="text-[10px] text-gray-500 mt-1 font-medium italic text-right">
                      Corresponds to bank giro batch disbursement and final worker voucher payout.
                    </p>
                  </div>
                </div>

              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => generateTimesheetPDF(editForm)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow transition-all"
                title="Download a beautiful high-fidelity timesheet PDF voucher"
              >
                <Download className="w-4 h-4" />
                Download Time Sheet/Salary Voucher PDF
              </button>
              
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsTimesheetModalOpen(false)}
                  className="bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-bold px-4 py-2 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={saveTimesheet}
                  className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 py-2 rounded-lg flex items-center gap-1.5 shadow transition-all"
                >
                  <Save className="w-3.5 h-3.5" />
                  Save & Sync to Payroll Register
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
