import React from 'react';
import { UserPlus, ShieldCheck, Globe, BookOpen } from 'lucide-react';

export default function OrientationAccessPanel() {
  return (
    <div className="p-6 bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <UserPlus className="w-6 h-6 text-blue-400" />
        New Staff Orientation & Global Access
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-800 p-4 rounded-md border border-gray-700">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-green-400" />
            Orientation Process
          </h3>
          <ul className="text-gray-300 space-y-2 list-disc list-inside">
            <li>Welcome & Company Policy Review</li>
            <li>Tooling Setup & Training</li>
            <li>Departmental Onboarding</li>
            <li>Buddy System Assignment</li>
          </ul>
        </div>

        <div className="bg-gray-800 p-4 rounded-md border border-gray-700">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Globe className="w-5 h-5 text-blue-400" />
            Global Access Provisioning
          </h3>
          <ul className="text-gray-300 space-y-2 list-disc list-inside">
            <li>Identity & Access Management (IAM)</li>
            <li>Secure VPN/Remote Work Setup</li>
            <li>Email & System Credentials</li>
            <li>Cloud Application Permissions</li>
          </ul>
        </div>
      </div>
      
      <div className="mt-6 flex justify-end">
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-semibold transition">
          Initiate Onboarding Workflow
        </button>
      </div>
    </div>
  );
}
