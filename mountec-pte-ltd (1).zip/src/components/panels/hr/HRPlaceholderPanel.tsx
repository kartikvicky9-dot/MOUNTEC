import React from 'react';

export default function HRPlaceholderPanel({ title }: { title: string }) {
  return (
    <div className="bg-gray-800 p-8 rounded-lg shadow-md border border-gray-700 text-white">
      <h3 className="text-xl font-bold mb-4">{title}</h3>
      <p className="text-gray-400">Content for {title} is under development.</p>
    </div>
  );
}
