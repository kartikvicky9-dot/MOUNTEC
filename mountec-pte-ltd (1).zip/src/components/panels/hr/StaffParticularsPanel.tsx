import React, { useState, useEffect, useRef } from 'react';
import FileUploadButton from '../../FileUploadButton';
import documentUtils from '../../../lib/documentUtils';
import { collection, query, onSnapshot, addDoc, updateDoc, deleteDoc, doc, writeBatch, getDocs, where } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { FileSpreadsheet, Loader2, RefreshCw, Trash2, Edit2, Plus, X, Save, Database, ArrowUp, ArrowDown, UserPlus, Calendar, Keyboard, AlertCircle } from 'lucide-react';
import { Worker } from '../../../types';
import { initialWorkers } from '../../../data/workers';
import { useAppContext } from '../../../context/AppContext';

// Date utilities to support native date pickers while preserving DD-MMM-YYYY format in database
const parseDateToForm = (dateStr: string | undefined): string => {
  if (!dateStr) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return dateStr;
  
  const parts = dateStr.split(/[-/ ]+/);
  if (parts.length !== 3) return '';
  
  let day = parseInt(parts[0], 10);
  let monthStr = parts[1].toLowerCase();
  let year = parseInt(parts[2], 10);
  
  if (isNaN(day) || isNaN(year)) return '';
  
  if (year < 100) {
    year = year > 50 ? 1900 + year : 2000 + year;
  }
  
  const months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
  let monthIdx = months.findIndex(m => monthStr.startsWith(m));
  
  if (monthIdx === -1) {
    const parsedMonth = parseInt(monthStr, 10);
    if (!isNaN(parsedMonth) && parsedMonth >= 1 && parsedMonth <= 12) {
      monthIdx = parsedMonth - 1;
    }
  }
  
  if (monthIdx === -1) return '';
  
  const dd = String(day).padStart(2, '0');
  const mm = String(monthIdx + 1).padStart(2, '0');
  const yyyy = String(year);
  
  return `${yyyy}-${mm}-${dd}`;
};

const formatFormToDate = (formDateStr: string | undefined): string => {
  if (!formDateStr) return '';
  const parts = formDateStr.split('-');
  if (parts.length !== 3) return formDateStr;
  
  const year = parts[0];
  const monthIdx = parseInt(parts[1], 10) - 1;
  const dd = parts[2].padStart(2, '0');
  
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  if (monthIdx < 0 || monthIdx > 11) return formDateStr;
  
  return `${dd}-${months[monthIdx]}-${year}`;
};

export default function StaffParticularsPanel() {
  const { selectedEmployeeIdFor23, setSelectedEmployeeIdFor23, syncWorkerToRawData } = useAppContext();
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Worker>>({});
  const [sortKey, setSortKey] = useState<keyof Worker | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'LIVE' | 'PENDING ISSUANCE OF WP' | 'CANCELLED'>('ALL');

  const counts = React.useMemo(() => {
    const total = workers.length;
    const live = workers.filter(w => (w.wpsPassStatus || '').trim().toUpperCase() === 'LIVE').length;
    const pending = workers.filter(w => {
      const s = (w.wpsPassStatus || '').trim().toUpperCase();
      return s === 'PENDING ISSUANCE OF WP' || s === 'PENDING ISSUANCE';
    }).length;
    const cancelled = workers.filter(w => (w.wpsPassStatus || '').trim().toUpperCase() === 'CANCELLED').length;
    return { total, live, pending, cancelled };
  }, [workers]);

  // Track explicitly deleted employee IDs in this session to prevent them from auto-reappearing via self-healing
  const deletedEmployeeIds = useRef<Set<string>>(new Set());

  // Custom dialog/alert/confirm states
  const [dialogConfig, setDialogConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    type: 'alert' | 'confirm_delete' | 'confirm_rejoin';
    onConfirm?: () => void;
    confirmText?: string;
    cancelText?: string;
  } | null>(null);

  const showCustomAlert = (message: string, title = "Notification") => {
    setDialogConfig({
      isOpen: true,
      title,
      message,
      type: 'alert',
      confirmText: 'OK'
    });
  };

  // Load local workers from localStorage as a double-persistence layer
  const getLocalWorkers = (): Worker[] => {
    try {
      const stored = localStorage.getItem('mountec_local_workers');
      if (!stored) return [];
      const parsed = JSON.parse(stored) as Worker[];
      return parsed.map(w => {
        let status = (w.wpsPassStatus || 'LIVE').trim().toUpperCase();
        if (status === 'PENDING ISSUANCE') {
          status = 'PENDING ISSUANCE OF WP';
        }
        return {
          ...w,
          wpsPassStatus: status
        };
      });
    } catch (e) {
      console.warn('Failed to load local workers:', e);
      return [];
    }
  };

  const saveLocalWorkers = (localWorkers: Worker[]) => {
    try {
      const normalized = localWorkers.map(w => {
        let status = (w.wpsPassStatus || 'LIVE').trim().toUpperCase();
        if (status === 'PENDING ISSUANCE') {
          status = 'PENDING ISSUANCE OF WP';
        }
        return {
          ...w,
          wpsPassStatus: status
        };
      });
      localStorage.setItem('mountec_local_workers', JSON.stringify(normalized));
    } catch (e) {
      console.warn('Failed to save local workers:', e);
    }
  };

  // One-time asynchronous self-healing and cleanup of ME-029 on mount to prevent snapshot race conditions and duplicates
  useEffect(() => {
    const checkAndSeedMe029 = async () => {
      try {
        const isMe029Deleted = localStorage.getItem('mountec_me029_deleted') === 'true';
        if (isMe029Deleted) return;

        const q = query(collection(db, 'workers'), where('employeeId', '==', 'ME-029'));
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
          const me029Data = initialWorkers.find(w => w.employeeId === 'ME-029');
          if (me029Data) {
            const seededData = {
              ...me029Data,
              wpsPassStatus: (me029Data.wpsPassStatus || 'LIVE').trim().toUpperCase()
            };
            await addDoc(collection(db, 'workers'), seededData);
            console.log("Seeded missing worker ME-029 successfully.");
          }
        } else {
          // Only update/fill details of ME-029 if they are empty or finNo is blank
          const docs = snapshot.docs;
          const me029Data = initialWorkers.find(w => w.employeeId === 'ME-029');
          if (me029Data) {
            const mainDoc = docs[0];
            const mainData = mainDoc.data();
            
            if (!mainData.finNo || mainData.finNo === '') {
              const updatedData = {
                ...mainData,
                nameOfWorker: mainData.nameOfWorker || me029Data.nameOfWorker,
                nationality: mainData.nationality || me029Data.nationality,
                dateOfApplication: mainData.dateOfApplication || me029Data.dateOfApplication,
                dateOfEmployment: mainData.dateOfEmployment || me029Data.dateOfEmployment,
                wpsPassIssuanceDate: mainData.wpsPassIssuanceDate || me029Data.wpsPassIssuanceDate,
                dateOfBirth: mainData.dateOfBirth || me029Data.dateOfBirth,
                finNo: mainData.finNo || me029Data.finNo,
                wpsPassNo: mainData.wpsPassNo || me029Data.wpsPassNo,
                wpsPassExpiryDate: mainData.wpsPassExpiryDate || me029Data.wpsPassExpiryDate,
                passportNo: mainData.passportNo || me029Data.passportNo,
                passportExpiryDate: mainData.passportExpiryDate || me029Data.passportExpiryDate,
                passportIssuingCountry: mainData.passportIssuingCountry || me029Data.passportIssuingCountry,
                wpsPassStatus: (mainData.wpsPassStatus || me029Data.wpsPassStatus || 'LIVE').trim().toUpperCase()
              };
              await updateDoc(doc(db, 'workers', mainDoc.id), updatedData);
              console.log("Updated ME-029 empty fields in Firestore.");
            }
          }

          if (snapshot.size > 1) {
            // Clean up duplicate ME-029 documents from any previous race conditions! Keep the most complete / non-LIVE status one and delete the rest
            const sortedDocs = [...docs].sort((a, b) => {
              const aData = a.data();
              const bData = b.data();
              const aStatus = (aData.wpsPassStatus || '').trim().toUpperCase();
              const bStatus = (bData.wpsPassStatus || '').trim().toUpperCase();
              
              // Prefer non-LIVE status (e.g. CANCELLED or PENDING) because that means it was edited/changed by the user
              if (aStatus !== 'LIVE' && bStatus === 'LIVE') return -1;
              if (aStatus === 'LIVE' && bStatus !== 'LIVE') return 1;
              
              // Otherwise, prefer the one with more filled fields
              const aKeys = Object.keys(aData).filter(k => aData[k] !== '').length;
              const bKeys = Object.keys(bData).filter(k => bData[k] !== '').length;
              return bKeys - aKeys; // descending order
            });
            
            for (let i = 1; i < sortedDocs.length; i++) {
              await deleteDoc(doc(db, 'workers', sortedDocs[i].id));
              console.log(`Deleted duplicate ME-029 document: ${sortedDocs[i].id}`);
            }
          }
        }
      } catch (err) {
        console.warn("Failed to check/auto-seed ME-029:", err);
      }
    };

    checkAndSeedMe029();
  }, []);

  useEffect(() => {
    const qWorkers = query(collection(db, 'workers'));
    const unsubscribeWorkers = onSnapshot(qWorkers, (snapshot) => {
      const firestoreWorkers = snapshot.docs.map(doc => {
        const data = doc.data() as Worker;
        let status = (data.wpsPassStatus || 'LIVE').trim().toUpperCase();
        if (status === 'PENDING ISSUANCE') {
          status = 'PENDING ISSUANCE OF WP';
        }
        
        // Self-healing: If ME-001 Stint 1 is found in Firestore with LIVE status, correct it to CANCELLED
        if ((data.employeeId || '').trim().toUpperCase() === 'ME-001' && (data.sNo || '').trim() === '1' && status === 'LIVE') {
          console.log("Self-healing: Correcting ME-001 Stint 1 status in Firestore workers collection to CANCELLED...");
          updateDoc(doc.ref, {
            wpsPassStatus: 'Cancelled',
            exitDate: '07-Apr-2026',
            workDurationMonth: '3.81'
          }).catch(err => console.warn("Failed to auto-heal ME-001 Stint 1 in Firestore workers:", err));
          status = 'CANCELLED';
        }

        // General self-healing: Active workers (LIVE or PENDING) cannot have exit date or work duration month in Firestore
        const isLiveOrPending = ['LIVE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE'].includes(status);
        if (isLiveOrPending && (data.exitDate || data.workDurationMonth)) {
          console.log(`Self-healing: Clearing exitDate/duration for active worker ${data.employeeId || ''} in Firestore workers...`);
          updateDoc(doc.ref, {
            exitDate: '',
            workDurationMonth: ''
          }).catch(err => console.warn("Failed to auto-heal active worker in Firestore:", err));
          data.exitDate = '';
          data.workDurationMonth = '';
        }

        return {
          ...data,
          id: doc.id,
          wpsPassStatus: status
        } as Worker;
      });
      const localWorkers = getLocalWorkers();
      
      // Build lookup sets from firestore workers for ultra-robust filtering of spreadsheet copies
      const firestoreIds = new Set(firestoreWorkers.map(w => w.id));
      const firestoreSpreadsheetIds = new Set(
        firestoreWorkers.map(w => w.spreadsheetId).filter(Boolean) as string[]
      );
      
      // Map stint keys (employeeId-sNo) and name keys (nameOfWorker-sNo) using clean trimmed values
      const firestoreStintKeys = new Set(
        firestoreWorkers.map(w => {
          const empId = (w.employeeId || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return empId && sNo ? `${empId}-${sNo}` : '';
        }).filter(Boolean)
      );

      const firestoreNameKeys = new Set(
        firestoreWorkers.map(w => {
          const name = (w.nameOfWorker || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return name && sNo ? `${name}-${sNo}` : '';
        }).filter(Boolean)
      );

      const uniqueLocal = localWorkers.filter(w => {
        // 1. If Firestore already has this exact ID, skip local copy
        if (firestoreIds.has(w.id)) return false;
        
        // 2. If Firestore has a worker explicitly matching this spreadsheet ID, skip local copy
        if (w.id && firestoreSpreadsheetIds.has(w.id)) return false;
        
        // 3. Match by trimmed employeeId + sNo (stint key)
        const empId = (w.employeeId || '').trim().toUpperCase();
        const sNo = (w.sNo || '').trim().toUpperCase();
        if (empId && sNo) {
          const stintKey = `${empId}-${sNo}`;
          if (firestoreStintKeys.has(stintKey)) return false;
        }

        // 4. Match by trimmed nameOfWorker + sNo (name key)
        const name = (w.nameOfWorker || '').trim().toUpperCase();
        if (name && sNo) {
          const nameKey = `${name}-${sNo}`;
          if (firestoreNameKeys.has(nameKey)) return false;
        }

        return true;
      });

      setWorkers([...firestoreWorkers, ...uniqueLocal]);
    }, (error) => {
      console.error("Firestore onSnapshot error in StaffParticularsPanel:", error);
      // Fallback to local workers if Firestore connection fails or is restricted
      setWorkers(getLocalWorkers());
    });

    return () => {
      unsubscribeWorkers();
    };
  }, []);

  const sortedWorkers = React.useMemo(() => {
    return [...workers].sort((a, b) => {
      if (sortKey) {
        const aVal = a[sortKey] ?? '';
        const bVal = b[sortKey] ?? '';

        if (sortKey === 'sNo') {
          const aNum = parseInt(aVal as string) || 0;
          const bNum = parseInt(bVal as string) || 0;
          return sortDirection === 'asc' ? aNum - bNum : bNum - aNum;
        }

        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      }
      
      // Default sort by S/No
      const aNum = parseInt(a.sNo || '') || 0;
      const bNum = parseInt(b.sNo || '') || 0;
      return aNum - bNum;
    });
  }, [workers, sortKey, sortDirection]);

  const filteredSortedWorkers = React.useMemo(() => {
    let list = sortedWorkers;
    if (selectedEmployeeIdFor23) {
      const cleanTarget = selectedEmployeeIdFor23.toLowerCase().trim();
      list = list.filter(w => 
        (w.employeeId || '').toLowerCase().trim() === cleanTarget ||
        (w.nameOfWorker || w.name || '').toLowerCase().trim().includes(cleanTarget) ||
        (w.finNo || '').toLowerCase().trim() === cleanTarget ||
        (w.wpsPassNo || '').toLowerCase().trim() === cleanTarget
      );
    }
    if (statusFilter !== 'ALL') {
      list = list.filter(w => {
        const s = (w.wpsPassStatus || '').trim().toUpperCase();
        if (statusFilter === 'PENDING ISSUANCE OF WP') {
          return s === 'PENDING ISSUANCE OF WP' || s === 'PENDING ISSUANCE';
        }
        return s === statusFilter;
      });
    }
    return list;
  }, [sortedWorkers, selectedEmployeeIdFor23, statusFilter]);

  const handleSort = (key: keyof Worker) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDirection('asc');
    }
  };

  const SortIcon = ({ columnKey }: { columnKey: keyof Worker }) => {
    if (sortKey !== columnKey) return <div className="w-4" />;
    return sortDirection === 'asc' ? <ArrowUp className="w-3 h-3 inline" /> : <ArrowDown className="w-3 h-3 inline" />;
  };

  const getRowColor = (worker: Worker) => {
    const isTarget = selectedEmployeeIdFor23 && (
      (worker.employeeId || '').toLowerCase().trim() === selectedEmployeeIdFor23.toLowerCase().trim() ||
      (worker.nameOfWorker || worker.name || '').toLowerCase().trim().includes(selectedEmployeeIdFor23.toLowerCase().trim())
    );
    if (isTarget) return 'bg-blue-950/70 border-l-4 border-blue-500 hover:bg-blue-950/80 animate-pulse';

    const s = (worker.wpsPassStatus || '').trim().toUpperCase();
    if (s === 'LIVE') return 'bg-green-950/20 hover:bg-green-950/30';
    if (s === 'CANCELLED') return 'bg-red-950/20 hover:bg-red-950/30';
    if (s === 'PENDING ISSUANCE OF WP' || s === 'PENDING ISSUANCE') return 'bg-yellow-950/20 hover:bg-yellow-950/30';
    return 'hover:bg-[#181818]';
  };

  const getStatusTextColor = (status: string) => {
    const s = (status || '').trim().toUpperCase();
    if (s === 'LIVE') return 'text-green-400 font-bold';
    if (s === 'CANCELLED') return 'text-red-400 font-bold';
    if (s === 'PENDING ISSUANCE OF WP' || s === 'PENDING ISSUANCE') return 'text-yellow-400 font-bold';
    return 'text-white';
  };

  const getStintLabel = (worker: Worker) => {
    if (!worker.employeeId) return null;
    const sameEmpWorkers = workers.filter(w => w.employeeId && w.employeeId.trim().toUpperCase() === worker.employeeId.trim().toUpperCase());
    if (sameEmpWorkers.length <= 1) return null;
    
    // Sort sameEmpWorkers by sNo or dateOfEmployment or fallback ID to get chronological order
    const sorted = [...sameEmpWorkers].sort((a, b) => {
      const aNum = parseInt(a.sNo || '') || 0;
      const bNum = parseInt(b.sNo || '') || 0;
      if (aNum !== bNum) return aNum - bNum;
      return (a.id || '').localeCompare(b.id || '');
    });
    
    const index = sorted.findIndex(w => w.id === worker.id) + 1;
    return {
      index,
      total: sorted.length
    };
  };

  const handleRejoin = (worker: Worker) => {
    // Clone the worker details for a new stint
    const clonedForm: Partial<Worker> = {
      employeeId: worker.employeeId || '',
      nameOfWorker: worker.nameOfWorker || '',
      nationality: worker.nationality || '',
      dateOfBirth: worker.dateOfBirth || '',
      finNo: worker.finNo || '',
      passportNo: worker.passportNo || '',
      passportExpiryDate: worker.passportExpiryDate || '',
      passportIssuingCountry: worker.passportIssuingCountry || '',
      bankAccountNo: worker.bankAccountNo || '',
      bankName: worker.bankName || '',
      mobileNumber: worker.mobileNumber || '',
      emailId: worker.emailId || '',
      password: worker.password || '',
      wpsPassStatus: 'PENDING ISSUANCE OF WP', // Default to pending work permit since they are re-joining
      dateOfApplication: new Date().toLocaleDateString('en-GB').replace(/\//g, '-'), // Pre-fill with today in DD-MM-YYYY format
      dateOfEmployment: '',
      wpsPassIssuanceDate: '',
      wpsPassNo: '',
      wpsPassExpiryDate: '',
      exitDate: '',
      workDurationMonth: ''
    };
    setEditForm(clonedForm);
    setIsAdding(true);
    setEditingId(null); // Ensure we are adding a brand new record
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const executeAddWorker = async (empId: string) => {
    try {
      // Safe nextSNo calculation to prevent NaN issues
      const nextSNo = (Math.max(0, ...workers.map(w => {
        const num = parseInt(w.sNo || '');
        return isNaN(num) ? 0 : num;
      })) + 1).toString();
      
      // Clean/sanitize editForm data to strip any undefined values that crash Firestore, and strip 'id' key
      const sanitizedForm: any = {};
      Object.keys(editForm).forEach(key => {
        if (key === 'id') return; // Never save 'id' field to document body
        let val = editForm[key as keyof Worker];
        if (typeof val === 'string') {
          val = val.trim();
        }
        if (val !== undefined && val !== null) {
          sanitizedForm[key] = val;
        }
      });

      const tempId = 'local-' + Date.now();
      const newWorkerData = { 
        ...sanitizedForm, 
        sNo: nextSNo,
        employeeId: empId.trim(),
        wpsPassStatus: (editForm.wpsPassStatus || 'LIVE').trim().toUpperCase()
      };
      
      const newWorker: Worker = { id: tempId, ...newWorkerData };

      // Sync to the master spreadsheet
      if (syncWorkerToRawData) {
        syncWorkerToRawData(newWorker, 'add');
      }

      // 1. Save to LocalStorage immediately (instant & highly reliable)
      const localWorkers = getLocalWorkers();
      saveLocalWorkers([...localWorkers.filter(w => w.id !== tempId), newWorker]);
      
      // 2. Clear and close add form immediately for premium UX responsiveness
      setEditForm({});
      setIsAdding(false);
      
      // 3. Update component state instantly
      setWorkers(prev => {
        const hasWorker = prev.some(w => w.id === tempId);
        if (!hasWorker) {
          return [...prev, newWorker];
        }
        return prev;
      });

      // 4. Asynchronously attempt to save to Firestore in the background
      (async () => {
        try {
          const docRef = await addDoc(collection(db, 'workers'), newWorkerData);
          const realId = docRef.id;
          
          // Swap local tempId with real Firestore ID in localStorage
          const currentLocal = getLocalWorkers();
          const updatedLocal = currentLocal.map(w => {
            if (w.id === tempId) {
              return { ...w, id: realId };
            }
            return w;
          });
          saveLocalWorkers(updatedLocal);

          // Update local state ID
          setWorkers(prev => prev.map(w => {
            if (w.id === tempId) {
              return { ...w, id: realId };
            }
            return w;
          }));
        } catch (fsError) {
          console.warn("Background Firestore add failed, keeping as local record:", fsError);
        }
      })();

    } catch (error) {
      console.error("Error adding worker: ", error);
      showCustomAlert("Failed to add worker. Check console for details.", "Error");
    }
  };

  const handleAdd = async () => {
    try {
      if (!editForm.nameOfWorker?.trim()) {
        showCustomAlert("Please enter the worker's full name.", "Required Field");
        return;
      }

      const empId = editForm.employeeId?.trim() || '';
      if (empId) {
        const activeStints = workers.filter(w => w.employeeId?.trim().toUpperCase() === empId.toUpperCase() && w.wpsPassStatus !== 'CANCELLED');
        if (activeStints.length > 0) {
          setDialogConfig({
            isOpen: true,
            title: "Worker Already Active",
            message: `An active or pending worker with Employee ID "${empId}" already exists. Do you want to create a new period/stint for this Employee ID (e.g. for re-joined staff)?`,
            type: 'confirm_rejoin',
            confirmText: 'Create New Period/Stint',
            cancelText: 'Cancel',
            onConfirm: () => {
              executeAddWorker(empId);
            }
          });
          return;
        }
      }

      executeAddWorker(empId);
    } catch (error) {
      console.error("Error in handleAdd:", error);
    }
  };

  const calculateDuration = (empDateStr: string | undefined, exitDateStr: string | undefined): string => {
    if (!empDateStr || !exitDateStr) return '';
    const parseDate = (dateStr: string) => {
      if (!dateStr) return null;
      const cleanStr = dateStr.trim();
      
      // Check for YYYY-MM-DD
      if (/^\d{4}-\d{2}-\d{2}$/.test(cleanStr)) {
        const d = new Date(cleanStr);
        if (!isNaN(d.getTime())) return d;
      }

      // Split by any punctuation/whitespace
      const parts = cleanStr.split(/[-/ ]+/);
      if (parts.length !== 3) return null;

      let day = parseInt(parts[0], 10);
      let monthStr = parts[1];
      let year = parseInt(parts[2], 10);

      // If year is first (YYYY-MM-DD but split)
      if (parts[0].length === 4) {
        year = parseInt(parts[0], 10);
        monthStr = parts[1];
        day = parseInt(parts[2], 10);
      }

      if (isNaN(day) || isNaN(year)) return null;

      if (year < 100) {
        year = year > 50 ? 1900 + year : 2000 + year;
      }

      const months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
      let monthIndex = months.findIndex(m => monthStr.toLowerCase().startsWith(m));

      if (monthIndex === -1) {
        // Handle numeric month
        const parsedMonth = parseInt(monthStr, 10);
        if (!isNaN(parsedMonth) && parsedMonth >= 1 && parsedMonth <= 12) {
          monthIndex = parsedMonth - 1;
        }
      }

      if (monthIndex === -1) return null;

      const d = new Date(year, monthIndex, day);
      if (isNaN(d.getTime())) return null;
      return d;
    };
    
    const empDate = parseDate(empDateStr);
    const exitDate = parseDate(exitDateStr);
    
    if (!empDate || !exitDate || isNaN(empDate.getTime()) || isNaN(exitDate.getTime())) return '';
    
    const diffTime = exitDate.getTime() - empDate.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    const months = (diffDays / 30.44).toFixed(2);
    return months;
  };

  // Reactive hook to automatically compute and show duration in the edit form, and clear exit date/duration for active status
  useEffect(() => {
    const status = (editForm.wpsPassStatus || '').trim().toUpperCase();
    const isLiveOrPending = ['LIVE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE'].includes(status);
    
    if (isLiveOrPending) {
      if (editForm.exitDate !== '' || editForm.workDurationMonth !== '') {
        setEditForm(prev => ({
          ...prev,
          exitDate: '',
          workDurationMonth: ''
        }));
      }
      return;
    }

    const empDate = editForm.dateOfEmployment;
    const exitDate = editForm.exitDate;
    if (empDate && exitDate) {
      const duration = calculateDuration(empDate, exitDate);
      if (duration !== editForm.workDurationMonth) {
        setEditForm(prev => ({ ...prev, workDurationMonth: duration }));
      }
    } else {
      if (editForm.workDurationMonth) {
        setEditForm(prev => ({ ...prev, workDurationMonth: '' }));
      }
    }
  }, [editForm.dateOfEmployment, editForm.exitDate, editForm.workDurationMonth, editForm.wpsPassStatus]);

  const handleFormChange = (key: keyof Worker, value: string) => {
    setEditForm(prev => {
      const updated = { ...prev, [key]: value };
      if (key === 'wpsPassStatus' && value.trim().toUpperCase() === 'PENDING ISSUANCE OF WP') {
        updated.wpsPassIssuanceDate = '';
      }
      return updated;
    });
  };

  const handleUpdate = async (id: string, shouldClose: boolean = true) => {
    try {
      const status = (editForm.wpsPassStatus || 'LIVE').trim().toUpperCase();
      const isLiveOrPending = ['LIVE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE'].includes(status);

      // Clean/sanitize editForm data to strip any undefined values that crash Firestore, and strip 'id' key
      const sanitizedForm: any = {};
      Object.keys(editForm).forEach(key => {
        if (key === 'id') return; // Never save 'id' field to document body
        let val = editForm[key as keyof Worker];
        if (typeof val === 'string') {
          val = val.trim();
        }
        if (val !== undefined && val !== null) {
          sanitizedForm[key] = val;
        }
      });

      if (isLiveOrPending) {
        sanitizedForm.exitDate = '';
        sanitizedForm.workDurationMonth = '';
      }

      const updatedWorkerData = {
        ...sanitizedForm,
        wpsPassStatus: status,
        ...(id.startsWith('w-') ? { spreadsheetId: id } : {})
      };
      
      // Sync to the master spreadsheet
      if (syncWorkerToRawData) {
        syncWorkerToRawData({ id, ...updatedWorkerData } as Worker, 'update');
      }

      // 1. Update LocalStorage immediately
      const localWorkers = getLocalWorkers();
      const updatedLocal = localWorkers.map(w => {
        if (w.id === id) {
          return { ...w, ...updatedWorkerData };
        }
        return w;
      });
      
      const existsInLocal = localWorkers.some(w => w.id === id);
      if (!existsInLocal) {
        updatedLocal.push({ id, ...updatedWorkerData } as Worker);
      }
      
      saveLocalWorkers(updatedLocal);
      
      // 2. Update state immediately
      setWorkers(prev => prev.map(w => {
        if (w.id === id) {
          return { ...w, ...updatedWorkerData };
        }
        return w;
      }));
      
      if (shouldClose) {
        setEditingId(null);
        setEditForm({});
      }

      // 3. Asynchronously attempt to save to Firestore in the background
      (async () => {
        try {
          if (id.startsWith('local-')) {
            // If it was a local worker, try to create it in Firestore now
            const docRef = await addDoc(collection(db, 'workers'), updatedWorkerData);
            const realId = docRef.id;
            
            // Swap ID in local storage
            const currentLocal = getLocalWorkers();
            const reUpdatedLocal = currentLocal.map(w => {
              if (w.id === id) {
                return { ...w, id: realId };
              }
              return w;
            });
            saveLocalWorkers(reUpdatedLocal);

            // Swap ID in state
            setWorkers(prev => prev.map(w => {
              if (w.id === id) {
                return { ...w, id: realId };
              }
              return w;
            }));
          } else if (id.startsWith('w-')) {
            // Spreadsheet worker being updated.
            // Search Firestore workers collection for matching employeeId + sNo (stint) to see if we already have a document for them.
            const empId = (updatedWorkerData.employeeId || '').trim();
            const sNo = (updatedWorkerData.sNo || '').trim();
            const q = query(collection(db, 'workers'), where('employeeId', '==', empId));
            const qSnapshot = await getDocs(q);
            
            // If we also have a stint number (sNo), narrow down or verify
            let targetDocId = null;
            if (!qSnapshot.empty) {
              const matchedDoc = qSnapshot.docs.find(d => {
                const data = d.data();
                return String(data.sNo || '').trim() === String(sNo);
              }) || qSnapshot.docs[0]; // fallback to first match
              targetDocId = matchedDoc.id;
            }
            
            if (targetDocId) {
              // Update the existing document
              await updateDoc(doc(db, 'workers', targetDocId), {
                ...updatedWorkerData,
                spreadsheetId: id
              });
              console.log(`Successfully updated existing Firestore worker document ${targetDocId} for ${empId}`);
            } else {
              // Create a brand new document in Firestore workers collection so they are permanently stored and visible to all panels
              const docRef = await addDoc(collection(db, 'workers'), {
                ...updatedWorkerData,
                spreadsheetId: id
              });
              console.log(`Created new Firestore worker document ${docRef.id} for spreadsheet worker ${empId}`);
            }
          } else {
            // Standard update for an existing Firestore worker document
            await updateDoc(doc(db, 'workers', id), updatedWorkerData);
          }
        } catch (fsError) {
          console.warn("Background Firestore update failed, relying on local sync:", fsError);
        }
      })();

    } catch (error) {
      console.error("Error updating worker:", error);
    }
  };

  useEffect(() => {
    if (editingId && editForm && Object.keys(editForm).length > 0) {
      const handler = setTimeout(() => {
        handleUpdate(editingId, false);
      }, 1000); // 1 second debounce
      
      return () => clearTimeout(handler);
    }
  }, [editForm, editingId]);

  const handleDelete = async (id: string, name: string) => {
    setDialogConfig({
      isOpen: true,
      title: "Confirm Deletion",
      message: `Are you sure you want to delete the worker record for "${name || 'Unnamed Worker'}"? This action cannot be undone.`,
      type: 'confirm_delete',
      confirmText: 'Delete Record',
      cancelText: 'Cancel',
      onConfirm: async () => {
        try {
          const workerToDelete = workers.find(w => w.id === id);
          if (workerToDelete && workerToDelete.employeeId) {
            const empIdUpper = workerToDelete.employeeId.trim().toUpperCase();
            deletedEmployeeIds.current.add(empIdUpper);
            if (empIdUpper === 'ME-029') {
              localStorage.setItem('mountec_me029_deleted', 'true');
            }
          }

          // Sync to the master spreadsheet
          if (workerToDelete && syncWorkerToRawData) {
            syncWorkerToRawData(workerToDelete, 'delete');
          }

          // 1. Delete from Firestore
          if (!id.startsWith('local-')) {
            try {
              await deleteDoc(doc(db, 'workers', id));
            } catch (fsError) {
              console.warn("Firestore delete failed:", fsError);
            }
          }
          
          // 2. Delete from LocalStorage (also cleanup any stale/temp versions of the same worker)
          const localWorkers = getLocalWorkers();
          const updatedLocal = localWorkers.filter(w => {
            if (w.id === id) return false;
            if (workerToDelete) {
              if (w.id.startsWith('local-')) {
                if (workerToDelete.employeeId && w.employeeId === workerToDelete.employeeId) return false;
                if (workerToDelete.nameOfWorker && w.nameOfWorker === workerToDelete.nameOfWorker) return false;
              }
            }
            return true;
          });
          saveLocalWorkers(updatedLocal);
          
          // 3. Update state immediately
          setWorkers(prev => prev.filter(w => w.id !== id));
        } catch (error) {
          console.error("Error deleting worker:", error);
        }
      }
    });
  };

  const seedData = async () => {
    const existingStints = new Set(workers.map(w => `${w.employeeId || ''}-${w.sNo || ''}`.trim().toUpperCase()));
    const batch = writeBatch(db);
    const workersCollection = collection(db, 'workers');
    let addedCount = 0;
    
    // Use a local set to prevent adding duplicate rows in the same batch run
    const addedInBatch = new Set<string>();
    
    for (const worker of initialWorkers) {
      const stintKey = `${worker.employeeId || ''}-${worker.sNo || ''}`.trim().toUpperCase();
      if (!existingStints.has(stintKey) && !addedInBatch.has(stintKey)) {
        const docRef = doc(workersCollection);
        batch.set(docRef, worker);
        addedInBatch.add(stintKey);
        addedCount++;
      }
    }
    
    if (addedCount > 0) {
      await batch.commit();
      showCustomAlert(`${addedCount} workers seeded successfully!`, "Success");
    } else {
      showCustomAlert('No new workers to seed.', "Information");
    }
  };

  const renderForm = () => (
    <div className="bg-[#181818] p-6 rounded-xl border border-[#333] mb-6 shadow-2xl">
      <h5 className="text-sm font-bold text-white mb-5 uppercase tracking-wider border-b border-[#333] pb-3">{editingId ? 'Edit Staff/Worker' : 'Add New Staff/Worker'}</h5>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-5">
        {[
          { key: 'employeeId', label: 'Employee ID' },
          { key: 'nameOfWorker', label: 'Name' },
          { key: 'nationality', label: 'Nationality' },
          { key: 'dateOfApplication', label: 'DATE OF APPLICATION' },
          { key: 'dateOfEmployment', label: 'Date Emp.' },
          { key: 'wpsPassIssuanceDate', label: 'WP Issue Date' },
          { key: 'dateOfBirth', label: 'DOB' },
          { key: 'finNo', label: 'NRIC/FIN No.' },
          { key: 'wpsPassNo', label: 'WP Pass No.' },
          { key: 'wpsPassExpiryDate', label: 'WP Pass Exp.' },
          { key: 'passportNo', label: 'Passport No.' },
          { key: 'passportExpiryDate', label: 'Passport Exp.' },
          { key: 'passportIssuingCountry', label: 'Pass Country' },
          { key: 'wpsPassStatus', label: 'WP Status' },
          { key: 'bankAccountNo', label: 'Bank Acc.' },
          { key: 'bankName', label: 'Bank Name' },
          { key: 'mobileNumber', label: 'Mobile' },
          { key: 'emailId', label: 'Email' },
          { key: 'password', label: 'Password' },
          { key: 'exitDate', label: 'Exit Date' },
          { key: 'workDurationMonth', label: 'Duration' },
        ].map(field => {
          const isDateField = [
            'dateOfApplication',
            'dateOfEmployment',
            'wpsPassIssuanceDate',
            'dateOfBirth',
            'wpsPassExpiryDate',
            'passportExpiryDate',
            'exitDate'
          ].includes(field.key);

          return (
            <div key={field.key} className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center h-4">
                <label className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">{field.label}</label>
              </div>
              {field.key === 'wpsPassStatus' ? (
                <select
                  className={`w-full bg-[#111] border border-[#333] px-3 py-2 text-xs rounded focus:outline-none focus:border-blue-500 h-9 font-bold ${
                    (editForm[field.key as keyof Worker] || 'LIVE').trim().toUpperCase() === 'LIVE' ? 'text-green-400' :
                    (editForm[field.key as keyof Worker] || 'LIVE').trim().toUpperCase() === 'CANCELLED' ? 'text-red-400' :
                    (editForm[field.key as keyof Worker] || 'LIVE').trim().toUpperCase() === 'PENDING ISSUANCE OF WP' ? 'text-yellow-400' :
                    'text-white'
                  }`}
                  value={editForm[field.key as keyof Worker] || 'LIVE'}
                  onChange={e => handleFormChange(field.key as keyof Worker, e.target.value)}
                >
                  <option value="LIVE" className="text-green-400 bg-[#111] font-bold">LIVE</option>
                  <option value="CANCELLED" className="text-red-400 bg-[#111] font-bold">CANCELLED</option>
                  <option value="PENDING ISSUANCE OF WP" className="text-yellow-400 bg-[#111] font-bold">PENDING ISSUANCE OF WP</option>
                </select>
              ) : isDateField ? (
                (() => {
                  const status = (editForm.wpsPassStatus || '').trim().toUpperCase();
                  const isLiveOrPending = ['LIVE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE'].includes(status);
                  const isPendingWP = status === 'PENDING ISSUANCE OF WP';
                  
                  const isWPFieldDisabled = field.key === 'wpsPassIssuanceDate' && isPendingWP;
                  const isExitDateDisabled = field.key === 'exitDate' && isLiveOrPending;
                  const isDisabled = isWPFieldDisabled || isExitDateDisabled;
                  
                  return (
                    <div className="relative flex items-center h-9">
                      <input 
                        type="text" 
                        className={`w-full bg-[#111] border border-[#333] pl-3 pr-10 py-2 text-white text-xs rounded focus:outline-none h-9 ${
                          isDisabled 
                            ? 'opacity-50 bg-black/45 cursor-not-allowed text-gray-500 border-dashed focus:border-[#333]' 
                            : 'focus:border-blue-500'
                        }`}
                        placeholder={
                          isWPFieldDisabled 
                            ? "Blank (Pending WP)" 
                            : isExitDateDisabled 
                            ? "Blank (Active Worker)" 
                            : "e.g. 12-Nov-2025"
                        }
                        value={isDisabled ? '' : (editForm[field.key as keyof Worker] || '')}
                        disabled={isDisabled}
                        onChange={e => handleFormChange(field.key as keyof Worker, e.target.value)}
                      />
                      <div className="absolute right-2 flex items-center justify-center w-6 h-6">
                        <input 
                          type="date"
                          className={`absolute opacity-0 w-6 h-6 ${isDisabled ? 'cursor-not-allowed pointer-events-none' : 'cursor-pointer'}`}
                          value={isDisabled ? '' : parseDateToForm(editForm[field.key as keyof Worker])}
                          disabled={isDisabled}
                          onChange={e => {
                            if (e.target.value) {
                              handleFormChange(field.key as keyof Worker, formatFormToDate(e.target.value));
                            }
                          }}
                        />
                        <Calendar className={`w-4 h-4 pointer-events-none ${isDisabled ? 'text-gray-600' : 'text-gray-400'}`} />
                      </div>
                    </div>
                  );
                })()
              ) : (
                <input 
                  type="text" 
                  className={`w-full bg-[#111] border border-[#333] px-3 py-2 text-white text-xs rounded focus:outline-none focus:border-blue-500 h-9 ${
                    field.key === 'workDurationMonth' || (field.key === 'exitDate' && ['LIVE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE'].includes((editForm.wpsPassStatus || '').trim().toUpperCase()))
                      ? 'opacity-70 bg-black/40 cursor-not-allowed font-bold text-yellow-400' 
                      : ''
                  }`}
                  value={editForm[field.key as keyof Worker] || ''}
                  placeholder={field.key === 'workDurationMonth' ? 'Auto-calculated' : ''}
                  readOnly={field.key === 'workDurationMonth'}
                  onChange={e => handleFormChange(field.key as keyof Worker, e.target.value)}
                />
              )}
            </div>
          );
        })}
      </div>
      <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-[#333]">
        <button type="button" onClick={() => { setIsAdding(false); setEditingId(null); setEditForm({}); }} className="px-5 py-2.5 bg-[#222] text-white rounded text-xs font-bold uppercase tracking-wider hover:bg-[#333] transition-colors">Cancel</button>
        <button type="button" onClick={() => editingId ? handleUpdate(editingId) : handleAdd()} className="px-5 py-2.5 bg-blue-600 text-white rounded text-xs font-bold uppercase tracking-wider hover:bg-blue-500 transition-colors">Save Details</button>
      </div>
    </div>
  );

  return (
    <div className="p-4 text-white">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold uppercase tracking-wider">STAFF PARTICULARS & INFORMATIONS</h3>
        <FileUploadButton onUpload={(file, displayName) => documentUtils.uploadDocument('staff_particulars', file, displayName)} />
      </div>

      {(isAdding || editingId) && renderForm()}

      <div className="border border-[#222] bg-[#141414] rounded-xl p-5 shadow-xl">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider">Live Tabulation (Managed)</h4>
          <div className="flex gap-2">
            <button 
              type="button" 
              onClick={seedData} 
              className="relative z-10 flex items-center gap-1.5 px-4 py-2 bg-gray-700 rounded text-xs font-bold uppercase tracking-wider hover:bg-gray-600 transition-colors"
            >
              <Database className="w-4 h-4" /> Seed Data
            </button>
            <button type="button" onClick={() => setIsAdding(true)} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 rounded text-xs font-bold uppercase tracking-wider hover:bg-blue-500">
              <Plus className="w-3.5 h-3.5" /> Add Staff/Worker
            </button>
          </div>
        </div>

        {/* Status Tabulation Categories */}
        <div className="flex flex-wrap gap-2 mb-5 border-b border-[#222] pb-4">
          <button
            type="button"
            onClick={() => setStatusFilter('ALL')}
            className={`px-3.5 py-2 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${
              statusFilter === 'ALL'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10'
                : 'bg-[#181818] text-gray-400 hover:text-white border border-[#222]'
            }`}
          >
            All Workers <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${statusFilter === 'ALL' ? 'bg-blue-700 text-white' : 'bg-[#2a2a2a] text-gray-400'}`}>{counts.total}</span>
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('LIVE')}
            className={`px-3.5 py-2 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${
              statusFilter === 'LIVE'
                ? 'bg-green-600 text-white shadow-lg shadow-green-500/10 border border-green-500/20'
                : 'bg-[#181818] text-gray-400 hover:text-white border border-[#222]'
            }`}
          >
            LIVE <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${statusFilter === 'LIVE' ? 'bg-green-700 text-white' : 'bg-[#2a2a2a] text-gray-400'}`}>{counts.live}</span>
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('PENDING ISSUANCE OF WP')}
            className={`px-3.5 py-2 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${
              statusFilter === 'PENDING ISSUANCE OF WP'
                ? 'bg-yellow-600 text-black shadow-lg shadow-yellow-500/10'
                : 'bg-[#181818] text-gray-400 hover:text-white border border-[#222]'
            }`}
          >
            PENDING ISSUANCE OF WP <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${statusFilter === 'PENDING ISSUANCE OF WP' ? 'bg-yellow-700 text-black' : 'bg-[#2a2a2a] text-gray-400'}`}>{counts.pending}</span>
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('CANCELLED')}
            className={`px-3.5 py-2 rounded-lg text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${
              statusFilter === 'CANCELLED'
                ? 'bg-red-600 text-white shadow-lg shadow-red-500/10 border border-red-500/20'
                : 'bg-[#181818] text-gray-400 hover:text-white border border-[#222]'
            }`}
          >
            CANCELLED <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${statusFilter === 'CANCELLED' ? 'bg-red-700 text-white' : 'bg-[#2a2a2a] text-gray-400'}`}>{counts.cancelled}</span>
          </button>
        </div>

        {selectedEmployeeIdFor23 && (
          <div className="mb-4 p-3 bg-blue-950/40 border border-blue-500/30 rounded-lg flex items-center justify-between animate-fade-in text-xs text-blue-300">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-blue-400" />
              <span>
                Showing master record linked from <strong>5.1.1.1 DAILY TOOLBOX MEETING</strong> for Employee / Name: <strong>{selectedEmployeeIdFor23}</strong>
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                if (setSelectedEmployeeIdFor23) {
                  setSelectedEmployeeIdFor23(null);
                }
              }}
              className="px-2.5 py-1 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded font-bold uppercase text-[10px] tracking-wider transition-colors"
            >
              Show All Workers
            </button>
          </div>
        )}

        <div className="overflow-x-auto border border-[#222] rounded-lg">
          <table className="w-full text-xs text-left text-gray-300">
            <thead className="bg-[#181818] border-b border-[#222] text-[#888] uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('sNo')}>S/No <SortIcon columnKey="sNo" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('employeeId')}>Employee ID <SortIcon columnKey="employeeId" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('nameOfWorker')}>FULL NAME <SortIcon columnKey="nameOfWorker" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('nationality')}>Nationality <SortIcon columnKey="nationality" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('dateOfApplication')}>DATE OF APPLICATION <SortIcon columnKey="dateOfApplication" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('dateOfEmployment')}>DATE OF EMPLOYMENT <SortIcon columnKey="dateOfEmployment" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('wpsPassIssuanceDate')}>DATE OF WORK PASS ISSUE <SortIcon columnKey="wpsPassIssuanceDate" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('dateOfBirth')}>DOB <SortIcon columnKey="dateOfBirth" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('finNo')}>NRIC/FIN NO. <SortIcon columnKey="finNo" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('wpsPassNo')}>WP/S Pass No. <SortIcon columnKey="wpsPassNo" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('wpsPassExpiryDate')}>WP/S Pass Exp. <SortIcon columnKey="wpsPassExpiryDate" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('passportNo')}>Passport No. <SortIcon columnKey="passportNo" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('passportExpiryDate')}>PASSPORT EXPIRY DATE <SortIcon columnKey="passportExpiryDate" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('passportIssuingCountry')}>PLACE OF ISSUE <SortIcon columnKey="passportIssuingCountry" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('wpsPassStatus')}>WP/S Status <SortIcon columnKey="wpsPassStatus" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('bankAccountNo')}>Bank Acc. <SortIcon columnKey="bankAccountNo" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('bankName')}>Bank Name <SortIcon columnKey="bankName" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('mobileNumber')}>Mobile <SortIcon columnKey="mobileNumber" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('emailId')}>Email <SortIcon columnKey="emailId" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('password')}>Password <SortIcon columnKey="password" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('exitDate')}>Exit Date <SortIcon columnKey="exitDate" /></th>
                <th className="px-4 py-3 cursor-pointer" onClick={() => handleSort('workDurationMonth')}>Duration <SortIcon columnKey="workDurationMonth" /></th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#222]">
              {filteredSortedWorkers.map((worker, index) => (
                <tr key={worker.id} className={`${getRowColor(worker)} transition-colors text-white whitespace-nowrap`}>
                  <td className="px-4 py-3">{index + 1}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col">
                      <span className="font-mono font-bold">{worker.employeeId}</span>
                      {(() => {
                        const stint = getStintLabel(worker);
                        if (stint) {
                          return (
                            <span className="inline-block mt-1 text-[9px] font-bold bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded uppercase tracking-wider w-max">
                              Stint {stint.index} of {stint.total}
                            </span>
                          );
                        }
                        return null;
                      })()}
                    </div>
                  </td>
                  <td className="px-4 py-3">{worker.nameOfWorker}</td>
                  <td className="px-4 py-3">{worker.nationality}</td>
                  <td className="px-4 py-3">{worker.dateOfApplication}</td>
                  <td className="px-4 py-3">{worker.dateOfEmployment}</td>
                  <td className="px-4 py-3">{worker.wpsPassIssuanceDate}</td>
                  <td className="px-4 py-3">{worker.dateOfBirth}</td>
                  <td className="px-4 py-3">{worker.finNo}</td>
                  <td className="px-4 py-3">{worker.wpsPassNo}</td>
                  <td className="px-4 py-3">{worker.wpsPassExpiryDate}</td>
                  <td className="px-4 py-3">{worker.passportNo}</td>
                  <td className="px-4 py-3">{worker.passportExpiryDate}</td>
                  <td className="px-4 py-3">{worker.passportIssuingCountry}</td>
                  <td className={`px-4 py-3 ${getStatusTextColor(worker.wpsPassStatus || '')}`}>{worker.wpsPassStatus}</td>
                  <td className="px-4 py-3">{worker.bankAccountNo}</td>
                  <td className="px-4 py-3">{worker.bankName}</td>
                  <td className="px-4 py-3">{worker.mobileNumber}</td>
                  <td className="px-4 py-3">{worker.emailId}</td>
                  <td className="px-4 py-3">{worker.password}</td>
                  <td className="px-4 py-3">{(worker.wpsPassStatus || '').toUpperCase() === 'CANCELLED' ? worker.exitDate : ''}</td>
                  <td className="px-4 py-3">{(worker.wpsPassStatus || '').toUpperCase() === 'CANCELLED' ? worker.workDurationMonth : ''}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-2">
                      <button type="button" onClick={() => { setEditingId(worker.id); setEditForm(worker); }} className="text-blue-400 hover:text-blue-300" title="Edit particulars"><Edit2 className="w-4 h-4" /></button>
                      
                      {(worker.wpsPassStatus || '').toUpperCase() === 'CANCELLED' && (
                        <button
                          type="button"
                          onClick={() => handleRejoin(worker)}
                          className="text-green-400 hover:text-green-300 flex items-center gap-0.5 px-1.5 py-0.5 bg-green-500/10 hover:bg-green-500/20 rounded border border-green-500/20 text-[10px] font-bold uppercase tracking-wider transition-colors"
                          title="Re-hire / Re-join worker for a new stint"
                        >
                          <UserPlus className="w-3.5 h-3.5" /> Re-hire
                        </button>
                      )}
                      
                      <button type="button" onClick={() => handleDelete(worker.id, worker.nameOfWorker || '')} className="text-red-400 hover:text-red-300" title="Delete record"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Custom Confirmation / Alert Dialog */}
      {dialogConfig && dialogConfig.isOpen && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in" id="custom-dialog-overlay">
          <div className="bg-[#141414] border border-[#2d2d2d] rounded-xl max-w-md w-full p-6 shadow-2xl animate-scale-in" id="custom-dialog-container">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-3 border-b border-[#2d2d2d] pb-2 flex items-center gap-2">
              {dialogConfig.type === 'confirm_delete' && <Trash2 className="w-4 h-4 text-red-500" />}
              {dialogConfig.type === 'confirm_rejoin' && <UserPlus className="w-4 h-4 text-green-500" />}
              {dialogConfig.type === 'alert' && <AlertCircle className="w-4 h-4 text-blue-500" />}
              {dialogConfig.title}
            </h4>
            <p className="text-gray-300 text-xs leading-relaxed mb-6">
              {dialogConfig.message}
            </p>
            <div className="flex justify-end items-center gap-3">
              {dialogConfig.type !== 'alert' && (
                <button
                  type="button"
                  onClick={() => setDialogConfig(null)}
                  className="px-4 py-2 bg-transparent hover:bg-white/5 border border-[#333] text-gray-300 hover:text-white rounded text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  {dialogConfig.cancelText || 'Cancel'}
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  if (dialogConfig.onConfirm) {
                    dialogConfig.onConfirm();
                  }
                  setDialogConfig(null);
                }}
                className={`px-4 py-2 rounded text-xs font-bold uppercase tracking-wider transition-colors ${
                  dialogConfig.type === 'confirm_delete' ? 'bg-red-600 hover:bg-red-500 text-white' :
                  dialogConfig.type === 'confirm_rejoin' ? 'bg-green-600 hover:bg-green-500 text-white' :
                  'bg-blue-600 hover:bg-blue-500 text-white'
                }`}
              >
                {dialogConfig.confirmText || 'OK'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
