import React, { useState, useEffect, useMemo } from 'react';
import { collection, query, onSnapshot, doc, setDoc, addDoc, updateDoc, getDocs, writeBatch, where } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { 
  Users, 
  Search, 
  Plus, 
  Save, 
  History, 
  DollarSign, 
  Calendar, 
  Clock, 
  Percent, 
  TrendingUp, 
  AlertCircle, 
  Trash2, 
  Edit, 
  Briefcase,
  HelpCircle,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { Worker } from '../../../types';

export interface SalaryProfile {
  id?: string;
  employeeId: string;
  nameOfWorker: string;
  designation: string;
  nationality: string;
  
  // Rate Profile
  rateType: 'Daily Rated' | 'Monthly Fixed';
  rateValue: number; // e.g. 100 (daily rate) or 2500 (monthly basic)
  
  // Hours and OT Threshold
  standardHoursStart: string; // e.g. "08:00"
  standardHoursEnd: string; // e.g. "17:00" or "19:00"
  otCutoffTime: string; // e.g. "17:00" or "19:00" (OT starts after this time)
  otRateMultiplier: number; // e.g. 1.5 or 2.0
  
  // Allowances (Monthly)
  allowanceHousing: number;
  allowanceTransport: number;
  allowancePhone: number;
  allowanceOther: number;
  
  // Deductions & Withholding
  withholdingAmount: number; // Monthly withholding (e.g. -$100)
  isSgPr: boolean; // Is SG Citizen/PR for CPF
  fwlAmount: number; // Foreign Worker Levy if foreigner (e.g. 350)
  
  // Administrative Info
  effectiveDate: string; // "YYYY-MM-DD"
  remarks: string;
  updatedAt: number;
  updatedBy: string;
  
  // Revision History List
  history?: Array<{
    id: string;
    rateType: 'Daily Rated' | 'Monthly Fixed';
    rateValue: number;
    standardHoursStart: string;
    standardHoursEnd: string;
    otCutoffTime: string;
    otRateMultiplier: number;
    allowanceHousing: number;
    allowanceTransport: number;
    allowancePhone: number;
    allowanceOther: number;
    withholdingAmount: number;
    effectiveDate: string;
    remarks: string;
    revisedAt: number;
    revisedBy: string;
  }>;
}

export default function SalaryProfileMasterPanel() {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [profiles, setProfiles] = useState<SalaryProfile[]>([]);
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [rateTypeFilter, setRateTypeFilter] = useState<string>('ALL');
  
  // Active editing / draft state
  const [editProfile, setEditProfile] = useState<Partial<SalaryProfile>>({});
  const [isRevisionMode, setIsRevisionMode] = useState<boolean>(false);
  const [revisionEffectiveDate, setRevisionEffectiveDate] = useState<string>('');
  const [revisionRemarks, setRevisionRemarks] = useState<string>('');
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  
  // Success / Alert messages
  const [alertMsg, setAlertMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Sync effective date default to today
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setRevisionEffectiveDate(today);
  }, []);

  // Fetch Workers Master List
  useEffect(() => {
    const qWorkers = query(collection(db, 'workers'));
    const unsubscribe = onSnapshot(qWorkers, (snapshot) => {
      const firestoreWorkers = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Worker));
      let localWorkers: Worker[] = [];
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        localWorkers = stored ? JSON.parse(stored) : [];
      } catch (e) {
        // ignore
      }
      
      const firestoreIds = new Set(firestoreWorkers.map(w => w.id));
      const firestoreSpreadsheetIds = new Set(
        firestoreWorkers.map(w => w.spreadsheetId).filter(Boolean) as string[]
      );
      
      const firestoreStintKeys = new Set(
        firestoreWorkers.map(w => {
          const empId = (w.employeeId || '').trim().toUpperCase();
          const sNo = (w.sNo || '').trim().toUpperCase();
          return empId && sNo ? `${empId}-${sNo}` : '';
        }).filter(Boolean)
      );

      const uniqueLocal = localWorkers.filter(w => {
        if (firestoreIds.has(w.id)) return false;
        if (w.id && firestoreSpreadsheetIds.has(w.id)) return false;
        
        const empId = (w.employeeId || '').trim().toUpperCase();
        const sNo = (w.sNo || '').trim().toUpperCase();
        if (empId && sNo) {
          const stintKey = `${empId}-${sNo}`;
          if (firestoreStintKeys.has(stintKey)) return false;
        }
        return true;
      });
      
      const merged = [...firestoreWorkers, ...uniqueLocal];
      setWorkers(merged);
      
      if (merged.length > 0 && !selectedWorkerId) {
        setSelectedWorkerId(merged[0].employeeId || '');
      }
    }, (err) => {
      console.warn("Error reading workers for salary master:", err);
      try {
        const stored = localStorage.getItem('mountec_local_workers');
        if (stored) {
          const parsed = JSON.parse(stored) as Worker[];
          setWorkers(parsed);
          if (parsed.length > 0 && !selectedWorkerId) {
            setSelectedWorkerId(parsed[0].employeeId || '');
          }
        }
      } catch (e) {
        // ignore
      }
    });
    return () => unsubscribe();
  }, []);

  // Fetch Salary Profiles
  useEffect(() => {
    const qProfiles = query(collection(db, 'salaryProfiles'));
    const unsubscribe = onSnapshot(qProfiles, (snapshot) => {
      const list = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as SalaryProfile));
      if (list.length > 0) {
        setProfiles(list);
        localStorage.setItem('mountec_local_salary_profiles', JSON.stringify(list));
      } else {
        const local = localStorage.getItem('mountec_local_salary_profiles');
        if (local) {
          setProfiles(JSON.parse(local));
        } else {
          setProfiles([]);
        }
      }
      setLoading(false);
    }, (err) => {
      console.warn("Firestore error reading salaryProfiles, loading local storage:", err);
      const local = localStorage.getItem('mountec_local_salary_profiles');
      if (local) {
        setProfiles(JSON.parse(local));
      } else {
        setProfiles([]);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Filter & Search Workers
  const filteredWorkers = useMemo(() => {
    return workers.filter(w => {
      const empId = w.employeeId || '';
      const name = w.nameOfWorker || w.name || '';
      const design = w.designation || '';
      const matchesSearch = 
        empId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        design.toLowerCase().includes(searchQuery.toLowerCase());
      
      const profile = profiles.find(p => p.employeeId === empId);
      const matchesRateFilter = 
        rateTypeFilter === 'ALL' ||
        (rateTypeFilter === 'DAILY' && profile?.rateType === 'Daily Rated') ||
        (rateTypeFilter === 'MONTHLY' && profile?.rateType === 'Monthly Fixed') ||
        (rateTypeFilter === 'UNCONFIGURED' && !profile);
        
      return matchesSearch && matchesRateFilter;
    });
  }, [workers, profiles, searchQuery, rateTypeFilter]);

  // Selected worker details
  const selectedWorker = useMemo(() => {
    return workers.find(w => w.employeeId === selectedWorkerId);
  }, [workers, selectedWorkerId]);

  // Selected worker profile
  const selectedProfile = useMemo(() => {
    return profiles.find(p => p.employeeId === selectedWorkerId);
  }, [profiles, selectedWorkerId]);

  // Sync draft editProfile when selectedWorkerId or selectedProfile changes
  useEffect(() => {
    if (selectedWorkerId) {
      if (selectedProfile) {
        setEditProfile(selectedProfile);
      } else if (selectedWorker) {
        // Generate sensible standard defaults if no profile exists
        const isSg = (selectedWorker.nationality || '').toLowerCase().includes('singapore') || 
                     (selectedWorker.nationality || '').toLowerCase().includes('local') ||
                     (selectedWorker.nationality || '').toLowerCase().includes('pr');
        
        const isDaily = (selectedWorker.designation || '').toLowerCase().includes('helper') || 
                        (selectedWorker.designation || '').toLowerCase().includes('specialist') ||
                        (selectedWorker.designation || '').toLowerCase().includes('mason') ||
                        (selectedWorker.designation || '').toLowerCase().includes('carpenter');
                        
        setEditProfile({
          employeeId: selectedWorkerId,
          nameOfWorker: selectedWorker.nameOfWorker || selectedWorker.name || 'Unknown',
          designation: selectedWorker.designation || 'Specialist',
          nationality: selectedWorker.nationality || 'Foreigner',
          rateType: isDaily ? 'Daily Rated' : 'Monthly Fixed',
          rateValue: isDaily ? 100 : 2400,
          standardHoursStart: '08:00',
          standardHoursEnd: isDaily ? '17:00' : '19:00',
          otCutoffTime: isDaily ? '17:00' : '19:00',
          otRateMultiplier: 1.5,
          allowanceHousing: isSg ? 0 : 150,
          allowanceTransport: 60,
          allowancePhone: 12,
          allowanceOther: 0,
          withholdingAmount: 0,
          isSgPr: isSg,
          fwlAmount: isSg ? 0 : 350,
          effectiveDate: new Date().toISOString().split('T')[0],
          remarks: 'Initial standard profile template generated.',
          history: []
        });
      }
    }
  }, [selectedWorkerId, selectedProfile, selectedWorker]);

  const triggerAlert = (type: 'success' | 'error', text: string) => {
    setAlertMsg({ type, text });
    setTimeout(() => {
      setAlertMsg(null);
    }, 4000);
  };

  const handleInputChange = (field: keyof SalaryProfile, value: any) => {
    setEditProfile(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-align defaults if rate type switches
      if (field === 'rateType') {
        if (value === 'Daily Rated') {
          updated.rateValue = prev.rateValue === 2400 ? 100 : prev.rateValue;
          updated.standardHoursEnd = '17:00';
          updated.otCutoffTime = '17:00';
        } else {
          updated.rateValue = prev.rateValue === 100 ? 2400 : prev.rateValue;
          updated.standardHoursEnd = '19:00';
          updated.otCutoffTime = '19:00';
        }
      }
      return updated;
    });
  };

  const handleSaveProfile = async (isRevision: boolean) => {
    if (!selectedWorkerId || !editProfile.rateValue || editProfile.rateValue <= 0) {
      triggerAlert('error', 'Please ensure basic rate values are correctly entered.');
      return;
    }

    const docId = selectedProfile?.id || editProfile.id || `profile-${selectedWorkerId}`;
    const userEmail = 'kartikvicky9@gmail.com'; // Log current editor
    
    const newPayload: SalaryProfile = {
      employeeId: selectedWorkerId,
      nameOfWorker: editProfile.nameOfWorker || selectedWorker?.nameOfWorker || selectedWorker?.name || 'Unknown',
      designation: editProfile.designation || selectedWorker?.designation || 'Specialist',
      nationality: editProfile.nationality || selectedWorker?.nationality || 'Foreigner',
      
      rateType: editProfile.rateType as 'Daily Rated' | 'Monthly Fixed',
      rateValue: Number(editProfile.rateValue) || 0,
      standardHoursStart: editProfile.standardHoursStart || '08:00',
      standardHoursEnd: editProfile.standardHoursEnd || '17:00',
      otCutoffTime: editProfile.otCutoffTime || '17:00',
      otRateMultiplier: Number(editProfile.otRateMultiplier) || 1.5,
      
      allowanceHousing: Number(editProfile.allowanceHousing) || 0,
      allowanceTransport: Number(editProfile.allowanceTransport) || 0,
      allowancePhone: Number(editProfile.allowancePhone) || 0,
      allowanceOther: Number(editProfile.allowanceOther) || 0,
      
      withholdingAmount: Number(editProfile.withholdingAmount) || 0,
      isSgPr: !!editProfile.isSgPr,
      fwlAmount: Number(editProfile.fwlAmount) || 0,
      
      effectiveDate: isRevision ? revisionEffectiveDate : (editProfile.effectiveDate || new Date().toISOString().split('T')[0]),
      remarks: isRevision ? revisionRemarks : (editProfile.remarks || 'Profile updated.'),
      updatedAt: Date.now(),
      updatedBy: userEmail,
      history: selectedProfile?.history || []
    };

    if (isRevision && selectedProfile) {
      // Archive current active profile details into historical record
      const historyRecord = {
        id: `rev-${Date.now()}`,
        rateType: selectedProfile.rateType,
        rateValue: selectedProfile.rateValue,
        standardHoursStart: selectedProfile.standardHoursStart,
        standardHoursEnd: selectedProfile.standardHoursEnd,
        otCutoffTime: selectedProfile.otCutoffTime,
        otRateMultiplier: selectedProfile.otRateMultiplier,
        allowanceHousing: selectedProfile.allowanceHousing,
        allowanceTransport: selectedProfile.allowanceTransport,
        allowancePhone: selectedProfile.allowancePhone,
        allowanceOther: selectedProfile.allowanceOther,
        withholdingAmount: selectedProfile.withholdingAmount,
        effectiveDate: selectedProfile.effectiveDate,
        remarks: selectedProfile.remarks || 'Archived on revision.',
        revisedAt: selectedProfile.updatedAt || Date.now(),
        revisedBy: selectedProfile.updatedBy || 'System'
      };
      newPayload.history = [historyRecord, ...(selectedProfile.history || [])];
    }

    try {
      const docRef = doc(db, 'salaryProfiles', docId);
      await setDoc(docRef, newPayload);
      
      // Also update Worker basic details in the workers collection for backwards compatibility
      if (selectedWorker?.id) {
        const workerRef = doc(db, 'workers', selectedWorker.id);
        await updateDoc(workerRef, {
          baseSalary: String(newPayload.rateValue),
          overtimeRate: String(newPayload.otRateMultiplier),
          designation: newPayload.designation
        });
      }

      // Sync local profiles instantly
      const updatedProfiles = profiles.map(p => p.employeeId === selectedWorkerId ? { ...newPayload, id: docId } : p);
      if (!profiles.some(p => p.employeeId === selectedWorkerId)) {
        updatedProfiles.push({ ...newPayload, id: docId });
      }
      setProfiles(updatedProfiles);
      localStorage.setItem('mountec_local_salary_profiles', JSON.stringify(updatedProfiles));
      
      triggerAlert('success', `Salary Profile for ${newPayload.nameOfWorker} (${selectedWorkerId}) successfully saved!${isRevision ? ' Revision recorded in history.' : ''}`);
      setIsRevisionMode(false);
      setRevisionRemarks('');
    } catch (err: any) {
      console.error("Error saving salary profile:", err);
      triggerAlert('error', `Failed to save salary profile: ${err.message || String(err)}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gray-900 border border-gray-800 p-4 rounded-lg shadow-sm">
        <div className="space-y-1">
          <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest font-sans block">Master Settings Panel</span>
          <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-indigo-400" />
            Worker Salary & Payroll Profile Master
          </h3>
          <p className="text-xs text-gray-400 font-sans max-w-2xl">
            Configure individual basic wage structures, daily standard shift schedules, overtime activation cutoff times, phone & travel allowances, and savings withholdings.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono bg-gray-800 text-gray-300 px-3 py-1.5 rounded border border-gray-700">
            Operator: <span className="text-indigo-400 font-bold">kartikvicky9</span>
          </span>
        </div>
      </div>

      {/* Main Grid: Left sidebar (list), Right pane (form & details) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Sidebar: Worker selector list */}
        <div className="lg:col-span-4 bg-[#111827] border border-gray-800 rounded-lg flex flex-col h-[700px] overflow-hidden">
          {/* Header & Filters */}
          <div className="p-4 border-b border-gray-800 space-y-3 bg-[#1F2937]/50">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search worker name, ID or post..."
                className="w-full bg-[#111827] border border-gray-800 rounded pl-9 pr-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 font-sans"
              />
            </div>
            
            <div className="flex gap-1.5">
              <button
                onClick={() => setRateTypeFilter('ALL')}
                className={`px-2.5 py-1 text-[10px] font-bold font-sans rounded transition-all ${rateTypeFilter === 'ALL' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
              >
                All
              </button>
              <button
                onClick={() => setRateTypeFilter('DAILY')}
                className={`px-2.5 py-1 text-[10px] font-bold font-sans rounded transition-all ${rateTypeFilter === 'DAILY' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
              >
                Daily Rated
              </button>
              <button
                onClick={() => setRateTypeFilter('MONTHLY')}
                className={`px-2.5 py-1 text-[10px] font-bold font-sans rounded transition-all ${rateTypeFilter === 'MONTHLY' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
              >
                Monthly Fixed
              </button>
              <button
                onClick={() => setRateTypeFilter('UNCONFIGURED')}
                className={`px-2.5 py-1 text-[10px] font-bold font-sans rounded transition-all ${rateTypeFilter === 'UNCONFIGURED' ? 'bg-orange-650/40 border border-orange-900/50 text-orange-400' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
              >
                Unset
              </button>
            </div>
          </div>

          {/* List of workers */}
          <div className="flex-1 overflow-y-auto divide-y divide-gray-800/60 p-2 space-y-1">
            {filteredWorkers.length === 0 ? (
              <div className="text-center py-12 text-gray-500 font-sans text-xs">
                No matching active workers found.
              </div>
            ) : (
              filteredWorkers.map(w => {
                const empId = w.employeeId || '';
                const hasProf = profiles.some(p => p.employeeId === empId);
                const prof = profiles.find(p => p.employeeId === empId);
                const isSelected = selectedWorkerId === empId;
                
                return (
                  <button
                    key={w.id || empId}
                    onClick={() => {
                      setSelectedWorkerId(empId);
                      setIsRevisionMode(false);
                    }}
                    className={`w-full text-left p-3 rounded flex items-center justify-between transition-all font-sans cursor-pointer ${isSelected ? 'bg-indigo-950/40 border border-indigo-900/50' : 'hover:bg-gray-900 border border-transparent'}`}
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white block">{w.nameOfWorker || w.name}</span>
                        {!hasProf && (
                          <span className="text-[8px] px-1 bg-amber-950/50 border border-amber-900/60 text-amber-400 font-semibold rounded font-sans uppercase">Unset</span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-gray-500 block">
                        {empId} • {w.designation || 'Specialist'}
                      </span>
                    </div>
                    {hasProf && (
                      <div className="text-right">
                        <span className={`text-[9px] font-semibold px-2 py-0.5 rounded font-sans block text-center ${prof?.rateType === 'Daily Rated' ? 'bg-emerald-950/40 border border-emerald-900/60 text-emerald-400' : 'bg-blue-950/40 border border-blue-900/60 text-blue-400'}`}>
                          {prof?.rateType === 'Daily Rated' ? 'Daily' : 'Monthly'}
                        </span>
                        <span className="text-[11px] font-mono font-bold text-gray-300 block mt-0.5">
                          ${prof?.rateValue?.toFixed(2)}
                        </span>
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Pane: Master Details & Forms */}
        <div className="lg:col-span-8 space-y-6">
          {alertMsg && (
            <div className={`p-4 rounded-lg flex items-center gap-3 border ${alertMsg.type === 'success' ? 'bg-emerald-950/50 border-emerald-900/50 text-emerald-400' : 'bg-red-950/50 border-red-900/50 text-red-400'}`}>
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="text-xs font-sans font-medium">{alertMsg.text}</p>
            </div>
          )}

          {!selectedWorkerId ? (
            <div className="bg-[#111827] border border-gray-800 rounded-lg p-12 text-center text-gray-500 font-sans space-y-3">
              <Users className="w-12 h-12 text-gray-700 mx-auto" />
              <p className="text-sm font-semibold text-gray-300">No worker selected</p>
              <p className="text-xs text-gray-500">Please choose an active worker from the list on the left to manage their salary rate configurations.</p>
            </div>
          ) : (
            <div className="bg-[#111827] border border-gray-800 rounded-lg overflow-hidden flex flex-col">
              
              {/* Profile Card Summary Banner */}
              <div className="bg-[#1F2937] px-6 py-4 border-b border-gray-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-white">{selectedWorker?.nameOfWorker || selectedWorker?.name}</span>
                    <span className="text-[10px] font-mono bg-[#111827] border border-gray-800 text-gray-400 px-1.5 py-0.5 rounded font-black">{selectedWorkerId}</span>
                  </div>
                  <p className="text-xs text-gray-400 font-sans">
                    Post: <span className="text-indigo-400 font-semibold">{selectedWorker?.designation || 'Specialist'}</span> • Nationality: <span className="text-gray-300">{selectedWorker?.nationality || 'Foreigner'}</span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {selectedProfile?.history && selectedProfile.history.length > 0 && (
                    <button
                      onClick={() => setShowHistoryModal(true)}
                      className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 hover:text-white rounded text-xs flex items-center gap-1.5 transition-all cursor-pointer font-sans"
                    >
                      <History className="w-3.5 h-3.5" />
                      View Revisions ({selectedProfile.history.length})
                    </button>
                  )}
                  <button
                    onClick={() => handleSaveProfile(false)}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded flex items-center gap-1.5 transition-all cursor-pointer font-sans shadow-sm"
                  >
                    <Save className="w-3.5 h-3.5" />
                    Save Changes
                  </button>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-6 space-y-6">
                
                {/* 1. Core Salary Type & Rate Configuration */}
                <div className="space-y-4">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-sans flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5" />
                    1. Basic Pay & Rate Structure
                  </span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Wage Rate Structure</label>
                      <select
                        value={editProfile.rateType || 'Daily Rated'}
                        onChange={(e) => handleInputChange('rateType', e.target.value)}
                        className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer font-sans font-semibold"
                      >
                        <option value="Daily Rated">Daily Rated (Base 08:00 to 17:00)</option>
                        <option value="Monthly Fixed">Monthly Fixed (Fixed Basic wage)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">
                        {editProfile.rateType === 'Daily Rated' ? 'Daily Basic Rate ($)' : 'Monthly Basic Salary ($)'}
                      </label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.rateValue || ''}
                          onChange={(e) => handleInputChange('rateValue', e.target.value)}
                          placeholder={editProfile.rateType === 'Daily Rated' ? '100.00' : '2400.00'}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white placeholder-gray-600 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Overtime (OT) Multiplier</label>
                      <select
                        value={editProfile.otRateMultiplier || 1.5}
                        onChange={(e) => handleInputChange('otRateMultiplier', parseFloat(e.target.value))}
                        className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer font-sans"
                      >
                        <option value="1.5">1.5x Hourly Rate (Standard Construction)</option>
                        <option value="2.0">2.0x Hourly Rate (Sundays / PH)</option>
                        <option value="1.0">1.0x Hourly Rate (Flat rate OT)</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* 2. Normal Hours & OT Activation Threshold */}
                <div className="pt-4 border-t border-gray-800/50 space-y-4">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-sans flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    2. Daily Work Shift & Overtime Thresholds
                  </span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Shift Start Time (Normal)</label>
                      <input
                        type="time"
                        value={editProfile.standardHoursStart || '08:00'}
                        onChange={(e) => handleInputChange('standardHoursStart', e.target.value)}
                        className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Shift End Time (Normal)</label>
                      <input
                        type="time"
                        value={editProfile.standardHoursEnd || '17:00'}
                        onChange={(e) => handleInputChange('standardHoursEnd', e.target.value)}
                        className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">OT Activation Cutoff Time</label>
                      <input
                        type="time"
                        value={editProfile.otCutoffTime || '17:00'}
                        onChange={(e) => handleInputChange('otCutoffTime', e.target.value)}
                        className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                      />
                      <span className="text-[9px] text-gray-500 mt-1 block leading-relaxed">
                        Any hours worked after this timestamp on a standard day count as Overtime (OT).
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-indigo-950/20 border border-indigo-900/30 rounded-lg">
                    <p className="text-[11px] text-indigo-300 leading-relaxed font-sans">
                      💡 <strong>Rule Engine:</strong> {editProfile.rateType === 'Daily Rated' ? (
                        <span>
                          For <strong>Daily Rated</strong> workers, hours between <strong>{editProfile.standardHoursStart || '08:00'}</strong> and <strong>{editProfile.standardHoursEnd || '17:00'}</strong> are covered by their daily basic rate (${editProfile.rateValue}). Any work logged past <strong>{editProfile.otCutoffTime || '17:00'}</strong> triggers overtime computed at <strong>{editProfile.otRateMultiplier || 1.5}x</strong> rate.
                        </span>
                      ) : (
                        <span>
                          For <strong>Monthly Fixed</strong> workers, their monthly fixed basic (${editProfile.rateValue}) covers all standard working hours. Any work deployment logged past <strong>{editProfile.otCutoffTime || '19:00'}</strong> triggers overtime hours computed at <strong>{editProfile.otRateMultiplier || 1.5}x</strong> basic hourly rate.
                        </span>
                      )}
                    </p>
                  </div>
                </div>

                {/* 3. Monthly Allowances */}
                <div className="pt-4 border-t border-gray-800/50 space-y-4">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-sans flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    3. Fixed Monthly Allowances
                  </span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Housing Allowance ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.allowanceHousing || 0}
                          onChange={(e) => handleInputChange('allowanceHousing', parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Transport Allowance ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.allowanceTransport || 0}
                          onChange={(e) => handleInputChange('allowanceTransport', parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Phone Allowance ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.allowancePhone || 0}
                          onChange={(e) => handleInputChange('allowancePhone', parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Other Allowance ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.allowanceOther || 0}
                          onChange={(e) => handleInputChange('allowanceOther', parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 4. Deductions, Levies & Withholdings */}
                <div className="pt-4 border-t border-gray-800/50 space-y-4">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-sans flex items-center gap-1">
                    <Percent className="w-3.5 h-3.5" />
                    4. Deductions, Levies & Withholdings
                  </span>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Monthly Withholding Savings ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.withholdingAmount || 0}
                          onChange={(e) => handleInputChange('withholdingAmount', parseFloat(e.target.value) || 0)}
                          placeholder="e.g. 100.00"
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                      <span className="text-[9px] text-gray-500 mt-1 block">
                        Subtracted from monthly payout as withheld amount (for safety or repatriation deposit).
                      </span>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">CPF / National Scheme Eligible</label>
                      <div className="flex items-center mt-2.5">
                        <input
                          id="isSgPr-chk"
                          type="checkbox"
                          checked={!!editProfile.isSgPr}
                          onChange={(e) => handleInputChange('isSgPr', e.target.checked)}
                          className="w-4 h-4 bg-gray-900 border-gray-800 rounded text-indigo-600 focus:ring-0 cursor-pointer"
                        />
                        <label htmlFor="isSgPr-chk" className="ml-2.5 text-xs text-gray-300 font-sans cursor-pointer">
                          Local Singaporean Citizen / PR
                        </label>
                      </div>
                      <span className="text-[9px] text-gray-500 mt-1.5 block">
                        If checked, employee and employer standard CPF contributions will apply during monthly generation.
                      </span>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1.5 font-sans">Foreign Worker Levy (FWL) ($)</label>
                      <div className="relative">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-500 font-mono">$</span>
                        <input
                          type="number"
                          value={editProfile.fwlAmount || 0}
                          disabled={!!editProfile.isSgPr}
                          onChange={(e) => handleInputChange('fwlAmount', parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1F2937] border border-gray-800 rounded pl-7 pr-3 py-2 text-xs font-mono text-white disabled:opacity-30 focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                      <span className="text-[9px] text-gray-500 mt-1 block">
                        Government levy paid by company. Standard is $350 for Work Permit.
                      </span>
                    </div>
                  </div>
                </div>

                {/* 5. Revision & History Controller */}
                <div className="pt-4 border-t border-gray-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest font-sans flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5" />
                      5. Rate Revision & Roll Control
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsRevisionMode(!isRevisionMode)}
                      className={`px-3 py-1 rounded text-[10px] font-bold uppercase font-sans tracking-wide transition-all border ${isRevisionMode ? 'bg-indigo-900/40 border-indigo-500 text-indigo-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}
                    >
                      {isRevisionMode ? '❌ Cancel Revision' : '🔄 Setup Rate Revision / Roll'}
                    </button>
                  </div>

                  {isRevisionMode ? (
                    <div className="p-4 bg-slate-950/40 border border-indigo-900/60 rounded-lg space-y-4 font-sans animate-fade-in">
                      <div className="flex items-center gap-2 text-indigo-400">
                        <AlertCircle className="w-4 h-4" />
                        <span className="text-xs font-bold">You are establishing a salary rate revision</span>
                      </div>
                      <p className="text-[11px] text-gray-400 leading-relaxed">
                        Revising the rate will archive the worker's current active salary profile values (above) into their **Revision History** for past payroll references, and stamp these new entries as the latest active profile starting on the effective date.
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Revision Effective Date</label>
                          <input
                            type="date"
                            value={revisionEffectiveDate}
                            onChange={(e) => setRevisionEffectiveDate(e.target.value)}
                            className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Reason / Revision Notes</label>
                          <input
                            type="text"
                            value={revisionRemarks}
                            onChange={(e) => setRevisionRemarks(e.target.value)}
                            placeholder="e.g. Promotion, revised union rates, annual adjustment"
                            className="w-full bg-[#1F2937] border border-gray-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end pt-2">
                        <button
                          type="button"
                          onClick={() => handleSaveProfile(true)}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          Commit & Roll Revised Salary Profile
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-gray-900/40 border border-gray-800 rounded-lg flex items-center justify-between gap-4 font-sans">
                      <p className="text-[11px] text-gray-400">
                        Making updates without checking the Revision tool above will perform an <strong>in-place correction</strong> of the current active parameters without storing previous records in history.
                      </p>
                      <button
                        type="button"
                        onClick={() => handleSaveProfile(false)}
                        className="px-3 py-1.5 bg-gray-800 hover:bg-indigo-600 text-gray-300 hover:text-white border border-gray-700 hover:border-indigo-600 rounded text-[10px] font-bold font-black tracking-wide cursor-pointer transition-all uppercase"
                      >
                        Quick Save
                      </button>
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}
        </div>

      </div>

      {/* Revision History Modal Window */}
      {showHistoryModal && selectedProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-[#111827] border border-gray-800 rounded-lg w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col">
            <div className="px-6 py-4 bg-[#1F2937] border-b border-gray-800 flex justify-between items-center">
              <span className="text-sm font-black text-white flex items-center gap-2">
                <History className="w-4 h-4 text-indigo-400" />
                Salary Profile Revision Log — {selectedProfile.nameOfWorker} ({selectedProfile.employeeId})
              </span>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="text-gray-400 hover:text-white p-1 hover:bg-gray-800 rounded transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto max-h-[500px] space-y-4">
              <p className="text-xs text-gray-400 font-sans leading-relaxed">
                Historic rates logged for past pay runs. These are preserved for auditing and retroactive calculation purposes.
              </p>

              <div className="border border-gray-800 rounded-lg overflow-hidden">
                <table className="w-full text-left border-collapse text-xs font-sans">
                  <thead>
                    <tr className="bg-gray-900 border-b border-gray-800 text-[9px] font-bold text-gray-400 uppercase tracking-wider">
                      <th className="py-3 px-4">Effective Date</th>
                      <th className="py-3 px-4">Wage Structure</th>
                      <th className="py-3 px-4 text-right">Basic Rate</th>
                      <th className="py-3 px-4">OT Hours/Cutoff</th>
                      <th className="py-3 px-4">Allowances</th>
                      <th className="py-3 px-4 text-right">Savings Hold</th>
                      <th className="py-3 px-4">Reason / Modified By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800/60 font-mono text-gray-300">
                    {/* Active/Current row */}
                    <tr className="bg-indigo-950/20 text-white font-semibold">
                      <td className="py-3 px-4">
                        <span className="font-bold text-indigo-400">{selectedProfile.effectiveDate}</span>
                        <span className="block text-[8px] uppercase tracking-wider font-sans font-bold text-emerald-400 mt-0.5">CURRENT ACTIVE</span>
                      </td>
                      <td className="py-3 px-4 font-sans">{selectedProfile.rateType}</td>
                      <td className="py-3 px-4 text-right font-black">${selectedProfile.rateValue?.toFixed(2)}</td>
                      <td className="py-3 px-4 text-xs font-sans">OT past {selectedProfile.otCutoffTime} ({selectedProfile.otRateMultiplier}x)</td>
                      <td className="py-3 px-4 text-xs font-sans">
                        H:${selectedProfile.allowanceHousing} • T:${selectedProfile.allowanceTransport} • P:${selectedProfile.allowancePhone}
                      </td>
                      <td className="py-3 px-4 text-right text-orange-400">${selectedProfile.withholdingAmount?.toFixed(2)}</td>
                      <td className="py-3 px-4 font-sans text-xs text-gray-300">
                        <span className="block italic">"{selectedProfile.remarks || 'Active Settings'}"</span>
                        <span className="block text-[9px] text-gray-500 mt-1">By {selectedProfile.updatedBy || 'System'}</span>
                      </td>
                    </tr>

                    {/* Past history logs */}
                    {(!selectedProfile.history || selectedProfile.history.length === 0) ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-gray-500 font-sans italic text-xs">
                          No previous revisions recorded.
                        </td>
                      </tr>
                    ) : (
                      selectedProfile.history.map((hist) => (
                        <tr key={hist.id} className="hover:bg-gray-900/40">
                          <td className="py-3 px-4 text-gray-400 font-bold">{hist.effectiveDate}</td>
                          <td className="py-3 px-4 font-sans text-gray-400">{hist.rateType}</td>
                          <td className="py-3 px-4 text-right font-bold text-gray-400">${hist.rateValue?.toFixed(2)}</td>
                          <td className="py-3 px-4 text-xs font-sans text-gray-500">OT past {hist.otCutoffTime} ({hist.otRateMultiplier}x)</td>
                          <td className="py-3 px-4 text-xs font-sans text-gray-500">
                            H:${hist.allowanceHousing} • T:${hist.allowanceTransport} • P:${hist.allowancePhone}
                          </td>
                          <td className="py-3 px-4 text-right text-gray-500">${hist.withholdingAmount?.toFixed(2)}</td>
                          <td className="py-3 px-4 font-sans text-xs text-gray-500">
                            <span className="block italic">"{hist.remarks || 'Previous settings'}"</span>
                            <span className="block text-[9px] text-gray-600 mt-1">
                              By {hist.revisedBy || 'System'} on {new Date(hist.revisedAt).toLocaleDateString()}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="px-6 py-4 bg-gray-900 border-t border-gray-800 flex justify-end">
              <button
                onClick={() => setShowHistoryModal(false)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded text-xs font-bold transition-all cursor-pointer font-sans"
              >
                Close History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
