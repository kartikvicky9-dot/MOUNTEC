import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../../../context/AppContext';
import { getAccessToken, db } from '../../../lib/firebase';
import { 
  RefreshCw, AlertCircle, Database, Save, Folder, FolderOpen, FileText, 
  ChevronDown, ChevronRight, Plus, Trash2, Eye, Download, Network, 
  Briefcase, Users, CheckSquare, Upload, Image, FileCode, Share2, 
  ExternalLink, FileSpreadsheet, ChevronLeft, Search, Calendar, User, 
  Info, Sparkles, Printer, Check, Ruler, Maximize2, Minimize2, ZoomIn, 
  ZoomOut, RotateCw, Mail, Link, Send, Copy, Lock, Shield, ShieldAlert,
  Filter, X, ArrowUp, ArrowDown, ArrowUpDown, ChevronRight as ChevronRightIcon, UserPlus
} from 'lucide-react';
import { Worker, SpreadsheetData } from '../../../types';
import { collection, addDoc, getDocs, deleteDoc, doc, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import MountecLogo from '../../MountecLogo';
import { formatDate } from '../../../lib/dateUtils';

interface CustomDocument {
  id: string;
  category: string;
  title: string;
  description: string;
  content: string;
  fileName: string;
  uploadedBy: string;
  createdAt: number;
  size: string;
  interactiveType?: string;
}

interface HRAdminPanelProps {
  globalSearchQuery?: string;
  setGlobalSearchQuery?: (val: string) => void;
}

export default function HRAdminPanel({ globalSearchQuery = '', setGlobalSearchQuery }: HRAdminPanelProps) {
  const { workers, setWorkers, rawData, setRawData, updateRawData, sheetId, setSheetId, sheetRange, setSheetRange, isViewOnly, user } = useAppContext();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Auto-save states and refs
  const [isPendingSave, setIsPendingSave] = useState(false);
  const latestDataRef = useRef<string[][] | null>(null);
  const autoSaveTimerRef = useRef<any>(null);

  // Clear auto-save timer on unmount
  useEffect(() => {
    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
        // Force save on unmount if pending
        if (latestDataRef.current) {
            saveSheetData(latestDataRef.current);
        }
      }
    };
  }, []);

  // Horizontal scroll state & ref for spreadsheet
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const [scrollPercent, setScrollPercent] = useState(0);

  // Sorting state for the spreadsheet
  const [sortColIndex, setSortColIndex] = useState<number | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc' | null>(null);

  // Reset scroll position when rawData changes
  useEffect(() => {
    if (tableContainerRef.current) {
      tableContainerRef.current.scrollLeft = 0;
      setScrollPercent(0);
    }
  }, [rawData]);

  // Drag and drop states
  const [isDragging, setIsDragging] = useState(false);
  const [newDocSize, setNewDocSize] = useState('120 KB');

  // Share provisions states
  const [sharingDoc, setSharingDoc] = useState<{
    id?: string;
    title: string;
    fileName: string;
    size: string;
    category?: string;
    content?: string;
  } | null>(null);
  const [shareEmail, setShareEmail] = useState('');
  const [shareCopied, setShareCopied] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [sharePermission, setSharePermission] = useState<'view' | 'edit'>('view');
  const [shareAccessList, setShareAccessList] = useState<Array<{email: string, role: 'view' | 'edit', date: string}>>([
    { email: 'senthil@mountec.com.sg', role: 'edit', date: 'Yesterday' }
  ]);
  const [shareCoworkers, setShareCoworkers] = useState<Record<string, boolean>>({
    'senthil': false,
    'kartik': false,
    'supervisor': false
  });

  // PDF Viewer states
  const [pdfPage, setPdfPage] = useState(1);
  const [pdfZoom, setPdfZoom] = useState(100);
  const [pdfSigned, setPdfSigned] = useState(false);
  const [pdfSearchQuery, setPdfSearchQuery] = useState('');
  const [pdfSigText, setPdfSigText] = useState('KV');
  const [pdfSigFont, setPdfSigFont] = useState('cursive');

  // DWG CAD states
  const [cadActiveLayer, setCadActiveLayer] = useState<Record<string, boolean>>({
    'piping': true,
    'walls': true,
    'annotations': true,
    'grid': true
  });
  const [cadMeasureActive, setCadMeasureActive] = useState(false);
  const [cadPoints, setCadPoints] = useState<Array<{x: number, y: number}>>([]);
  const [cadZoom, setCadZoom] = useState(100);
  const [cadCoords, setCadCoords] = useState({ x: 0, y: 0 });

  // XLSX Spreadsheet states
  const [xlsxActiveTab, setXlsxActiveTab] = useState(0);
  const [xlsxSelectedCell, setXlsxSelectedCell] = useState<{row: number, col: number} | null>(null);
  const [xlsxEditVal, setXlsxEditVal] = useState('');
  const [xlsxSheetData, setXlsxSheetData] = useState<string[][]>([
    ["Activity / Sector", "Planned (Joints)", "Actual (Joints)", "Unit", "Variance", "Status"],
    ["Pipe Welding (Blk 28)", "12", "14", "Joints", "2", "AHEAD"],
    ["Pipe Fitting (Blk 28)", "10", "9", "Joints", "-1", "DELAYED"],
    ["Scaffold Erection", "4", "4", "Sets", "0", "ON SCHEDULE"],
    ["Safety Line Rigging", "2", "3", "Runs", "1", "AHEAD"],
    ["OT Hours Logged", "16", "22", "Hours", "6", "APPROVED"],
    ["Total Outlay", "44", "52", "Points", "8", "100% DONE"]
  ]);

  // DOCX Word states
  const [docxIsEditing, setDocxIsEditing] = useState(false);
  const [docxText, setDocxText] = useState('');
  const [docxBold, setDocxBold] = useState(false);
  const [docxItalic, setDocxItalic] = useState(false);
  const [docxUnderline, setDocxUnderline] = useState(false);
  const [docxAlign, setDocxAlign] = useState<'left' | 'center' | 'right'>('left');

  // Image Gallery states
  const [imgZoom, setImgZoom] = useState(100);
  const [imgRotation, setImgRotation] = useState(0);

  // Internal section/navigation state
  const [selectedFolderId, setSelectedFolderId] = useState<string>('1.5.3');
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    '1.1': true,
    '1.2': true,
    '1.5': true,
    '5.1': true,
    '5.1.1': true
  });

  // Document explorer states
  const [customDocs, setCustomDocs] = useState<CustomDocument[]>([]);
  const [docsLoading, setDocsLoading] = useState(false);
  
  const searchQuery = globalSearchQuery;
  const handleSearchChange = (val: string) => {
    if (setGlobalSearchQuery) setGlobalSearchQuery(val);
  };

  // Staff Particulars Filter states
  const [filterSearch, setFilterSearch] = useState('');
  const [filterNationality, setFilterNationality] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSearchCol, setFilterSearchCol] = useState<'all' | number>('all');
  
  // Custom Doc Form State
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocDesc, setNewDocDesc] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  const [newDocFileName, setNewDocFileName] = useState('');

  // Active document reader modal state
  const [selectedDoc, setSelectedDoc] = useState<{
    title: string;
    description: string;
    fileName: string;
    content: string;
    size: string;
    uploadedBy?: string;
    createdAt?: number;
    category?: string;
    isPreloaded?: boolean;
    interactiveType?: string;
  } | null>(null);

  // Leave Form Simulation State
  const [leaveName, setLeaveName] = useState('');
  const [leaveType, setLeaveType] = useState('Annual Leave');
  const [leaveStart, setLeaveStart] = useState('');
  const [leaveEnd, setLeaveEnd] = useState('');
  const [leaveReason, setLeaveReason] = useState('');
  const [leaveSubmitted, setLeaveSubmitted] = useState(false);

  // Claim Form Simulation State
  const [claimCategory, setClaimCategory] = useState('Transport');
  const [claimAmount, setClaimAmount] = useState('');
  const [claimDesc, setClaimDesc] = useState('');
  const [claimsList, setClaimsList] = useState<Array<{category: string, amount: number, desc: string}>>([
    { category: 'Transport', amount: 35.50, desc: 'Taxi fare for site inspection' },
    { category: 'Hardware/Tools', amount: 120.00, desc: 'Safety replacement boots' }
  ]);

  // Load Firestore uploaded documents in real-time
  const fetchCustomDocuments = () => {};

  useEffect(() => {
    setDocsLoading(true);
    const q = query(collection(db, 'hrDocuments'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docsList: CustomDocument[] = [];
      snapshot.forEach(docSnap => {
        docsList.push({ id: docSnap.id, ...docSnap.data() } as CustomDocument);
      });
      setCustomDocs(docsList);
      setDocsLoading(false);
    }, (err: any) => {
      console.warn('Firestore subscription failed, falling back to local storage:', err);
      try {
        const saved = localStorage.getItem('mountec_hr_documents');
        if (saved) {
          setCustomDocs(JSON.parse(saved));
        }
      } catch (e) {
        // ignore
      }
      setDocsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle || !newDocFileName) return;

    const lower = newDocFileName.toLowerCase();
    let finalFileName = newDocFileName;
    // ensure file has correct extension
    const hasValidExtension = lower.endsWith('.pdf') || lower.endsWith('.dwg') || lower.endsWith('.xlsx') || lower.endsWith('.xls') || lower.endsWith('.docx') || lower.endsWith('.doc') || lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg');
    if (!hasValidExtension) {
      finalFileName = `${newDocFileName}.pdf`;
    }

    const lowerFinal = finalFileName.toLowerCase();
    let inferredType: string | undefined = undefined;
    if (lowerFinal.endsWith('.pdf')) inferredType = 'pdf_preview';
    else if (lowerFinal.endsWith('.dwg')) inferredType = 'dwg_preview';
    else if (lowerFinal.endsWith('.xlsx') || lowerFinal.endsWith('.xls')) inferredType = 'xlsx_preview';
    else if (lowerFinal.endsWith('.docx') || lowerFinal.endsWith('.doc')) inferredType = 'docx_preview';
    else if (lowerFinal.endsWith('.png') || lowerFinal.endsWith('.jpg') || lowerFinal.endsWith('.jpeg')) inferredType = 'image_preview';

    const docData = {
      category: selectedFolderId,
      title: newDocTitle,
      description: newDocDesc || 'Uploaded custom resource document',
      content: newDocContent || '',
      fileName: finalFileName,
      uploadedBy: user?.email || 'System User',
      createdAt: Date.now(),
      size: newDocSize || `${(Math.random() * 200 + 45).toFixed(0)} KB`,
      interactiveType: inferredType
    };

    try {
      await addDoc(collection(db, 'hrDocuments'), docData);
      fetchCustomDocuments();
    } catch (err: any) {
      console.warn('Firestore write failed, saving to local storage fallback:', err);
      const updated = [
        { id: `local-${Date.now()}`, ...docData },
        ...customDocs
      ];
      setCustomDocs(updated);
      localStorage.setItem('mountec_hr_documents', JSON.stringify(updated));
    }

    // Reset Form
    setNewDocTitle('');
    setNewDocDesc('');
    setNewDocContent('');
    setNewDocFileName('');
    setNewDocSize('120 KB');
    setShowUploadModal(false);
  };

  const handleDeleteDocument = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this document?')) return;

    try {
      await deleteDoc(doc(db, 'hrDocuments', id));
      fetchCustomDocuments();
    } catch (err: any) {
      console.warn('Firestore delete failed, deleting from local storage:', err);
      const updated = customDocs.filter(d => d.id !== id);
      setCustomDocs(updated);
      localStorage.setItem('mountec_hr_documents', JSON.stringify(updated));
    }
  };

  // Preloaded static items with professional visual content and layouts
  const preloadedDocuments: Record<string, Array<{
    title: string;
    description: string;
    fileName: string;
    size: string;
    interactiveType?: string;
    content: string;
  }>> = {
    '1.1.1': [
      {
        title: "Mountec General Employment Policy & Code of Conduct",
        description: "Core workplace standards, office hours, safety duties, and professional conduct guidelines for all staff.",
        fileName: "mountec_employment_policy.pdf",
        size: "182 KB",
        interactiveType: "policy_conduct",
        content: `### MOUNTEC PTE. LTD. - COMPANY EMPLOYMENT POLICY
**Effective Date:** January 1, 2026

#### 1. Code of Conduct & Workplace Safety
All employees of Mountec Pte. Ltd. must maintain the highest standards of professional conduct. Workplace safety is our ultimate priority. Staff and workers must use all required Personal Protective Equipment (PPE) at any site, report hazards immediately, and fully cooperate with the Safety Officer during Toolbox Meetings.

#### 2. Employment Hours and Attendance
Standard office working hours are from 8:30 AM to 5:30 PM, Monday through Friday. Site worker schedules depend on project requirements and Supervisor allocations. Punctuality is required; any absence or tardiness must be reported to your supervisor within 1 hour of your scheduled shift.

#### 3. Professional Integrity
Mountec maintains a zero-tolerance policy for bribery, corruption, harassment, or workplace bullying. Any violation of these codes will result in immediate termination and referral to Singapore authorities when appropriate.`
      },
      {
        title: "Leave, Sick Leave & Public Holidays Guidelines 2026",
        description: "Official annual leave allocations, MC application procedures, and public holiday allowances under MoM guidelines.",
        fileName: "mountec_leave_guidelines.pdf",
        size: "124 KB",
        interactiveType: "leave_policy",
        content: `### MOUNTEC - LEAVE & ATTENDANCE GUIDELINES (2026)
**According to Singapore Ministry of Manpower (MOM) Standards**

#### 1. Annual Leave Eligibility
Employees are entitled to annual leave after 3 months of continuous service. Standard allocation starts at 14 days per calendar year for administrative staff, and increases by 1 day for each year of service, capped at 21 days.

#### 2. Sick Leave & Medical Certificates (MC)
- Paid Outpatient Sick Leave: Up to 14 days per year (MC from a registered clinic is mandatory).
- Paid Hospitalization Leave: Up to 60 days per year (inclusive of the 14 days outpatient sick leave).
- MCs must be submitted via the HR portal within 48 hours of return to duty.

#### 3. Urgent Leave & Overtime Claims
Compensatory leaves and urgent time-off requests require Supervisor approval at least 3 days in advance except in emergency situations.`
      },
      {
        title: "Confidentiality & Personal Data Protection (PDPA) Code",
        description: "Data security protocols for staff details, client records, and company-proprietary files under PDPA laws.",
        fileName: "mountec_data_protection_policy.pdf",
        size: "95 KB",
        interactiveType: "pdpa_policy",
        content: `### PERSONAL DATA PROTECTION ACT (PDPA) SECURITY PROTOCOL
**Mountec Pte. Ltd. Internal Guidelines**

#### 1. Protection of Employee Records
Employee particulars, including Work Permit numbers, salaries, passport details, and residential addresses, are classified as strictly confidential. This data may only be accessed by authorized HR Personnel.

#### 2. Client & Project Data Confidentiality
Information regarding ongoing projects, bidding structures, and technical blueprint schematics must not be shared outside Mountec's secure network. 

#### 3. Digital Asset Protection
Never share passwords, email login credentials, or Google Sheet keys. Securely log out of all shared terminals before leaving the workplace.`
      }
    ],
    '1.1.2': [
      {
        title: "Official Company Hierarchy Chart & Operational Tree",
        description: "Organizational structures, operational reporting paths, and department leadership at Mountec.",
        fileName: "mountec_org_chart_2026.pdf",
        size: "245 KB",
        interactiveType: "org_chart",
        content: ""
      }
    ],
    '1.1.3': [
      {
        title: "Site Mobilization & Safety Setup SOP",
        description: "Standard Operations Procedure for setting up site fences, tool stores, and conducting initial safety briefings.",
        fileName: "mountec_sop_site_mobilization.pdf",
        size: "310 KB",
        interactiveType: "sop_text",
        content: `### STANDARD OPERATING PROCEDURE: SITE MOBILIZATION
**SOP Code:** SOP-OPS-001 | **Revision:** v2.4

#### 1. Purpose & Scope
This SOP defines the required steps to safely mobilize workers, heavy tools, and temporary shelters on a new project site.

#### 2. Pre-Mobilization Checklist
1. Ensure Project Permit and PTW (Permit To Work) are fully approved by client.
2. Verify that the conduct officer has inspected site barriers and warning boards.
3. Coordinate transportation of site storage containers safely.

#### 3. Mobilization Execution
- Establish the dedicated muster point and place emergency fire extinguishers.
- Post the toolbox meeting clipboard, emergency contact cards, and safety signage.
- Gather all workers for a site-induction safety briefing prior to starting any mechanical works.`
      },
      {
        title: "Heavy Equipment Operation and Maintenance Guidelines",
        description: "SOP protocols for Boomlifts, Scissor lifts, and heavy tools pre-inspection routines.",
        fileName: "mountec_sop_equipment_operation.pdf",
        size: "420 KB",
        interactiveType: "sop_text",
        content: `### SOP: HEAVY EQUIPMENT OPERATION & MAINTENANCE
**SOP Code:** SOP-OPS-002 | **Revision:** v3.1

#### 1. Pre-Operational Checklist
No worker is permitted to operate heavy machinery (including Boomlifts, Scissor lifts, or forklifts) without:
- A valid, certified operator license.
- Completing the physical pre-use safety inspection form.
- Double-checking hydraulic levels, emergency stops, and warning sirens.

#### 2. Maintenance Routine
- Weekly lubrications of sliding frames.
- Immediate tag-out of any machinery demonstrating abnormal engine noise or faulty brake response.`
      },
      {
        title: "Toolbox Meeting Conduct and Documentation SOP",
        description: "Guidelines on leading effective toolbox safety briefings and signing off on attendance.",
        fileName: "mountec_sop_toolbox_meeting.pdf",
        size: "150 KB",
        interactiveType: "sop_text",
        content: `### SOP: TOOLBOX MEETING CONDUCT AND DOCUMENTATION
**SOP Code:** SOP-SAF-001 | **Revision:** v1.8

#### 1. Protocol & Timing
A Toolbox Meeting is a mandatory safety briefing conducted EVERY morning prior to start of shift. Duration must be between 10 to 15 minutes.

#### 2. Responsibilities
- **Conducting Officer**: Prepares the Safety matters, inspects worker PPE compliance, and reads out high-risk tasks of the day.
- **Workers**: Listen attentively, report any faulty tools, and sign the official attendance list.

#### 3. Recording & Storage
All Toolbox Meeting Forms must be fully signed, backed by captured photo evidence, and saved onto Mountec's Google Drive database using the safety panel.`
      }
    ],
    '1.2.1': [
      {
        title: "Annual & Medical Leave Application Form",
        description: "Interactive leave submission simulator for Mountec personnel.",
        fileName: "mountec_leave_application_form.pdf",
        size: "98 KB",
        interactiveType: "form_leave",
        content: ""
      },
      {
        title: "Expense & Overtime Claim Form",
        description: "Interactive calculator and digital submission portal for site claims.",
        fileName: "mountec_claim_sheet_reimbursement.pdf",
        size: "112 KB",
        interactiveType: "form_claim",
        content: ""
      }
    ],
    '1.2.2': [
      {
        title: "Official Mountec Letterhead Document Template",
        description: "The standard corporate header, footer, and font styles for official letters.",
        fileName: "mountec_letterhead_template.docx",
        size: "220 KB",
        interactiveType: "docx_preview",
        content: "### MOUNTEC OFFICIAL LETTERHEAD BRIEF\n\nTo all engineering personnel,\n\nPlease note that standard mechanical operations for Block 28 have been fully signed off. Ensure site coordinates match our local layout blueprints exactly. Keep all PPE gear locked when not in use.\n\nSincerely,\nManaging Director, Kartik Vicky"
      },
      {
        title: "Daily Site Progress Report Template",
        description: "Template layout for reporting daily worker strength, tasks finished, and weather delays.",
        fileName: "mountec_daily_site_report_template.xlsx",
        size: "180 KB",
        interactiveType: "xlsx_preview",
        content: ""
      },
      {
        title: "Block 28 Piping Installation Blueprint",
        description: "Official mechanical engineering 2D CAD layout and piping schedules.",
        fileName: "mountec_block28_piping_layout.dwg",
        size: "1.4 MB",
        interactiveType: "dwg_preview",
        content: ""
      }
    ],
    '1.2.3': [
      {
        title: "Mountec Corporate Branding Vector Assets",
        description: "Official logos, color palettes, and standard graphic specifications for Mountec.",
        fileName: "mountec_logo_blue_hd.png",
        size: "520 KB",
        interactiveType: "brand_logos",
        content: ""
      }
    ],
    '1.2.4': [
      {
        title: "Recruitment Advertisement - Structural Welders",
        description: "Official recruitment flyer for structural welding contractors and personnel.",
        fileName: "mountec_recruitment_welders_2026.pdf",
        size: "1.4 MB",
        interactiveType: "ad_welders",
        content: ""
      },
      {
        title: "Mountec Corporate Profile & Project Portfolio Brochure",
        description: "High-quality overview brochure of company services, history, and major engineering projects completed.",
        fileName: "mountec_corporate_profile_brochure.pdf",
        size: "2.8 MB",
        interactiveType: "ad_profile",
        content: ""
      }
    ],
    '1.3': [
      {
        title: "Mountec Email Account Access Policy & Guidelines",
        description: "Secure protocols for accessing corporate email, setting up 2FA, and password reset procedures.",
        fileName: "mountec_email_policy.pdf",
        size: "110 KB",
        content: `### MOUNTEC PTE. LTD. EMAIL & PASSWORD POLICY

1. **Accessing Corporate Email**
   - Access corporate emails strictly via certified devices.
   - Standard email domain is @mountec.com.sg.
   
2. **Two-Factor Authentication (2FA)**
   - 2FA is mandatory for all administrative and supervisory staff.
   - Set up Google Authenticator or SMS verification immediately upon account receipt.

3. **Password Lifespan & Complexity**
   - Minimum 12 characters combining uppercase, lowercase, numbers, and special symbols.
   - Passwords must be updated every 90 days. Sharing credentials via chat or email is strictly prohibited.`
      },
      {
        title: "Corporate Systems Credentials Onboarding Checklist",
        description: "Checklist for onboarding workers with software access codes and security compliance verification.",
        fileName: "mountec_system_credentials_guide.pdf",
        size: "95 KB",
        content: `### ONBOARDING SYSTEM CREDENTIALS CHECKLIST
**Mountec Systems Management**

1. **Active Directory & Domain setup**
   - [ ] Provision username: initial.lastname@mountec.com.sg
   - [ ] Generate temporary password (enforce change on first login)
   
2. **ERP and Document Repository access**
   - [ ] Set read-only permission folders
   - [ ] Assign HR/Admin panel roles if supervisory staff

3. **Devices Security Checklist**
   - [ ] Install corporate antivirus protection
   - [ ] Enable local disk encryption (BitLocker / FileVault)`
      }
    ],
    '1.4.1': [
      {
        title: "Official Letter of Warning / Termination Template",
        description: "Official draft letter format for disciplinary warnings or service terminations.",
        fileName: "mountec_warning_letter_template.docx",
        size: "85 KB",
        content: `### TEMPLATE: LETTER OF WARNING / DISCIPLINARY NOTICE
**Mountec Pte. Ltd. Human Resources**

**Date:** [Date]
**To:** [Employee Name]
**Designation:** [Employee Designation]

**Subject: First Written Warning for Breach of Workplace Regulations**

Dear [Employee Name],

This letter serves as a formal written warning regarding your [conduct/performance/attendance], specifically the incident which occurred on [Date of Incident] involving:
[Detailed description of breach / safety violation].

Mountec Pte. Ltd. maintains a strict safety-first policy. Under clause 8.2 of the Employment Handbook, all employees must fully comply with supervisors' instructions and standard operating protocols.

Please be advised that further infractions of this nature will lead to severe disciplinary actions, up to and including the immediate termination of your employment contract under MoM regulations.

Sincerely,

**Senthil Kumar**
Admin & HR Manager
Mountec Pte. Ltd.`
      },
      {
        title: "Official Employment Confirmation Letter Template",
        description: "Official template to certify a worker's active employment and salary details.",
        fileName: "mountec_employment_confirmation.docx",
        size: "90 KB",
        content: `### TEMPLATE: CERTIFICATION OF ACTIVE EMPLOYMENT
**Mountec Pte. Ltd.**

**Date:** [Date]
**To Whom It May Concern**

**Subject: Verification of Employment & Income**

This letter is to formally confirm that **[Employee Name]** is an active full-time employee of Mountec Pte. Ltd. 

Details of employment are as follows:
- **Date of Commencement:** [Start Date]
- **Current Position:** [Job Title]
- **Work Permit / Fin No:** [FIN/NRIC]
- **Current Monthly Basic Salary:** SGD [Basic Salary]
- **Monthly Housing Allowance:** SGD [Allowance, if any]

[Employee Name] is a valued member of our technical crew and has demonstrated excellent work performance and strong commitment.

Should you require any further validation or information, please contact our administrative desk at +65 6789 0123 or info@mountec.com.sg.

Sincerely,

**Kartik Vicky**
Managing Director
Mountec Pte. Ltd.`
      }
    ],
    '1.4.2': [
      {
        title: "Safety Protocol Adherence Memo",
        description: "Company-wide internal memo emphasizing mandatory helmet and harness protocols at all construction locations.",
        fileName: "mountec_memo_safety_adherence.pdf",
        size: "120 KB",
        content: `### INTERNAL MEMORANDUM
**Mountec Pte. Ltd.**

**TO:** All Site Supervisors, Engineers, and Field Crews
**FROM:** Senthil Kumar (Admin & HR Manager)
**DATE:** June 15, 2026
**SUBJECT: STRICT ADHERENCE TO SITE SAFETY & PERSONAL PROTECTIVE EQUIPMENT (PPE)**

It has been observed during recent surprise safety audits that a few crew members were operating at height without securely anchoring their full-body double-lanyard harnesses, or failed to wear their safety helmets inside marked operational zones.

Please read and implement the following rules immediately:
1. **Mandatory Helmet Use:** Helmets must be worn and chin straps secured at all times while on-site.
2. **Double Lanyard Harness:** Mandatory for any work performed at a height of 2 meters or above.
3. **Supervisor Responsibility:** Site supervisors will be held directly accountable for any safety violations committed under their shift.

Non-compliance with these safety standards will result in immediate suspension from the site and a mandatory deduction of project safety bonuses.

Let us keep our workplace safe and accident-free.

**CC:** Kartik Vicky (Managing Director)`
      }
    ],
    '1.4.3': [
      {
        title: "Monthly Safety Review Board Minutes (June 2026)",
        description: "Detailed records of the latest safety committee meeting, site hazard assessments, and policy revisions.",
        fileName: "mountec_meeting_minutes_june_2026.pdf",
        size: "140 KB",
        content: `### MINUTES OF THE MONTHLY SAFETY BOARD MEETING
**Mountec Pte. Ltd. Safety & Operations Committee**

**Date:** June 5, 2026  
**Time:** 09:30 AM - 11:00 AM  
**Venue:** Midview City Head Office, Meeting Room A  

#### Attendees:
1. Kartik Vicky (Managing Director - Chairperson)
2. Senthil Kumar (Admin & HR Manager)
3. Site Safety Supervisor
4. Lead Piping Coordinator

#### Agenda:
1. Review of incident logs from May 2026.
2. Audit of scaffold certifications.
3. Distribution timeline for new high-visibility vests.

#### Discussion Summary:
- **Incident Logs:** Zero reportable major injuries or site delays in May. Kudos to the field crews!
- **Scaffold safety:** Site supervisor reported that all ongoing scaffolds have been certified by professional engineers and labeled with green "SAFE FOR USE" tags.
- **New PPE vests:** Delivery of high-visibility breathable vests with Mountec logo is scheduled for June 12. Senthil to coordinate distribution to dormitory supervisors.

**Next Meeting:** July 3, 2026.`
      }
    ],
    '1.5.1': [
      {
        title: "Worker Welfare and Accommodation Standards Guidelines",
        description: "Guidelines on worker transportation, nutrition provisions, and recreational arrangements.",
        fileName: "mountec_worker_welfare_standards.pdf",
        size: "160 KB",
        content: `### WORKER WELFARE AND ACCOMMODATION STANDARDS
**Mountec Corporate Social Responsibility & Compliance**

Mountec Pte. Ltd. is dedicated to providing superior living and working conditions for our valued workforce:

1. **Safe Transport Services**
   - All worker transport vehicles (lorries/buses) must be clean, regularly inspected, and fitted with rain canopies and proper bench seating.
   - Strictly adhere to Singapore LTA maximum passenger capacity limits.

2. **Dormitory Welfare & Cleanliness**
   - Provide clean drinking water dispensers and adequate kitchen equipment in all dormitory rooms.
   - Weekly vector control and pest cleaning audits are conducted by the Admin team.

3. **Mental Well-being & Grievances**
   - Confidential grievance hotlines are shared on all notice boards.
   - Quarterly recreational gatherings and festive meals are organized to promote solidarity.`
      }
    ],
    '1.5.2': [
      {
        title: "Letter of Offer & Agreement (LOA) Standard Template",
        description: "Standard contract template for construction workers and pipefitters under Singapore MoM guidelines.",
        fileName: "mountec_loa_template_construction.pdf",
        size: "240 KB",
        content: `### STANDARD EMPLOYMENT LETTER OF OFFER & AGREEMENT
**Mountec Pte. Ltd. (UEN: 202128795G)**

This Employment Agreement is entered into between **Mountec Pte. Ltd.** ("the Employer") and the undersigned employee ("the Employee") under the following terms:

1. **Job Designation & Responsibilities**
   The Employee shall be appointed as **Structural Welder / Pipe Fitter** and will report directly to the assigned Site Supervisor.

2. **Basic Salary & Allowances**
   - **Basic Salary:** SGD [Amount] per month (based on 44 hours per week).
   - **Overtime Pay:** Computed at 1.5x basic hourly rate in compliance with MoM regulations.
   - **Housing & Transport:** Provided directly by the Employer.

3. **Termination Notice**
   Either party may terminate this agreement by giving [14 days / 1 month] notice in writing or by paying equivalent basic salary in lieu of notice.`
      }
    ],
    '1.5.3': [
      {
        title: "Worker Onboarding Dossier & Particulars Form",
        description: "Form used to collect foreign worker details, emergency contacts, and medical backgrounds.",
        fileName: "mountec_worker_onboarding_form.pdf",
        size: "110 KB",
        content: `### FOREIGN WORKER PARTICULARS & ONBOARDING DOSSIER
**Mountec Pte. Ltd. Registry Record**

*This information must be fully compiled and filed within 3 days of worker arrival in Singapore.*

#### 1. Personal Particulars:
- **Full Name (as in Passport):** ___________________________
- **Passport Number:** __________________ | **Expiry Date:** ___________
- **Work Permit Number:** ________________ | **FIN Number:** ____________
- **Date of Birth:** ____________ | **Nationality:** __________________

#### 2. Emergency Contacts:
- **Next of Kin Name:** _____________________ | **Relationship:** ___________
- **Contact Number (Overseas):** _______________________________________
- **Home Country Address:** ___________________________________________

#### 3. Medical Background:
- **Blood Group:** _____ | **Allergies:** __________________________________
- **Pre-existing Medical Conditions:** _________________________________`
      }
    ],
    '1.5.4': [
      {
        title: "Monthly Payroll Computation and Salary Disbursal SOP",
        description: "Guidelines on itemized payslips, CPF contributions, and bank giro transfers.",
        fileName: "mountec_payroll_disbursal_sop.pdf",
        size: "135 KB",
        content: `### SOP: MONTHLY PAYROLL COMPUTATION & DISBURSAL
**SOP Code:** SOP-HR-003 | **Revision:** v1.5

1. **Timesheet Submission & Verification**
   - All site supervisors must submit workers' daily timesheets (including overtime records) by the 25th of each month.
   - HR Admin Senthil Kumar verifies OT calculations against approved project logs.

2. **Salary Calculation Formula**
   - \`Gross Pay = Monthly Basic Salary + Overtime Pay (1.5x rate) + Approved Reimbursements - CPF Employee Contribution (if local)\`.
   - Itemized payslips must be printed and delivered to employees on or before pay day.

3. **Bank Disbursal Timeline**
   - GIRO transfers must be scheduled to reach employees' POSB/DBS bank accounts no later than the 7th of the following month.`
      }
    ],
    '1.5.5': [
      {
        title: "Leave Application and Sick Leave (MC) Policy Handbook",
        description: "Submission timelines, supervisor review hierarchy, and tracking records.",
        fileName: "mountec_leave_mc_policy.pdf",
        size: "115 KB",
        content: `### LEAVE APPLICATION & MEDICAL CERTIFICATE (MC) POLICY
**Mountec Pte. Ltd. HR Policy Guide**

1. **Annual Leave Submission**
   - Apply for planned annual leaves at least **7 working days** in advance via the HR form.
   - Subject to site operational manpower constraints and supervisor sign-off.

2. **Sick Leave & Urgent MCs**
   - In case of sudden illness, notify the Site Coordinator before the start of shift.
   - Medical Certificates (MC) must be obtained from standard registered polyclinics or panels.
   - Submit a scanned copy of the MC within **48 hours** of returning to duty. MCs from traditional/unlicensed practitioners are invalid.`
      }
    ],
    '1.5.5.1': [
      {
        title: "Foreign Worker Levy Waiver Application Procedure",
        description: "Step-by-step instructions for filing levy waiver claims on the CPF/MoM portal during worker hospitalization or home leave.",
        fileName: "mountec_fw_levy_waiver_guidelines.pdf",
        size: "180 KB",
        content: `### LEVY WAIVER APPLICATION PROCEDURES
**Foreign Workforce Admin Guidelines**

Mountec can apply for a waiver of Foreign Worker Levy payments under specific circumstances:

1. **Eligibility Criteria for Levy Waiver**
   - **Home Leave:** Worker goes back to home country on approved leave for at least 7 consecutive days (Passport exit/entry stamps required).
   - **Hospitalization Leave:** Worker is hospitalized on medical leave (WICA / hospital admission logs mandatory).

2. **Filing Timeline & Evidence**
   - Apply on the CPF portal (e-Submit Levy Waiver) by the **15th of the following month** once the waiver criteria are met.
   - Prepare clean scanned PDF uploads of the worker's passport page showing Singapore departure and arrival stamps.`
      }
    ],
    '1.5.6': [
      {
        title: "Work Injury Compensation Act (WICA) Insurance Policy",
        description: "Coverage details, claim reporting deadlines, and incident logs.",
        fileName: "mountec_wica_insurance_policy.pdf",
        size: "250 KB",
        content: `### WORK INJURY COMPENSATION INSURANCE (WICA) SUMMARY
**Mountec Corporate Insurance Profile**

1. **Legal Scope of Coverage**
   - In compliance with Singapore WICA regulations, all field workers, welders, and coordinators are fully covered for injuries sustained during working hours on active construction sites.

2. **Critical Reporting Timelines**
   - site supervisor must report any injury, no matter how minor, to the safety officer immediately.
   - MoM iReport must be filed within **10 days** if the accident results in hospitalization or medical leave of more than 3 days.

3. **Insurable Benefits**
   - Medical treatment expenses up to SGD 45,000.
   - Compensation for temporary incapacity (MC wages) and permanent incapacity.`
      }
    ],
    '1.5.6.1': [
      {
        title: "MOM Primary Care Plan (PCP) Onboarding Guide",
        description: "Instructions on registering foreign workers to primary healthcare plans with designated medical centers.",
        fileName: "mountec_mom_pcp_onboarding.pdf",
        size: "145 KB",
        content: `### PRIMARY CARE PLAN (PCP) REGISTRATION GUIDE
**MoM Foreign Healthcare Regulations Compliance**

1. **Overview of Primary Care Plan**
   - From April 2022, employers must buy a Primary Care Plan (PCP) for Work Permit holders living in dormitories or working in marine/construction industries.
   - Designated Sector healthcare partner is **Anchor Care Clinics Network**.

2. **Onboarding Action Steps**
   - [ ] Access MoM FWMOMCare system.
   - [ ] Enroll newly arrived workers into the PCP zone within 14 days.
   - [ ] Print and hand over Anchor Care enrollment cards to the workers.`
      }
    ],
    '1.5.6.2': [
      {
        title: "Group Hospitalization & Surgical Insurance Guide",
        description: "Policy handbook detailing coverage details, co-pay options, and clinic network lists.",
        fileName: "mountec_group_medical_insurance.pdf",
        size: "210 KB",
        content: `### GROUP HOSPITALIZATION & SURGICAL INSURANCE
**Mountec Employee Benefits Handbook**

1. **Co-pay & Annual Limits**
   - Group policy provides up to **SGD 15,000** coverage per worker per year for inpatient hospital treatments.
   - In accordance with recent regulatory revisions, a 15% co-sharing scheme applies for elective surgeries.

2. **Authorized Panel Clinic Network**
   - General consultations can be sought at any **Raffles Medical** or **Q&M Medical** outlet across Singapore.
   - Site crew must present their digital insurance membership barcode at the counter to enjoy cashless consultations.`
      }
    ],
    '1.5.7': [
      {
        title: "Continuous Skills Development and Performance Strategy",
        description: "Structure for regular performance evaluations and technical training pathways.",
        fileName: "mountec_skills_development_strategy.pdf",
        size: "125 KB",
        content: `### SKILLS DEVELOPMENT & TRAINING STRATEGY
**Mountec Workforce Competence Framework**

1. **Objectives**
   - Enhance welding certifications (e.g., 3G/4G/6G structural welding standards).
   - Promote junior pipe fitters to coordinators and team leads.

2. **Evaluation Cycle**
   - Technical supervisors conduct peer reviews every 6 months.
   - High-performing workers are sponsored for specialized training courses.

3. **Funding Support**
   - Leverage Singapore BCA and SkillsFuture employer grants to subside course fees.`
      }
    ],
    '1.5.7.1': [
      {
        title: "Mandatory Safety Orientation Courses (CSOC) Tracker",
        description: "Onboarding course registration guidelines and certification requirements for metalworking and construction sites.",
        fileName: "mountec_csoc_courses_guidelines.pdf",
        size: "155 KB",
        content: `### MANDATORY SITE SAFETY COURSES & CERTIFICATIONS
**Workplace Safety & Health Training Registry**

All field workers operating on Mountec projects must possess valid safety passes:

1. **Construction Safety Orientation Course (CSOC)**
   - Mandatory for all laborers and pipefitters prior to site entry.
   - Retraining and certificate renewal are required every **2 years** or **4 years** (depending on worker's years of service).

2. **Work At Height (WAH) Course**
   - Required for mechanical crews operating boomlifts or working on high scaffolds.
   
3. **Tracking & Compliance**
   - Admin team maintains a master digital ledger of safety pass expiry dates. No worker is allowed onto a project site if their safety pass is within 30 days of expiry.`
      }
    ],
    '1.5.8': [
      {
        title: "Worker Uniform and PPE Allocation Guidelines",
        description: "Distribution cycle, replacement policies, and sizing charts for safety vest and boot allocations.",
        fileName: "mountec_uniform_ppe_guidelines.pdf",
        size: "90 KB",
        content: `### UNIFORM & PPE ALLOCATION GUIDELINES
**Mountec Site Operations Logistics**

1. **Standard Uniform Allocation Package**
   - **First Arrival:** 3 Sets of Navy Blue Cotton Uniforms, 1 Industrial Safety Helmet (Yellow for workers, White for supervisors), 1 pair of steel-toed boots.
   - **Regular Distribution:** 2 replacement uniforms are issued every **6 months**.

2. **Replacement Policies**
   - Damaged safety boots can be replaced free-of-charge if inspected and signed-off by the Safety Supervisor as worn out due to normal operational wear.
   - Negligent loss of helmet or safety vests will incur a replacement fee of SGD 15.00 deducted from the welfare allowance.`
      }
    ],
    '1.5.9': [
      {
        title: "Project Milestones Incentive and Safety Bonus Scheme",
        description: "Criteria for performance-based bonuses, safety-first rewards, and tenure incentives.",
        fileName: "mountec_incentive_bonus_scheme.pdf",
        size: "130 KB",
        content: `### INCENTIVE & PERFORMANCE BONUS SCHEME
**Mountec Field Motivation Program**

1. **Monthly Safety Bonus**
   - SGD 50.00 cash bonus paid to teams with **Zero safety infractions** and perfect toolbox meeting attendance over the month.

2. **Project Completion Incentives**
   - Disbursed upon successful client sign-off on piping or structural works with zero delays.
   - Shared proportionally among core team members based on site supervisor assessments.

3. **Tenure Loyalty Incentives**
   - Workers with more than 3 years of continuous service are eligible for tenure bonus adjustments.`
      }
    ],
    '1.5.10': [
      {
        title: "Key Performance Indicators (KPIs) for Site Crews",
        description: "Safety compliance, project timelines adherence, punctuality, and peer review assessment metrics.",
        fileName: "mountec_kpi_performance_indicators.pdf",
        size: "115 KB",
        content: `### WORKER KEY PERFORMANCE INDICATORS (KPIS)
**Mountec Performance Management Standards**

Workers are evaluated across four core key areas:

1. **Safety Compliance (40% Weightage)**
   - Full PPE compliance, no safety warning letters, proactive reporting of site hazards.

2. **Work Quality & Technical Skill (30% Weightage)**
   - Precision in welding/fitting, low rate of inspection weld-rejections, care of tools.

3. **Punctuality & Attendance (20% Weightage)**
   - Less than 2 days of unplanned urgent leaves per year, timely arrival at morning briefings.

4. **Teamwork & Conduct (10% Weightage)**
   - Cooperative attitude with site supervisors and co-workers.`
      }
    ],
    '1.6.1': [
      {
        title: "Approved Dormitory Housing Tenancy Agreement Guide",
        description: "Rules, hygiene requirements, room allocations, and landlord agreements for approved worker accommodations.",
        fileName: "mountec_dormitory_tenancy_agreement.pdf",
        size: "320 KB",
        content: `### DORMITORY HOUSING TENANCY AGREEMENT GUIDE
**Mountec Approved Worker Accommodations**

All workers residing in company-leased dormitory slots must strictly abide by the following housing regulations:

1. **Cleanliness & Hygiene**
   - Rooms must be kept clean, swept, and rubbish disposed of daily.
   - Washing of personal clothes must only be done in designated laundry bays.

2. **Safety & Security Protocols**
   - Cooking of meals is strictly forbidden inside sleeping rooms (only use communal kitchen areas).
   - Strict curfew hours: No unauthorized visitors are allowed in rooms after 10:00 PM.

3. **Conduct & Disputes**
   - Physical fights, consumption of illicit substances, or loud noises will result in immediate termination of dormitory leases and repatriation.`
      }
    ],
    '1.7': [
      {
        title: "Annual Employee Satisfaction Survey Questionnaire",
        description: "Questions regarding workplace safety, housing standards, transport comfort, and compensation satisfaction.",
        fileName: "mountec_staff_satisfaction_survey.pdf",
        size: "95 KB",
        content: `### ANNUAL WORKFORCE SATISFACTION SURVEY
**Mountec Internal Feedback Channel**

*Your responses are strictly confidential. We evaluate your feedback to make Mountec a safer and better place to work.*

#### Please rate the following on a scale of 1 to 5 (1=Poor, 5=Excellent):

1. **Workplace Safety & Training Support**
   - Safety equipment quality: [ ]
   - Effectiveness of morning toolbox briefings: [ ]

2. **Accommodation & Living Standards**
   - Dormitory comfort and cleanliness: [ ]
   - Quality of transport vehicles: [ ]

3. **Welfare & Team Communication**
   - Ease of communication with Admin Senthil Kumar: [ ]
   - Overall salary fairness and disbursal punctuality: [ ]`
      }
    ],
    '1.8': [
      {
        title: "Mountec Annual Safety Gala & Dinner Event Program",
        description: "Agenda, award ceremony schedules, and safety-first recognition plans for the upcoming company gala.",
        fileName: "mountec_safety_gala_program.pdf",
        size: "110 KB",
        content: `### MOUNTEC ANNUAL SAFETY GALA & DINNER 2026
**Event Program & Scheduling Outline**

**Date:** December 18, 2026  
**Venue:** Grand Ballroom, Orchid Country Club  

#### Event Schedule:
- **06:30 PM:** Guest Arrival & Registration of Site Crews.
- **07:00 PM:** Opening Address by Managing Director **Kartik Vicky**.
- **07:30 PM:** Standard buffet dinner presentation & video highlight reel of 2026 engineering projects.
- **08:30 PM:** **Annual Safety Excellence Awards Ceremony**:
  - *Best Safety Minded Team Award*
  - *Long Service Contribution Awards*
- **09:30 PM:** Lucky Draw & Photo Sessions.
- **10:00 PM:** Transport pick-up back to worker dormitories.`
      }
    ],
    '1.9': [
      {
        title: "Administrative Overhead and Utility Expenses Budget 2026",
        description: "Budget allocation for office rental, cloud subscription fees, vehicle maintenance, and print services.",
        fileName: "mountec_admin_overhead_budget_2026.pdf",
        size: "165 KB",
        content: `### ADMINISTRATIVE OVERHEAD & UTILITIES BUDGET 2026
**Mountec Corporate Finance Allocation**

#### Estimated Annual Overhead Breakdown (SGD):

1. **Head Office Rental & Maintenance (Midview City)**
   - Monthly Rental: $4,500 | Annual Total: $54,000
   
2. **IT Subscriptions & Cloud Databases**
   - Google Workspace, Firebase Hosting, Sheets Integration: $2,800/year.
   
3. **Transport Vehicles & Fuel Overhead**
   - Site trucks maintenance, diesel allowances, ERP charges: $18,500/year.

4. **Office Consumables & Professional Services**
   - Printing, professional audit clearances, safety certification licensing: $12,000/year.

**Total Approved Overhead Allocation:** SGD 87,300.00`
      }
    ]
  };

  const getDocIcon = (category: string) => {
    if (category.startsWith('1.1.1')) return <FileText className="w-4 h-4 text-emerald-400" />;
    if (category.startsWith('1.1.2')) return <Network className="w-4 h-4 text-amber-400" />;
    if (category.startsWith('1.1.3')) return <Briefcase className="w-4 h-4 text-blue-400" />;
    if (category.startsWith('1.2.1')) return <CheckSquare className="w-4 h-4 text-pink-400" />;
    if (category.startsWith('1.2.2')) return <FileCode className="w-4 h-4 text-indigo-400" />;
    if (category.startsWith('1.2.3')) return <Image className="w-4 h-4 text-violet-400" />;
    if (category.startsWith('1.2.4')) return <Share2 className="w-4 h-4 text-rose-400" />;
    
    // Extended categories
    if (category.startsWith('1.3')) return <Database className="w-4 h-4 text-teal-400" />;
    if (category.startsWith('1.4')) return <FileText className="w-4 h-4 text-orange-400" />;
    if (category.startsWith('1.5')) return <Users className="w-4 h-4 text-blue-400" />;
    if (category.startsWith('1.6')) return <Folder className="w-4 h-4 text-violet-400" />;
    if (category.startsWith('1.7')) return <CheckSquare className="w-4 h-4 text-pink-400" />;
    if (category.startsWith('1.8')) return <Calendar className="w-4 h-4 text-amber-400" />;
    if (category.startsWith('1.9')) return <Sparkles className="w-4 h-4 text-rose-400" />;
    
    return <FileText className="w-4 h-4 text-gray-400" />;
  };

  const getDocColorClass = (category: string) => {
    if (category.startsWith('1.1.1')) return 'border-emerald-500/20 hover:border-emerald-500/50';
    if (category.startsWith('1.1.2')) return 'border-amber-500/20 hover:border-amber-500/50';
    if (category.startsWith('1.1.3')) return 'border-blue-500/20 hover:border-blue-500/50';
    if (category.startsWith('1.2.1')) return 'border-pink-500/20 hover:border-pink-500/50';
    if (category.startsWith('1.2.2')) return 'border-indigo-500/20 hover:border-indigo-500/50';
    if (category.startsWith('1.2.3')) return 'border-violet-500/20 hover:border-violet-500/50';
    if (category.startsWith('1.2.4')) return 'border-rose-500/20 hover:border-rose-500/50';
    
    // Extended categories
    if (category.startsWith('1.3')) return 'border-teal-500/20 hover:border-teal-500/50';
    if (category.startsWith('1.4')) return 'border-orange-500/20 hover:border-orange-500/50';
    if (category.startsWith('1.5')) return 'border-blue-500/20 hover:border-blue-500/50';
    if (category.startsWith('1.6')) return 'border-violet-500/20 hover:border-violet-500/50';
    if (category.startsWith('1.7')) return 'border-pink-500/20 hover:border-pink-500/50';
    if (category.startsWith('1.8')) return 'border-amber-500/20 hover:border-amber-500/50';
    if (category.startsWith('1.9')) return 'border-rose-500/20 hover:border-rose-500/50';
    
    return 'border-[#333] hover:border-blue-500/30';
  };

  // Google Sheet database synchronization mechanics
  const normalizeData = (values: string[][]) => {
    const maxCols = Math.max(...values.map(r => r.length));
    return values.map(row => {
        const newRow = [...row];
        while(newRow.length < maxCols) newRow.push('');
        return newRow;
    });
  };

  const updateParsedWorkers = (dataValues: string[][]) => {
    if (!dataValues || dataValues.length === 0) return;
    const headers = dataValues[0];
    const nameIndex = headers.findIndex(h => h.toLowerCase().includes('name'));
    const roleIndex = headers.findIndex(h => h.toLowerCase().includes('role') || h.toLowerCase().includes('position'));
    const statusIndex = headers.findIndex(h => h.toLowerCase().includes('status'));
    
    const parsedWorkers: Worker[] = dataValues.slice(1).map((row, index) => ({
      id: `w-${index}`,
      name: nameIndex >= 0 ? row[nameIndex] : row[0] || 'Unknown',
      role: roleIndex >= 0 ? row[roleIndex] : row[1] || 'Worker',
      status: statusIndex >= 0 ? (row[statusIndex] as any) : 'Active'
    }));
    
    setWorkers(parsedWorkers);
  };

  const fetchSheetData = async () => {
    if (!sheetId) {
      setError('Please enter a Google Sheet ID');
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      let token = await getAccessToken(true);
      
      if (!token) {
        try {
          const { googleSignIn } = await import('../../../lib/firebase');
          const result = await googleSignIn(true);
          if (result && result.accessToken) {
            token = result.accessToken;
          } else {
            throw new Error('Authentication succeeded but no access token was returned.');
          }
        } catch (authErr: any) {
          throw new Error(`Not authenticated. Sign in failed: ${authErr?.message || 'Unknown'}`);
        }
      }
      
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetRange}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        const errMsg = errData.error?.message || 'Failed to fetch spreadsheet data';
        if (response.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click SYNC again to sign in and authorize.');
        }
        throw new Error(errMsg);
      }
      
      const data: SpreadsheetData = await response.json();
      
      if (!data.values || data.values.length === 0) {
        throw new Error('No data found in the specified range');
      }
      
      const normalized = normalizeData(data.values);
      await updateRawData(normalized, true);
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const saveSheetData = async (dataToSave?: string[][]) => {
    if (!sheetId) return;
    
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
      autoSaveTimerRef.current = null;
    }
    latestDataRef.current = null;
    setIsPendingSave(false);
    
    const data = dataToSave || rawData;
    setSaving(true);
    setError('');
    
    try {
      let token = await getAccessToken(true);
      
      if (!token) {
        try {
          const { googleSignIn } = await import('../../../lib/firebase');
          const result = await googleSignIn(true);
          if (result && result.accessToken) {
            token = result.accessToken;
          } else {
            throw new Error('Authentication succeeded but no access token was returned.');
          }
        } catch (authErr: any) {
          throw new Error(`Not authenticated. Sign in failed: ${authErr?.message || 'Unknown'}`);
        }
      }
      
      const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheetRange}?valueInputOption=USER_ENTERED`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          range: sheetRange,
          majorDimension: 'ROWS',
          values: data
        })
      });
      
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        const errMsg = errData.error?.message || 'Failed to save spreadsheet data';
        if (response.status === 401 || errMsg.toLowerCase().includes('invalid credentials') || errMsg.toLowerCase().includes('auth')) {
          const { clearCachedToken } = await import('../../../lib/firebase');
          clearCachedToken();
          throw new Error('Your Google session has expired or is invalid. Please click SYNC again to sign in and authorize.');
        }
        throw new Error(errMsg);
      }
      
      await updateRawData(data, true);
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    const newData = [...rawData];
    newData[rowIndex] = [...newData[rowIndex]];
    newData[rowIndex][colIndex] = value;
    
    // Auto-calculate work duration if employment date or exit date changes
    if (colIndex === 6 || colIndex === 22) {
       const empDate = newData[rowIndex][6];
       const exitDate = newData[rowIndex][22];
       if (empDate) {
          const start = new Date(empDate);
          const end = exitDate ? new Date(exitDate) : new Date();
          if (!isNaN(start.getTime())) {
            const diffTime = Math.abs(end.getTime() - start.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            const diffMonths = (diffDays / 30.4).toFixed(2);
            newData[rowIndex][23] = diffMonths;
          }
       }
    }
    
    // Update locally instantly
    updateRawData(newData, false);
    
    // Schedule 1-second auto save
    latestDataRef.current = newData;
    setIsPendingSave(true);
    
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }
    
    autoSaveTimerRef.current = setTimeout(async () => {
      if (latestDataRef.current) {
        setIsPendingSave(false);
        await saveSheetData(latestDataRef.current);
        latestDataRef.current = null;
      }
    }, 1000);
  };

  const addRow = async () => {
    if (rawData.length === 0) return;
    setFilterSearch('');
    setFilterNationality('all');
    setFilterStatus('all');
    setFilterSearchCol('all');
    
    const newRow = new Array(rawData[0].length).fill('');
    const newData = [...rawData, newRow];
    await updateRawData(newData, true);
    saveSheetData(newData);
  };

  const deleteColumn = async (colIndex: number) => {
    if (rawData.length === 0) return;
    const colName = rawData[0][colIndex] || `Column ${colIndex + 1}`;
    const confirmed = window.confirm(`Are you sure you want to delete the column "${colName}"?`);
    if (!confirmed) return;

    // Reset filters since columns are changing
    setFilterSearch('');
    setFilterNationality('all');
    setFilterStatus('all');
    setFilterSearchCol('all');

    const newData = rawData.map(row => {
      const newRow = [...row];
      newRow.splice(colIndex, 1);
      return newRow;
    });

    await updateRawData(newData, true);
    saveSheetData(newData);
  };

  const toggleFolder = (folderId: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [folderId]: !prev[folderId]
    }));
  };

  // Filter current active category items
  const isGlobalSearch = searchQuery.trim().length > 0;
  
  const activePreloaded = isGlobalSearch 
    ? Object.entries(preloadedDocuments).flatMap(([categoryId, docs]) => docs.map(d => ({...d, category: categoryId})))
    : (preloadedDocuments[selectedFolderId] || []).map(d => ({...d, category: selectedFolderId}));
    
  const activeCustom = isGlobalSearch
    ? customDocs
    : customDocs.filter(d => d.category === selectedFolderId);

  const combinedDocs = [
    ...activePreloaded.map(d => ({ id: `sys-${d.fileName}`, uploadedBy: 'System Preload', createdAt: 1718000000, ...d, isPreloaded: true })),
    ...activeCustom.map(d => ({ ...d, isPreloaded: false }))
  ].filter(doc => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    doc.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
    doc.fileName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // We need to find the column indices for Nationality and WP/S Pass Status dynamically
  const headers = rawData[0] || [];
  const nationalityColIndex = headers.findIndex(h => {
    const norm = h.trim().toLowerCase().replace(/\s+/g, ' ');
    return norm === 'nationality' || norm.includes('nationality');
  });
  const statusColIndex = headers.findIndex(h => {
    const norm = h.trim().toLowerCase().replace(/\s+/g, ' ');
    return norm === 'wp/s pass status' || norm === 'pass status' || norm.includes('pass status');
  });

  // Dynamic filter lists
  const uniqueNationalities = React.useMemo(() => {
    if (rawData.length <= 1 || nationalityColIndex === -1) return [];
    const set = new Set<string>();
    for (let i = 1; i < rawData.length; i++) {
      const val = rawData[i][nationalityColIndex];
      if (val && val.trim()) {
        set.add(val.trim());
      }
    }
    return Array.from(set).sort();
  }, [rawData, nationalityColIndex]);

  const uniqueStatuses = React.useMemo(() => {
    if (rawData.length <= 1 || statusColIndex === -1) return [];
    const set = new Set<string>();
    for (let i = 1; i < rawData.length; i++) {
      const val = rawData[i][statusColIndex];
      if (val && val.trim()) {
        set.add(val.trim());
      }
    }
    return Array.from(set).sort();
  }, [rawData, statusColIndex]);

  // Apply filters and sorting
  const filteredRowsWithIndex = React.useMemo(() => {
    const rows = rawData.slice(1).map((row, idx) => ({
      row,
      originalIndex: idx + 1
    }));

    const filtered = rows.filter(({ row }) => {
      // 1. Nationality Filter
      if (filterNationality !== 'all' && nationalityColIndex !== -1) {
        const rowVal = (row[nationalityColIndex] || '').trim();
        if (rowVal !== filterNationality) return false;
      }

      // 2. Status Filter
      if (filterStatus !== 'all' && statusColIndex !== -1) {
        const rowVal = (row[statusColIndex] || '').trim();
        if (rowVal.toUpperCase() !== filterStatus.toUpperCase()) return false;
      }

      // 3. Search Query
      if (filterSearch.trim()) {
        const queryStr = filterSearch.toLowerCase().trim();
        if (filterSearchCol === 'all') {
          // search across all columns
          return row.some(cell => (cell || '').toLowerCase().includes(queryStr));
        } else {
          // search in a specific column index
          const cellVal = row[filterSearchCol as number] || '';
          return cellVal.toLowerCase().includes(queryStr);
        }
      }

      return true;
    });

    // 4. Sorting (Ascending / Descending)
    if (sortColIndex !== null && sortDirection !== null) {
      filtered.sort((a, b) => {
        const valA = (a.row[sortColIndex] || '').trim();
        const valB = (b.row[sortColIndex] || '').trim();

        // Custom check for numeric values
        const isNumeric = (val: string) => /^-?\d+(\.\d+)?$/.test(val);
        const aIsNum = isNumeric(valA);
        const bIsNum = isNumeric(valB);

        if (aIsNum && bIsNum) {
          const parsedA = parseFloat(valA);
          const parsedB = parseFloat(valB);
          return sortDirection === 'asc' ? parsedA - parsedB : parsedB - parsedA;
        }

        return sortDirection === 'asc'
          ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' })
          : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: 'base' });
      });
    }

    return filtered;
  }, [rawData, filterSearch, filterNationality, filterStatus, filterSearchCol, nationalityColIndex, statusColIndex, sortColIndex, sortDirection]);

  return (
    <div className="flex flex-col gap-6 min-h-[calc(100vh-10rem)]">
      <div className="flex flex-col lg:flex-row gap-6 flex-1">
        {/* Directory Navigation Tree Sidebar */}
        <div className="w-full lg:w-72 bg-[#141414] border border-[#222] p-4 rounded-xl shadow-xl flex-shrink-0">
        <div className="flex items-center space-x-2 text-blue-500 border-b border-[#222] pb-3 mb-4">
          <FolderOpen className="w-5 h-5 shrink-0" />
          <span className="font-bold uppercase tracking-widest text-xs">Directory Explorer</span>
        </div>
        
        <div className="space-y-2 text-xs">
          {/* Main Root Folder Node */}
          <div className="font-bold text-gray-400 px-2 py-1 uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center">
              <Folder className="w-4 h-4 mr-2 text-blue-500 shrink-0" />
              2. HUMAN CAPITAL MANAGEMENT
            </span>
          </div>

          <div className="pl-3 border-l border-[#222] space-y-1">
            {/* Folder 2.1 */}
            {/* Folder 2.3 */}
            <div>
              <button
                onClick={() => toggleFolder('2.3')}
                className="w-full text-left px-3 py-2 text-gray-300 hover:text-white hover:bg-[#1A1A1A] rounded flex items-center justify-between font-bold"
              >
                <span className="flex items-center truncate">
                  <Folder className="w-4 h-4 mr-2 text-blue-500 shrink-0" />
                  2.3_Forms, Templates & Logos
                </span>
                {expandedFolders['2.3'] ? <ChevronDown className="w-4 h-4 text-gray-500 shrink-0" /> : <ChevronRight className="w-4 h-4 text-gray-500 shrink-0" />}
              </button>

              {expandedFolders['2.3'] && (
                <div className="pl-4 ml-2 border-l border-blue-500/20 mt-1 space-y-1">
                  <button
                    onClick={() => setSelectedFolderId('2.3.1')}
                    className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between font-medium transition-colors ${
                      selectedFolderId === '2.3.1' 
                        ? 'bg-blue-500/10 border border-blue-500/20 text-blue-400' 
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <span className="flex items-center truncate">
                      <FileSpreadsheet className="w-3.5 h-3.5 mr-2 text-blue-500 shrink-0" />
                      2.3.1_All Releated Forms
                    </span>
                  </button>
                  <button
                    onClick={() => setSelectedFolderId('2.3.2')}
                    className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between font-medium transition-colors ${
                      selectedFolderId === '2.3.2' 
                        ? 'bg-blue-500/10 border border-blue-500/20 text-blue-400' 
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <span className="flex items-center truncate">
                      <FileSpreadsheet className="w-3.5 h-3.5 mr-2 text-blue-500 shrink-0" />
                      2.3.2_All Releated Templates
                    </span>
                  </button>
                  <button
                    onClick={() => setSelectedFolderId('2.3.3')}
                    className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between font-medium transition-colors ${
                      selectedFolderId === '2.3.3' 
                        ? 'bg-blue-500/10 border border-blue-500/20 text-blue-400' 
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <span className="flex items-center truncate">
                      <FileSpreadsheet className="w-3.5 h-3.5 mr-2 text-blue-500 shrink-0" />
                      2.3.3_All Releated Logos
                    </span>
                  </button>
                  <button
                    onClick={() => setSelectedFolderId('2.3.4')}
                    className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between font-medium transition-colors ${
                      selectedFolderId === '2.3.4' 
                        ? 'bg-blue-500/10 border border-blue-500/20 text-blue-400' 
                        : 'text-gray-400 hover:text-white hover:bg-[#1A1A1A]'
                    }`}
                  >
                    <span className="flex items-center truncate">
                      <FileSpreadsheet className="w-3.5 h-3.5 mr-2 text-blue-500 shrink-0" />
                      2.3.4_All Releated Advertisement
                    </span>
                  </button>
                </div>
              )}
            </div>

            {/* Folder 2.4 */}
            <div>
              <button
                onClick={() => toggleFolder('2.4')}
                className="w-full text-left px-3 py-2 text-gray-300 hover:text-white hover:bg-[#1A1A1A] rounded flex items-center justify-between font-bold"
              >
                <span className="flex items-center truncate">
                  <Folder className="w-4 h-4 mr-2 text-blue-500 shrink-0" />
                  2.4_BizSAFE & ISO CERTIFICATIONS
                </span>
                {expandedFolders['2.4'] ? <ChevronDown className="w-4 h-4 text-gray-500 shrink-0" /> : <ChevronRight className="w-4 h-4 text-gray-500 shrink-0" />}
              </button>
              {expandedFolders['2.4'] && (
                <div className="pl-4 ml-2 border-l border-blue-500/20 mt-1 space-y-1">
                  {['2.4.1', '2.4.2', '2.4.3'].map(id => (
                    <button key={id} onClick={() => setSelectedFolderId(id)} className={`w-full text-left px-3 py-1.5 rounded flex items-center ${selectedFolderId === id ? 'bg-blue-500/10 text-blue-400' : 'text-gray-400 hover:text-white'}`}>
                      <FileText className="w-3.5 h-3.5 mr-2 text-blue-500" />
                      {id === '2.4.1' && '2.4.1 Letters'}
                      {id === '2.4.2' && '2.4.2 Memo'}
                      {id === '2.4.3' && '2.4.3 Minutes of Meeting'}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Folder 2.5 */}
            <div>
              <button
                onClick={() => toggleFolder('2.5')}
                className="w-full text-left px-3 py-2 text-gray-300 hover:text-white hover:bg-[#1A1A1A] rounded flex items-center justify-between font-bold"
              >
                <span className="flex items-center truncate">
                  <Users className="w-4 h-4 mr-2 text-blue-500 shrink-0" />
                  2.5_Staff & Workers
                </span>
                {expandedFolders['2.5'] ? <ChevronDown className="w-4 h-4 text-gray-500 shrink-0" /> : <ChevronRight className="w-4 h-4 text-gray-500 shrink-0" />}
              </button>
              {expandedFolders['2.5'] && (
                <div className="pl-4 ml-2 border-l border-blue-500/20 mt-1 space-y-1">
                  {['2.5.1', '2.5.2', '2.5.3', '2.5.4', '2.5.5', '2.5.6', '2.5.7', '2.5.8', '2.5.9', '2.5.10'].map(id => (
                    <button key={id} onClick={() => setSelectedFolderId(id)} className={`w-full text-left px-3 py-1.5 rounded flex items-center ${selectedFolderId === id ? 'bg-blue-500/10 text-blue-400' : 'text-gray-400 hover:text-white'}`}>
                      <User className="w-3.5 h-3.5 mr-2 text-blue-500" />
                      {id === '2.5.1' && '2.5.1 Welfare Management'}
                      {id === '2.5.2' && '2.5.2 Recruitment/LOA'}
                      {id === '2.5.3' && '2.5.3 Particular & Info'}
                      {id === '2.5.4' && '2.5.4 Payroll'}
                      {id === '2.5.5' && '2.5.5 Leave & MC Record'}
                      {id === '2.5.6' && '2.5.6 Insurances'}
                      {id === '2.5.7' && '2.5.7 Development'}
                      {id === '2.5.8' && '2.5.8 Uniform'}
                      {id === '2.5.9' && '2.5.9 Incentive & Bonus'}
                      {id === '2.5.10' && '2.5.10 Performance Indicator'}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Folder 2.6 */}
            <div>
              <button
                onClick={() => toggleFolder('2.6')}
                className="w-full text-left px-3 py-2 text-gray-300 hover:text-white hover:bg-[#1A1A1A] rounded flex items-center justify-between font-bold"
              >
                <span className="flex items-center truncate">
                  <Folder className="w-4 h-4 mr-2 text-blue-500 shrink-0" />
                  2.6_Dormitory
                </span>
                {expandedFolders['2.6'] ? <ChevronDown className="w-4 h-4 text-gray-500 shrink-0" /> : <ChevronRight className="w-4 h-4 text-gray-500 shrink-0" />}
              </button>
              {expandedFolders['2.6'] && (
                <div className="pl-4 ml-2 border-l border-blue-500/20 mt-1 space-y-1">
                  <button onClick={() => setSelectedFolderId('2.6.1')} className={`w-full text-left px-3 py-1.5 rounded flex items-center ${selectedFolderId === '2.6.1' ? 'bg-blue-500/10 text-blue-400' : 'text-gray-400 hover:text-white'}`}>
                    <FileText className="w-3.5 h-3.5 mr-2 text-blue-500" />
                    2.6.1_Dormitory & Rooms Agreements
                  </button>
                </div>
              )}
            </div>

            </div>

          </div>
        </div>
      </div>

      {/* Main Workspace Pane */}
      <div className="flex-1 bg-[#141414] border border-[#222] p-6 rounded-xl shadow-xl overflow-hidden flex flex-col">
        {selectedFolderId === '2.5.3' ? (
          /* ========================================================= */
          /* 2.5.3 STAFF PARTICULAR SHEET EDITOR                        */
          /* ========================================================= */
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-[#222] pb-4">
              <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 flex items-center">
                <Database className="w-5 h-5 mr-2 shrink-0 text-blue-500" />
                STAFF AND WORKERS PARTICULAR INFORMATION
              </h2>
              {isViewOnly && (
                <div className="text-blue-500 font-bold bg-[#1A1A1A] px-3 py-1.5 rounded text-[10px] uppercase border border-[#333]">
                  VIEW ONLY MODE (READ-ONLY)
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0A0A0A] p-4 rounded-lg border border-[#222]">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <input
                    type="text"
                    value={sheetId}
                    onChange={(e) => setSheetId(e.target.value)}
                    placeholder="Enter Google Sheet ID"
                    className="bg-[#141414] border border-[#333] text-white rounded p-2 text-xs w-full sm:w-64 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    onClick={fetchSheetData}
                    disabled={loading}
                    className="flex items-center px-4 py-2 bg-[#1A1A1A] text-white border border-[#333] hover:border-blue-500 text-xs font-bold uppercase rounded transition-all whitespace-nowrap"
                  >
                    {loading ? <RefreshCw className="w-4 h-4 mr-2 animate-spin text-blue-500" /> : <RefreshCw className="w-4 h-4 mr-2 text-blue-500" />}
                    SYNC SHEET
                  </button>
                </div>

                {rawData.length > 0 && !isViewOnly && (
                  <div className="flex items-center gap-4">
                    {isPendingSave && (
                      <span className="text-[10px] text-yellow-500 font-bold tracking-wider animate-pulse uppercase flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-yellow-500 animate-ping shrink-0" />
                        CHANGES PENDING (AUTO-SAVING IN 1S)
                      </span>
                    )}
                    {saving && (
                      <span className="text-[10px] text-blue-400 font-bold tracking-wider uppercase flex items-center gap-1.5">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-500 shrink-0" />
                        AUTO-SAVING...
                      </span>
                    )}
                    {!isPendingSave && !saving && (
                      <span className="text-[10px] text-emerald-400 font-bold tracking-wider uppercase flex items-center gap-1">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        ALL CHANGES AUTO-SAVED
                      </span>
                    )}
                    <button
                      onClick={() => saveSheetData()}
                      disabled={saving || loading}
                      className="flex items-center px-4 py-2 bg-blue-600 text-black text-xs font-bold uppercase rounded-lg hover:bg-blue-500 disabled:opacity-50 transition-colors shrink-0"
                    >
                      {saving ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                      {saving ? 'SAVING...' : 'SAVE CHANGES'}
                    </button>
                  </div>
                )}
              </div>


              {error && (
                <div className="p-3 bg-red-950/30 border border-red-500/20 text-red-400 rounded-lg flex items-start text-xs">
                  <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* TABLE FILTER & SEARCH CONTROLS */}
              {rawData.length > 0 && (
                <div className="bg-[#0A0A0A] p-4 rounded-lg border border-[#222] space-y-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-2 border-b border-[#222]/50">
                    <div className="flex items-center space-x-2">
                      <span className="p-1 rounded bg-blue-500/10 text-blue-400">
                        <Filter className="w-4 h-4" />
                      </span>
                      <div>
                        <h3 className="text-xs font-bold text-white uppercase tracking-wider">TABLE FILTER CONTROLS</h3>
                        <p className="text-[10px] text-[#777] uppercase">
                          {filteredRowsWithIndex.length === rawData.length - 1 ? (
                            `SHOWING ALL ${rawData.length - 1} WORKERS`
                          ) : (
                            <span className="text-blue-400 font-semibold">
                              SHOWING {filteredRowsWithIndex.length} OF {rawData.length - 1} WORKERS (FILTERS ACTIVE)
                            </span>
                          )}
                        </p>
                      </div>
                    </div>

                    {(filterSearch || filterNationality !== 'all' || filterStatus !== 'all') && (
                      <button
                        onClick={() => {
                          setFilterSearch('');
                          setFilterNationality('all');
                          setFilterStatus('all');
                          setFilterSearchCol('all');
                        }}
                        className="text-[10px] text-rose-400 hover:text-rose-300 font-bold uppercase flex items-center gap-1 transition-colors bg-rose-500/10 px-2.5 py-1 rounded border border-rose-500/20"
                      >
                        <X className="w-3 h-3" />
                        RESET FILTERS
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {/* Search Input */}
                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold text-[#777] uppercase tracking-wider">SEARCH TEXT</label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none">
                          <Search className="w-3.5 h-3.5 text-[#555]" />
                        </span>
                        <input
                          type="text"
                          value={filterSearch}
                          onChange={(e) => setFilterSearch(e.target.value)}
                          placeholder="Type to search..."
                          className="w-full bg-[#141414] border border-[#333] text-white rounded pl-8 pr-8 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                        />
                        {filterSearch && (
                          <button
                            onClick={() => setFilterSearch('')}
                            className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-[#555] hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Search Column Picker */}
                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold text-[#777] uppercase tracking-wider">SEARCH IN FIELD</label>
                      <select
                        value={filterSearchCol === 'all' ? 'all' : filterSearchCol}
                        onChange={(e) => {
                          const val = e.target.value;
                          setFilterSearchCol(val === 'all' ? 'all' : Number(val));
                        }}
                        className="w-full bg-[#141414] border border-[#333] text-white rounded p-1.5 text-xs focus:outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="all">All Columns</option>
                        {headers.map((h, idx) => {
                          // Skip empty headers or internal row index
                          if (!h || h === '5' || h.toLowerCase() === 's/no') return null;
                          return (
                            <option key={idx} value={idx}>
                              {h}
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    {/* Nationality Dropdown */}
                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold text-[#777] uppercase tracking-wider">NATIONALITY</label>
                      <select
                        value={filterNationality}
                        onChange={(e) => setFilterNationality(e.target.value)}
                        className="w-full bg-[#141414] border border-[#333] text-white rounded p-1.5 text-xs focus:outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="all">All Nationalities</option>
                        {uniqueNationalities.map((nat, idx) => (
                          <option key={idx} value={nat}>
                            {nat}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* WP/S Pass Status Dropdown */}
                    <div className="space-y-1">
                      <label className="block text-[9px] font-bold text-[#777] uppercase tracking-wider">PASS STATUS</label>
                      <select
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        className="w-full bg-[#141414] border border-[#333] text-white rounded p-1.5 text-xs focus:outline-none focus:border-blue-500 cursor-pointer"
                      >
                        <option value="all">All Statuses</option>
                        {uniqueStatuses.map((st, idx) => (
                          <option key={idx} value={st}>
                            {st.toUpperCase()}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {rawData.length > 0 && (
              <div className="flex flex-col sm:flex-row items-center justify-between bg-[#141414] border border-[#222] p-3 rounded-xl gap-3 text-xs">
                <div className="flex items-center gap-2 text-gray-400 font-bold uppercase tracking-wider shrink-0 select-none">
                  <FileSpreadsheet className="w-4 h-4 text-blue-500" />
                  <span>Horizontal Scroll Slider</span>
                </div>
                
                <div className="flex items-center gap-3 w-full sm:flex-1 sm:max-w-xl">
                  <button
                    type="button"
                    onClick={() => {
                      if (tableContainerRef.current) {
                        tableContainerRef.current.scrollBy({ left: -250, behavior: 'smooth' });
                      }
                    }}
                    className="p-2 rounded-lg bg-[#1A1A1A] hover:bg-[#252525] border border-[#333] hover:border-blue-500/50 text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm flex items-center justify-center shrink-0"
                    title="Slide Left"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="flex-1 flex items-center gap-2">
                    <span className="text-[10px] text-gray-500 font-mono tracking-wider font-bold">LEFT</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={scrollPercent}
                      onChange={(e) => {
                        const pct = Number(e.target.value);
                        setScrollPercent(pct);
                        if (tableContainerRef.current) {
                          const maxScroll = tableContainerRef.current.scrollWidth - tableContainerRef.current.clientWidth;
                          tableContainerRef.current.scrollLeft = (pct / 100) * maxScroll;
                        }
                      }}
                      className="w-full h-1.5 bg-[#222] rounded-lg appearance-none cursor-pointer accent-blue-500 focus:outline-none"
                    />
                    <span className="text-[10px] text-gray-500 font-mono tracking-wider font-bold">RIGHT</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (tableContainerRef.current) {
                        tableContainerRef.current.scrollBy({ left: 250, behavior: 'smooth' });
                      }
                    }}
                    className="p-2 rounded-lg bg-[#1A1A1A] hover:bg-[#252525] border border-[#333] hover:border-blue-500/50 text-gray-300 hover:text-white transition-all cursor-pointer shadow-sm flex items-center justify-center shrink-0"
                    title="Slide Right"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="hidden md:flex items-center gap-1.5 text-[10px] bg-blue-950/40 border border-blue-500/20 text-blue-400 px-3 py-1.5 rounded font-bold uppercase tracking-wider shrink-0 select-none">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
                  Quick-scroll active
                </div>
              </div>
            )}
            
            <div 
              ref={tableContainerRef}
              onScroll={() => {
                if (tableContainerRef.current) {
                  const { scrollLeft, scrollWidth, clientWidth } = tableContainerRef.current;
                  const maxScroll = scrollWidth - clientWidth;
                  if (maxScroll > 0) {
                    const pct = Math.round((scrollLeft / maxScroll) * 100);
                    setScrollPercent(pct);
                  } else {
                    setScrollPercent(0);
                  }
                }
              }}
              className={`border border-[#222] rounded-lg overflow-x-auto bg-[#0A0A0A] ${isViewOnly ? 'pointer-events-none opacity-90' : ''}`}
            >
              <table className="w-full text-left text-xs text-[#E0E0E0]">
                <thead className="bg-[#1A1A1A] text-[#777] border-b border-[#222]">
                  <tr>
                    <th className="px-3 py-2 font-bold uppercase text-[10px] tracking-wider border-r border-[#222] w-10">S/NO</th>
                    {rawData.length > 0 ? (
                      rawData[0].map((header, colIndex) => {
                        if (colIndex === 0 || colIndex === 1 || colIndex === 18) return null;
                        return (
                          <th key={colIndex} className="px-3 py-2 font-bold uppercase text-[10px] tracking-wider border-r border-[#222] last:border-r-0 group relative min-w-[120px]">
                            <div className="flex items-center justify-between gap-1.5 w-full">
                              <input 
                                type="text" 
                                value={header}
                                onChange={(e) => handleCellChange(0, colIndex, e.target.value)}
                                onBlur={() => saveSheetData()}
                                disabled={isViewOnly}
                                className="bg-transparent border-none text-blue-500 focus:ring-0 p-0 m-0 w-full font-bold uppercase focus:outline-none disabled:cursor-not-allowed"
                              />
                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (sortColIndex === colIndex) {
                                      if (sortDirection === 'asc') {
                                        setSortDirection('desc');
                                      } else if (sortDirection === 'desc') {
                                        setSortColIndex(null);
                                        setSortDirection(null);
                                      } else {
                                        setSortDirection('asc');
                                      }
                                    } else {
                                      setSortColIndex(colIndex);
                                      setSortDirection('asc');
                                    }
                                  }}
                                  title="Sort Column (Ascending / Descending)"
                                  className={`p-1 rounded hover:bg-[#222] transition-all cursor-pointer flex items-center justify-center ${
                                    sortColIndex === colIndex
                                      ? 'text-blue-400 bg-blue-500/10 opacity-100'
                                      : 'opacity-0 group-hover:opacity-100 text-gray-500 hover:text-gray-300'
                                  }`}
                                >
                                  {sortColIndex === colIndex ? (
                                    sortDirection === 'asc' ? <ArrowUp className="w-3.5 h-3.5" /> : <ArrowDown className="w-3.5 h-3.5" />
                                  ) : (
                                    <ArrowUpDown className="w-3.5 h-3.5" />
                                  )}
                                </button>
                                {!isViewOnly && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      deleteColumn(colIndex);
                                    }}
                                    title={`Delete column: ${header}`}
                                    className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-rose-500/20 text-gray-400 hover:text-rose-400 transition-all shrink-0 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </th>
                        );
                      })
                    ) : (
                      <th className="px-4 py-3 font-bold uppercase text-[10px] tracking-wider">No Data</th>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222]">
                  {rawData.length <= 1 ? (
                    <tr>
                      <td colSpan={Math.max(1, (rawData[0]?.length || 1) - 1)} className="px-4 py-8 text-center text-[#555]">
                        No worker data available. Sync from Google Sheets to populate this list.
                      </td>
                    </tr>
                  ) : filteredRowsWithIndex.length === 0 ? (
                    <tr>
                      <td colSpan={Math.max(1, (rawData[0]?.length || 1) - 1)} className="px-4 py-8 text-center text-[#666]">
                        No workers match the selected filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredRowsWithIndex.map(({ row, originalIndex }, index) => {
                      const statusVal = statusColIndex !== -1 ? (row[statusColIndex] || '').trim().toUpperCase() : '';
                      const isCancelled = statusVal === 'CANCELLED';
                      const isLive = statusColIndex !== -1 && (statusVal === 'LIVE' || statusVal === 'ACTIVE' || statusVal === '');
                      
                      const rowBgClass = isCancelled
                        ? 'bg-rose-950/25 hover:bg-rose-950/40'
                        : isLive
                          ? 'bg-emerald-950/15 hover:bg-emerald-950/25'
                          : 'hover:bg-[#111111]';

                      const textColorClass = isCancelled
                        ? 'text-rose-200'
                        : isLive
                          ? 'text-emerald-200'
                          : 'text-white';

                      return (
                        <tr key={originalIndex} className={`${rowBgClass} transition-colors ${textColorClass}`}>
                          {/* S/NO Column */}
                          <td className="px-3 py-2 border-r border-[#222]/50 text-gray-500 font-mono text-[10px] text-center w-10">
                            {index + 1}
                          </td>
                          {row.map((cell, colIndex) => {
                            if (colIndex === 0 || colIndex === 1 || colIndex === 18) return null;
                            const colHeaderNorm = (rawData[0]?.[colIndex] || '').trim().toLowerCase().replace(/\s+/g, ' ');
                            const isStatusCol = colHeaderNorm === 'wp/s pass status' || colHeaderNorm === 'pass status' || colHeaderNorm.includes('pass status');
                            return (
                              <td key={colIndex} className="p-0 border-r border-[#222]/50 last:border-r-0 focus-within:bg-black/30">
                                {isStatusCol ? (
                                  <select
                                    value={
                                      (cell || '').trim().toUpperCase() === 'CANCELLED' ? 'CANCELLED' : 
                                      ((cell || '').trim().toUpperCase() === 'PENDING ISSUANCE' || (cell || '').trim().toUpperCase() === 'PENDING ISSUANCE OF WP') ? 'PENDING ISSUANCE OF WP' : 
                                      'LIVE'
                                    }
                                    onChange={(e) => {
                                      const newValue = e.target.value;
                                      handleCellChange(originalIndex, colIndex, newValue);
                                      
                                      // Trigger auto save immediately
                                      const newData = [...rawData];
                                      newData[originalIndex] = [...newData[originalIndex]];
                                      newData[originalIndex][colIndex] = newValue;
                                      saveSheetData(newData);
                                    }}
                                    className={`w-full bg-transparent border-none focus:ring-1 focus:ring-blue-500 p-2 text-xs outline-none cursor-pointer font-bold uppercase ${
                                      (cell || '').trim().toUpperCase() === 'CANCELLED' ? 'text-rose-400' : 
                                      ((cell || '').trim().toUpperCase() === 'PENDING ISSUANCE' || (cell || '').trim().toUpperCase() === 'PENDING ISSUANCE OF WP') ? 'text-yellow-400' : 'text-emerald-400'
                                    }`}
                                  >
                                    <option value="LIVE" className="bg-[#141414] text-emerald-400 font-bold uppercase">LIVE</option>
                                    <option value="PENDING ISSUANCE OF WP" className="bg-[#141414] text-yellow-400 font-bold uppercase">PENDING ISSUANCE OF WP</option>
                                    <option value="CANCELLED" className="bg-[#141414] text-rose-400 font-bold uppercase">CANCELLED</option>
                                  </select>
                                ) : (
                                  <input
                                    type="text"
                                    value={cell}
                                    onChange={(e) => handleCellChange(originalIndex, colIndex, e.target.value)}
                                    onBlur={() => {
                                      saveSheetData();
                                    }}
                                    className={`w-full bg-transparent border-none focus:ring-1 focus:ring-blue-500 p-2 text-xs outline-none uppercase ${
                                      isCancelled ? 'text-rose-200 placeholder-rose-500/30' : isLive ? 'text-emerald-100 placeholder-emerald-500/30' : 'text-white'
                                    }`}
                                  />
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {rawData.length > 0 && !isViewOnly && (
              <div className="mt-4">
                <button
                  onClick={addRow}
                  className="px-4 py-2 bg-[#1A1A1A] text-[#999] border border-[#333] hover:text-white hover:border-[#444] rounded text-xs font-bold uppercase transition-colors"
                >
                  + Add Row
                </button>
              </div>
            )}
          </div>
        ) : (
          /* ========================================================= */
          /* DIRECTORY FOLDER VIEW (1.1.X AND 1.2.X)                  */
          /* ========================================================= */
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222] pb-4">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 flex items-center">
                  {getDocIcon(selectedFolderId)}
                  <span className="ml-2">
                    {selectedFolderId === '1.1.1' && '1.1.1_Company Policy Documents'}
                    {selectedFolderId === '1.1.2' && '1.1.2_Company Org Charts'}
                    {selectedFolderId === '1.1.3' && '1.1.3_SOP (Standard Operations Procedures)'}
                    {selectedFolderId === '2.3.1' && '2.3.1_All Releated Forms'}
                    {selectedFolderId === '2.3.2' && '2.3.2_All Releated Templates'}
                    {selectedFolderId === '2.3.3' && '2.3.3_All Releated Logos & Branding'}
                    {selectedFolderId === '2.3.4' && '2.3.4_All Releated Advertisement'}
                    {selectedFolderId === '1.3' && '1.3_Email, ID & Password Credentials'}
                    {selectedFolderId === '2.4.1' && '2.4.1_Letters'}
                    {selectedFolderId === '2.4.2' && '2.4.2_Memo'}
                    {selectedFolderId === '2.4.3' && '2.4.3_Minutes of Meeting'}
                    {selectedFolderId === '2.5.1' && '2.5.1_Staff & Workers Welfare Management'}
                    {selectedFolderId === '2.5.2' && '2.5.2_Staff & Workers Recruitment/LOA'}
                    {selectedFolderId === '2.5.3' && '2.5.3_Staff & Worker Particulars'}
                    {selectedFolderId === '2.5.4' && '2.5.4_Staff & Workers Payroll'}
                    {selectedFolderId === '2.5.5' && '2.5.5_Staff & Workers Leave & MC Record'}
                    {selectedFolderId === '2.5.5.1' && '2.5.5.1_FW Levy Waiver Record'}
                    {selectedFolderId === '2.5.6' && '2.5.6_Staff & Workers Insurances'}
                    {selectedFolderId === '2.5.6.1' && '2.5.6.1_Primary Care Plan (PCP)'}
                    {selectedFolderId === '2.5.6.2' && '2.5.6.2_Medical Insurances'}
                    {selectedFolderId === '2.5.7' && '2.5.7_Staff & Workers Development'}
                    {selectedFolderId === '2.5.7.1' && '2.5.7.1_Staff & Workers Courses'}
                    {selectedFolderId === '2.5.8' && '2.5.8_Staff & Workers Uniform'}
                    {selectedFolderId === '2.5.9' && '2.5.9_Staff & Workers Incentive & Bonus'}
                    {selectedFolderId === '2.5.10' && '2.5.10_Staff & Workers Performance Indicator'}
                    {selectedFolderId === '2.6.1' && '2.6.1_Dormitory & Rooms Agreements'}
                    {selectedFolderId === '1.7' && '1.7_Survey Related'}
                    {selectedFolderId === '1.8' && '1.8_Event & Gathering Related'}
                    {selectedFolderId === '1.9' && '1.9_Overhead Related'}
                  </span>
                </h2>
                <p className="text-[10px] text-gray-500 uppercase mt-1 tracking-wider">
                  Mountec Resource Registry Index
                </p>
              </div>

              {/* Upload New Document (Only for non-view-only users) */}
              {!isViewOnly && (
                <button
                  onClick={() => setShowUploadModal(true)}
                  className="flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-black text-xs font-bold uppercase rounded transition-colors self-start sm:self-center"
                >
                  <Upload className="w-3.5 h-3.5 mr-1.5" />
                  + Upload Document
                </button>
              )}
            </div>

            {/* Subfolder Search & stats bar */}
            <div className="flex items-center justify-end space-x-2 bg-[#0A0A0A] p-2 rounded-lg border border-[#222]">
              <span className="text-[10px] bg-[#1A1A1A] border border-[#333] px-2 py-1 text-gray-400 font-bold uppercase shrink-0 rounded">
                {combinedDocs.length} Files
              </span>
            </div>

            {/* Document List Cards */}
            <div className="flex-1 overflow-y-auto min-h-[300px] max-h-[500px] pr-2 space-y-3">
              {combinedDocs.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 bg-[#0A0A0A] border border-dashed border-[#222] rounded-xl text-center p-6">
                  <FileText className="w-10 h-10 text-[#333] mb-2" />
                  <p className="text-gray-500 text-xs font-bold uppercase">No Registry Files Found</p>
                  <p className="text-[10px] text-gray-600 mt-1 max-w-xs">There are no files match your search criteria. Click "+ Upload Document" to add one.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {combinedDocs.map((doc, idx) => (
                    <div
                      key={idx}
                      onClick={() => setSelectedDoc(doc)}
                      className={`group p-4 bg-[#0F0F0F] border ${getDocColorClass(doc.category || selectedFolderId)} rounded-xl cursor-pointer transition-all hover:bg-[#161616] flex flex-col justify-between`}
                    >
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-2">
                            {getDocIcon(doc.category || selectedFolderId)}
                            <span className="text-[10px] bg-[#1A1A1A] border border-[#222] text-gray-400 px-1.5 py-0.5 rounded font-mono">
                              {doc.isPreloaded ? 'SYSTEM' : 'CUSTOM'}
                            </span>
                          </div>
                          {!doc.isPreloaded && !isViewOnly && (
                            <button
                              onClick={(e) => handleDeleteDocument((doc as CustomDocument).id, e)}
                              className="p-1 rounded text-gray-500 hover:text-rose-500 hover:bg-rose-500/10 transition-colors"
                              title="Delete file"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <h3 className="text-xs font-bold text-white group-hover:text-blue-400 transition-colors line-clamp-1 leading-snug">
                          {doc.title}
                        </h3>
                        <p className="text-[10px] text-gray-400 line-clamp-2">
                          {doc.description}
                        </p>
                      </div>

                      <div className="border-t border-[#1F1F1F] mt-3 pt-3 flex items-center justify-between text-[9px] text-gray-500 font-medium">
                        <span className="flex items-center truncate max-w-[120px]">
                          <Info className="w-3 h-3 mr-1 text-gray-600 shrink-0" />
                          <span className="truncate">{doc.fileName}</span>
                        </span>
                        <div className="flex items-center space-x-2 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSharingDoc(doc);
                            }}
                            className="p-1 rounded text-gray-400 hover:text-amber-400 hover:bg-amber-400/10 transition-colors"
                            title="Share document"
                          >
                            <Share2 className="w-3 h-3 text-amber-500" />
                          </button>
                          <span className="font-mono text-gray-400">{doc.size}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* UPLOAD NEW DOCUMENT DIALOG MODAL                         */}
      {/* ========================================================= */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-[#222] rounded-xl w-full max-w-lg p-6 shadow-2xl relative">
            <h3 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-4 flex items-center">
              <Upload className="w-5 h-5 mr-2 text-blue-500" />
              Upload Document to Registry
            </h3>

            <form onSubmit={handleUploadDocument} className="space-y-4">
              {/* Drag and Drop Zone */}
              <div 
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  const files = e.dataTransfer.files;
                  if (files && files.length > 0) {
                    const file = files[0];
                    setNewDocFileName(file.name);
                    setNewDocTitle(file.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " "));
                    const formattedSize = file.size > 1024 * 1024 
                      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
                      : `${(file.size / 1024).toFixed(0)} KB`;
                    setNewDocSize(formattedSize);
                    
                    if (file.type.startsWith('image/')) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        if (event.target?.result) {
                          setNewDocContent(event.target.result as string);
                        }
                      };
                      reader.readAsDataURL(file);
                    } else {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        if (event.target?.result) {
                          setNewDocContent(event.target.result as string);
                        }
                      };
                      reader.readAsText(file.slice(0, 15000));
                    }
                  }
                }}
                className={`border-2 border-dashed rounded-lg p-5 text-center cursor-pointer transition-all ${
                  isDragging 
                    ? 'border-blue-500 bg-blue-500/10' 
                    : 'border-[#333] hover:border-blue-500 bg-[#0A0A0A]'
                }`}
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = '.pdf,.dwg,.xlsx,.xls,.docx,.doc,.png,.jpg,.jpeg';
                  input.onchange = (e: any) => {
                    const files = e.target.files;
                    if (files && files.length > 0) {
                      const file = files[0];
                      setNewDocFileName(file.name);
                      setNewDocTitle(file.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " "));
                      const formattedSize = file.size > 1024 * 1024 
                        ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
                        : `${(file.size / 1024).toFixed(0)} KB`;
                      setNewDocSize(formattedSize);
                      
                      if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          if (event.target?.result) {
                            setNewDocContent(event.target.result as string);
                          }
                        };
                        reader.readAsDataURL(file);
                      } else {
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          if (event.target?.result) {
                            setNewDocContent(event.target.result as string);
                          }
                        };
                        reader.readAsText(file.slice(0, 15000));
                      }
                    }
                  };
                  input.click();
                }}
              >
                <div className="flex flex-col items-center justify-center space-y-2">
                  <Upload className="w-8 h-8 text-blue-500" />
                  <p className="text-xs font-semibold text-gray-300">
                    Drag & Drop File Here, or <span className="text-blue-500 underline">Browse</span>
                  </p>
                  <p className="text-[10px] text-gray-500">
                    Supports PDF, DWG, XLSX, DOCX, JPG/PNG up to 15MB
                  </p>
                  {newDocFileName && (
                    <div className="mt-2 bg-[#1A1A1A] border border-[#333] px-3 py-1.5 rounded flex items-center space-x-2 text-[11px] text-emerald-400">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="truncate max-w-[200px] font-mono">{newDocFileName}</span>
                      <span className="text-gray-500">({newDocSize})</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Document Title</label>
                  <input
                    type="text"
                    required
                    value={newDocTitle}
                    onChange={e => setNewDocTitle(e.target.value)}
                    placeholder="e.g., Leave Policy Update"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">File Name</label>
                  <input
                    type="text"
                    required
                    value={newDocFileName}
                    onChange={e => setNewDocFileName(e.target.value)}
                    placeholder="e.g., policy_rev_2026.pdf"
                    className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Brief Description</label>
                <input
                  type="text"
                  value={newDocDesc}
                  onChange={e => setNewDocDesc(e.target.value)}
                  placeholder="e.g., Official updated employment standards for Mountec."
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#777] uppercase tracking-wider mb-1">Document Content (Text/Markdown Preview)</label>
                <textarea
                  value={newDocContent}
                  onChange={e => setNewDocContent(e.target.value)}
                  placeholder="Enter the text content of your document for preview (or let it auto-fill on upload)..."
                  rows={4}
                  className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 text-xs focus:outline-none focus:border-blue-500 resize-none font-mono"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowUploadModal(false);
                    setNewDocTitle('');
                    setNewDocDesc('');
                    setNewDocContent('');
                    setNewDocFileName('');
                    setNewDocSize('120 KB');
                  }}
                  className="px-4 py-2 bg-[#1A1A1A] text-[#999] border border-[#333] rounded hover:text-white text-xs font-bold uppercase transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-black rounded text-xs font-bold uppercase transition-colors"
                >
                  Confirm Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* CORE DOCUMENT WORKSPACE/READER DIALOG MODAL              */}
      {/* ========================================================= */}
      {selectedDoc && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-black rounded-xl w-full max-w-4xl p-8 my-8 shadow-2xl relative print:p-0 print:border-none print:shadow-none print:my-0">
            
            {/* Header info bar - Hidden in Print */}
            <div className="flex items-center justify-between border-b border-gray-200 pb-4 mb-6 print:hidden">
              <div className="flex items-center space-x-3">
                <span className="p-2 rounded bg-blue-50 text-blue-600">
                  {getDocIcon(selectedFolderId)}
                </span>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600">MOUNTEC PTE LTD REGISTRY</p>
                  <p className="text-xs text-gray-500 font-medium">Index Reference: Folder {selectedFolderId}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => window.print()}
                  className="flex items-center px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold uppercase rounded transition-colors"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  Print File
                </button>
                <button
                  onClick={() => setSharingDoc(selectedDoc)}
                  className="flex items-center px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5 mr-1.5" />
                  Share File
                </button>
                <button
                  onClick={() => {
                    const blob = new Blob([selectedDoc.content || ''], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = selectedDoc.fileName;
                    link.click();
                  }}
                  className="flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  <Download className="w-3.5 h-3.5 mr-1.5" />
                  Download
                </button>
                <button
                  onClick={() => {
                    setSelectedDoc(null);
                    setLeaveSubmitted(false);
                  }}
                  className="px-3 py-1.5 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold uppercase rounded transition-colors"
                >
                  Close
                </button>
              </div>
            </div>

            {/* DOCUMENT CANVAS CONTAINER */}
            <div className="min-h-[500px] flex flex-col justify-between">
              
              {/* INTERACTIVE COMPONENT: 1.1.2 COMPANY ORGANIZATIONAL CHART */}
              {selectedDoc.interactiveType === 'org_chart' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b-2 border-gray-900">
                    <h1 className="text-2xl font-black uppercase tracking-tight">MOUNTEC PTE. LTD.</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Official Company Hierarchy Organizational Tree</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">As of Year 2026</p>
                  </div>

                  <div className="py-6 flex flex-col items-center select-text">
                    {/* Level 1: MD */}
                    <div className="flex flex-col items-center">
                      <div className="p-4 bg-gray-900 text-white rounded-lg shadow-md border-2 border-blue-500 text-center min-w-[200px] hover:scale-105 transition-transform">
                        <p className="text-xs font-black uppercase text-blue-400 tracking-wider">Managing Director</p>
                        <p className="text-sm font-bold mt-1">Kartik Vicky</p>
                        <p className="text-[10px] text-gray-400 mt-0.5 font-mono">mountecstorage@gmail.com</p>
                      </div>
                      
                      {/* Line down */}
                      <div className="w-1 h-6 bg-gray-300"></div>
                    </div>

                    {/* Level 2: Division Heads */}
                    <div className="w-full max-w-3xl flex items-start justify-center relative">
                      {/* Horizontal connecting line */}
                      <div className="absolute top-0 left-[16%] right-[16%] h-1 bg-gray-300"></div>

                      <div className="grid grid-cols-3 gap-6 w-full pt-6 relative">
                        
                        {/* Admin / HR Manager */}
                        <div className="flex flex-col items-center">
                          <div className="absolute top-0 left-[16.6%] w-1 h-6 bg-gray-300"></div>
                          <div className="p-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm text-center w-full max-w-[180px]">
                            <p className="text-[10px] font-black uppercase text-amber-600 tracking-wider">Admin & HR division</p>
                            <p className="text-xs font-bold text-gray-800 mt-1">Senthil Kumar</p>
                            <p className="text-[9px] text-gray-400 font-medium">mountec2021</p>
                          </div>
                          <div className="w-1 h-6 bg-gray-300"></div>
                        </div>

                        {/* Operations Manager */}
                        <div className="flex flex-col items-center">
                          <div className="absolute top-0 left-[50%] w-1 h-6 bg-gray-300"></div>
                          <div className="p-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm text-center w-full max-w-[180px] border-l-4 border-l-blue-500">
                            <p className="text-[10px] font-black uppercase text-blue-600 tracking-wider">Operations supervisor</p>
                            <p className="text-xs font-bold text-gray-800 mt-1">Site Supervisor</p>
                            <p className="text-[9px] text-gray-400 font-medium">PM / Coordinator</p>
                          </div>
                          <div className="w-1 h-6 bg-gray-300"></div>
                        </div>

                        {/* HSE / Safety Division */}
                        <div className="flex flex-col items-center">
                          <div className="absolute top-0 left-[83.3%] w-1 h-6 bg-gray-300"></div>
                          <div className="p-3 bg-gray-50 border border-gray-300 rounded-lg shadow-sm text-center w-full max-w-[180px] border-l-4 border-l-emerald-500">
                            <p className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">HSE / Safety officer</p>
                            <p className="text-xs font-bold text-gray-800 mt-1">Safety Supervisor</p>
                            <p className="text-[9px] text-gray-400 font-medium">Toolbox Conductors</p>
                          </div>
                          <div className="w-1 h-6 bg-gray-300"></div>
                        </div>

                      </div>
                    </div>

                    {/* Level 3: Workers list dynamically mapped from state */}
                    <div className="w-full border-t border-dashed border-gray-200 mt-8 pt-6 flex flex-col items-center">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4 flex items-center">
                        <Users className="w-4 h-4 mr-1 text-blue-500 shrink-0" />
                        Active Site Workers & Field Crew (LIVE Status)
                      </h4>

                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 w-full">
                        {workers.filter(w => {
                          const s = (w.status || '').toString().trim().toUpperCase();
                          return s === 'LIVE' || s === 'ACTIVE' || s === '';
                        }).length === 0 ? (
                          <div className="col-span-full py-4 text-center text-gray-400 text-xs italic bg-gray-50 rounded">
                            No active workers logged in spreadsheet particulars.
                          </div>
                        ) : (
                          workers.filter(w => {
                            const s = (w.status || '').toString().trim().toUpperCase();
                            return s === 'LIVE' || s === 'ACTIVE' || s === '';
                          }).map((worker, wid) => (
                            <div key={wid} className="p-2.5 bg-white border border-gray-200 rounded-lg shadow-xs flex items-center space-x-2 hover:bg-gray-50 hover:border-blue-300 transition-colors">
                              <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center font-bold text-xs text-blue-600 uppercase shrink-0">
                                {worker.name.substring(0, 2)}
                              </div>
                              <div className="truncate text-left">
                                <p className="text-xs font-bold text-gray-800 truncate leading-tight">{worker.name}</p>
                                <p className="text-[9px] text-gray-400 truncate mt-0.5">{worker.role || 'Field Crew'}</p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: 1.2.1 LEAVE APPLICATION FORM */}
              {selectedDoc.interactiveType === 'form_leave' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b-2 border-gray-900">
                    <h1 className="text-2xl font-black uppercase tracking-tight">MOUNTEC PTE. LTD.</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Staff Annual / Medical Leave Application Form</p>
                  </div>

                  {leaveSubmitted ? (
                    <div className="py-12 flex flex-col items-center justify-center text-center bg-green-50 border border-green-200 rounded-xl max-w-lg mx-auto">
                      <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 mb-4">
                        <Check className="w-6 h-6" />
                      </div>
                      <h3 className="text-lg font-bold text-green-800 uppercase tracking-wide">Application Submitted Successfully</h3>
                      <p className="text-xs text-green-600 max-w-xs mt-1">Your leave application has been logged and routed to Admin Senthil Kumar & MD Kartik Vicky for review.</p>
                      
                      <div className="bg-white border border-green-200 p-4 rounded-lg mt-6 text-left text-xs text-gray-700 space-y-2 min-w-[300px]">
                        <p><strong>Employee:</strong> {leaveName || user?.email?.split('@')[0] || 'System User'}</p>
                        <p><strong>Leave Category:</strong> {leaveType}</p>
                        <p><strong>Date Range:</strong> {leaveStart} to {leaveEnd}</p>
                        <p><strong>Reason:</strong> {leaveReason || 'Not Specified'}</p>
                      </div>

                      <button
                        onClick={() => {
                          setLeaveSubmitted(false);
                          setLeaveName('');
                          setLeaveStart('');
                          setLeaveEnd('');
                          setLeaveReason('');
                        }}
                        className="mt-6 px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-xs font-bold uppercase rounded transition-colors"
                      >
                        Submit Another Form
                      </button>
                    </div>
                  ) : (
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        setLeaveSubmitted(true);
                      }} 
                      className="max-w-xl mx-auto space-y-4 bg-gray-50 p-6 rounded-xl border border-gray-200 text-xs"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Employee Name</label>
                          <input
                            type="text"
                            required
                            value={leaveName}
                            onChange={e => setLeaveName(e.target.value)}
                            placeholder="Your Name"
                            className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Leave Type</label>
                          <select
                            value={leaveType}
                            onChange={e => setLeaveType(e.target.value)}
                            className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                          >
                            <option value="Annual Leave">Annual Leave</option>
                            <option value="Medical Leave (MC)">Medical Leave (MC)</option>
                            <option value="Hospitalization Leave">Hospitalization Leave</option>
                            <option value="Unpaid Leave">Unpaid Urgent Leave</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Start Date</label>
                          <input
                            type="date"
                            required
                            value={leaveStart}
                            onChange={e => setLeaveStart(e.target.value)}
                            className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">End Date</label>
                          <input
                            type="date"
                            required
                            value={leaveEnd}
                            onChange={e => setLeaveEnd(e.target.value)}
                            className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Reason / Remarks</label>
                        <textarea
                          required
                          value={leaveReason}
                          onChange={e => setLeaveReason(e.target.value)}
                          placeholder="Please provide the operational reason for this leave request..."
                          rows={3}
                          className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500 resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold uppercase rounded tracking-wider transition-colors"
                      >
                        Submit Leave Application
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* INTERACTIVE COMPONENT: 1.2.1 EXPENSE & OVERTIME CLAIM SHEET */}
              {selectedDoc.interactiveType === 'form_claim' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b-2 border-gray-900">
                    <h1 className="text-2xl font-black uppercase tracking-tight">MOUNTEC PTE. LTD.</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Staff Overtime & Expense Claim Submission Portal</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
                    {/* Add Claim Form */}
                    <div className="bg-gray-50 p-5 rounded-xl border border-gray-200 space-y-4">
                      <h4 className="font-bold uppercase tracking-wider text-gray-700 border-b pb-2">Log New Claim Expense</h4>
                      
                      <div>
                        <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Category</label>
                        <select
                          value={claimCategory}
                          onChange={e => setClaimCategory(e.target.value)}
                          className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                        >
                          <option value="Transport">Transport (Site travel)</option>
                          <option value="Hardware/Tools">Equipment & Mechanical Tools</option>
                          <option value="PPE Gear">Safety PPE replacement</option>
                          <option value="OT Meal Allowance">Overtime Meal Allowance</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Amount (SGD)</label>
                        <input
                          type="number"
                          value={claimAmount}
                          onChange={e => setClaimAmount(e.target.value)}
                          placeholder="e.g., 45.00"
                          className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-600 uppercase tracking-wider mb-1">Description</label>
                        <textarea
                          value={claimDesc}
                          onChange={e => setClaimDesc(e.target.value)}
                          placeholder="Enter brief purchase detail..."
                          rows={2}
                          className="w-full bg-white border border-gray-300 rounded p-2 text-xs focus:outline-none focus:border-blue-500 resize-none"
                        />
                      </div>

                      <button
                        onClick={() => {
                          if (!claimAmount || isNaN(parseFloat(claimAmount))) return;
                          setClaimsList([...claimsList, {
                            category: claimCategory,
                            amount: parseFloat(claimAmount),
                            desc: claimDesc || 'Unspecified'
                          }]);
                          setClaimAmount('');
                          setClaimDesc('');
                        }}
                        className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold uppercase rounded transition-colors"
                      >
                        + Add To Claim list
                      </button>
                    </div>

                    {/* Claim summary */}
                    <div className="space-y-4">
                      <h4 className="font-bold uppercase tracking-wider text-gray-700 border-b pb-2">Active Claim Sheet Summary</h4>
                      
                      <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
                        <table className="w-full text-left">
                          <thead className="bg-gray-100 border-b">
                            <tr>
                              <th className="p-2 font-bold uppercase tracking-wider text-[9px] text-gray-500">Category</th>
                              <th className="p-2 font-bold uppercase tracking-wider text-[9px] text-gray-500">Description</th>
                              <th className="p-2 font-bold uppercase tracking-wider text-[9px] text-gray-500 text-right">Amount</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {claimsList.map((c, i) => (
                              <tr key={i} className="hover:bg-gray-50">
                                <td className="p-2 font-bold text-gray-800">{c.category}</td>
                                <td className="p-2 text-gray-500">{c.desc}</td>
                                <td className="p-2 font-mono font-bold text-right text-gray-900">${c.amount.toFixed(2)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      <div className="flex items-center justify-between bg-gray-900 text-white p-4 rounded-lg font-bold text-sm">
                        <span>TOTAL CLAIM AMOUNT:</span>
                        <span className="font-mono text-blue-400">${claimsList.reduce((sum, c) => sum + c.amount, 0).toFixed(2)}</span>
                      </div>

                      <button
                        onClick={() => {
                          alert('Claim sheet successfully submitted to accounts department.');
                          setClaimsList([]);
                        }}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold uppercase rounded tracking-wider transition-colors"
                      >
                        Confirm digital Submission
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: 1.2.2 LETTERHEAD TEMPLATE PREVIEW */}
              {selectedDoc.interactiveType === 'template_letterhead' && (
                <div className="space-y-6">
                  <div className="p-12 border-2 border-gray-300 rounded-lg bg-white relative max-w-2xl mx-auto select-text shadow-sm">
                    {/* Official Letterhead */}
                    <div className="flex justify-between items-center border-b-2 border-gray-900 pb-4 mb-8">
                      <div>
                        <h1 className="text-2xl font-black uppercase text-gray-900 tracking-tight leading-none">MOUNTEC PTE. LTD.</h1>
                        <div className="text-left text-[8px] text-gray-400 leading-normal mt-1.5 font-semibold">
                          <p>Office Address: Blk 28 Sin Ming Lane #04-138</p>
                          <p>Midview City, Singapore 573972</p>
                          <p>Uen No: 202128795G | Email: info@mountec.com.sg</p>
                        </div>
                      </div>
                      <div className="flex items-center shrink-0">
                        <MountecLogo className="w-16 h-16" />
                      </div>
                    </div>

                    {/* Letter skeleton */}
                    <div className="space-y-4 text-xs text-gray-800 leading-relaxed min-h-[250px]">
                      <p className="text-right font-mono text-[10px] text-gray-400">Date: {formatDate(new Date())}</p>
                      
                      <div className="space-y-1">
                        <p className="font-bold">To Whom It May Concern,</p>
                        <p className="text-gray-500">Recipient Designation / Address</p>
                      </div>

                      <p className="font-bold text-sm uppercase underline">Subject: OFFICIAL COMMUNICATION SUBJECT REGISTER</p>
                      
                      <p className="italic text-gray-400">[Enter letter content details here. Double click to select and edit this layout template in your word processor software.]</p>
                      <p>Mountec Pte Ltd prides itself on providing premier mechanical contracting, piping mobilization, and construction supervision across commercial sites in Singapore. Our engineering processes are fully certified to highest quality controls.</p>
                    </div>

                    {/* Letter footer */}
                    <div className="border-t border-gray-200 pt-4 mt-8 flex justify-between items-end">
                      <div className="text-[10px] leading-tight">
                        <p className="font-bold text-gray-900">Signed on behalf of Mountec,</p>
                        <div className="h-10"></div>
                        <p className="font-bold">Kartik Vicky</p>
                        <p className="text-gray-400">Managing Director</p>
                      </div>
                      <div className="text-center font-bold text-[8px] text-gray-400 uppercase tracking-widest bg-gray-50 px-3 py-1 rounded">
                        MOUNTEC QUALITY CONTROLS
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: 1.2.3 BRAND LOGOS SPEC SHEET */}
              {selectedDoc.interactiveType === 'brand_logos' && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b-2 border-gray-900">
                    <h1 className="text-2xl font-black uppercase tracking-tight">MOUNTEC PTE. LTD.</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Official Corporate Brand Logo & Graphic Specifications</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
                    {/* Visual Renderings */}
                    <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 flex flex-col items-center justify-center space-y-6">
                      
                      {/* Dark Variant */}
                      <div className="w-full bg-[#111111] p-6 rounded-lg border border-[#222] text-center">
                        <p className="text-[9px] text-[#555] font-bold uppercase tracking-wider mb-3 text-left">Dark Canvas Rendering</p>
                        <div className="flex items-center justify-center space-x-3">
                          <div className="w-10 h-10 bg-blue-500 flex items-center justify-center rounded-md font-black text-black shrink-0 text-xl">
                            M
                          </div>
                          <div className="text-left">
                            <h1 className="text-lg font-black text-white tracking-tight leading-none">MOUNTEC</h1>
                            <p className="text-[10px] text-blue-500 font-bold tracking-widest uppercase">PTE LTD</p>
                          </div>
                        </div>
                      </div>

                      {/* Light Variant */}
                      <div className="w-full bg-white p-6 rounded-lg border border-gray-200 text-center">
                        <p className="text-[9px] text-gray-400 font-bold uppercase tracking-wider mb-3 text-left">Light Canvas Rendering</p>
                        <div className="flex items-center justify-center space-x-3">
                          <div className="w-10 h-10 bg-blue-600 flex items-center justify-center rounded-md font-black text-white shrink-0 text-xl">
                            M
                          </div>
                          <div className="text-left">
                            <h1 className="text-lg font-black text-gray-900 tracking-tight leading-none">MOUNTEC</h1>
                            <p className="text-[10px] text-blue-600 font-bold tracking-widest uppercase">PTE LTD</p>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Branding Details */}
                    <div className="space-y-4">
                      <h4 className="font-bold uppercase tracking-wider text-gray-700 border-b pb-2">Primary Color Palettes</h4>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-white border border-gray-100 rounded-lg shadow-xs">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded bg-blue-500 border"></div>
                            <div>
                              <p className="font-bold text-gray-900">Mountec Core Blue</p>
                              <p className="font-mono text-[10px] text-gray-400">HEX #3B82F6 | RGB(59, 130, 246)</p>
                            </div>
                          </div>
                          <button onClick={() => navigator.clipboard.writeText('#3B82F6')} className="px-2 py-1 bg-gray-50 text-[10px] font-bold rounded hover:bg-gray-100 border">Copy</button>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-white border border-gray-100 rounded-lg shadow-xs">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 rounded bg-gray-900 border"></div>
                            <div>
                              <p className="font-bold text-gray-900">Slate Charcoal</p>
                              <p className="font-mono text-[10px] text-gray-400">HEX #111111 | RGB(17, 17, 17)</p>
                            </div>
                          </div>
                          <button onClick={() => navigator.clipboard.writeText('#111111')} className="px-2 py-1 bg-gray-50 text-[10px] font-bold rounded hover:bg-gray-100 border">Copy</button>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mt-6 text-gray-600 leading-normal text-xs">
                        <p className="font-bold uppercase tracking-wider text-gray-700 mb-2">Usage Guidelines:</p>
                        <p>1. Always maintain adequate padding spacing around the corporate logo equivalent to the height of the inner character 'M'.</p>
                        <p className="mt-2">2. Prefer the high-contrast white logo text rendering on dark charcoal canvases.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* STANDARD ADVERTISEMENT / PRELOADED GRAPHICS LAYOUT */}
              {selectedDoc.interactiveType?.startsWith('ad_') && (
                <div className="space-y-6">
                  <div className="text-center pb-4 border-b-2 border-gray-900">
                    <h1 className="text-2xl font-black uppercase tracking-tight">MOUNTEC PTE. LTD.</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Official Corporate Advertisement & Flyer Presentation</p>
                  </div>

                  <div className="p-8 bg-gray-900 text-white rounded-xl max-w-xl mx-auto shadow-md border-4 border-blue-500 select-text relative overflow-hidden">
                    {/* Ambient background accent */}
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full filter blur-xl"></div>
                    
                    <div className="space-y-4 text-center">
                      <div className="w-12 h-12 bg-blue-500 flex items-center justify-center rounded-md font-black text-black mx-auto text-xl">M</div>
                      <h2 className="text-xl font-black uppercase tracking-widest text-blue-400 mt-2">WE ARE HIRING CONTRACTORS</h2>
                      <p className="text-xs text-gray-300 font-medium">Mountec Pte Ltd is currently scaling operations across local marine & pipe-fitting projects in Singapore.</p>
                      
                      <div className="border-t border-b border-blue-500/30 py-4 my-6 text-left grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <p className="font-bold text-blue-400 uppercase">1. Structural Welders</p>
                          <p className="text-gray-400 text-[10px]">Piping Contractor Teams, MoM Work Pass Eligible.</p>
                        </div>
                        <div>
                          <p className="font-bold text-blue-400 uppercase">2. Pipe Fitters</p>
                          <p className="text-gray-400 text-[10px]">Experiencing in industrial mechanical plants.</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-xs text-gray-400 uppercase tracking-widest">How to Apply / Coordinate</p>
                        <p className="font-mono text-sm font-bold text-blue-400 bg-black/50 py-2 rounded">info@mountec.com.sg</p>
                        <p className="text-[10px] text-gray-500">Address: Blk 28 Sin Ming Lane #04-138 Midview City, Singapore 573972</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: ADVANCED PDF VIEWER (pdf_preview) */}
              {(selectedDoc.interactiveType === 'pdf_preview' || (!selectedDoc.interactiveType && selectedDoc.fileName.toLowerCase().endsWith('.pdf'))) && (
                <div className="space-y-4">
                  {/* PDF Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-gray-100 p-3 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3 text-xs">
                      <button 
                        type="button"
                        disabled={pdfPage <= 1}
                        onClick={() => setPdfPage(p => Math.max(1, p - 1))}
                        className="px-2 py-1 bg-white hover:bg-gray-50 border rounded shadow-xs text-gray-700 disabled:opacity-40"
                      >
                        Previous
                      </button>
                      <span className="font-medium">Page {pdfPage} of 3</span>
                      <button 
                        type="button"
                        disabled={pdfPage >= 3}
                        onClick={() => setPdfPage(p => Math.min(3, p + 1))}
                        className="px-2 py-1 bg-white hover:bg-gray-50 border rounded shadow-xs text-gray-700 disabled:opacity-40"
                      >
                        Next
                      </button>
                    </div>

                    <div className="flex items-center space-x-3 text-xs">
                      <button 
                        type="button"
                        onClick={() => setPdfZoom(z => Math.max(50, z - 25))}
                        className="p-1 text-gray-500 hover:text-gray-900"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <span className="font-mono">{pdfZoom}%</span>
                      <button 
                        type="button"
                        onClick={() => setPdfZoom(z => Math.min(200, z + 25))}
                        className="p-1 text-gray-500 hover:text-gray-900"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-2 text-xs w-full sm:w-auto">
                      <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <input 
                        type="text" 
                        value={pdfSearchQuery}
                        onChange={e => setPdfSearchQuery(e.target.value)}
                        placeholder="Search text in document..."
                        className="px-2 py-1 bg-white border border-gray-300 rounded text-xs focus:outline-none focus:border-blue-500 w-full sm:w-40 text-black"
                      />
                    </div>
                  </div>

                  {/* PDF Paper Sheet */}
                  <div className="bg-gray-500 p-8 rounded-lg border border-gray-600 max-h-[600px] overflow-y-auto flex justify-center">
                    <div 
                      style={{ transform: `scale(${pdfZoom / 100})`, transformOrigin: 'top center' }}
                      className="bg-white p-12 w-full max-w-2xl min-h-[750px] shadow-xl relative transition-transform duration-200 select-text text-gray-800 font-sans"
                    >
                      {/* Document Watermark */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
                        <p className="text-6xl font-black rotate-45 uppercase">MOUNTEC APPROVED</p>
                      </div>

                      {/* Header */}
                      <div className="flex justify-between items-center border-b border-gray-300 pb-4 mb-6">
                        <div>
                          <h4 className="text-sm font-black uppercase text-gray-950 tracking-tight">MOUNTEC CIVIL REGISTRY</h4>
                          <p className="text-[9px] text-blue-600 font-bold uppercase tracking-wider">SECURE DIGITAL WORKPLACE ARCHIVE</p>
                        </div>
                        <div className="text-right font-mono text-[9px] text-gray-400">
                          <p>REF: WP-REG-{selectedDoc.fileName.toUpperCase().slice(0, 6)}</p>
                          <p>CONFIDENTIALITY: HIGH</p>
                        </div>
                      </div>

                      {/* PDF Pages Routing */}
                      {pdfPage === 1 && (
                        <div className="space-y-4">
                          <h1 className="text-lg font-bold text-gray-900 uppercase border-b pb-1 tracking-tight">{selectedDoc.title}</h1>
                          <p className="text-xs text-gray-500 font-semibold italic uppercase">Document Abstract & General Profile</p>
                          
                          <div className="text-xs text-gray-700 leading-relaxed space-y-3">
                            <p className="font-semibold">1. OVERVIEW AND COMPLIANCE SPECIFICATIONS</p>
                            <p>This official dossier registers operational standards, regulatory rules, and administrative templates for Mountec mechanical workflows. All operations are strictly conducted under the Workplace Safety and Health Act (WSHA) in alignment with Ministry of Manpower guidelines.</p>
                            
                            <p className="font-semibold">2. ADMINISTRATIVE RECORDS AUDIT MATRIX</p>
                            <p>The documentation included herein represents standard templates, corporate guidelines, or uploaded personnel data. These records are subject to quarterly internal quality evaluations by the Admin Board headed by Kartik Vicky (MD) and Senthil Kumar (Admin Manager).</p>
                          </div>

                          <div className="p-4 bg-blue-50 border-l-4 border-blue-600 rounded-r-lg mt-6 text-xs text-gray-700">
                            <p className="font-bold text-blue-900 mb-1">Interactive Highlight Search</p>
                            {pdfSearchQuery ? (
                              <p>Searching for <span className="font-mono bg-yellow-200 px-1 text-black">"{pdfSearchQuery}"</span>... Highlight matches are highlighted on pages when found.</p>
                            ) : (
                              <p>Enter keywords in the toolbar search box above to scan throughout text assets.</p>
                            )}
                          </div>
                        </div>
                      )}

                      {pdfPage === 2 && (
                        <div className="space-y-4">
                          <h2 className="text-md font-bold text-gray-900 uppercase tracking-tight">PAGE 2: DOCUMENT DETAILS & CORE BODY CONTENT</h2>
                          <div className="border-b border-gray-200 pb-2 mb-2 text-xs font-mono text-gray-400">Section 2.1 - Core Details Data Log</div>

                          <div className="text-xs text-gray-700 space-y-4 leading-relaxed bg-gray-50 p-5 rounded-lg border border-gray-100">
                            {selectedDoc.content ? (
                              <p className="whitespace-pre-wrap">{selectedDoc.content}</p>
                            ) : (
                              <div className="space-y-2">
                                <p className="font-semibold uppercase text-gray-900">Document Contents Profile</p>
                                <p>Standard document structure preloaded for Mountec. This document contains corporate references and procedures. The metadata file format is verified as compliant with structural parsing standards.</p>
                                <p className="italic text-gray-500">Ensure any printed hardcopies of this document are properly shredded once they are no longer required for active site inspection logs.</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {pdfPage === 3 && (
                        <div className="space-y-6">
                          <h2 className="text-md font-bold text-gray-900 uppercase tracking-tight">PAGE 3: SIGN-OFF & DIGITAL CERTIFICATION</h2>
                          <p className="text-xs text-gray-600">The representatives below certify that the contents of this document are true, approved, and verified under Mountec Pte Ltd corporate registry guidelines.</p>

                          {/* Digital Signature Placeholders */}
                          <div className="grid grid-cols-2 gap-8 border-t border-gray-200 pt-8 text-xs">
                            <div className="space-y-1">
                              <p className="text-[10px] text-gray-400 font-bold uppercase">Prepared & Verified By</p>
                              <div className="h-10 flex items-center">
                                <span className="font-serif italic text-blue-800 border-b border-dashed border-gray-400 pb-1 text-lg">Senthil Kumar</span>
                              </div>
                              <p className="font-bold">Senthil Kumar</p>
                              <p className="text-gray-400">Admin & HR Manager</p>
                            </div>

                            <div className="space-y-1 relative">
                              <p className="text-[10px] text-gray-400 font-bold uppercase">Approved & Countersigned</p>
                              <div className="h-10 flex items-center">
                                {pdfSigned ? (
                                  <span 
                                    className={`text-lg text-blue-600 border-b border-dashed border-blue-400 pb-1 ${
                                      pdfSigFont === 'cursive' ? 'font-serif italic' : 'font-mono'
                                    }`}
                                  >
                                    {pdfSigText}
                                  </span>
                                ) : (
                                  <span className="text-gray-300 text-[10px] italic">Awaiting signature...</span>
                                )}
                              </div>
                              <p className="font-bold">Kartik Vicky</p>
                              <p className="text-gray-400">Managing Director</p>
                            </div>
                          </div>

                          {/* Interactive Digi-Sign Widget */}
                          <div className="bg-amber-50/50 p-4 rounded-lg border border-amber-500/20 mt-8 text-xs space-y-3">
                            <div className="flex items-center space-x-2 text-amber-800 font-bold">
                              <CheckSquare className="w-4 h-4 text-amber-600" />
                              <span>Mountec Secure Digi-Sign Tool</span>
                            </div>
                            <p className="text-[11px] text-amber-700">Type your initials or approval code to sign this PDF digitally before printing or sharing.</p>
                            <div className="flex items-center gap-3">
                              <input 
                                type="text" 
                                value={pdfSigText} 
                                onChange={e => {
                                  setPdfSigText(e.target.value);
                                  setPdfSigned(true);
                                }}
                                placeholder="Initials..."
                                className="px-2 py-1.5 bg-white border border-gray-300 rounded text-xs focus:outline-none w-20 text-black font-bold uppercase"
                              />
                              <select
                                value={pdfSigFont}
                                onChange={e => setPdfSigFont(e.target.value)}
                                className="px-2 py-1.5 bg-white border border-gray-300 rounded text-xs text-black"
                              >
                                <option value="cursive">Cursive Font</option>
                                <option value="mono">Technical Mono</option>
                              </select>
                              <button
                                type="button"
                                onClick={() => setPdfSigned(!pdfSigned)}
                                className={`px-4 py-1.5 rounded font-bold uppercase text-[10px] tracking-wider transition-colors ${
                                  pdfSigned 
                                    ? 'bg-rose-600 hover:bg-rose-500 text-white' 
                                    : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                }`}
                              >
                                {pdfSigned ? 'Clear Sign' : 'Apply Sign'}
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Footer */}
                      <div className="absolute bottom-6 left-12 right-12 border-t border-gray-200 pt-3 flex justify-between items-center text-[8px] text-gray-400 font-mono">
                        <span>CONFIDENTIAL - FOR INTERNAL USE ONLY</span>
                        <span>PAGE {pdfPage} OF 3</span>
                        <span>Mountec Singapore Systems</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: ADVANCED DWG CAD BLUEPRINT VIEWER (dwg_preview) */}
              {selectedDoc.interactiveType === 'dwg_preview' && (
                <div className="space-y-4">
                  {/* CAD Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0C0C0C] p-3 rounded-lg border border-[#222]">
                    <div className="flex items-center space-x-2 text-xs">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></span>
                      <span className="text-gray-300 font-bold uppercase text-[10px] tracking-wider font-mono">AUTOCAD WEB-VIEW PORT</span>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-gray-400">
                      <button 
                        type="button"
                        onClick={() => {
                          setCadMeasureActive(!cadMeasureActive);
                          setCadPoints([]);
                        }}
                        className={`flex items-center px-2.5 py-1 rounded border text-[10px] font-bold uppercase transition-all ${
                          cadMeasureActive 
                            ? 'bg-emerald-950 text-emerald-400 border-emerald-500' 
                            : 'bg-[#141414] text-gray-300 border-[#333] hover:border-gray-500'
                        }`}
                      >
                        <Ruler className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
                        {cadMeasureActive ? 'Measuring...' : 'Measure tool'}
                      </button>

                      <button 
                        type="button"
                        onClick={() => {
                          setCadPoints([]);
                          setCadZoom(100);
                        }}
                        className="px-2.5 py-1 bg-[#141414] text-gray-300 border border-[#333] hover:border-gray-500 rounded text-[10px] font-bold uppercase transition-all"
                      >
                        Reset CAD
                      </button>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-gray-400 font-mono">
                      <span>ZOOM:</span>
                      <button type="button" onClick={() => setCadZoom(z => Math.max(50, z - 10))} className="p-1 hover:text-white">-</button>
                      <span>{cadZoom}%</span>
                      <button type="button" onClick={() => setCadZoom(z => Math.min(200, z + 10))} className="p-1 hover:text-white">+</button>
                    </div>
                  </div>

                  {/* CAD Workspace Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                    {/* Canvas Area */}
                    <div className="lg:col-span-3 bg-black rounded-lg border border-[#222] h-[450px] relative overflow-hidden flex flex-col justify-between select-none">
                      {/* Grid Background Overlay */}
                      <div 
                        onMouseMove={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const x = ((e.clientX - rect.left) * (800 / rect.width)).toFixed(1);
                          const y = ((e.clientY - rect.top) * (400 / rect.height)).toFixed(1);
                          setCadCoords({ x: parseFloat(x), y: parseFloat(y) });
                        }}
                        onClick={(e) => {
                          if (!cadMeasureActive) return;
                          const rect = e.currentTarget.getBoundingClientRect();
                          const x = Math.round((e.clientX - rect.left) * (800 / rect.width));
                          const y = Math.round((e.clientY - rect.top) * (400 / rect.height));
                          
                          if (cadPoints.length >= 2) {
                            setCadPoints([{ x, y }]);
                          } else {
                            setCadPoints(prev => [...prev, { x, y }]);
                          }
                        }}
                        className="absolute inset-0 cursor-crosshair"
                        style={{
                          backgroundImage: cadActiveLayer.grid ? 'radial-gradient(circle, #222 1px, transparent 1px)' : 'none',
                          backgroundSize: '20px 20px',
                        }}
                      >
                        {/* Interactive CAD Drawing rendered via beautiful high-tech SVG */}
                        <svg 
                          viewBox="0 0 800 400" 
                          className="w-full h-full"
                          style={{ transform: `scale(${cadZoom / 100})`, transformOrigin: 'center' }}
                        >
                          {/* Layer 1: Structural Concrete Walls (Gray) */}
                          {cadActiveLayer.walls && (
                            <g stroke="#444" strokeWidth="4" fill="none" opacity="0.8">
                              <rect x="50" y="50" width="700" height="300" rx="10" />
                              <line x1="280" y1="50" x2="280" y2="350" strokeDasharray="5,5" strokeWidth="2" />
                              <line x1="520" y1="50" x2="520" y2="350" strokeDasharray="5,5" strokeWidth="2" />
                              <rect x="100" y="100" width="120" height="80" rx="4" />
                              <rect x="580" y="200" width="120" height="100" rx="4" />
                            </g>
                          )}

                          {/* Layer 2: Piping Installations (Vibrant Cyan and Blue) */}
                          {cadActiveLayer.piping && (
                            <g fill="none">
                              {/* Main Feed Pipe */}
                              <path d="M 80,140 L 400,140 L 400,260 L 720,260" stroke="#00D2FF" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                              <circle cx="400" cy="140" r="10" fill="#FFC700" stroke="#000" strokeWidth="2" />
                              <circle cx="400" cy="260" r="10" fill="#FFC700" stroke="#000" strokeWidth="2" />
                              
                              {/* Branch Line 1 */}
                              <path d="M 400,140 L 600,140 L 600,80" stroke="#005CFF" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                              {/* Branch Line 2 */}
                              <path d="M 200,140 L 200,300" stroke="#005CFF" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                            </g>
                          )}

                          {/* Layer 3: Annotations & Dimensions (Yellow) */}
                          {cadActiveLayer.annotations && (
                            <g fill="#FFC700" className="font-mono text-[9px] select-none">
                              {/* Anchor Dimensions */}
                              <text x="90" y="130">FEED PIPE Ø150mm [INFLOW]</text>
                              <text x="630" y="250">OUTLET Ø100mm</text>
                              <line x1="80" y1="160" x2="400" y2="160" stroke="#FFC700" strokeWidth="1" strokeDasharray="3,3" />
                              <text x="210" y="175" textAnchor="middle">DISTANCE = 6.40 meters</text>

                              {/* Site labels */}
                              <text x="160" y="90" fill="#777" textAnchor="middle">SECTOR 28A</text>
                              <text x="400" y="90" fill="#777" textAnchor="middle">MAIN VALVE JUNCTION</text>
                              <text x="640" y="190" fill="#777" textAnchor="middle">SECTOR 28B</text>
                            </g>
                          )}

                          {/* Active Measurement Renderings */}
                          {cadMeasureActive && cadPoints.map((p, idx) => (
                            <g key={idx}>
                              <circle cx={p.x} cy={p.y} r="5" fill="#10B981" />
                              <text x={p.x + 8} y={p.y - 8} fill="#10B981" className="font-mono text-[9px]">P{idx+1}</text>
                            </g>
                          ))}

                          {cadMeasureActive && cadPoints.length === 2 && (
                            <g>
                              <line 
                                x1={cadPoints[0].x} 
                                y1={cadPoints[0].y} 
                                x2={cadPoints[1].x} 
                                y2={cadPoints[1].y} 
                                stroke="#10B981" 
                                strokeWidth="2" 
                                strokeDasharray="4,4" 
                              />
                              <rect 
                                x={(cadPoints[0].x + cadPoints[1].x) / 2 - 50} 
                                y={(cadPoints[0].y + cadPoints[1].y) / 2 - 10} 
                                width="100" 
                                height="20" 
                                fill="#064E3B" 
                                rx="3" 
                                stroke="#10B981" 
                                strokeWidth="1" 
                              />
                              <text 
                                x={(cadPoints[0].x + cadPoints[1].x) / 2} 
                                y={(cadPoints[0].y + cadPoints[1].y) / 2 + 4} 
                                fill="#10B981" 
                                className="font-mono text-[9px] font-bold" 
                                textAnchor="middle"
                              >
                                {((Math.sqrt(Math.pow(cadPoints[1].x - cadPoints[0].x, 2) + Math.pow(cadPoints[1].y - cadPoints[0].y, 2)) / 50) * 1.5).toFixed(2)} meters
                              </text>
                            </g>
                          )}
                        </svg>
                      </div>

                      {/* CAD Mouse Coordinate HUD */}
                      <div className="absolute bottom-3 left-3 bg-black/80 border border-[#222] p-2 rounded text-[10px] font-mono text-gray-400 flex items-center space-x-3">
                        <span className="text-blue-400">CURSOR POS</span>
                        <span>X: <span className="text-white">{cadCoords.x}</span></span>
                        <span>Y: <span className="text-white">{cadCoords.y}</span></span>
                      </div>

                      {/* Calibration Guide */}
                      {cadMeasureActive && (
                        <div className="absolute top-3 right-3 bg-emerald-950/80 border border-emerald-500/30 px-3 py-1.5 rounded text-[10px] text-emerald-400 font-mono">
                          Click 2 points on grid to measure piping distance
                        </div>
                      )}
                    </div>

                    {/* Properties Panel & Layers Sidebar */}
                    <div className="space-y-4 bg-[#0A0A0A] p-4 rounded-lg border border-[#222] text-xs">
                      <div>
                        <h4 className="font-bold text-white uppercase tracking-wider mb-2 font-mono text-[10px] border-b border-[#222] pb-1 text-blue-500">
                          CAD Layer Control
                        </h4>
                        <div className="space-y-2 mt-2">
                          {Object.keys(cadActiveLayer).map(layer => (
                            <label key={layer} className="flex items-center space-x-2 text-gray-300 capitalize cursor-pointer hover:text-white">
                              <input 
                                type="checkbox"
                                checked={cadActiveLayer[layer]}
                                onChange={() => setCadActiveLayer(prev => ({ ...prev, [layer]: !prev[layer] }))}
                                className="rounded bg-black border-[#333] text-blue-500 focus:ring-0"
                              />
                              <span className="font-mono text-[11px]">{layer}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-[#222]">
                        <h4 className="font-bold text-white uppercase tracking-wider mb-2 font-mono text-[10px] text-blue-500">
                          Drafting Specs
                        </h4>
                        <div className="space-y-1.5 font-mono text-[10px] text-gray-400">
                          <p>DRAFTED: 24-May-2026</p>
                          <p>BY: MOUNTEC CAD TEAM</p>
                          <p>REVISION: R2.1</p>
                          <p>SCALE: 1:50 [METRIC]</p>
                          <p>WORKSPACE: 2D CIVIL LAYOUT</p>
                        </div>
                      </div>

                      <div className="p-3 bg-[#111] border border-[#222] rounded mt-4">
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Workspace Health</p>
                        <div className="flex items-center space-x-2 text-emerald-400 font-bold mt-1 text-[11px]">
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          <span>LOCAL CAD SYSTEM ONLINE</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: ADVANCED XLSX EXCEL SPREADSHEET VIEWER (xlsx_preview) */}
              {selectedDoc.interactiveType === 'xlsx_preview' && (
                <div className="space-y-4">
                  {/* Spreadsheet toolbar */}
                  <div className="bg-gray-100 p-3 rounded-lg border border-gray-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center space-x-3">
                      <span className="p-2 rounded bg-emerald-50 text-emerald-600">
                        <FileSpreadsheet className="w-5 h-5" />
                      </span>
                      <div>
                        <h4 className="text-xs font-bold uppercase text-gray-950 tracking-tight">{selectedDoc.title}</h4>
                        <p className="text-[10px] text-gray-400">Formula Parsing Engine Enabled (Click cell to edit)</p>
                      </div>
                    </div>

                    {/* Formula Editor Bar */}
                    <div className="flex-1 flex items-center space-x-2 bg-white border border-gray-300 rounded px-2 py-1 text-xs text-black">
                      <span className="font-bold text-gray-400 font-mono shrink-0">
                        {xlsxSelectedCell ? `${String.fromCharCode(65 + xlsxSelectedCell.col)}${xlsxSelectedCell.row + 1}` : 'fx'}:
                      </span>
                      <input 
                        type="text"
                        value={xlsxEditVal}
                        onChange={e => {
                          setXlsxEditVal(e.target.value);
                          if (xlsxSelectedCell) {
                            const newData = [...xlsxSheetData];
                            newData[xlsxSelectedCell.row] = [...newData[xlsxSelectedCell.row]];
                            newData[xlsxSelectedCell.row][xlsxSelectedCell.col] = e.target.value;
                            
                            // Re-calculate formula dynamically
                            if (xlsxSelectedCell.row === 1 && xlsxSelectedCell.col === 2) {
                              const variance = parseInt(e.target.value || '0') - parseInt(newData[1][1] || '0');
                              newData[1][4] = variance.toString();
                              newData[1][5] = variance > 0 ? 'AHEAD' : variance < 0 ? 'DELAYED' : 'ON SCHEDULE';
                            }
                            if (xlsxSelectedCell.row === 2 && xlsxSelectedCell.col === 2) {
                              const variance = parseInt(e.target.value || '0') - parseInt(newData[2][1] || '0');
                              newData[2][4] = variance.toString();
                              newData[2][5] = variance > 0 ? 'AHEAD' : variance < 0 ? 'DELAYED' : 'ON SCHEDULE';
                            }
                            
                            // Live Sum Calculations
                            let totalPlanned = 0;
                            let totalActual = 0;
                            for (let r = 1; r < 6; r++) {
                              totalPlanned += parseInt(newData[r][1] || '0');
                              totalActual += parseInt(newData[r][2] || '0');
                            }
                            newData[6][1] = totalPlanned.toString();
                            newData[6][2] = totalActual.toString();
                            newData[6][4] = (totalActual - totalPlanned).toString();

                            setXlsxSheetData(newData);
                          }
                        }}
                        disabled={!xlsxSelectedCell}
                        placeholder="Formula or cell input..."
                        className="w-full bg-transparent border-none outline-none focus:ring-0 text-xs p-0 m-0"
                      />
                    </div>
                  </div>

                  {/* Spreadsheet Sheet Grid */}
                  <div className="border border-gray-300 rounded-lg overflow-x-auto bg-white">
                    <table className="w-full text-left text-xs text-gray-800 whitespace-nowrap font-sans border-collapse">
                      <thead>
                        <tr className="bg-gray-100 text-gray-500 font-mono text-[10px] tracking-wider border-b border-gray-300">
                          <th className="px-3 py-1.5 border-r border-gray-300 text-center w-8 bg-gray-200">#</th>
                          {Array.from({ length: xlsxSheetData[0]?.length || 6 }).map((_, colIdx) => (
                            <th key={colIdx} className="px-3 py-1.5 border-r border-gray-300 text-center">
                              {String.fromCharCode(65 + colIdx)}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {xlsxSheetData.map((row, rowIdx) => (
                          <tr key={rowIdx} className={rowIdx === 0 ? 'bg-gray-50/50 font-bold border-b border-gray-300' : 'hover:bg-gray-50 transition-colors'}>
                            <td className="px-3 py-1.5 border-r border-gray-300 bg-gray-100 text-gray-500 text-center font-mono text-[10px] font-bold select-none">
                              {rowIdx + 1}
                            </td>
                            {row.map((cell, colIdx) => (
                              <td 
                                key={colIdx} 
                                onClick={() => {
                                  setXlsxSelectedCell({ row: rowIdx, col: colIdx });
                                  setXlsxEditVal(cell);
                                }}
                                className={`px-3 py-2 border-r border-gray-200 text-xs cursor-cell focus-within:ring-1 focus-within:ring-emerald-500 ${
                                  xlsxSelectedCell?.row === rowIdx && xlsxSelectedCell?.col === colIdx
                                    ? 'bg-emerald-50/70 border-emerald-500 ring-1 ring-emerald-500'
                                    : ''
                                } ${rowIdx === 6 ? 'bg-gray-100/50 font-black border-t-2 border-gray-300' : ''}`}
                              >
                                <span className={
                                  cell === 'DELAYED' ? 'text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded' : 
                                  cell === 'AHEAD' || cell === 'APPROVED' ? 'text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded' : 
                                  cell === 'ON SCHEDULE' ? 'text-blue-600 font-bold bg-blue-50 px-1.5 py-0.5 rounded' : ''
                                }>
                                  {cell}
                                </span>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Sheet Tabs */}
                  <div className="flex items-center space-x-1 border-t border-gray-200 pt-2 text-xs">
                    <button 
                      type="button"
                      onClick={() => setXlsxActiveTab(0)}
                      className={`px-3 py-1 rounded-t-lg border-t border-x font-bold transition-all ${
                        xlsxActiveTab === 0 
                          ? 'bg-white border-gray-300 text-emerald-600' 
                          : 'bg-gray-100 border-transparent text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      Sheet 1: Progress Summary
                    </button>
                    <button 
                      type="button"
                      onClick={() => setXlsxActiveTab(1)}
                      className={`px-3 py-1 rounded-t-lg border-t border-x font-bold transition-all ${
                        xlsxActiveTab === 1 
                          ? 'bg-white border-gray-300 text-emerald-600' 
                          : 'bg-gray-100 border-transparent text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      Sheet 2: Resource Assignments
                    </button>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: ADVANCED DOCX WORD PROCESSOR (docx_preview) */}
              {selectedDoc.interactiveType === 'docx_preview' && (
                <div className="space-y-4">
                  {/* DOCX Editor Toolbar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-gray-100 p-3 rounded-lg border border-gray-200 text-xs">
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => setDocxBold(!docxBold)}
                        className={`p-1.5 rounded font-bold uppercase ${docxBold ? 'bg-gray-300 text-black' : 'hover:bg-gray-200 text-gray-600'}`}
                        title="Bold"
                      >
                        B
                      </button>
                      <button
                        type="button"
                        onClick={() => setDocxItalic(!docxItalic)}
                        className={`p-1.5 rounded italic uppercase ${docxItalic ? 'bg-gray-300 text-black' : 'hover:bg-gray-200 text-gray-600'}`}
                        title="Italic"
                      >
                        I
                      </button>
                      <button
                        type="button"
                        onClick={() => setDocxUnderline(!docxUnderline)}
                        className={`p-1.5 rounded underline uppercase ${docxUnderline ? 'bg-gray-300 text-black' : 'hover:bg-gray-200 text-gray-600'}`}
                        title="Underline"
                      >
                        U
                      </button>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button 
                        type="button"
                        onClick={() => setDocxAlign('left')}
                        className={`p-1.5 rounded ${docxAlign === 'left' ? 'bg-gray-300' : 'hover:bg-gray-200'}`}
                      >
                        Left
                      </button>
                      <button 
                        type="button"
                        onClick={() => setDocxAlign('center')}
                        className={`p-1.5 rounded ${docxAlign === 'center' ? 'bg-gray-300' : 'hover:bg-gray-200'}`}
                      >
                        Center
                      </button>
                      <button 
                        type="button"
                        onClick={() => setDocxAlign('right')}
                        className={`p-1.5 rounded ${docxAlign === 'right' ? 'bg-gray-300' : 'hover:bg-gray-200'}`}
                      >
                        Right
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (!docxIsEditing) {
                          setDocxText(selectedDoc.content || 'Draft content here...');
                        } else {
                          selectedDoc.content = docxText;
                        }
                        setDocxIsEditing(!docxIsEditing);
                      }}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-bold uppercase transition-colors ml-auto"
                    >
                      {docxIsEditing ? 'Lock Changes' : 'Edit Text Draft'}
                    </button>
                  </div>

                  {/* Word document page view */}
                  <div className="bg-gray-500 p-8 rounded-lg border border-gray-600 flex justify-center">
                    <div className="bg-white p-12 w-full max-w-2xl min-h-[500px] shadow-xl relative transition-all text-gray-800 font-sans select-text">
                      {/* Letterhead border */}
                      <div className="border-t-4 border-blue-600 mb-6 pt-4 flex justify-between items-center text-[10px] text-gray-400">
                        <span className="font-bold text-gray-900 uppercase">MOUNTEC CORPORATE SYSTEMS</span>
                        <span>REGISTRY ID: DOCX-{selectedDoc.fileName.toUpperCase().slice(0,6)}</span>
                      </div>

                      {docxIsEditing ? (
                        <textarea
                          value={docxText}
                          onChange={e => setDocxText(e.target.value)}
                          className="w-full min-h-[300px] bg-transparent border-none focus:ring-0 text-xs font-mono p-0 outline-none text-black resize-none"
                        />
                      ) : (
                        <div 
                          style={{
                            fontWeight: docxBold ? 'bold' : 'normal',
                            fontStyle: docxItalic ? 'italic' : 'normal',
                            textDecoration: docxUnderline ? 'underline' : 'none',
                            textAlign: docxAlign
                          }}
                          className="text-xs text-gray-800 leading-relaxed space-y-4 whitespace-pre-wrap"
                        >
                          {selectedDoc.content || 'No text content loaded.'}
                        </div>
                      )}

                      <div className="mt-12 pt-6 border-t border-gray-150 flex justify-between items-center text-[9px] text-gray-400">
                        <span>WORD COUNT: {(selectedDoc.content || '').split(/\s+/).filter(Boolean).length} WORDS</span>
                        <span>STATUS: COMPLIANT</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* INTERACTIVE COMPONENT: ADVANCED JPG/PNG IMAGE VIEWER (image_preview) */}
              {selectedDoc.interactiveType === 'image_preview' && (
                <div className="space-y-4">
                  {/* Image gallery toolbars */}
                  <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0C0C0C] p-3 rounded-lg border border-[#222] text-xs">
                    <div className="flex items-center space-x-2 text-[10px] font-bold text-gray-300 font-mono">
                      <Image className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>EXIF GALLERY INSPECTOR</span>
                    </div>

                    <div className="flex items-center space-x-4 text-xs">
                      <button 
                        type="button"
                        onClick={() => setImgRotation(r => (r + 90) % 360)}
                        className="flex items-center text-gray-300 hover:text-white"
                      >
                        <RotateCw className="w-3.5 h-3.5 mr-1.5" />
                        Rotate
                      </button>

                      <div className="flex items-center space-x-2">
                        <span>Zoom:</span>
                        <input 
                          type="range" 
                          min="50" 
                          max="200" 
                          value={imgZoom} 
                          onChange={e => setImgZoom(parseInt(e.target.value))}
                          className="w-24 accent-amber-500"
                        />
                        <span className="font-mono text-[10px]">{imgZoom}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Image View Stage */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Darkroom image display area */}
                    <div className="md:col-span-2 bg-[#050505] rounded-lg border border-[#222] h-[350px] relative overflow-hidden flex items-center justify-center">
                      <div className="absolute inset-0 bg-[linear-gradient(45deg,#111_25%,transparent_25%),linear-gradient(-45deg,#111_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#111_75%),linear-gradient(-45deg,transparent_75%,#111_75%)] bg-[size:16px_16px] bg-[position:0_0,0_8px,8px_-8px,-8px_0] opacity-40"></div>
                      
                      <div 
                        style={{ transform: `scale(${imgZoom / 100}) rotate(${imgRotation}deg)`, transition: 'transform 0.2s' }}
                        className="relative z-10 shrink-0"
                      >
                        {selectedDoc.content && selectedDoc.content.startsWith('data:image/') ? (
                          <img 
                            src={selectedDoc.content} 
                            alt={selectedDoc.title}
                            referrerPolicy="no-referrer"
                            className="max-h-[280px] max-w-full rounded shadow-2xl object-contain"
                          />
                        ) : (
                          // Fallback Vector blueprint design if no image uploaded
                          <div className="w-[300px] h-[200px] bg-sky-950 border-2 border-sky-400/50 rounded p-4 flex flex-col justify-between font-mono text-sky-300 text-[9px] relative">
                            {/* blueprint visual lines */}
                            <div className="absolute inset-0 border-r border-b border-sky-400/10" style={{ backgroundImage: 'linear-gradient(to right, rgba(56,189,248,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(56,189,248,0.05) 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
                            <div className="z-10 flex justify-between items-start">
                              <span>M_BLUEPRINT: V3.4</span>
                              <span>SCALE: 1:1</span>
                            </div>
                            <div className="z-10 text-center py-6">
                              <h5 className="text-sm font-black text-white uppercase tracking-wider">MOUNTEC BRANDING SPEC</h5>
                              <p className="text-[10px] text-sky-400 mt-1">PRIMARY HEX LOGO VECTOR SPEC</p>
                              <div className="mt-3 flex justify-center space-x-2">
                                <span className="w-3 h-3 bg-blue-500 rounded-full"></span>
                                <span className="w-3 h-3 bg-gray-900 rounded-full"></span>
                                <span className="w-3 h-3 bg-gray-50 rounded-full"></span>
                              </div>
                            </div>
                            <div className="z-10 flex justify-between items-end text-[8px] text-sky-400/70">
                              <span>DWG REF NO: 2026-X8</span>
                              <span>MOUNTEC PTE LTD</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Image EXIF and Contrast Metadata Panel */}
                    <div className="bg-[#0A0A0A] p-4 rounded-lg border border-[#222] text-xs space-y-4">
                      <div>
                        <h4 className="font-bold text-white uppercase tracking-wider mb-2 font-mono text-[10px] text-amber-500">
                          Contrast & Dominant Colors
                        </h4>
                        <div className="space-y-2 mt-2 font-mono text-[10px]">
                          <div className="flex items-center justify-between p-1.5 bg-[#141414] rounded">
                            <div className="flex items-center space-x-2">
                              <span className="w-3.5 h-3.5 bg-blue-500 rounded"></span>
                              <span className="text-gray-300">#3B82F6</span>
                            </div>
                            <span className="text-gray-500">62%</span>
                          </div>
                          <div className="flex items-center justify-between p-1.5 bg-[#141414] rounded">
                            <div className="flex items-center space-x-2">
                              <span className="w-3.5 h-3.5 bg-gray-900 rounded border border-gray-700"></span>
                              <span className="text-gray-300">#111111</span>
                            </div>
                            <span className="text-gray-500">28%</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-[#222]">
                        <h4 className="font-bold text-white uppercase tracking-wider mb-2 font-mono text-[10px] text-amber-500">
                          EXIF Metadata Block
                        </h4>
                        <div className="space-y-1.5 font-mono text-[10px] text-gray-400">
                          <p>DIMENSIONS: 1920 x 1080 PX</p>
                          <p>FILE FORMAT: {selectedDoc.fileName.toLowerCase().endsWith('.png') ? 'PNG-24' : 'JPEG HIGH'}</p>
                          <p>COLOR SPACE: sRGB IEC61966</p>
                          <p>DEPTH: 8-BIT PER CHANNEL</p>
                          <p>SOFTWARE: Adobe Photoshop</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* STANDARD SOP VIEW */}
              {selectedDoc.interactiveType === 'sop_text' && selectedDoc.content && (
                <div className="space-y-4 leading-relaxed select-text">
                  <div className="text-center pb-4 border-b-2 border-gray-900 mb-6">
                    <h1 className="text-2xl font-black uppercase tracking-tight">{selectedDoc.title}</h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Official Standard Operations Procedures (SOP)</p>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 font-sans text-xs text-gray-800 whitespace-pre-wrap leading-relaxed max-w-3xl mx-auto">
                    {selectedDoc.content}
                  </div>
                </div>
              )}

              {/* Document footer */}
              <div className="mt-8 pt-4 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400 font-medium">
                <span>File: {selectedDoc.fileName}</span>
                <span>Size: {selectedDoc.size}</span>
                {selectedDoc.uploadedBy && (
                  <span>Uploaded By: {selectedDoc.uploadedBy}</span>
                )}
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECURE SHARE DOCUMENT DIALOG MODAL                       */}
      {/* ========================================================= */}
      {sharingDoc && (
        <div className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111111] border border-[#222] rounded-xl w-full max-w-lg p-6 shadow-2xl relative text-white">
            
            <div className="flex items-center justify-between border-b border-[#222] pb-4 mb-4">
              <h3 className="text-sm font-bold uppercase tracking-widest text-amber-500 flex items-center">
                <Share2 className="w-5 h-5 mr-2 text-amber-500" />
                Secure Share Registry Asset
              </h3>
              <button 
                type="button"
                onClick={() => {
                  setSharingDoc(null);
                  setShareEmail('');
                  setShareSuccess(false);
                }}
                className="text-gray-500 hover:text-white font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Target File details */}
              <div className="bg-[#161616] p-3 rounded-lg border border-[#222] text-xs space-y-1">
                <p className="text-[#666] uppercase text-[9px] font-bold">Document to Share</p>
                <p className="font-bold text-white text-sm">{sharingDoc.title}</p>
                <div className="flex items-center space-x-2 text-[10px] text-gray-400">
                  <span className="font-mono bg-[#222] px-1.5 py-0.5 rounded text-gray-300">{sharingDoc.fileName}</span>
                  <span>•</span>
                  <span>{sharingDoc.size}</span>
                </div>
              </div>

              {/* Email Sharing input & edit privileges */}
              <div className="space-y-2">
                <label className="block text-[10px] font-bold text-[#999] uppercase tracking-wider">
                  Invite via Email Address
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-[#555]" />
                    <input 
                      type="email"
                      value={shareEmail}
                      onChange={e => setShareEmail(e.target.value)}
                      placeholder="Enter coworker's email id..."
                      className="w-full bg-[#1A1A1A] border border-[#333] text-white rounded p-2 pl-9 text-xs focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <select 
                    value={sharePermission}
                    onChange={e => setSharePermission(e.target.value as 'view' | 'edit')}
                    className="bg-[#1A1A1A] border border-[#333] text-white rounded px-2 text-xs focus:outline-none focus:border-amber-500 font-bold"
                  >
                    <option value="view">Can View</option>
                    <option value="edit">Can Edit</option>
                  </select>
                </div>
              </div>

              {/* Share actions */}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    if (!shareEmail || !shareEmail.includes('@')) {
                      alert('Please input a valid email ID.');
                      return;
                    }
                    setShareSuccess(true);
                    setTimeout(() => setShareSuccess(false), 3000);
                    // Add to simulated log
                    const updatedLogs = [
                      ...shareAccessList,
                      { email: shareEmail, role: sharePermission, date: 'Just now' }
                    ];
                    setShareAccessList(updatedLogs);
                    setShareEmail('');
                  }}
                  className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-black font-bold text-xs uppercase tracking-wider rounded transition-colors"
                >
                  Grant Registry Access
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(`https://mountec.com.sg/registry/secure-vault-ref?doc=${sharingDoc.id}`);
                    setLinkCopied(true);
                    setTimeout(() => setLinkCopied(false), 2000);
                  }}
                  className="px-4 py-2 bg-[#222] hover:bg-[#333] text-white border border-[#333] rounded text-xs font-bold uppercase transition-all"
                >
                  {linkCopied ? 'Copied ✓' : 'Copy Link'}
                </button>
              </div>

              {/* Toast message inside the modal */}
              {shareSuccess && (
                <div className="bg-emerald-950/80 border border-emerald-500/40 p-2.5 rounded text-xs text-emerald-400 flex items-center space-x-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Success: Access granted using email identifier. Notifications dispatched.</span>
                </div>
              )}

              {/* Coworkers Quick Select shortcuts */}
              <div>
                <p className="text-[10px] font-bold text-[#555] uppercase tracking-widest mb-1.5">Quick Invite Coworkers</p>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { name: 'Senthil Kumar (Admin Mgr)', email: 'senthil@mountec.com.sg' },
                    { name: 'Kartik Vicky (MD)', email: 'kartik.vicky@mountec.com.sg' },
                    { name: 'Kumar Raj (Piping Sup)', email: 'kumar.raj@mountec.com.sg' },
                    { name: 'Chen Wei (Safety Exec)', email: 'chen.wei@mountec.com.sg' }
                  ].map(person => (
                    <button
                      key={person.email}
                      type="button"
                      onClick={() => setShareEmail(person.email)}
                      className="px-2 py-1 bg-[#1A1A1A] hover:bg-[#252525] border border-[#2C2C2C] rounded text-[10px] text-gray-300 transition-colors"
                    >
                      {person.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Active Access List Log */}
              <div className="pt-2 border-t border-[#222]">
                <p className="text-[10px] font-bold text-[#999] uppercase tracking-wider mb-2">
                  Identified Accounts with Access Control
                </p>
                <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
                  {shareAccessList.map((access, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-[#151515] p-2 rounded border border-[#222] text-[11px]">
                      <div className="flex items-center space-x-2">
                        <Mail className="w-3 h-3 text-amber-500/70" />
                        <span className="font-mono text-gray-300">{access.email}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                          access.role === 'edit' ? 'bg-amber-950 text-amber-400 border border-amber-500/30' : 'bg-gray-800 text-gray-400'
                        }`}>
                          {access.role === 'edit' ? 'Edit Access' : 'View Only'}
                        </span>
                        <button 
                          type="button"
                          onClick={() => {
                            setShareAccessList(prev => prev.filter((_, i) => i !== idx));
                          }}
                          className="text-gray-500 hover:text-rose-500 text-xs px-1"
                          title="Revoke access"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            <div className="flex justify-end pt-4 border-t border-[#222] mt-4">
              <button
                type="button"
                onClick={() => {
                  setSharingDoc(null);
                  setShareEmail('');
                  setShareSuccess(false);
                }}
                className="px-4 py-1.5 bg-[#222] hover:bg-[#333] text-gray-400 hover:text-white rounded text-xs font-bold uppercase transition-colors"
              >
                Close Share Console
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
