import React, { useState, useEffect } from 'react';
import { db } from '../../../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  getDocs, 
  updateDoc, 
  query, 
  where,
  runTransaction
} from 'firebase/firestore';
import { 
  Plus, 
  Trash2, 
  ArrowLeftRight, 
  AlertTriangle, 
  Check, 
  X, 
  Wrench, 
  User, 
  MapPin, 
  Calendar, 
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { METCItem, METCSite, SiteInventory } from './metcTypes';

interface METCControlPanelProps {
  items: METCItem[];
  sites: METCSite[];
  siteInventory: SiteInventory[];
  loading: boolean;
}

export default function METCControlPanel({ items, sites, siteInventory, loading }: METCControlPanelProps) {
  const [activeTab, setActiveTab] = useState<'issue' | 'return'>('issue');
  const [selectedSiteId, setSelectedSiteId] = useState<string>('');
  const [selectedSite, setSelectedSite] = useState<METCSite | null>(null);
  const [remarks, setRemarks] = useState('');

  // Issue Form States
  const [issueItemsList, setIssueItemsList] = useState<{ item: METCItem; quantity: number }[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<string>('');
  const [issueQty, setIssueQty] = useState<number>(1);
  const [searchItemQuery, setSearchItemQuery] = useState<string>('');

  // Return Input States
  const [returnQuantities, setReturnQuantities] = useState<{ [itemCode: string]: { returnQty: number; repairQty: number; lostQty: number; repairRemarks?: string; lostReason?: string } }>({});

  // Message alert states
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (selectedSiteId) {
      const site = sites.find(s => s.id === selectedSiteId) || null;
      setSelectedSite(site);
    } else {
      setSelectedSite(null);
    }
    // Reset lists when changing site
    setIssueItemsList([]);
    setReturnQuantities({});
  }, [selectedSiteId, sites]);

  // Handle setting return states for the selected site
  const activeSiteInventory = siteInventory.filter(si => si.siteId === selectedSiteId && si.currentSiteQty > 0);

  // Quick Action: Add Item to Issue Draft List
  const handleAddIssueItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItemId) return;
    const selectedItem = items.find(i => i.id === selectedItemId);
    if (!selectedItem) return;

    if (issueQty <= 0) {
      showMsg('error', 'Issue quantity must be greater than 0');
      return;
    }

    // Verify stock availability
    const totalDraftedQty = issueItemsList
      .filter(draft => draft.item.itemCode === selectedItem.itemCode)
      .reduce((sum, draft) => sum + draft.quantity, 0);

    const availableStock = selectedItem.currentStock - totalDraftedQty;
    if (issueQty > selectedItem.currentStock) {
      showMsg('error', `Insufficient stock. Only ${selectedItem.currentStock} ${selectedItem.unit} available in store.`);
      return;
    }
    if (issueQty > availableStock) {
      showMsg('error', `Insufficient stock. You already drafted ${totalDraftedQty} of this item. Remaining available: ${availableStock}`);
      return;
    }

    // Add to draft list
    const existingIndex = issueItemsList.findIndex(draft => draft.item.id === selectedItem.id);
    if (existingIndex > -1) {
      const updated = [...issueItemsList];
      updated[existingIndex].quantity += issueQty;
      setIssueItemsList(updated);
    } else {
      setIssueItemsList([...issueItemsList, { item: selectedItem, quantity: issueQty }]);
    }

    // Reset input fields
    setSelectedItemId('');
    setIssueQty(1);
    setSearchItemQuery('');
  };

  const handleRemoveDraftItem = (index: number) => {
    const updated = [...issueItemsList];
    updated.splice(index, 1);
    setIssueItemsList(updated);
  };

  const showMsg = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => {
      setStatusMessage(null);
    }, 6000);
  };

  // ----------------------------------------------------
  // ACTION: ISSUE ALL
  // ----------------------------------------------------
  const handleIssueAll = async () => {
    if (!selectedSiteId || !selectedSite) {
      showMsg('error', 'Please select a Site & Supervisor first.');
      return;
    }
    if (issueItemsList.length === 0) {
      showMsg('error', 'No items in the draft list. Please add items to issue.');
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const today = new Date().toISOString().split('T')[0];
      const timestamp = Date.now();
      const randSuffix = Math.floor(100 + Math.random() * 900); // Unique number generator
      const transactionNo = `ISS-${today.replace(/-/g, '')}-${randSuffix}`;

      // Transaction Header Payload
      const txHeaderPayload = {
        transactionNo,
        siteId: selectedSite.id,
        siteName: selectedSite.siteName,
        supervisorName: selectedSite.supervisorName,
        date: today,
        timestamp,
        type: 'Issue',
        status: 'Completed',
        totalItems: issueItemsList.length,
        remarks: remarks || 'Issued from Store'
      };

      // Perform transaction updates
      await runTransaction(db, async (txn) => {
        // 1. Create Transaction Header
        const txHeaderRef = doc(collection(db, 'metc_transactions'), transactionNo);
        txn.set(txHeaderRef, txHeaderPayload);

        for (const draft of issueItemsList) {
          const item = draft.item;
          const qty = draft.quantity;

          // Retrieve fresh item data for stock level checks
          const itemDocRef = doc(db, 'metc_items', item.id);
          const freshItemSnap = await txn.get(itemDocRef);
          if (!freshItemSnap.exists()) {
            throw new Error(`Item ${item.itemName} does not exist in master list.`);
          }
          const freshItemData = freshItemSnap.data() as METCItem;
          if (freshItemData.currentStock < qty) {
            throw new Error(`Insufficient stock for ${item.itemName}. Fresh Available: ${freshItemData.currentStock}`);
          }

          // 2. Create Transaction Detail Record
          const detailRef = doc(collection(db, 'metc_transaction_details'));
          txn.set(detailRef, {
            transactionNo,
            itemCode: item.itemCode,
            itemName: item.itemName,
            category: item.category,
            storeStockBefore: freshItemData.currentStock,
            quantity: qty
          });

          // 3. Deduct stock from store
          txn.update(itemDocRef, {
            currentStock: freshItemData.currentStock - qty
          });

          // 4. Update Site Inventory
          const siteInvId = `${selectedSite.id}_${item.itemCode}`;
          const siteInvRef = doc(db, 'site_inventory', siteInvId);
          const siteInvSnap = await txn.get(siteInvRef);

          if (siteInvSnap.exists()) {
            const freshSiteInv = siteInvSnap.data();
            txn.update(siteInvRef, {
              issuedQty: (freshSiteInv.issuedQty || 0) + qty,
              currentSiteQty: (freshSiteInv.currentSiteQty || 0) + qty
            });
          } else {
            txn.set(siteInvRef, {
              siteId: selectedSite.id,
              siteName: selectedSite.siteName,
              itemCode: item.itemCode,
              itemName: item.itemName,
              category: item.category,
              issuedQty: qty,
              returnedQty: 0,
              underRepairQty: 0,
              lostQty: 0,
              currentSiteQty: qty
            });
          }
        }
      });

      showMsg('success', `Transaction ${transactionNo} processed successfully! Items issued.`);
      setIssueItemsList([]);
      setRemarks('');
    } catch (err: any) {
      console.error(err);
      showMsg('error', err.message || 'Error occurred while issuing items.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ----------------------------------------------------
  // ACTION: RECEIVE RETURN (Return, Repair, Lost combined)
  // ----------------------------------------------------
  const handleReceiveReturn = async () => {
    if (!selectedSiteId || !selectedSite) {
      showMsg('error', 'Please select a Site first.');
      return;
    }

    // Filter out items where some action was performed
    const itemsToProcess = Object.entries(returnQuantities).filter(([itemCode, qtyObj]) => {
      return qtyObj.returnQty > 0 || qtyObj.repairQty > 0 || qtyObj.lostQty > 0;
    });

    if (itemsToProcess.length === 0) {
      showMsg('error', 'No returned, repair, or lost quantities were entered.');
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    try {
      const today = new Date().toISOString().split('T')[0];
      const timestamp = Date.now();
      const randSuffix = Math.floor(100 + Math.random() * 900);
      const transactionNo = `RET-${today.replace(/-/g, '')}-${randSuffix}`;

      // Transaction Header
      const txHeaderPayload = {
        transactionNo,
        siteId: selectedSite.id,
        siteName: selectedSite.siteName,
        supervisorName: selectedSite.supervisorName,
        date: today,
        timestamp,
        type: 'Return',
        status: 'Completed',
        totalItems: itemsToProcess.length,
        remarks: remarks || 'Received Return from Site'
      };

      await runTransaction(db, async (txn) => {
        // 1. Create Return Transaction Header
        const txHeaderRef = doc(collection(db, 'metc_transactions'), transactionNo);
        txn.set(txHeaderRef, txHeaderPayload);

        for (const [itemCode, q] of itemsToProcess) {
          const totalRequestedAction = q.returnQty + q.repairQty + q.lostQty;
          
          // Get site inventory doc
          const siteInvId = `${selectedSite.id}_${itemCode}`;
          const siteInvRef = doc(db, 'site_inventory', siteInvId);
          const siteInvSnap = await txn.get(siteInvRef);

          if (!siteInvSnap.exists()) {
            throw new Error(`Inventory item ${itemCode} does not exist for this site.`);
          }

          const siteInvData = siteInvSnap.data();
          if (siteInvData.currentSiteQty < totalRequestedAction) {
            throw new Error(`Insufficient site stock for ${siteInvData.itemName}. Site Qty: ${siteInvData.currentSiteQty}, Requested: ${totalRequestedAction}`);
          }

          // Get fresh store item to track stock levels
          const qItems = query(collection(db, 'metc_items'), where('itemCode', '==', itemCode));
          const itemsSnap = await getDocs(qItems);
          if (itemsSnap.empty) {
            throw new Error(`Item master ${itemCode} not found.`);
          }
          const itemDoc = itemsSnap.docs[0];
          const itemData = itemDoc.data() as METCItem;
          const itemDocRef = doc(db, 'metc_items', itemDoc.id);

          // 2. Log Details in Transaction details (Only log returned / received quantities in details)
          const detailRef = doc(collection(db, 'metc_transaction_details'));
          txn.set(detailRef, {
            transactionNo,
            itemCode,
            itemName: itemData.itemName,
            category: itemData.category,
            storeStockBefore: itemData.currentStock,
            quantity: q.returnQty // Log return amount as primary quantity
          });

          // 3. Process return Qty (Restored to store stock)
          if (q.returnQty > 0) {
            txn.update(itemDocRef, {
              currentStock: itemData.currentStock + q.returnQty
            });
          }

          // 4. Update Site Inventory
          txn.update(siteInvRef, {
            returnedQty: (siteInvData.returnedQty || 0) + q.returnQty,
            underRepairQty: (siteInvData.underRepairQty || 0) + q.repairQty,
            lostQty: (siteInvData.lostQty || 0) + q.lostQty,
            currentSiteQty: siteInvData.currentSiteQty - totalRequestedAction
          });

          // 5. Save Repair History if logged
          if (q.repairQty > 0) {
            const repairRef = doc(collection(db, 'metc_repairs'));
            txn.set(repairRef, {
              itemCode,
              itemName: itemData.itemName,
              siteId: selectedSite.id,
              siteName: selectedSite.siteName,
              quantity: q.repairQty,
              date: today,
              timestamp,
              status: 'Under Repair',
              remarks: q.repairRemarks || 'Sent for repair from Site'
            });
          }

          // 6. Save Lost History if logged
          if (q.lostQty > 0) {
            const lostRef = doc(collection(db, 'metc_lost'));
            txn.set(lostRef, {
              itemCode,
              itemName: itemData.itemName,
              siteId: selectedSite.id,
              siteName: selectedSite.siteName,
              quantity: q.lostQty,
              date: today,
              timestamp,
              reason: q.lostReason || 'Unspecified site loss'
            });
          }
        }
      });

      showMsg('success', `Return transaction ${transactionNo} logged successfully! Site stock adjusted.`);
      setReturnQuantities({});
      setRemarks('');
    } catch (err: any) {
      console.error(err);
      showMsg('error', err.message || 'Error occurred while processing return.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReturnFieldChange = (itemCode: string, field: 'returnQty' | 'repairQty' | 'lostQty', value: number) => {
    setReturnQuantities(prev => {
      const current = prev[itemCode] || { returnQty: 0, repairQty: 0, lostQty: 0 };
      return {
        ...prev,
        [itemCode]: {
          ...current,
          [field]: value
        }
      };
    });
  };

  const handleReturnTextChange = (itemCode: string, field: 'repairRemarks' | 'lostReason', value: string) => {
    setReturnQuantities(prev => {
      const current = prev[itemCode] || { returnQty: 0, repairQty: 0, lostQty: 0 };
      return {
        ...prev,
        [itemCode]: {
          ...current,
          [field]: value
        }
      };
    });
  };

  // Filter items in selector list based on query
  const filteredItems = items.filter(i => 
    i.itemName.toLowerCase().includes(searchItemQuery.toLowerCase()) || 
    i.itemCode.toLowerCase().includes(searchItemQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Tab Selectors */}
      <div className="flex border-b border-gray-800">
        <button
          onClick={() => { setActiveTab('issue'); setStatusMessage(null); }}
          className={`px-6 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'issue'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <ArrowLeftRight className="w-4 h-4 text-blue-500" />
          <span>STORE → SITE (Issue Material/Tools)</span>
        </button>
        <button
          onClick={() => { setActiveTab('return'); setStatusMessage(null); }}
          className={`px-6 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'return'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <ArrowLeftRight className="w-4 h-4 text-emerald-500" />
          <span>SITE → STORE (Receive Return & Log Issues)</span>
        </button>
      </div>

      {/* Common Controls: Site Selector */}
      <div className="bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Select Target Construction Site</label>
            <div className="relative">
              <select
                value={selectedSiteId}
                onChange={(e) => setSelectedSiteId(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-blue-500 appearance-none cursor-pointer"
              >
                <option value="">-- Choose Construction Site --</option>
                {sites.map(site => (
                  <option key={site.id} value={site.id}>
                    {site.siteName}
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-gray-500">
                <MapPin className="w-4 h-4" />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Site Supervisor (Assigned)</label>
            <div className="relative">
              <input
                type="text"
                readOnly
                placeholder="Auto-assigned Supervisor Name"
                value={selectedSite ? selectedSite.supervisorName : ''}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-3 text-sm text-gray-400 focus:outline-none"
              />
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-gray-600">
                <User className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Success/Error Alerts */}
      {statusMessage && (
        <div className={`p-4 rounded-xl border flex items-start space-x-3 transition-all animate-fadeIn ${
          statusMessage.type === 'success' 
            ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-300' 
            : 'bg-rose-950/20 border-rose-900/50 text-rose-300'
        }`}>
          {statusMessage.type === 'success' ? <Check className="w-5 h-5 flex-shrink-0 text-emerald-400 mt-0.5" /> : <AlertTriangle className="w-5 h-5 flex-shrink-0 text-rose-400 mt-0.5" />}
          <div className="text-sm font-medium">{statusMessage.text}</div>
        </div>
      )}

      {/* TAB content: ISSUE ITEMS */}
      {activeTab === 'issue' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left panel: Add item Form */}
          <div className="lg:col-span-5 bg-[#111111] border border-gray-800 rounded-xl p-5 space-y-4 shadow-lg">
            <h3 className="text-sm font-bold text-gray-200 flex items-center space-x-2">
              <Plus className="w-4 h-4 text-blue-500" />
              <span>DRAFT ITEM ISSUE ROW</span>
            </h3>
            
            <form onSubmit={handleAddIssueItem} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Search & Select Item</label>
                <div className="space-y-2">
                  <input
                    type="text"
                    placeholder="Type name/code to filter..."
                    value={searchItemQuery}
                    onChange={(e) => setSearchItemQuery(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                  />
                  <select
                    value={selectedItemId}
                    required
                    onChange={(e) => setSelectedItemId(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="">-- Choose Item ({filteredItems.length} found) --</option>
                    {filteredItems.map(item => (
                      <option key={item.id} value={item.id} disabled={item.currentStock <= 0}>
                        {item.itemName} [{item.itemCode}] - (Store: {item.currentStock} {item.unit}) {item.currentStock <= 0 ? ' [OUT OF STOCK]' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1.5">Issue Quantity</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={issueQty}
                    onChange={(e) => setIssueQty(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1.5">Unit</label>
                  <input
                    type="text"
                    readOnly
                    placeholder="-"
                    value={items.find(i => i.id === selectedItemId)?.unit || ''}
                    className="w-full bg-[#1A1A1A]/40 border border-gray-800/50 rounded-lg p-2.5 text-sm text-gray-500"
                  />
                </div>
              </div>

              {selectedItemId && (
                <div className="p-3 bg-blue-950/20 border border-blue-900/30 rounded-lg text-xs text-blue-300">
                  <span className="font-bold">Info:</span> Selected item belongs to{' '}
                  <span className="underline">{items.find(i => i.id === selectedItemId)?.category}</span>.
                  Available store stock is {items.find(i => i.id === selectedItemId)?.currentStock}{' '}
                  {items.find(i => i.id === selectedItemId)?.unit}.
                </div>
              )}

              <button
                type="submit"
                disabled={!selectedSiteId || !selectedItemId}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-lg font-bold text-sm transition-colors cursor-pointer flex items-center justify-center space-x-2 shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Add Row to Active list</span>
              </button>
            </form>
          </div>

          {/* Right panel: Active Draft List & Finalize */}
          <div className="lg:col-span-7 bg-[#111111] border border-gray-800 rounded-xl p-5 flex flex-col justify-between shadow-lg min-h-[400px]">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-bold text-gray-200 flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>ACTIVE TRANSACTION LIST (DRAFT)</span>
                </h3>
                <span className="text-xs bg-gray-800 px-2 py-1 rounded text-gray-400">
                  {issueItemsList.length} rows
                </span>
              </div>

              {issueItemsList.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center text-gray-600 border-2 border-dashed border-gray-800/40 rounded-xl">
                  <ArrowLeftRight className="w-12 h-12 text-gray-700 mb-2 animate-pulse" />
                  <p className="text-sm font-medium">Draft inventory allocation is empty.</p>
                  <p className="text-xs mt-1">Select a site and start adding items using the left form panel.</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-gray-800 max-h-[250px] overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1A1A1A] border-b border-gray-800 text-gray-400">
                        <th className="p-3">Item Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3 text-center">In Store</th>
                        <th className="p-3 text-center">Issue Qty</th>
                        <th className="p-3 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-800">
                      {issueItemsList.map((draft, idx) => (
                        <tr key={idx} className="hover:bg-[#1A1A1A]/30">
                          <td className="p-3 font-semibold text-white">{draft.item.itemName}</td>
                          <td className="p-3 text-gray-400">{draft.item.category}</td>
                          <td className="p-3 text-center text-gray-400">{draft.item.currentStock} {draft.item.unit}</td>
                          <td className="p-3 text-center font-bold text-blue-400">{draft.quantity} {draft.item.unit}</td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => handleRemoveDraftItem(idx)}
                              className="p-1 hover:bg-rose-950/30 text-gray-500 hover:text-rose-400 rounded transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Remarks/Transaction Notes */}
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Remarks / Transaction Notes</label>
                <textarea
                  placeholder="E.g., Requested for immediate concrete works, returned tools must be cleaned."
                  rows={2}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-4 border-t border-gray-800/80 mt-4">
              <button
                type="button"
                onClick={() => { setIssueItemsList([]); setRemarks(''); }}
                disabled={issueItemsList.length === 0}
                className="px-4 py-3 bg-gray-800 hover:bg-gray-700 disabled:opacity-40 text-gray-300 rounded-lg font-semibold text-sm transition-colors flex items-center space-x-2"
              >
                <X className="w-4 h-4" />
                <span>Clear</span>
              </button>
              
              <button
                type="button"
                onClick={handleIssueAll}
                disabled={isSubmitting || issueItemsList.length === 0 || !selectedSiteId}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-lg font-bold text-sm transition-all shadow-lg flex items-center justify-center space-x-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                <span>{isSubmitting ? 'Processing Transaction...' : 'Issue All Drafted Items'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB content: RETURN ITEMS & REPAIR & LOST */}
      {activeTab === 'return' && (
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-bold text-gray-200">
                CURRENT ACTIVE SITE INVENTORY FOR ALLOCATED SITE
              </h3>
              <p className="text-xs text-gray-500">Only items currently outstanding on site will appear. You can process returns, repairs, or lost items together.</p>
            </div>
            {selectedSiteId && (
              <span className="text-xs font-semibold bg-emerald-950/50 text-emerald-400 px-3 py-1 rounded border border-emerald-900/50">
                {activeSiteInventory.length} Items Issued Outstanding
              </span>
            )}
          </div>

          {!selectedSiteId ? (
            <div className="flex flex-col items-center justify-center py-20 text-center text-gray-600">
              <MapPin className="w-12 h-12 text-gray-800 mb-2 animate-bounce" />
              <p className="text-sm font-semibold">No Site Selected.</p>
              <p className="text-xs mt-1">Please select a construction site from the top panel to load its outstanding inventory.</p>
            </div>
          ) : activeSiteInventory.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center text-gray-600 border-2 border-dashed border-gray-800/40 rounded-xl">
              <Check className="w-12 h-12 text-emerald-800/40 mb-2" />
              <p className="text-sm font-semibold text-emerald-500">Perfect Site Balance!</p>
              <p className="text-xs mt-1 text-gray-500">This construction site has zero outstanding tools or materials issued to it.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="overflow-x-auto rounded-lg border border-gray-800">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#1A1A1A] border-b border-gray-800 text-gray-400">
                      <th className="p-3">Item Details</th>
                      <th className="p-3 text-center">Site Balance</th>
                      <th className="p-3 text-center bg-emerald-950/25 text-emerald-400">Return Qty (to Store)</th>
                      <th className="p-3 text-center bg-blue-950/25 text-blue-400">Send to Repair</th>
                      <th className="p-3 text-center bg-rose-950/25 text-rose-400">Mark Lost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                    {activeSiteInventory.map((si) => {
                      const returnState = returnQuantities[si.itemCode] || { returnQty: 0, repairQty: 0, lostQty: 0 };
                      const sumAction = returnState.returnQty + returnState.repairQty + returnState.lostQty;
                      const hasOverAllocation = sumAction > si.currentSiteQty;

                      return (
                        <tr key={si.id} className="hover:bg-[#1A1A1A]/30">
                          <td className="p-3 space-y-1">
                            <div className="font-semibold text-white">{si.itemName}</div>
                            <div className="text-[10px] text-gray-500 flex items-center space-x-2">
                              <span>Code: {si.itemCode}</span>
                              <span>•</span>
                              <span>Cat: {si.category}</span>
                            </div>
                          </td>
                          <td className="p-3 text-center">
                            <span className="font-bold text-gray-300 bg-gray-800 px-2 py-1 rounded text-xs">
                              {si.currentSiteQty}
                            </span>
                          </td>
                          
                          {/* RETURN INPUT */}
                          <td className="p-3 bg-emerald-950/10">
                            <input
                              type="number"
                              min="0"
                              max={si.currentSiteQty}
                              placeholder="0"
                              value={returnState.returnQty || ''}
                              onChange={(e) => handleReturnFieldChange(si.itemCode, 'returnQty', Math.max(0, parseInt(e.target.value) || 0))}
                              className="w-16 bg-[#1A1A1A] border border-gray-800 rounded p-1 text-center font-bold text-emerald-400 mx-auto block"
                            />
                          </td>

                          {/* REPAIR INPUT */}
                          <td className="p-3 bg-blue-950/10 space-y-1.5">
                            <input
                              type="number"
                              min="0"
                              max={si.currentSiteQty}
                              placeholder="0"
                              value={returnState.repairQty || ''}
                              onChange={(e) => handleReturnFieldChange(si.itemCode, 'repairQty', Math.max(0, parseInt(e.target.value) || 0))}
                              className="w-16 bg-[#1A1A1A] border border-gray-800 rounded p-1 text-center font-bold text-blue-400 mx-auto block"
                            />
                            {returnState.repairQty > 0 && (
                              <input
                                type="text"
                                placeholder="Repair notes..."
                                value={returnState.repairRemarks || ''}
                                onChange={(e) => handleReturnTextChange(si.itemCode, 'repairRemarks', e.target.value)}
                                className="w-full bg-[#1A1A1A] border border-gray-800 rounded px-2 py-1 text-[10px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                              />
                            )}
                          </td>

                          {/* LOST INPUT */}
                          <td className="p-3 bg-rose-950/10 space-y-1.5">
                            <input
                              type="number"
                              min="0"
                              max={si.currentSiteQty}
                              placeholder="0"
                              value={returnState.lostQty || ''}
                              onChange={(e) => handleReturnFieldChange(si.itemCode, 'lostQty', Math.max(0, parseInt(e.target.value) || 0))}
                              className="w-16 bg-[#1A1A1A] border border-gray-800 rounded p-1 text-center font-bold text-rose-400 mx-auto block"
                            />
                            {returnState.lostQty > 0 && (
                              <input
                                type="text"
                                placeholder="Why lost?"
                                value={returnState.lostReason || ''}
                                onChange={(e) => handleReturnTextChange(si.itemCode, 'lostReason', e.target.value)}
                                className="w-full bg-[#1A1A1A] border border-gray-800 rounded px-2 py-1 text-[10px] text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
                              />
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Check for over-allocation warnings */}
              {Object.entries(returnQuantities).some(([itemCode, q]) => {
                const si = activeSiteInventory.find(i => i.itemCode === itemCode);
                return si ? (q.returnQty + q.repairQty + q.lostQty) > si.currentSiteQty : false;
              }) && (
                <div className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-400 rounded-lg text-xs flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>Warning: One or more rows have combined actions exceeding the outstanding site balance! Complete transaction will fail validation.</span>
                </div>
              )}

              {/* Return Notes */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end pt-2">
                <div className="md:col-span-9">
                  <label className="block text-xs font-semibold text-gray-400 mb-1.5">Return Transaction Comments</label>
                  <input
                    type="text"
                    placeholder="E.g., Batch returned after excavation works completion. All drills checked."
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-xs text-white placeholder-gray-700 focus:outline-none focus:border-blue-500"
                  />
                </div>
                
                <div className="md:col-span-3">
                  <button
                    type="button"
                    onClick={handleReceiveReturn}
                    disabled={isSubmitting}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-800 disabled:text-gray-500 text-white rounded-lg font-bold text-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer shadow-md"
                  >
                    {isSubmitting ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    <span>{isSubmitting ? 'Logging...' : 'Receive & Log Return'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
