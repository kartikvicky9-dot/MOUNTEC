export interface METCItem {
  id: string; // Firestore doc ID
  itemCode: string; // METC-001
  itemName: string;
  category: string; // Materials | Equipment | Tools | Consumables
  unit: string; // Pcs, Tons, Bags, etc.
  minimumStock: number;
  currentStock: number; // Store Stock
  description: string;
}

export interface METCCategory {
  id: string;
  name: string;
}

export interface METCSite {
  id: string;
  siteName: string;
  supervisorName: string;
}

export interface SiteInventory {
  id: string; // composite e.g., "siteId_itemCode"
  siteId: string;
  siteName: string;
  itemCode: string;
  itemName: string;
  category: string;
  issuedQty: number;
  returnedQty: number;
  underRepairQty: number;
  lostQty: number;
  currentSiteQty: number; // Issued - Returned - Repair - Lost
}

export interface METCTransaction {
  id: string;
  transactionNo: string;
  siteId: string;
  siteName: string;
  supervisorName: string;
  date: string; // YYYY-MM-DD
  timestamp: number;
  type: 'Issue' | 'Return';
  status: string; // 'Completed' | 'Partial'
  totalItems: number;
  remarks?: string;
}

export interface METCTransactionDetail {
  id: string;
  transactionNo: string;
  itemCode: string;
  itemName: string;
  category: string;
  storeStockBefore: number;
  quantity: number; // Issue or return quantity
}

export interface METCStockIn {
  id: string;
  supplier: string;
  invoiceNo: string;
  date: string;
  timestamp: number;
  itemCode: string;
  itemName: string;
  quantity: number;
  unitCost?: number;
  remarks?: string;
  source: 'Purchase' | 'Head Office Transfer' | 'Supplier Return' | 'Manual Stock Addition';
}

export interface METCStockAdjustment {
  id: string;
  itemCode: string;
  itemName: string;
  type: 'Add' | 'Deduct';
  quantity: number;
  reason: 'Physical Count' | 'Damage' | 'Correction' | 'Missing Stock';
  remarks?: string;
  date: string;
  timestamp: number;
}

export interface METCRepair {
  id: string;
  itemCode: string;
  itemName: string;
  siteId: string;
  siteName: string; // 'Store' if from store
  quantity: number;
  date: string;
  timestamp: number;
  status: 'Under Repair' | 'Repaired' | 'Scrapped';
  remarks?: string;
}

export interface METCLost {
  id: string;
  itemCode: string;
  itemName: string;
  siteId: string;
  siteName: string;
  quantity: number;
  date: string;
  timestamp: number;
  reason: string;
}

export const SEED_SITES = [
  { siteName: "Jurong East MRT Station", supervisorName: "John Tan" },
  { siteName: "Changi Airport T5 Extension", supervisorName: "Alex Wong" },
  { siteName: "Marina Bay Sands Outer Ring", supervisorName: "David Lim" },
  { siteName: "Tuas South Reclamation Area", supervisorName: "S. Subramaniam" }
];

export const SEED_CATEGORIES = ["Materials", "Equipment", "Tools", "Consumables"];

export const SEED_ITEMS = [
  { itemCode: "METC-001", itemName: "High-Tensile Steel Rebars (12mm)", category: "Materials", unit: "Tons", minimumStock: 5, currentStock: 25, description: "Grade 500 steel reinforcing bars" },
  { itemCode: "METC-002", itemName: "Portland Cement (50kg)", category: "Materials", unit: "Bags", minimumStock: 50, currentStock: 200, description: "General purpose Portland cement" },
  { itemCode: "METC-003", itemName: "Demolition Jackhammer 220V", category: "Equipment", unit: "Sets", minimumStock: 2, currentStock: 8, description: "Heavy duty electric concrete breaker" },
  { itemCode: "METC-004", itemName: "Portable Diesel Generator 5kW", category: "Equipment", unit: "Units", minimumStock: 1, currentStock: 4, description: "Silent diesel generator for site power" },
  { itemCode: "METC-005", itemName: "DeWalt Impact Drill 20V", category: "Tools", unit: "Sets", minimumStock: 4, currentStock: 15, description: "Cordless brushless impact drill kit" },
  { itemCode: "METC-006", itemName: "Heavy Duty Laser Level", category: "Tools", unit: "Units", minimumStock: 2, currentStock: 6, description: "Self-leveling 3D green beam laser level" },
  { itemCode: "METC-007", itemName: "N95 Dust Masks (Box of 50)", category: "Consumables", unit: "Boxes", minimumStock: 10, currentStock: 40, description: "Particulate respirator safety masks" },
  { itemCode: "METC-008", itemName: "Reflective Safety Vests", category: "Consumables", unit: "Pcs", minimumStock: 20, currentStock: 120, description: "High-visibility neon green safety vest" },
  { itemCode: "METC-009", itemName: "Safety Harness & Lanyard", category: "Tools", unit: "Sets", minimumStock: 5, currentStock: 20, description: "Full body fall protection safety harness" },
  { itemCode: "METC-010", itemName: "LED Site Floodlight 100W", category: "Equipment", unit: "Pcs", minimumStock: 5, currentStock: 18, description: "IP66 waterproof outdoor construction work light" }
];
