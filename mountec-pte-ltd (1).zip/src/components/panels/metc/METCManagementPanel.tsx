import React, { useState, useEffect } from 'react';
import { db } from '../../../lib/firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  getDocs,
  doc,
  setDoc,
  query,
  limit
} from 'firebase/firestore';
import { 
  Plus, 
  Sliders, 
  Calendar, 
  Layers, 
  ClipboardList, 
  FileText, 
  Clock, 
  ArrowLeftRight, 
  AlertTriangle, 
  Info, 
  Database, 
  Check, 
  TrendingUp, 
  Archive, 
  RefreshCw 
} from 'lucide-react';

import { 
  METCItem, 
  METCCategory, 
  METCSite, 
  SiteInventory,
  SEED_SITES,
  SEED_CATEGORIES,
  SEED_ITEMS
} from './metcTypes';

import METCControlPanel from './METCControlPanel';
import METCMasterPanel from './METCMasterPanel';
import METCReportsPanel from './METCReportsPanel';

interface METCManagementPanelProps {
  selectedFolderId?: string; // used as active sub-tab from Dashboard sidebar
  setSelectedFolderId?: (id: string) => void;
}

export default function METCManagementPanel({ selectedFolderId, setSelectedFolderId }: METCManagementPanelProps) {
  // Local state as fallback if not driven by Sidebar
  const [localSubTab, setLocalSubTab] = useState<'control_panel' | 'master' | 'reports'>('control_panel');
  const activeSubTab = selectedFolderId && ['control_panel', 'master', 'reports'].includes(selectedFolderId)
    ? (selectedFolderId as 'control_panel' | 'master' | 'reports')
    : localSubTab;

  const handleSubTabChange = (tab: 'control_panel' | 'master' | 'reports') => {
    if (setSelectedFolderId) {
      setSelectedFolderId(tab);
    } else {
      setLocalSubTab(tab);
    }
  };

  // Real-time Database state
  const [items, setItems] = useState<METCItem[]>([]);
  const [categories, setCategories] = useState<METCCategory[]>([]);
  const [sites, setSites] = useState<METCSite[]>([]);
  const [siteInventory, setSiteInventory] = useState<SiteInventory[]>([]);

  const [loading, setLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);

  // ----------------------------------------------------
  // REAL-TIME FIRESTORE SYNCHRONIZATION
  // ----------------------------------------------------
  useEffect(() => {
    setLoading(true);

    // 1. Items Listener
    const unsubItems = onSnapshot(collection(db, 'metc_items'), (snap) => {
      const itemsList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }) as METCItem);
      setItems(itemsList.sort((a, b) => a.itemCode.localeCompare(b.itemCode)));
    });

    // 2. Categories Listener
    const unsubCategories = onSnapshot(collection(db, 'metc_categories'), (snap) => {
      const catList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }) as METCCategory);
      setCategories(catList.sort((a, b) => a.name.localeCompare(b.name)));
    });

    // 3. Sites Listener
    const unsubSites = onSnapshot(collection(db, 'metc_sites'), (snap) => {
      const sitesList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }) as METCSite);
      setSites(sitesList.sort((a, b) => a.siteName.localeCompare(b.siteName)));
      setLoading(false);
    });

    // 4. Site Inventory Listener
    const unsubSiteInv = onSnapshot(collection(db, 'site_inventory'), (snap) => {
      const invList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }) as SiteInventory);
      setSiteInventory(invList);
    });

    return () => {
      unsubItems();
      unsubCategories();
      unsubSites();
      unsubSiteInv();
    };
  }, []);

  // ----------------------------------------------------
  // AUTO-SEEDER ROUTINE (SPECTACULAR FIRST TURN)
  // ----------------------------------------------------
  useEffect(() => {
    const checkAndSeed = async () => {
      // Avoid overlapping seed processes
      if (loading || isSeeding) return;

      // Seed only if main master collections are empty
      if (items.length === 0 && categories.length === 0 && sites.length === 0) {
        setIsSeeding(true);
        try {
          console.log("METC Module: Initializing clean Firestore mock seeder...");
          
          // A. Seed Categories
          const catRefs: { [name: string]: string } = {};
          for (const name of SEED_CATEGORIES) {
            const docRef = await addDoc(collection(db, 'metc_categories'), { name });
            catRefs[name] = docRef.id;
          }

          // B. Seed Sites
          for (const site of SEED_SITES) {
            await addDoc(collection(db, 'metc_sites'), site);
          }

          // C. Seed Items
          for (const item of SEED_ITEMS) {
            await addDoc(collection(db, 'metc_items'), item);
          }

          console.log("METC Module Seeder complete!");
        } catch (e) {
          console.error("Failed to seed initial METC database values:", e);
        } finally {
          setIsSeeding(false);
        }
      }
    };
    checkAndSeed();
  }, [items, categories, sites, loading, isSeeding]);

  const handleTriggerManualSeed = async () => {
    setIsSeeding(true);
    try {
      // Force write categories
      for (const name of SEED_CATEGORIES) {
        if (!categories.some(c => c.name === name)) {
          await addDoc(collection(db, 'metc_categories'), { name });
        }
      }
      // Force write sites
      for (const site of SEED_SITES) {
        if (!sites.some(s => s.siteName === site.siteName)) {
          await addDoc(collection(db, 'metc_sites'), site);
        }
      }
      // Force write items
      for (const item of SEED_ITEMS) {
        if (!items.some(i => i.itemCode === item.itemCode)) {
          await addDoc(collection(db, 'metc_items'), item);
        }
      }
    } catch (e) {
      alert("Seeding error");
    } finally {
      setIsSeeding(false);
    }
  };

  // ----------------------------------------------------
  // COMPUTED ANALYTICS SUMMARY
  // ----------------------------------------------------
  const totalStoreStock = items.reduce((sum, item) => sum + item.currentStock, 0);
  const totalSiteAllocations = siteInventory.reduce((sum, si) => sum + si.currentSiteQty, 0);
  const lowStockCount = items.filter(item => item.currentStock <= item.minimumStock).length;
  const pendingReturnItemsCount = siteInventory.filter(si => si.currentSiteQty > 0).length;

  return (
    <div className="p-6 bg-[#0A0A0A] text-[#E0E0E0] space-y-6 overflow-y-auto h-full print:bg-white print:text-black">
      
      {/* Header Area */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-900 pb-5 print:hidden">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center space-x-2">
            <ClipboardList className="w-7 h-7 text-blue-500" />
            <span>Materials, Equipment, Tools & Consumables (METC)</span>
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Store & Site inventory tracking system. Issuance, returns, repair schedules, and stocktaking.
          </p>
        </div>

        {isSeeding && (
          <div className="flex items-center space-x-2 bg-blue-950/40 border border-blue-900/50 rounded-lg px-4 py-2 text-xs text-blue-400">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Seeding mock data for first-time use...</span>
          </div>
        )}

        {!isSeeding && items.length === 0 && (
          <button
            onClick={handleTriggerManualSeed}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs shadow-md"
          >
            Seed Initial METC Data
          </button>
        )}
      </div>

      {/* Realtime KPI Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 print:hidden">
        
        {/* KPI 1: Main Store Stock */}
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-4 shadow flex items-center space-x-3.5">
          <div className="p-2.5 bg-emerald-950/20 text-emerald-400 rounded-lg border border-emerald-900/20">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Main Store Items</div>
            <div className="text-lg font-bold text-white mt-0.5">{items.length} <span className="text-xs text-gray-500 font-normal">Catalog</span></div>
          </div>
        </div>

        {/* KPI 2: Site Outstanding Stock */}
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-4 shadow flex items-center space-x-3.5">
          <div className="p-2.5 bg-blue-950/20 text-blue-400 rounded-lg border border-blue-900/20">
            <ArrowLeftRight className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Site outstanding</div>
            <div className="text-lg font-bold text-white mt-0.5">
              {totalSiteAllocations} <span className="text-xs text-gray-500 font-normal">items allocated</span>
            </div>
          </div>
        </div>

        {/* KPI 3: Pending Returns */}
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-4 shadow flex items-center space-x-3.5">
          <div className="p-2.5 bg-amber-950/20 text-amber-400 rounded-lg border border-amber-900/20">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Sites Outstanding Logs</div>
            <div className="text-lg font-bold text-white mt-0.5">{pendingReturnItemsCount} <span className="text-xs text-gray-500 font-normal">Pending returns</span></div>
          </div>
        </div>

        {/* KPI 4: Low Stock Warnings */}
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-4 shadow flex items-center space-x-3.5">
          <div className="p-2.5 bg-rose-950/20 text-rose-400 rounded-lg border border-rose-900/20">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Low Stock Alerts</div>
            <div className="text-lg font-bold mt-0.5 text-white">
              <span className={lowStockCount > 0 ? 'text-rose-500 animate-pulse font-extrabold' : 'text-gray-400'}>
                {lowStockCount}
              </span>
              <span className="text-xs text-gray-500 font-normal"> need restock</span>
            </div>
          </div>
        </div>

      </div>

      {/* Subtabs Selector */}
      <div className="flex border-b border-gray-800 gap-4 pb-2 print:hidden">
        {[
          { id: 'control_panel', label: 'METC Control Panel', icon: Sliders },
          { id: 'master', label: 'METC Master', icon: Layers },
          { id: 'reports', label: 'Reports & Audit Logs', icon: FileText }
        ].map(subTab => {
          const Icon = subTab.icon;
          const isActive = activeSubTab === subTab.id;
          return (
            <button
              key={subTab.id}
              onClick={() => handleSubTabChange(subTab.id as any)}
              className={`flex items-center space-x-2 text-xs font-semibold pb-2 border-b-2 transition-all ${
                isActive 
                  ? 'border-blue-500 text-blue-400 font-bold' 
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{subTab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Tab Routing Frame */}
      <div className="bg-[#0D0D0D] border border-gray-800 rounded-2xl p-6 shadow-2xl min-h-[500px] print:border-none print:p-0">
        {loading ? (
          <div className="py-24 flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
            <span className="text-xs text-gray-500">Connecting to Firestore database...</span>
          </div>
        ) : (
          <>
            {activeSubTab === 'control_panel' && (
              <METCControlPanel 
                items={items} 
                sites={sites} 
                siteInventory={siteInventory} 
                loading={loading} 
              />
            )}
            {activeSubTab === 'master' && (
              <METCMasterPanel 
                items={items} 
                categories={categories} 
                loading={loading} 
              />
            )}
            {activeSubTab === 'reports' && (
              <METCReportsPanel 
                items={items} 
                categories={categories} 
                sites={sites} 
                siteInventory={siteInventory} 
                loading={loading} 
              />
            )}
          </>
        )}
      </div>

    </div>
  );
}
