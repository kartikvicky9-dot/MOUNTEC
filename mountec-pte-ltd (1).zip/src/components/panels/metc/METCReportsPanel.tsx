import React, { useState, useEffect } from 'react';
import { db } from '../../../lib/firebase';
import { 
  collection, 
  query, 
  onSnapshot, 
  orderBy, 
  getDocs
} from 'firebase/firestore';
import { 
  Search, 
  FileSpreadsheet, 
  Printer, 
  RefreshCw, 
  MapPin, 
  Tag, 
  Calendar, 
  Info, 
  ArrowLeftRight, 
  Wrench, 
  AlertTriangle, 
  Check, 
  Clock, 
  ChevronRight,
  TrendingUp,
  Sliders
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { 
  METCItem, 
  METCCategory, 
  METCSite, 
  SiteInventory, 
  METCTransaction, 
  METCStockIn, 
  METCStockAdjustment, 
  METCRepair, 
  METCLost 
} from './metcTypes';

interface METCReportsPanelProps {
  items: METCItem[];
  categories: METCCategory[];
  sites: METCSite[];
  siteInventory: SiteInventory[];
  loading: boolean;
}

type ReportType = 
  | 'store_inventory' 
  | 'site_inventory' 
  | 'issue_history' 
  | 'return_history' 
  | 'repairs' 
  | 'lost' 
  | 'stock_in' 
  | 'adjustments' 
  | 'pending_returns' 
  | 'low_stock';

export default function METCReportsPanel({ items, categories, sites, siteInventory, loading }: METCReportsPanelProps) {
  const [activeReport, setActiveReport] = useState<ReportType>('store_inventory');

  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSiteId, setSelectedSiteId] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  // Loaded database histories
  const [transactions, setTransactions] = useState<METCTransaction[]>([]);
  const [repairs, setRepairs] = useState<METCRepair[]>([]);
  const [lost, setLost] = useState<METCLost[]>([]);
  const [stockIns, setStockIns] = useState<METCStockIn[]>([]);
  const [adjustments, setAdjustments] = useState<METCStockAdjustment[]>([]);

  const [localLoading, setLocalLoading] = useState(false);

  // Subscriptions for logs on tab load
  useEffect(() => {
    setLocalLoading(true);
    let unsubTx = () => {};
    let unsubRepairs = () => {};
    let unsubLost = () => {};
    let unsubStockIn = () => {};
    let unsubAdjust = () => {};

    // 1. Transactions subscription
    const qTx = query(collection(db, 'metc_transactions'), orderBy('timestamp', 'desc'));
    unsubTx = onSnapshot(qTx, (snap) => {
      setTransactions(snap.docs.map(d => ({ id: d.id, ...d.data() }) as METCTransaction));
    });

    // 2. Repairs subscription
    const qRep = query(collection(db, 'metc_repairs'), orderBy('timestamp', 'desc'));
    unsubRepairs = onSnapshot(qRep, (snap) => {
      setRepairs(snap.docs.map(d => ({ id: d.id, ...d.data() }) as METCRepair));
    });

    // 3. Lost subscription
    const qLost = query(collection(db, 'metc_lost'), orderBy('timestamp', 'desc'));
    unsubLost = onSnapshot(qLost, (snap) => {
      setLost(snap.docs.map(d => ({ id: d.id, ...d.data() }) as METCLost));
    });

    // 4. Stock In subscription
    const qStIn = query(collection(db, 'metc_stock_in'), orderBy('timestamp', 'desc'));
    unsubStockIn = onSnapshot(qStIn, (snap) => {
      setStockIns(snap.docs.map(d => ({ id: d.id, ...d.data() }) as METCStockIn));
    });

    // 5. Adjustments subscription
    const qAdj = query(collection(db, 'metc_stock_adjustments'), orderBy('timestamp', 'desc'));
    unsubAdjust = onSnapshot(qAdj, (snap) => {
      setAdjustments(snap.docs.map(d => ({ id: d.id, ...d.data() }) as METCStockAdjustment));
      setLocalLoading(false);
    });

    return () => {
      unsubTx();
      unsubRepairs();
      unsubLost();
      unsubStockIn();
      unsubAdjust();
    };
  }, [activeReport]);

  // ----------------------------------------------------
  // REPORT DATA RESOLUTION & FILTERING
  // ----------------------------------------------------
  const getFilteredData = (): any[] => {
    let raw: any[] = [];

    switch (activeReport) {
      case 'store_inventory':
        raw = items.map(i => ({
          'Item Code': i.itemCode,
          'Item Name': i.itemName,
          'Category': i.category,
          'Unit': i.unit,
          'Min Alert Qty': i.minimumStock,
          'Current Store Stock': i.currentStock,
          'Description': i.description || '-'
        }));
        break;

      case 'site_inventory':
        raw = siteInventory.map(si => ({
          'Site Name': si.siteName,
          'Item Code': si.itemCode,
          'Item Name': si.itemName,
          'Category': si.category,
          'Issued Quantity': si.issuedQty,
          'Returned Quantity': si.returnedQty,
          'Under Repair Quantity': si.underRepairQty,
          'Lost Quantity': si.lostQty,
          'Current Site Stock': si.currentSiteQty,
          siteId: si.siteId // keep for filtering
        }));
        break;

      case 'issue_history':
        raw = transactions
          .filter(tx => tx.type === 'Issue')
          .map(tx => ({
            'Transaction No': tx.transactionNo,
            'Site Name': tx.siteName,
            'Supervisor Name': tx.supervisorName,
            'Date': tx.date,
            'Total Items': tx.totalItems,
            'Remarks': tx.remarks || '-',
            siteId: tx.siteId // keep for filtering
          }));
        break;

      case 'return_history':
        raw = transactions
          .filter(tx => tx.type === 'Return')
          .map(tx => ({
            'Transaction No': tx.transactionNo,
            'Site Name': tx.siteName,
            'Supervisor Name': tx.supervisorName,
            'Date': tx.date,
            'Total Items': tx.totalItems,
            'Remarks': tx.remarks || '-',
            siteId: tx.siteId // keep for filtering
          }));
        break;

      case 'repairs':
        raw = repairs.map(r => ({
          'Item Code': r.itemCode,
          'Item Name': r.itemName,
          'Site Source': r.siteName,
          'Quantity': r.quantity,
          'Logged Date': r.date,
          'Status': r.status,
          'Remarks': r.remarks || '-',
          siteId: r.siteId // keep for filtering
        }));
        break;

      case 'lost':
        raw = lost.map(l => ({
          'Item Code': l.itemCode,
          'Item Name': l.itemName,
          'Site Source': l.siteName,
          'Quantity': l.quantity,
          'Logged Date': l.date,
          'Reason': l.reason || '-',
          siteId: l.siteId // keep for filtering
        }));
        break;

      case 'stock_in':
        raw = stockIns.map(si => ({
          'Source': si.source,
          'Supplier': si.supplier,
          'Invoice No': si.invoiceNo,
          'Item Code': si.itemCode,
          'Item Name': si.itemName,
          'Quantity Received': si.quantity,
          'Unit Cost (S$)': si.unitCost ? `S$ ${si.unitCost.toFixed(2)}` : '-',
          'Log Date': si.date,
          'Remarks': si.remarks || '-'
        }));
        break;

      case 'adjustments':
        raw = adjustments.map(a => ({
          'Item Code': a.itemCode,
          'Item Name': a.itemName,
          'Correction Type': a.type === 'Add' ? 'Add (+)' : 'Deduct (-)',
          'Quantity Adjusted': a.quantity,
          'Reason': a.reason,
          'Explanation': a.remarks || '-',
          'Adjustment Date': a.date
        }));
        break;

      case 'pending_returns':
        raw = siteInventory
          .filter(si => si.currentSiteQty > 0)
          .map(si => ({
            'Site Name': si.siteName,
            'Item Code': si.itemCode,
            'Item Name': si.itemName,
            'Category': si.category,
            'Outstanding Site Qty': si.currentSiteQty,
            siteId: si.siteId // keep for filtering
          }));
        break;

      case 'low_stock':
        raw = items
          .filter(i => i.currentStock <= i.minimumStock)
          .map(i => ({
            'Item Code': i.itemCode,
            'Item Name': i.itemName,
            'Category': i.category,
            'Min Limit': i.minimumStock,
            'Current Store Balance': i.currentStock,
            'Unit': i.unit,
            'Status': 'RESTOCK REQUIRED'
          }));
        break;
    }

    // Apply filters
    return raw.filter(row => {
      // 1. Text Search Filter (scans values inside the row objects)
      const valuesStr = Object.values(row).join(' ').toLowerCase();
      const matchSearch = searchQuery ? valuesStr.includes(searchQuery.toLowerCase()) : true;

      // 2. Site Filter
      const matchSite = selectedSiteId ? row.siteId === selectedSiteId || row['Site Name'] === sites.find(s => s.id === selectedSiteId)?.siteName : true;

      // 3. Category Filter
      const rowCategory = row['Category'] || row['Item Category'];
      const matchCategory = selectedCategory ? rowCategory === selectedCategory : true;

      return matchSearch && matchSite && matchCategory;
    });
  };

  const filteredData = getFilteredData();

  // ----------------------------------------------------
  // ACTION: EXPORT TO EXCEL
  // ----------------------------------------------------
  const handleExportExcel = () => {
    if (filteredData.length === 0) return;

    // Remove temporary filtering keys (like siteId) before writing out to sheet
    const cleanRows = filteredData.map(row => {
      const copy = { ...row };
      delete copy.siteId;
      return copy;
    });

    const worksheet = XLSX.utils.json_to_sheet(cleanRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "METC_Report");

    // Format title
    const reportTitle = activeReport.toUpperCase().replace(/_/g, ' ');
    XLSX.writeFile(workbook, `METC_${reportTitle}_Report.xlsx`);
  };

  // ----------------------------------------------------
  // ACTION: PRINT REPORT
  // ----------------------------------------------------
  const handlePrint = () => {
    window.print();
  };

  const reportOptions: { value: ReportType; label: string; count?: number; icon: any; color: string }[] = [
    { value: 'store_inventory', label: 'Main Store Inventory', icon: Check, color: 'text-emerald-500' },
    { value: 'site_inventory', label: 'Site-wise Allocation', icon: MapPin, color: 'text-blue-500' },
    { value: 'pending_returns', label: 'Outstanding Site Returns', count: siteInventory.filter(si => si.currentSiteQty > 0).length, icon: Clock, color: 'text-amber-500' },
    { value: 'low_stock', label: 'Low Stock Alerts', count: items.filter(i => i.currentStock <= i.minimumStock).length, icon: AlertTriangle, color: 'text-rose-500' },
    { value: 'issue_history', label: 'Issue Transaction History', icon: ArrowLeftRight, color: 'text-blue-400' },
    { value: 'return_history', label: 'Return Transaction History', icon: ArrowLeftRight, color: 'text-emerald-400' },
    { value: 'repairs', label: 'Repairs Log / Under Repair', icon: Wrench, color: 'text-orange-500' },
    { value: 'lost', label: 'Lost / Damaged Items', icon: AlertTriangle, color: 'text-red-500' },
    { value: 'stock_in', label: 'Stock In (Arrival Log)', icon: TrendingUp, color: 'text-emerald-500' },
    { value: 'adjustments', label: 'Stock Corrections Audit', icon: Sliders, color: 'text-purple-500' },
  ];

  const getTableHeaders = (): string[] => {
    if (filteredData.length === 0) return [];
    // Filter out siteId metadata from visual table columns
    return Object.keys(filteredData[0]).filter(k => k !== 'siteId');
  };

  const headers = getTableHeaders();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 print:block">
      
      {/* Left panel: Report selection menu (hidden on print) */}
      <div className="lg:col-span-3 bg-[#111111] border border-gray-800 rounded-xl p-4 shadow-lg space-y-3 print:hidden">
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider px-2 mb-2">Reports Selector</h3>
        <nav className="space-y-1.5">
          {reportOptions.map((opt) => {
            const IconComp = opt.icon;
            const isSelected = activeReport === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => {
                  setActiveReport(opt.value);
                  setSearchQuery('');
                  setSelectedSiteId('');
                  setSelectedCategory('');
                }}
                className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <IconComp className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-white' : opt.color}`} />
                  <span>{opt.label}</span>
                </div>
                {opt.count !== undefined && opt.count > 0 && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    isSelected ? 'bg-white text-blue-600' : 'bg-gray-800 text-gray-300'
                  }`}>
                    {opt.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Right panel: Active report, search filters, and tabular representation */}
      <div className="lg:col-span-9 bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-4 print:border-none print:bg-white print:text-black">
        
        {/* Header summary of selected report */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gray-800/60 pb-3 print:border-b-2 print:border-gray-300">
          <div>
            <h3 className="text-base font-bold text-white print:text-black uppercase tracking-wide">
              {reportOptions.find(o => o.value === activeReport)?.label}
            </h3>
            <p className="text-xs text-gray-500 print:hidden">
              Displaying real-time records synchronized from main Firestore schema.
            </p>
          </div>

          <div className="flex items-center space-x-2 mt-3 sm:mt-0 print:hidden">
            <button
              onClick={handleExportExcel}
              disabled={filteredData.length === 0}
              className="py-2 px-3.5 bg-[#1A1A1A] hover:bg-gray-800 disabled:opacity-40 text-emerald-400 rounded-lg text-xs font-bold border border-gray-800 flex items-center space-x-1.5 transition-colors cursor-pointer shadow"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export Excel</span>
            </button>
            <button
              onClick={handlePrint}
              disabled={filteredData.length === 0}
              className="py-2 px-3.5 bg-[#1A1A1A] hover:bg-gray-800 disabled:opacity-40 text-gray-300 rounded-lg text-xs font-bold border border-gray-800 flex items-center space-x-1.5 transition-colors cursor-pointer shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
          </div>
        </div>

        {/* Dynamic Filters Bar (Hidden on print) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#1A1A1A]/40 p-3 rounded-lg border border-gray-800/40 print:hidden">
          <div className="relative">
            <input
              type="text"
              placeholder="Search in records..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2 pl-8 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-blue-500"
            />
            <div className="absolute inset-y-0 left-2.5 flex items-center pointer-events-none text-gray-600">
              <Search className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Conditional Site Filter */}
          {['site_inventory', 'issue_history', 'return_history', 'repairs', 'lost', 'pending_returns'].includes(activeReport) ? (
            <div className="relative">
              <select
                value={selectedSiteId}
                onChange={(e) => setSelectedSiteId(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2 pr-8 text-xs text-white focus:outline-none appearance-none cursor-pointer"
              >
                <option value="">-- All Sites --</option>
                {sites.map(site => (
                  <option key={site.id} value={site.id}>{site.siteName}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-gray-500">
                <MapPin className="w-3.5 h-3.5" />
              </div>
            </div>
          ) : <div className="hidden sm:block"></div>}

          {/* Conditional Category Filter */}
          {['store_inventory', 'site_inventory', 'pending_returns', 'low_stock'].includes(activeReport) ? (
            <div className="relative">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2 pr-8 text-xs text-white focus:outline-none appearance-none cursor-pointer"
              >
                <option value="">-- All Categories --</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.name}>{cat.name}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-gray-500">
                <Tag className="w-3.5 h-3.5" />
              </div>
            </div>
          ) : <div className="hidden sm:block"></div>}
        </div>

        {/* Tabular Records */}
        <div className="bg-[#111111] border border-gray-800 rounded-lg overflow-hidden shadow-md print:border-none">
          {loading || localLoading ? (
            <div className="p-20 flex flex-col items-center justify-center space-y-3">
              <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
              <span className="text-xs text-gray-500">Compiling report data...</span>
            </div>
          ) : filteredData.length === 0 ? (
            <div className="p-16 text-center text-gray-600 border border-dashed border-gray-800/30 rounded-lg">
              <Info className="w-10 h-10 text-gray-700 mx-auto mb-2" />
              <p className="text-xs font-semibold">No records match the current filter set.</p>
              <p className="text-[10px] mt-0.5">Try widening search criteria or selecting a different report selector.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-[11px] print:text-black">
                <thead>
                  <tr className="bg-[#1A1A1A] border-b border-gray-800 text-gray-400 font-semibold print:bg-gray-100 print:text-black print:border-b-2">
                    {headers.map((h, i) => (
                      <th key={i} className="p-3 whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800 print:divide-y-2 print:divide-gray-300">
                  {filteredData.map((row, rowIdx) => {
                    const isAlertRow = row['Status'] === 'RESTOCK REQUIRED' || row['Current Store Balance'] <= row['Min Limit'];
                    return (
                      <tr 
                        key={rowIdx} 
                        className={`hover:bg-[#1A1A1A]/25 print:hover:bg-transparent ${
                          isAlertRow ? 'bg-rose-950/5 text-rose-300' : 'text-gray-300 print:text-black'
                        }`}
                      >
                        {headers.map((h, colIdx) => {
                          const val = row[h];
                          return (
                            <td key={colIdx} className="p-3">
                              {h.includes('No') || h.includes('Code') ? (
                                <span className="font-mono font-semibold text-blue-400 print:text-black">{val}</span>
                              ) : h === 'Status' ? (
                                <span className={`px-2 py-0.5 rounded text-[9px] font-extrabold ${
                                  val === 'Under Repair' ? 'bg-blue-950/50 text-blue-400 border border-blue-900/40' :
                                  val === 'RESTOCK REQUIRED' ? 'bg-rose-950/50 text-rose-400 border border-rose-900/40 animate-pulse' :
                                  val === 'Repaired' ? 'bg-emerald-950/50 text-emerald-400' : 'bg-gray-800 text-gray-400'
                                }`}>
                                  {val}
                                </span>
                              ) : (
                                <span>{val}</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Print specific footer */}
        <div className="hidden print:block text-center text-[10px] text-gray-400 pt-8 border-t border-gray-200 mt-10">
          <p>Mountec Construction Management System - METC Management Report</p>
          <p>Generated on: {new Date().toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
