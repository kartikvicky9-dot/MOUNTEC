import React, { useState } from 'react';
import { db } from '../../../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  runTransaction
} from 'firebase/firestore';
import { 
  Plus, 
  Trash2, 
  Edit, 
  Layers, 
  Calendar, 
  AlertTriangle, 
  Check, 
  X, 
  Sliders, 
  Archive,
  DollarSign,
  TrendingUp,
  Tag,
  RefreshCw
} from 'lucide-react';
import { METCItem, METCCategory } from './metcTypes';

interface METCMasterPanelProps {
  items: METCItem[];
  categories: METCCategory[];
  loading: boolean;
}

export default function METCMasterPanel({ items, categories, loading }: METCMasterPanelProps) {
  const [activeTab, setActiveTab] = useState<'items' | 'stock_in' | 'adjust' | 'categories'>('items');

  // Status Message State
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 1. Items Master States
  const [editingItem, setEditingItem] = useState<METCItem | null>(null);
  const [showItemForm, setShowItemForm] = useState(false);
  const [itemCode, setItemCode] = useState('');
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState('');
  const [itemUnit, setItemUnit] = useState('Pcs');
  const [itemMinStock, setItemMinStock] = useState<number>(5);
  const [itemCurrentStock, setItemCurrentStock] = useState<number>(0);
  const [itemDesc, setItemDesc] = useState('');

  // 2. Stock In States
  const [stockInItemId, setStockInItemId] = useState('');
  const [stockInQty, setStockInQty] = useState<number>(10);
  const [stockInSupplier, setStockInSupplier] = useState('');
  const [stockInInvoice, setStockInInvoice] = useState('');
  const [stockInCost, setStockInCost] = useState<number>(0);
  const [stockInSource, setStockInSource] = useState<'Purchase' | 'Head Office Transfer' | 'Supplier Return' | 'Manual Stock Addition'>('Purchase');
  const [stockInRemarks, setStockInRemarks] = useState('');

  // 3. Stock Adjustment States
  const [adjItemId, setAdjItemId] = useState('');
  const [adjType, setAdjType] = useState<'Add' | 'Deduct'>('Add');
  const [adjQty, setAdjQty] = useState<number>(1);
  const [adjReason, setAdjReason] = useState<'Physical Count' | 'Damage' | 'Correction' | 'Missing Stock'>('Physical Count');
  const [adjRemarks, setAdjRemarks] = useState('');

  // 4. Category States
  const [newCatName, setNewCatName] = useState('');

  const triggerMsg = (type: 'success' | 'error', text: string) => {
    setStatusMsg({ type, text });
    setTimeout(() => setStatusMsg(null), 5000);
  };

  const handleOpenNewItemForm = () => {
    setEditingItem(null);
    setItemCode(`METC-${String(items.length + 1).padStart(3, '0')}`);
    setItemName('');
    setItemCategory(categories[0]?.name || 'Materials');
    setItemUnit('Pcs');
    setItemMinStock(5);
    setItemCurrentStock(0);
    setItemDesc('');
    setShowItemForm(true);
  };

  const handleEditItem = (item: METCItem) => {
    setEditingItem(item);
    setItemCode(item.itemCode);
    setItemName(item.itemName);
    setItemCategory(item.category);
    setItemUnit(item.unit);
    setItemMinStock(item.minimumStock);
    setItemCurrentStock(item.currentStock);
    setItemDesc(item.description);
    setShowItemForm(true);
  };

  // CRUD: Add or Edit METC Item
  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemCode || !itemName || !itemCategory) {
      triggerMsg('error', 'Please fill in all required fields.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        itemCode: itemCode.trim(),
        itemName: itemName.trim(),
        category: itemCategory,
        unit: itemUnit,
        minimumStock: Number(itemMinStock),
        currentStock: Number(itemCurrentStock),
        description: itemDesc.trim()
      };

      if (editingItem) {
        // Update item doc
        await updateDoc(doc(db, 'metc_items', editingItem.id), payload);
        triggerMsg('success', `Item ${itemName} updated successfully.`);
      } else {
        // Prevent duplicate item codes
        const codeExists = items.some(i => i.itemCode.toLowerCase() === itemCode.trim().toLowerCase());
        if (codeExists) {
          triggerMsg('error', `An item with code ${itemCode} already exists!`);
          setIsSubmitting(false);
          return;
        }
        // Add new item doc
        await addDoc(collection(db, 'metc_items'), payload);
        triggerMsg('success', `Item ${itemName} added successfully to catalog.`);
      }

      setShowItemForm(false);
      setEditingItem(null);
    } catch (err: any) {
      triggerMsg('error', err.message || 'Error occurred while saving item.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // CRUD: Delete Item
  const handleDeleteItem = async (id: string, name: string) => {
    if (!window.confirm(`Are you absolutely sure you want to delete ${name} from the catalog? This cannot be undone.`)) return;

    try {
      await deleteDoc(doc(db, 'metc_items', id));
      triggerMsg('success', `Item ${name} deleted successfully.`);
    } catch (err: any) {
      triggerMsg('error', err.message || 'Error deleting item.');
    }
  };

  // TRANSACTION: Save Stock In
  const handleSaveStockIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockInItemId) {
      triggerMsg('error', 'Please select an item first.');
      return;
    }
    if (stockInQty <= 0) {
      triggerMsg('error', 'Quantity must be positive.');
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedItem = items.find(i => i.id === stockInItemId);
      if (!selectedItem) throw new Error('Selected item is invalid.');

      const today = new Date().toISOString().split('T')[0];
      const timestamp = Date.now();

      await runTransaction(db, async (txn) => {
        // Fetch fresh currentStock
        const itemRef = doc(db, 'metc_items', selectedItem.id);
        const itemSnap = await txn.get(itemRef);
        if (!itemSnap.exists()) throw new Error('Item no longer exists.');
        
        const freshStock = itemSnap.data().currentStock || 0;

        // 1. Create stock_in log
        const logRef = doc(collection(db, 'metc_stock_in'));
        txn.set(logRef, {
          supplier: stockInSupplier || 'Head Office Transfer',
          invoiceNo: stockInInvoice || 'N/A',
          date: today,
          timestamp,
          itemCode: selectedItem.itemCode,
          itemName: selectedItem.itemName,
          quantity: stockInQty,
          unitCost: Number(stockInCost) || 0,
          remarks: stockInRemarks || 'Log: Stock In',
          source: stockInSource
        });

        // 2. Increment store balance
        txn.update(itemRef, {
          currentStock: freshStock + stockInQty
        });
      });

      triggerMsg('success', `Received ${stockInQty} ${selectedItem.unit} of ${selectedItem.itemName}. Store stock increased!`);
      // Reset
      setStockInItemId('');
      setStockInQty(10);
      setStockInSupplier('');
      setStockInInvoice('');
      setStockInCost(0);
      setStockInRemarks('');
    } catch (err: any) {
      triggerMsg('error', err.message || 'Error receiving stock.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // TRANSACTION: Save Stock Adjustment
  const handleSaveAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjItemId) {
      triggerMsg('error', 'Please select an item first.');
      return;
    }
    if (adjQty <= 0) {
      triggerMsg('error', 'Adjustment quantity must be greater than 0.');
      return;
    }

    setIsSubmitting(true);
    try {
      const selectedItem = items.find(i => i.id === adjItemId);
      if (!selectedItem) throw new Error('Selected item is invalid.');

      const today = new Date().toISOString().split('T')[0];
      const timestamp = Date.now();

      await runTransaction(db, async (txn) => {
        const itemRef = doc(db, 'metc_items', selectedItem.id);
        const itemSnap = await txn.get(itemRef);
        if (!itemSnap.exists()) throw new Error('Item no longer exists.');

        const freshStock = itemSnap.data().currentStock || 0;
        let finalStock = freshStock;

        if (adjType === 'Add') {
          finalStock += adjQty;
        } else {
          if (freshStock < adjQty) {
            throw new Error(`Invalid correction. Deduct quantity (${adjQty}) exceeds current store stock (${freshStock}).`);
          }
          finalStock -= adjQty;
        }

        // 1. Create Stock adjustment record
        const logRef = doc(collection(db, 'metc_stock_adjustments'));
        txn.set(logRef, {
          itemCode: selectedItem.itemCode,
          itemName: selectedItem.itemName,
          type: adjType,
          quantity: adjQty,
          reason: adjReason,
          remarks: adjRemarks || 'Log: Manual adjustment',
          date: today,
          timestamp
        });

        // 2. Update store stock
        txn.update(itemRef, {
          currentStock: finalStock
        });
      });

      triggerMsg('success', `Adjustment saved successfully! Stock updated.`);
      setAdjItemId('');
      setAdjQty(1);
      setAdjRemarks('');
    } catch (err: any) {
      triggerMsg('error', err.message || 'Error occurred during stock correction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // CRUD: Categories
  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const catExists = categories.some(c => c.name.toLowerCase() === newCatName.trim().toLowerCase());
    if (catExists) {
      triggerMsg('error', 'Category already exists!');
      return;
    }

    try {
      await addDoc(collection(db, 'metc_categories'), { name: newCatName.trim() });
      triggerMsg('success', `Category "${newCatName}" created successfully.`);
      setNewCatName('');
    } catch (err: any) {
      triggerMsg('error', err.message || 'Error saving category.');
    }
  };

  const handleDeleteCategory = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete category "${name}"? Items linked to this category will remain, but you won't be able to select it for new items.`)) return;

    try {
      await deleteDoc(doc(db, 'metc_categories', id));
      triggerMsg('success', `Category "${name}" deleted.`);
    } catch (err: any) {
      triggerMsg('error', 'Error deleting category.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Sub Menu Navigation */}
      <div className="flex border-b border-gray-800">
        <button
          onClick={() => { setActiveTab('items'); setStatusMsg(null); }}
          className={`px-5 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'items'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Archive className="w-4 h-4 text-blue-500" />
          <span>ITEMS CATALOG (CRUD)</span>
        </button>
        <button
          onClick={() => { setActiveTab('stock_in'); setStatusMsg(null); }}
          className={`px-5 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'stock_in'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-500" />
          <span>STOCK IN (New Delivery)</span>
        </button>
        <button
          onClick={() => { setActiveTab('adjust'); setStatusMsg(null); }}
          className={`px-5 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'adjust'
              ? 'border-amber-500 text-amber-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Sliders className="w-4 h-4 text-amber-500" />
          <span>STOCK ADJUSTMENT (Correction)</span>
        </button>
        <button
          onClick={() => { setActiveTab('categories'); setStatusMsg(null); }}
          className={`px-5 py-3 font-semibold text-sm transition-colors border-b-2 flex items-center space-x-2 ${
            activeTab === 'categories'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Layers className="w-4 h-4 text-purple-500" />
          <span>CATEGORIES</span>
        </button>
      </div>

      {/* Alert Banner */}
      {statusMsg && (
        <div className={`p-4 rounded-xl border flex items-start space-x-3 transition-all ${
          statusMsg.type === 'success' 
            ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-300' 
            : 'bg-rose-950/20 border-rose-900/50 text-rose-300'
        }`}>
          {statusMsg.type === 'success' ? <Check className="w-5 h-5 text-emerald-400 flex-shrink-0" /> : <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0" />}
          <div className="text-sm font-semibold">{statusMsg.text}</div>
        </div>
      )}

      {/* -------------------- VIEW: ITEMS CRUD -------------------- */}
      {activeTab === 'items' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider">Store Inventory Items Master</h3>
            <button
              onClick={handleOpenNewItemForm}
              className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center space-x-1 transition-all cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Item</span>
            </button>
          </div>

          {showItemForm && (
            <div className="bg-[#111111] border border-blue-900/40 rounded-xl p-5 shadow-lg space-y-4">
              <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                <h4 className="text-sm font-bold text-blue-400">{editingItem ? `EDIT CATALOG ITEM: ${editingItem.itemName}` : 'REGISTER NEW METC ITEM'}</h4>
                <button onClick={() => setShowItemForm(false)} className="text-gray-500 hover:text-white"><X className="w-4 h-4" /></button>
              </div>

              <form onSubmit={handleSaveItem} className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Item Code *</label>
                  <input
                    type="text"
                    required
                    value={itemCode}
                    onChange={(e) => setItemCode(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Item Name *</label>
                  <input
                    type="text"
                    required
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Category *</label>
                  <select
                    value={itemCategory}
                    required
                    onChange={(e) => setItemCategory(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500 cursor-pointer"
                  >
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.name}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Unit of Measure (e.g., Tons, Pcs, Bags)</label>
                  <input
                    type="text"
                    required
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Alert Minimum Stock Level</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={itemMinStock}
                    onChange={(e) => setItemMinStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500 font-bold text-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Current Store Stock</label>
                  <input
                    type="number"
                    min="0"
                    required
                    disabled={!!editingItem} // Store Stock should only be increased via "Stock In" or "Stock Adjust" after initial creation
                    value={itemCurrentStock}
                    onChange={(e) => setItemCurrentStock(parseInt(e.target.value) || 0)}
                    className={`w-full border border-gray-800 rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500 font-bold ${
                      editingItem ? 'bg-gray-800/40 text-gray-400 cursor-not-allowed' : 'bg-[#1A1A1A] text-white'
                    }`}
                  />
                  {editingItem && (
                    <span className="text-[10px] text-gray-500 block mt-1">To update stock of existing items, use Stock In or Stock Adjustment tabs.</span>
                  )}
                </div>

                <div className="md:col-span-3">
                  <label className="block text-xs font-semibold text-gray-400 mb-1">Description / Notes</label>
                  <input
                    type="text"
                    value={itemDesc}
                    onChange={(e) => setItemDesc(e.target.value)}
                    placeholder="Short description of technical specifications or storage requirements"
                    className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="md:col-span-3 flex justify-end space-x-3 pt-3 border-t border-gray-800/60 mt-2">
                  <button
                    type="button"
                    onClick={() => { setShowItemForm(false); setEditingItem(null); }}
                    className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg font-semibold text-xs transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-lg font-bold text-xs transition-all flex items-center space-x-1"
                  >
                    {isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>{editingItem ? 'Update Catalog Item' : 'Create Item'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-[#111111] border border-gray-800 rounded-xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#1A1A1A] border-b border-gray-800 text-gray-400">
                    <th className="p-3">Code</th>
                    <th className="p-3">Item Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3 text-center">Unit</th>
                    <th className="p-3 text-center">Min. Alert</th>
                    <th className="p-3 text-center">Current Store Stock</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-gray-500">
                        Item catalog is empty. Add a new item to get started.
                      </td>
                    </tr>
                  ) : (
                    items.map((item) => {
                      const isLowStock = item.currentStock <= item.minimumStock;
                      return (
                        <tr key={item.id} className={`hover:bg-[#1A1A1A]/30 ${isLowStock ? 'bg-amber-950/5' : ''}`}>
                          <td className="p-3 font-mono font-bold text-blue-400">{item.itemCode}</td>
                          <td className="p-3 font-semibold text-white space-y-1">
                            <div>{item.itemName}</div>
                            {item.description && <div className="text-[10px] text-gray-500 font-normal">{item.description}</div>}
                          </td>
                          <td className="p-3 text-gray-300">{item.category}</td>
                          <td className="p-3 text-center text-gray-400">{item.unit}</td>
                          <td className="p-3 text-center font-bold text-amber-500">{item.minimumStock}</td>
                          <td className={`p-3 text-center font-bold text-sm ${isLowStock ? 'text-amber-500 animate-pulse' : 'text-emerald-400'}`}>
                            {item.currentStock} {item.unit}
                            {isLowStock && (
                              <span className="block text-[9px] font-semibold text-amber-500 tracking-wider">LOW STOCK</span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center space-x-1">
                              <button
                                onClick={() => handleEditItem(item)}
                                className="p-1.5 bg-gray-800 hover:bg-gray-700 text-blue-400 hover:text-blue-300 rounded transition-colors"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteItem(item.id, item.itemName)}
                                className="p-1.5 bg-gray-800 hover:bg-gray-700 text-rose-400 hover:text-rose-300 rounded transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* -------------------- VIEW: STOCK IN -------------------- */}
      {activeTab === 'stock_in' && (
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-5">
          <div>
            <h3 className="text-sm font-bold text-gray-200 flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <span>LOG STORE ARRIVALS (INCOMING STOCK)</span>
            </h3>
            <p className="text-xs text-gray-500">Record newly purchased items, transfers, or returns directly into the physical main warehouse.</p>
          </div>

          <form onSubmit={handleSaveStockIn} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Select Item *</label>
              <select
                required
                value={stockInItemId}
                onChange={(e) => setStockInItemId(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="">-- Choose Item --</option>
                {items.map(item => (
                  <option key={item.id} value={item.id}>
                    {item.itemName} [{item.itemCode}] - (Currently: {item.currentStock} {item.unit})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Receive Quantity *</label>
              <input
                type="number"
                min="1"
                required
                value={stockInQty}
                onChange={(e) => setStockInQty(parseInt(e.target.value) || 0)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Stock In Source *</label>
              <select
                required
                value={stockInSource}
                onChange={(e: any) => setStockInSource(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="Purchase">Purchase (Invoice Reference)</option>
                <option value="Head Office Transfer">Head Office Transfer</option>
                <option value="Supplier Return">Supplier Return</option>
                <option value="Manual Stock Addition">Manual Stock Addition</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Supplier Name</label>
              <input
                type="text"
                placeholder="E.g., Steel Dynamics Singapore"
                value={stockInSupplier}
                onChange={(e) => setStockInSupplier(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Invoice Number</label>
              <input
                type="text"
                placeholder="E.g., INV-993821"
                value={stockInInvoice}
                onChange={(e) => setStockInInvoice(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Unit Cost (S$ - Optional)</label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="0.00"
                  value={stockInCost || ''}
                  onChange={(e) => setStockInCost(parseFloat(e.target.value) || 0)}
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 pl-8 font-mono"
                />
                <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-gray-500 text-xs font-bold font-mono">
                  S$
                </div>
              </div>
            </div>

            <div className="md:col-span-3">
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Stock In Notes / Remarks</label>
              <input
                type="text"
                placeholder="E.g. Received by store officer Alex. Inspected for transit damages."
                value={stockInRemarks}
                onChange={(e) => setStockInRemarks(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="md:col-span-3 flex justify-end pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="py-3 px-6 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-lg font-bold text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-md"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>Record Store Stock Arrival</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* -------------------- VIEW: STOCK ADJUSTMENTS -------------------- */}
      {activeTab === 'adjust' && (
        <div className="bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-5">
          <div className="p-3 bg-amber-950/15 border border-amber-900/30 text-amber-400 rounded-lg text-xs flex items-start space-x-2.5">
            <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-500" />
            <div>
              <span className="font-bold block">AUDIT PRECAUTION:</span>
              Manual stock corrections bypass standard workflows. These logs are stored permanently inside correction histories for audit checks. Please ensure the reasons entered are descriptive.
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-gray-200 flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-500" />
              <span>MANUAL STORE CORRECTION AUDIT</span>
            </h3>
            <p className="text-xs text-gray-500">Perform adjustments based on visual stocktaking counts, physical discrepancies, or damaged items.</p>
          </div>

          <form onSubmit={handleSaveAdjustment} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Select Item *</label>
              <select
                required
                value={adjItemId}
                onChange={(e) => setAdjItemId(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="">-- Choose Item --</option>
                {items.map(item => (
                  <option key={item.id} value={item.id}>
                    {item.itemName} [{item.itemCode}] - (Store: {item.currentStock} {item.unit})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Adjustment Action *</label>
              <select
                required
                value={adjType}
                onChange={(e: any) => setAdjType(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="Add">ADD Stock (+)</option>
                <option value="Deduct">DEDUCT Stock (-)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Quantity *</label>
              <input
                type="number"
                min="1"
                required
                value={adjQty}
                onChange={(e) => setAdjQty(parseInt(e.target.value) || 0)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-amber-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Primary Reason *</label>
              <select
                required
                value={adjReason}
                onChange={(e: any) => setAdjReason(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                <option value="Physical Count">Physical Count Discrepancy</option>
                <option value="Damage">Damage / Spoilage</option>
                <option value="Correction">Administrative Correction</option>
                <option value="Missing Stock">Missing Stock (Theft/Lost)</option>
              </select>
            </div>

            <div className="md:col-span-4">
              <label className="block text-xs font-semibold text-gray-400 mb-1.5">Adjustment Explanation / Remarks *</label>
              <input
                type="text"
                required
                placeholder="E.g., Discovered during Friday morning physical audit. Container seal was broken."
                value={adjRemarks}
                onChange={(e) => setAdjRemarks(e.target.value)}
                className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="md:col-span-4 flex justify-end pt-3">
              <button
                type="submit"
                disabled={isSubmitting}
                className="py-3 px-6 bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white rounded-lg font-bold text-sm transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-md"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                <span>Process Stock Correction</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* -------------------- VIEW: CATEGORIES CRUD -------------------- */}
      {activeTab === 'categories' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-5 bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-gray-200 flex items-center space-x-2">
              <Tag className="w-4 h-4 text-purple-500" />
              <span>ADD PRODUCT CATEGORY</span>
            </h3>
            
            <form onSubmit={handleAddCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-400 mb-1.5">Category Name *</label>
                <input
                  type="text"
                  required
                  placeholder="E.g., Electronics, Heavy Materials"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="w-full bg-[#1A1A1A] border border-gray-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold text-xs transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Category</span>
              </button>
            </form>
          </div>

          <div className="md:col-span-7 bg-[#111111] border border-gray-800 rounded-xl p-5 shadow-lg space-y-3">
            <h3 className="text-sm font-bold text-gray-200">EXISTING SYSTEM CATEGORIES</h3>
            <p className="text-xs text-gray-500">Managing these affects items options during creation.</p>

            <div className="border border-gray-800 rounded-lg overflow-hidden">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#1A1A1A] border-b border-gray-800 text-gray-400">
                    <th className="p-3">Category ID</th>
                    <th className="p-3">Category Name</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800 text-gray-300">
                  {categories.map((cat, idx) => {
                    const isImmutable = ["Materials", "Equipment", "Tools", "Consumables"].includes(cat.name);
                    return (
                      <tr key={cat.id || idx} className="hover:bg-[#1A1A1A]/30">
                        <td className="p-3 font-mono text-gray-500">{cat.id || 'Seeded'}</td>
                        <td className="p-3 font-semibold text-white">{cat.name}</td>
                        <td className="p-3 text-center">
                          {isImmutable ? (
                            <span className="text-[10px] bg-gray-800 text-gray-500 px-2 py-0.5 rounded font-bold">LOCKED SYSTEM</span>
                          ) : (
                            <button
                              onClick={() => handleDeleteCategory(cat.id, cat.name)}
                              className="p-1 text-rose-400 hover:bg-rose-950/20 rounded transition-colors"
                            >
                              <Trash2 className="w-4 h-4 mx-auto" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
