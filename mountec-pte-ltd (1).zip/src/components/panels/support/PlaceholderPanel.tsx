import React from 'react';

export default function PlaceholderPanel({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-64 bg-[#141414] rounded-xl shadow-2xl shadow-black/50 border border-[#222]">
      <h3 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-2">{title}</h3>
      <p className="text-[10px] uppercase tracking-wider text-[#555]">This section is currently under construction.</p>
    </div>
  );
}
