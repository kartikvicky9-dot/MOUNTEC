import React, { useState } from 'react';
import PlaceholderPanel from '../support/PlaceholderPanel';

export default function SupportManagementPanel() {
  const [activeTab, setActiveTab] = useState('6.1');

  const tabs = [
    { id: '6.1', label: '6.1 Information Sharing', component: () => <PlaceholderPanel title="Information Sharing" /> },
  ];

  const ActiveComponent = (tabs.find(t => t.id === activeTab)?.component || PlaceholderPanel) as any;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-xl text-white">
      <h2 className="text-2xl font-bold p-6 border-b border-gray-800">6. Support & General</h2>
      <div className="flex flex-1 overflow-hidden">
        <div className="w-80 border-r border-gray-800 p-4 space-y-2 overflow-y-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left p-3 rounded text-sm ${activeTab === tab.id ? 'bg-blue-600' : 'hover:bg-gray-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 p-6 overflow-y-auto">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
}
