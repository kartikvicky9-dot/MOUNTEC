import React, { useEffect, useState } from 'react';
import { db } from '../../../lib/firebase';
import { collection, query, onSnapshot, doc, setDoc, deleteDoc, updateDoc, orderBy, addDoc } from 'firebase/firestore';
import { Key, Mail, User, Plus, Trash2, Edit2, Eye, EyeOff, Shield, Check, X, ShieldAlert, KeyRound, Share2, Copy, ExternalLink } from 'lucide-react';
import { useAppContext } from '../../../context/AppContext';

interface Credential {
  id: string;
  email: string;
  password?: string;
  name?: string;
  role: 'Master Admin' | 'Admin' | 'User';
  accessiblePanels?: string[];
  createdAt: number;
  employeeId?: string;
}

const AVAILABLE_PANELS = [
  { id: 'executive', label: '1. EXECUTIVE & GOVERNANCE' },
  { id: 'hr', label: '2. HUMAN CAPITAL MANAGEMENT' },
  { id: 'ops', label: '3. OPERATIONS & DELIVERY' },
  { id: 'accounts', label: '4. FINANCE & ACCOUNTING' },
  { id: 'safety', label: '5. SAFETY' },
  { id: 'general', label: '6. SUPPORT & GENERAL' },
];

const generateStrongPassword = () => {
  const uppers = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lowers = "abcdefghijklmnopqrstuvwxyz";
  const numbers = "0123456789";
  const symbols = "!@#$%^&*";
  const allChars = uppers + lowers + numbers + symbols;
  
  let pass = "";
  // Ensure we have at least one of each character class for maximum security
  pass += uppers[Math.floor(Math.random() * uppers.length)];
  pass += lowers[Math.floor(Math.random() * lowers.length)];
  pass += numbers[Math.floor(Math.random() * numbers.length)];
  pass += symbols[Math.floor(Math.random() * symbols.length)];
  
  // Fill the rest to reach 10 characters
  for (let i = 0; i < 6; i++) {
    pass += allChars[Math.floor(Math.random() * allChars.length)];
  }
  
  // Shuffle the final string
  return pass.split('').sort(() => 0.5 - Math.random()).join('');
};

export default function UserCredentialsPanel() {
  const { isMasterAdmin, isUserAdmin, user, workers = [] } = useAppContext();
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'Master Admin' | 'Admin' | 'User'>('User');
  const [accessiblePanels, setAccessiblePanels] = useState<string[]>(['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);
  const [selectedWorkerId, setSelectedWorkerId] = useState('');
  
  // Edit states
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<'Master Admin' | 'Admin' | 'User'>('User');
  const [editAccessiblePanels, setEditAccessiblePanels] = useState<string[]>([]);
  const [editEmployeeId, setEditEmployeeId] = useState('');
  const [editError, setEditError] = useState('');
  const [editSuccess, setEditSuccess] = useState('');
  
  // Visibility state for passwords
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});
  const [showAddFormPassword, setShowAddFormPassword] = useState(false);
  
  // Selection filter & Search filter
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Share & Notify states
  const [sharingCred, setSharingCred] = useState<Credential | null>(null);
  const [copiedInvite, setCopiedInvite] = useState(false);

  useEffect(() => {
    const colRef = collection(db, 'userCredentials');
    const unsubscribe = onSnapshot(colRef, (snapshot) => {
      try {
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Credential[];
        
        // Super robust client-side sort to completely avoid NaN with empty,
        // malformed, string, or Firestore Timestamp formats of createdAt.
        data.sort((a, b) => {
          const getTime = (val: any) => {
            if (!val) return 0;
            if (typeof val === 'number') return val;
            if (typeof val === 'string') {
              const num = parseInt(val, 10);
              if (!isNaN(num) && num > 1000000) return num;
              const parsed = new Date(val).getTime();
              return isNaN(parsed) ? 0 : parsed;
            }
            if (typeof val === 'object') {
              if (typeof val.seconds === 'number') {
                return val.seconds * 1000;
              }
              if (typeof val.getTime === 'function') {
                return val.getTime();
              }
              if (typeof val.toDate === 'function') {
                return val.toDate().getTime();
              }
            }
            return 0;
          };
          return getTime(b.createdAt) - getTime(a.createdAt);
        });

        setCredentials(data);
        setLoading(false);
      } catch (err: any) {
        console.error("Error processing user credentials update:", err);
      }
    }, (err) => {
      console.error("Error fetching credentials:", err);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAddCredential = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email.trim() || !name.trim()) {
      setError('Name and Email fields are required.');
      return;
    }

    // Check if email already exists
    const exists = credentials.some(c => c.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      setError('A user credential with this email already exists.');
      return;
    }

    try {
      const savedName = name.trim();
      const savedEmail = email.trim().toLowerCase();
      const savedPassword = "";
      const savedRole = role;
      const savedPanels = accessiblePanels;
      const savedEmployeeId = selectedWorkerId || '';

      await addDoc(collection(db, 'userCredentials'), {
        email: savedEmail,
        password: savedPassword,
        name: savedName,
        role: savedRole,
        accessiblePanels: savedPanels,
        employeeId: savedEmployeeId,
        createdAt: Date.now()
      });

      setSuccess(`Credential for ${savedName} successfully created.`);
      setEmail('');
      setPassword('');
      setName('');
      setRole('User');
      setAccessiblePanels(['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);
      setSelectedUserId(''); // Reset filter to show the newly added user
      setSelectedWorkerId(''); // Reset selected worker ID dropdown
      setSearchQuery(''); // Reset search query

      // Open the notify and share invitation dialog immediately
      setSharingCred({
        id: 'temp-' + Date.now(),
        email: savedEmail,
        password: savedPassword,
        name: savedName,
        role: savedRole,
        accessiblePanels: savedPanels,
        employeeId: savedEmployeeId,
        createdAt: Date.now()
      });
    } catch (err: any) {
      console.error("Failed to add user credential:", err);
      setError(err.message || 'Failed to save credential.');
    }
  };

  const handleDelete = async (id: string, emailStr: string) => {
    const lowerEmail = emailStr.toLowerCase().trim();
    if (lowerEmail === 'kartikvicky9@gmail.com' || lowerEmail === 'mountecstorage@gmail.com' || lowerEmail === 'mountec21@gmail.com') {
      alert('The primary administrator account cannot be deleted.');
      return;
    }
    if (!confirm(`Are you sure you want to delete the credentials for ${emailStr}?`)) {
      return;
    }
    setError('');
    setSuccess('');
    try {
      await deleteDoc(doc(db, 'userCredentials', id));
      setSuccess('User credential successfully deleted.');
    } catch (err: any) {
      setError(err.message || 'Failed to delete credential.');
    }
  };

  const startEdit = (cred: Credential) => {
    setEditError('');
    setEditSuccess('');
    setEditingId(cred.id);
    setEditEmail(cred.email);
    setEditPassword(cred.password || '');
    setEditName(cred.name || '');
    setEditRole(cred.role || 'User');
    setEditAccessiblePanels(cred.accessiblePanels || ['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);
    setEditEmployeeId(cred.employeeId || '');
  };

  const handleSaveEdit = async (id: string) => {
    setEditError('');
    setEditSuccess('');
    
    if (!editEmail.trim() || !editName.trim()) {
      setEditError('Name and Email fields are required.');
      return;
    }

    const originalCred = credentials.find(c => c.id === id);
    if (!originalCred) {
      setEditError('User not found.');
      return;
    }

    const finalPassword = originalCred.password || '';

    const wasMaster = originalCred && (
      originalCred.email.toLowerCase().trim() === 'kartikvicky9@gmail.com' || 
      originalCred.email.toLowerCase().trim() === 'mountecstorage@gmail.com' ||
      originalCred.email.toLowerCase().trim() === 'mountec21@gmail.com'
    );

    let finalRole = editRole;
    let finalEmail = editEmail.trim().toLowerCase();
    let finalPanels = editAccessiblePanels;

    if (wasMaster) {
      finalRole = 'Master Admin';
      finalEmail = originalCred.email.toLowerCase().trim(); // lock down email
      // Force all panels access for master admin
      finalPanels = ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials'];
    }

    try {
      await updateDoc(doc(db, 'userCredentials', id), {
        email: finalEmail,
        password: finalPassword,
        name: editName.trim(),
        role: finalRole,
        accessiblePanels: finalPanels,
        employeeId: editEmployeeId
      });

      setEditSuccess('Credential updated successfully.');
      setTimeout(() => {
        setEditingId(null);
      }, 1000);
    } catch (err: any) {
      setEditError(err.message || 'Failed to update credential.');
    }
  };

  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const uniqueWorkers = React.useMemo(() => {
    const map = new Map<string, any>();
    (workers || []).forEach(w => {
      const eid = w.employeeId?.trim();
      if (eid) {
        if (!map.has(eid) || (w.nameOfWorker || w.name)) {
          map.set(eid, w);
        }
      }
    });
    return Array.from(map.values()).sort((a, b) => (a.employeeId || '').localeCompare(b.employeeId || ''));
  }, [workers]);

  const filteredCredentials = React.useMemo(() => {
    return credentials.filter(cred => {
      // 1. Dropdown selection filter
      if (selectedUserId !== '' && cred.id !== selectedUserId) {
        return false;
      }
      
      // 2. Search query filter
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      
      const nameMatch = (cred.name || '').toLowerCase().includes(q);
      const emailMatch = (cred.email || '').toLowerCase().includes(q);
      const roleMatch = (cred.role || '').toLowerCase().includes(q);
      const idMatch = (cred.employeeId || '').toLowerCase().includes(q);
      
      return nameMatch || emailMatch || roleMatch || idMatch;
    });
  }, [credentials, selectedUserId, searchQuery]);

  if (!isMasterAdmin) {
    return (
      <div className="bg-red-950/20 border border-red-500/20 p-6 rounded-xl flex items-center gap-4">
        <ShieldAlert className="w-8 h-8 text-red-500" />
        <div>
          <h3 className="text-white font-bold">Access Restricted</h3>
          <p className="text-xs text-[#777] mt-1">Only the designated Master Administrator can access and manage the user credentials directory.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="bg-[#141414] p-6 rounded-xl shadow-2xl border border-[#222]">
        <h2 className="text-sm font-bold uppercase tracking-widest text-blue-500 mb-2 flex items-center">
          <KeyRound className="w-5 h-5 mr-2" />
          Credentials & User Management
        </h2>
        <p className="text-[#777] text-xs">
          Manage system login credentials, view passwords, edit accounts, or register new users.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Create Credential Form */}
        <div className="lg:col-span-1 bg-[#141414] p-6 rounded-xl border border-[#222] h-fit">
          <h3 className="text-xs font-bold uppercase tracking-wider text-white mb-4 flex items-center">
            <Plus className="w-4 h-4 mr-2 text-blue-500" />
            Add New User Account
          </h3>

          <form onSubmit={handleAddCredential} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-blue-500 uppercase tracking-wider mb-1">Link Employee (2.3 Particulars) - Optional</label>
              <select
                value={selectedWorkerId}
                onChange={e => {
                  const val = e.target.value;
                  setSelectedWorkerId(val);
                  if (val) {
                    const selectedWorker = uniqueWorkers.find(w => w.employeeId === val);
                    if (selectedWorker) {
                      setName(selectedWorker.nameOfWorker || selectedWorker.name || '');
                      setEmail(selectedWorker.emailId || '');
                    }
                  }
                }}
                className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded-lg py-2 px-3 focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Optional: Link Employee ID & Name --</option>
                {uniqueWorkers.map(w => (
                  <option key={`add-w-${w.employeeId}`} value={w.employeeId}>
                    {w.employeeId} - {(w.nameOfWorker || w.name || '').toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider mb-1">Full Name</label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-4 w-4 text-[#555]" />
                </div>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 text-xs bg-[#0A0A0A] border-[#333] text-white rounded-lg py-2 border"
                  placeholder="John Doe"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider mb-1">Email Address</label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-4 w-4 text-[#555]" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 text-xs bg-[#0A0A0A] border-[#333] text-white rounded-lg py-2 border"
                  placeholder="john@mountec.com"
                />
              </div>
            </div>

             <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider mb-1">Access Role</label>
              <select
                value={role}
                onChange={e => setRole(e.target.value as any)}
                className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded-lg py-2 px-3 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="User">Standard User</option>
                <option value="Admin">Administrator (Full Access)</option>
                <option value="Master Admin">Master Administrator</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#555] uppercase tracking-wider mb-2">Panel Access Control</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {AVAILABLE_PANELS.map(panel => (
                  <label key={`add-panel-${panel.id}`} className="flex items-center space-x-2 bg-[#0A0A0A] border border-[#333] p-2 rounded-lg cursor-pointer hover:border-[#555] transition-colors">
                    <input
                      type="checkbox"
                      checked={accessiblePanels.includes(panel.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setAccessiblePanels([...accessiblePanels, panel.id]);
                        } else {
                          setAccessiblePanels(accessiblePanels.filter(p => p !== panel.id));
                        }
                      }}
                      className="form-checkbox h-3 w-3 text-blue-600 rounded bg-[#111] border-[#333]"
                    />
                    <span className="text-xs text-[#AAA]">{panel.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase tracking-widest rounded-lg flex items-center justify-center transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4 mr-2" />
              Save Account
            </button>
          </form>

          {error && (
            <div className="mt-4 p-3 rounded-lg bg-red-950/30 border border-red-500/20 text-red-400 text-[11px] flex items-start">
              <ShieldAlert className="w-4 h-4 mr-2 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mt-4 p-3 rounded-lg bg-green-950/30 border border-green-500/20 text-green-400 text-[11px] flex items-start">
              <Check className="w-4 h-4 mr-2 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}
        </div>

        {/* Credentials Directory */}
        <div className="lg:col-span-2 bg-[#141414] p-6 rounded-xl border border-[#222]">
          <div className="flex flex-col gap-4 mb-6 pb-4 border-b border-[#222]">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                System User Directory
              </h3>
              <span className="text-[10px] font-mono text-[#555] bg-[#0A0A0A] border border-[#222] px-2.5 py-1 rounded-md">
                Total: {credentials.length} ({filteredCredentials.length} shown)
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search name, email, role, ME ID..."
                  className="w-full bg-[#0A0A0A] border border-[#333] text-white placeholder-[#555] text-xs rounded-lg py-2 px-3 focus:outline-none focus:border-blue-500"
                />
              </div>
              
              {credentials.length > 0 && (
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="bg-[#0A0A0A] border border-[#333] text-[#AAA] text-xs rounded-lg py-2 px-3 focus:outline-none focus:border-blue-500 w-full sm:w-auto min-w-[200px]"
                >
                  <option value="">All Registered Users</option>
                  {credentials.map(c => (
                    <option key={`filter-${c.id}`} value={c.id}>
                      {c.name || 'No Name'} ({c.email})
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12 text-xs text-[#555] uppercase tracking-widest">
              Loading credential registry...
            </div>
          ) : credentials.length === 0 ? (
            <div className="text-center py-12 text-xs text-[#555] uppercase tracking-widest border-2 border-dashed border-[#222] rounded-xl">
              No registered accounts found. Feel free to add the first user.
            </div>
          ) : filteredCredentials.length === 0 ? (
            <div className="text-center py-12 text-xs text-[#555] uppercase tracking-widest border-2 border-dashed border-[#222] rounded-xl">
              No matching user accounts found for your search criteria.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredCredentials.map(cred => {
                const isEditing = editingId === cred.id;
                const isPasswordVisible = visiblePasswords[cred.id] || false;

                return (
                  <div key={cred.id} className="bg-[#1A1A1A] border border-[#2A2A2A] rounded-xl p-4 transition-all hover:border-[#333]">
                    {isEditing ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center pb-2 border-b border-[#222]">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-500">Edit User Account</span>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleSaveEdit(cred.id)}
                              className="p-1 bg-green-500/20 text-green-400 border border-green-500/30 rounded hover:bg-green-500/30"
                              title="Save Changes"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="p-1 bg-red-500/20 text-red-400 border border-red-500/30 rounded hover:bg-red-500/30"
                              title="Cancel"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {editError && (
                          <div className="p-2.5 rounded bg-red-950/30 border border-red-500/20 text-red-400 text-[10px] flex items-center">
                            <ShieldAlert className="w-3.5 h-3.5 mr-2 shrink-0" />
                            <span>{editError}</span>
                          </div>
                        )}

                        {editSuccess && (
                          <div className="p-2.5 rounded bg-green-950/30 border border-green-500/20 text-green-400 text-[10px] flex items-center">
                            <Check className="w-3.5 h-3.5 mr-2 shrink-0" />
                            <span>{editSuccess}</span>
                          </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="md:col-span-2">
                            <label className="block text-[10px] text-blue-500 uppercase font-bold mb-1">Link Employee (2.3 Particulars)</label>
                            <select
                              value={editEmployeeId}
                              onChange={e => {
                                const val = e.target.value;
                                setEditEmployeeId(val);
                                if (val) {
                                  const selectedWorker = uniqueWorkers.find(w => w.employeeId === val);
                                  if (selectedWorker) {
                                    setEditName(selectedWorker.nameOfWorker || selectedWorker.name || '');
                                    setEditEmail(selectedWorker.emailId || '');
                                  }
                                }
                              }}
                              className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded p-2 focus:outline-none focus:border-blue-500"
                            >
                              <option value="">-- Unlinked / No ME ID --</option>
                              {uniqueWorkers.map(w => (
                                <option key={`edit-w-${w.employeeId}`} value={w.employeeId}>
                                  {w.employeeId} - {(w.nameOfWorker || w.name || '').toUpperCase()}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-[#555] uppercase font-bold mb-1">Full Name</label>
                            <input
                              type="text"
                              value={editName}
                              onChange={e => setEditName(e.target.value)}
                              className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded p-2 focus:outline-none focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-[#555] uppercase font-bold mb-1">Email ID</label>
                            <input
                              type="email"
                              value={editEmail}
                              onChange={e => setEditEmail(e.target.value)}
                              className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded p-2 focus:outline-none focus:border-blue-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-[#555] uppercase font-bold mb-1">Role</label>
                            <select
                              value={editRole}
                              onChange={e => setEditRole(e.target.value as any)}
                              className="w-full bg-[#0A0A0A] border border-[#333] text-white text-xs rounded p-2 focus:outline-none focus:border-blue-500"
                            >
                              <option value="User">Standard User</option>
                              <option value="Admin">Administrator (Full Access)</option>
                              <option value="Master Admin">Master Administrator</option>
                            </select>
                          </div>
                        </div>

                        <div className="pt-2">
                          <label className="block text-[10px] text-[#555] uppercase font-bold mb-2">Panel Access Control</label>
                          <div className="flex flex-wrap gap-2">
                            {AVAILABLE_PANELS.map(panel => (
                              <label key={`edit-panel-${panel.id}`} className="flex items-center space-x-2 bg-[#0A0A0A] border border-[#333] px-3 py-1.5 rounded-md cursor-pointer hover:border-[#555] transition-colors">
                                <input
                                  type="checkbox"
                                  checked={editAccessiblePanels.includes(panel.id)}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      setEditAccessiblePanels([...editAccessiblePanels, panel.id]);
                                    } else {
                                      setEditAccessiblePanels(editAccessiblePanels.filter(p => p !== panel.id));
                                    }
                                  }}
                                  className="form-checkbox h-3 w-3 text-blue-600 rounded bg-[#111] border-[#333]"
                                />
                                <span className="text-xs text-[#AAA]">{panel.label}</span>
                              </label>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1.5">
                          <div className="flex items-center flex-wrap gap-2">
                            <span className="font-bold text-white text-sm uppercase tracking-wider">{cred.name?.toUpperCase() || 'NO NAME'}</span>
                            {cred.employeeId && (
                              <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded-md font-bold">
                                ME ID: {cred.employeeId}
                              </span>
                            )}
                            <span className={`text-[9px] font-extrabold uppercase tracking-widest px-2.5 py-0.5 rounded-full border ${
                              cred.role === 'Master Admin'
                                ? 'bg-[#2D1A3B] text-[#D6BCFA] border-[#553C9A]'
                                : cred.role === 'Admin'
                                ? 'bg-[#0E2033] text-[#3182CE] border-[#1A365D]'
                                : 'bg-[#1A1D20] text-[#718096] border-[#2D3748]'
                            }`}>
                              {cred.role === 'Master Admin' ? 'MASTER ADMIN' : cred.role === 'Admin' ? 'ADMIN' : 'STANDARD USER'}
                            </span>
                          </div>
                          
                          <div className="text-[12px] text-[#888] flex items-center gap-2">
                            <Mail className="w-3.5 h-3.5 text-[#555]" />
                            <span className="text-[#999]">{cred.email}</span>
                          </div>
                          
                          {cred.password && cred.password.trim() !== "" && (
                            <div className="text-[12px] text-[#888] flex items-center gap-2">
                              <Key className="w-3.5 h-3.5 text-[#555]" />
                              <span className="font-mono bg-[#0A0A0A] px-2.5 py-1 rounded text-[11px] text-[#DDD] border border-[#222] flex items-center">
                                {isPasswordVisible ? cred.password : '••••••••'}
                              </span>
                              <button
                                onClick={() => togglePasswordVisibility(cred.id)}
                                className="text-[#555] hover:text-[#AAA] p-1 transition-colors cursor-pointer"
                                title="Toggle Visibility"
                              >
                                {isPasswordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              </button>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button
                            onClick={() => setSharingCred(cred)}
                            className="p-2.5 bg-[#141414] text-blue-400 hover:text-blue-300 border border-[#2B2B2B] hover:border-blue-500/30 rounded-xl transition-all cursor-pointer"
                            title="Share & Notify via Email"
                          >
                            <Share2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => startEdit(cred)}
                            className="p-2.5 bg-[#141414] text-[#999] hover:text-white border border-[#2B2B2B] hover:border-[#444] rounded-xl transition-all cursor-pointer"
                            title="Edit Account"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(cred.id, cred.email)}
                            disabled={cred.email.toLowerCase() === 'kartikvicky9@gmail.com' || cred.email.toLowerCase() === 'mountecstorage@gmail.com' || cred.email.toLowerCase() === 'mountec21@gmail.com'}
                            className="p-2.5 bg-[#141414] text-red-500/70 hover:text-red-400 border border-red-500/10 hover:border-red-500/30 rounded-xl transition-all disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer"
                            title="Delete Account"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Share & Send Email Invitation Modal */}
      {sharingCred && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-[#141414] border border-[#2B2B2B] w-full max-w-xl rounded-2xl p-6 shadow-2xl relative overflow-hidden">
            {/* Background design accents */}
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
            
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-500/10 rounded-xl border border-blue-500/20 text-blue-400">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                    Share & Notify User
                  </h3>
                  <p className="text-[#555] text-[11px] mt-0.5">
                    Authorized account created. Now authorize on AI Studio and notify the recipient.
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setSharingCred(null);
                  setCopiedInvite(false);
                }}
                className="p-1 bg-[#222] hover:bg-[#333] border border-[#333] text-[#AAA] hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Account Details Summary */}
            <div className="bg-[#0A0A0A] border border-[#222] rounded-xl p-4 space-y-3 mb-6">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-[#1A1A1A]">
                <span className="text-[#555] uppercase font-bold tracking-wider text-[10px]">Account Owner</span>
                <span className="text-white font-semibold uppercase">{sharingCred.name || 'No Name'}</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-[#1A1A1A]">
                <span className="text-[#555] uppercase font-bold tracking-wider text-[10px]">Email Address</span>
                <span className="font-mono text-blue-400">{sharingCred.email}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#555] uppercase font-bold tracking-wider text-[10px]">Temporary Password</span>
                <span className="font-mono bg-[#111] px-2 py-0.5 rounded text-green-400 border border-[#222]">{sharingCred.password || '••••••••'}</span>
              </div>
            </div>

            {/* Step 1: AI Studio App Sharing (Screenshot reference) */}
            <div className="bg-yellow-950/10 border border-yellow-500/20 rounded-xl p-4 space-y-2 mb-6">
              <div className="flex items-start space-x-3">
                <Shield className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-yellow-500 uppercase tracking-wider">
                    CRITICAL PLATFORM SECURITY STEP
                  </h4>
                  <p className="text-[11px] text-[#AAA] leading-relaxed mt-1">
                    To allow <strong className="text-white">{sharingCred.email}</strong> to sign in or view the app iframe, you must explicitly add them in Google AI Studio:
                  </p>
                  <ol className="list-decimal list-inside text-[11px] text-[#888] space-y-1 mt-2">
                    <li>Click the <span className="text-[#CCC] font-semibold">"● Share"</span> button at the top-right of your AI Studio workspace.</li>
                    <li>Add <strong className="text-blue-400 font-mono text-[10px] bg-[#111] px-1 py-0.5 rounded border border-[#222]">{sharingCred.email}</strong> under <span className="text-white font-bold">"People who can sign in to your app"</span> list (exactly as shown in your screenshot).</li>
                    <li>Click <span className="text-[#CCC] font-semibold">Done / Save</span> to authorize.</li>
                  </ol>
                </div>
              </div>
            </div>

            {/* Step 2: Notify Recipient */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-[#555] uppercase tracking-widest">
                Deliver Invitation Details
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Mailto Button */}
                <button
                  onClick={() => {
                    const appUrl = "https://ais-pre-t7xmrgycrbt7ac4tuj2oyd-610677682546.asia-east1.run.app";
                    const subject = encodeURIComponent("🔐 Authorized Access to Mountec Portal");
                    const body = encodeURIComponent(
                      `Dear ${sharingCred.name || 'User'},\n\n` +
                      `Your account has been successfully created on the Mountec Corporate Portal!\n\n` +
                      `Please find your secure login details below:\n` +
                      `--------------------------------------------------\n` +
                      `🌐 Portal Link: ${appUrl}\n` +
                      `📧 Registered Email: ${sharingCred.email}\n` +
                      `🔑 Sign-in Method: Authorized Google Account or Email Validation\n` +
                      `--------------------------------------------------\n\n` +
                      `Instructions to sign in:\n` +
                      `1. Click the Portal Link above on your laptop, desktop, or mobile phone:\n` +
                      `   ${appUrl}\n` +
                      `2. Choose "Sign in with Google" using your authorized email address.\n\n` +
                      `Note: This direct link works instantly on all Android, iOS, and standard web browsers.\n\n` +
                      `Best regards,\n` +
                      `Mountec Management Team`
                    );
                    window.open(`mailto:${sharingCred.email}?subject=${subject}&body=${body}`);
                  }}
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-blue-900/20 border border-blue-500/20 hover:-translate-y-0.5"
                >
                  <Mail className="w-4 h-4" />
                  <span>Notify via Email</span>
                </button>

                {/* Copy Button */}
                <button
                  onClick={() => {
                    const appUrl = "https://ais-pre-t7xmrgycrbt7ac4tuj2oyd-610677682546.asia-east1.run.app";
                    const text = (
                      `🔐 MOUNTEC CORPORATE PORTAL ACCESS\n\n` +
                      `Dear ${sharingCred.name || 'User'},\n\n` +
                      `Your account is ready! Here are your authorized log-in details:\n\n` +
                      `🌐 Portal Link: ${appUrl}\n` +
                      `📧 Email ID: ${sharingCred.email}\n` +
                      `🔑 Sign-in Method: Authorized Google Account\n\n` +
                      `Please open the direct Portal Link above on your mobile phone, laptop, or desktop browser to access and sign in.`
                    );
                    navigator.clipboard.writeText(text);
                    setCopiedInvite(true);
                    setTimeout(() => setCopiedInvite(false), 2000);
                  }}
                  className={`w-full py-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer border ${
                    copiedInvite
                      ? 'bg-green-950/30 border-green-500/50 text-green-400'
                      : 'bg-[#1D1D1D] hover:bg-[#252525] border-[#2F2F2F] text-white hover:-translate-y-0.5'
                  }`}
                >
                  {copiedInvite ? (
                    <>
                      <Check className="w-4 h-4 text-green-400" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#AAA]" />
                      <span>Copy Invitation</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-[#222] flex justify-end">
              <button
                onClick={() => {
                  setSharingCred(null);
                  setCopiedInvite(false);
                }}
                className="px-4 py-2 bg-[#1A1A1A] hover:bg-[#222] border border-[#2B2B2B] text-xs font-bold uppercase tracking-wider rounded-lg text-[#AAA] hover:text-white transition-colors cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
