import React from 'react';
import SubFlowChart from '../SubFlowChart';

export default function SupportFlowChart() {
  const steps = [
    { id: '6.1', title: '6.1 INFORMATION SHARING' },
  ];
  return <SubFlowChart title="SUPPORT & GENERAL FLOW" steps={steps} />;
}
