import React from 'react';
import { FilePlus } from 'lucide-react';

type FlowchartNode = {
  title: string;
  children?: FlowchartNode[];
};

const flowchartData: FlowchartNode[] = [
  {
    title: '1. Executive & Governance',
    children: [
      { title: '1.1 Policies & Org Chart', children: [{ title: '1.1.1 Company Policy' }, { title: '1.1.2 Company Org Chart' }, { title: '1.1.3 SOP' }] },
      { title: '1.2 The Company Act [Constitution]' },
      { title: '1.3 ACRA' },
      { title: '1.4 BizSAFE & ISO CERTIFICATIONS' },
      { title: '1.5 Email, ID & Password' },
      { title: '1.6 Letters & Memo' },
      { title: '1.7 Company Profiles' },
      { title: '1.8 Survey Related' },
      { title: '1.9 Event & Gathering Related' },
      { title: '1.10 Overhead Related' }
    ]
  },
  {
    title: '2. Human Capital Management',
    children: [
      { title: '2.3 Forms, Templates & Logos', children: [{ title: '2.3.1 All Related Forms' }, { title: '2.3.2 All Related Templates' }, { title: '2.3.3 All Related Logos & Branding' }, { title: '2.3.4 All Related Advertisement' }] },
      { title: '2.4 BizSAFE & ISO CERTIFICATIONS', children: [{ title: '2.4.1 Letters' }, { title: '2.4.2 Memo' }, { title: '2.4.3 Minutes of Meeting' }] },
      { title: '2.5 Staff & Workers', children: [{ title: '2.5.1 Welfare Management' }, { title: '2.5.2 Recruitment/LOA' }, { title: '2.5.3 Staff & Worker Particulars' }, { title: '2.5.4 Payroll' }, { title: '2.5.5 Leave & MC Record', children: [{ title: '2.5.5.1 FW Levy Waiver Record' }] }, { title: '2.5.6 Insurances', children: [{ title: '2.5.6.1 Primary Care Plan (PCP)' }, { title: '2.5.6.2 Medical Insurances' }] }, { title: '2.5.7 Development', children: [{ title: '2.5.7.1 Staff & Workers Courses' }] }, { title: '2.5.8 Uniform' }, { title: '2.5.9 Incentive & Bonus' }, { title: '2.5.10 Performance Indicator' }] },
      { title: '2.6 Dormitory', children: [{ title: '2.6.1 Dormitory & Rooms Agreements' }] }
    ]
  },
  {
    title: '3. Operations & Delivery',
    children: [
        { title: '3.1 Sales', children: [{ title: '3.1.1 Client Register' }, { title: '3.1.2 Quotation Register' }, { title: '3.1.3 Sales Quotations' }, { title: '3.1.4 Business Development' }, { title: '3.1.5 Supplier & Subcon Quotations with information', children: [{ title: '3.1.5.1 Strategic Roadmap' }] }, { title: '3.1.6 Pre-qualification Documents Submission' }] },
        { title: '3.2 Projects', children: [{ title: '3.2.1 Projects Register' }, { title: '3.2.2 Projects Reference' }, { title: '3.2.3 Progress Claim Register' }, { title: '3.2.4 Variation Order (VO) Register' }, { title: '3.2.5 Projects List (Main & Quick)', children: [{ title: '3.2.5.1 Sales Stage' }, { title: '3.2.5.2 Sub-contract & Work Order' }, { title: '3.2.5.3 Project Budget' }, { title: '3.2.5.4 Documents from Client' }, { title: '3.2.5.5 Submission & Approval' }, { title: '3.2.5.6 Unit Chart & Schedule' }, { title: '3.2.5.7 Ordering of materials' }, { title: '3.2.5.8 Photos' }, { title: '3.2.5.9 Progress & Final Claim' }, { title: '3.2.5.10 Variation Order' }, { title: '3.2.5.11 Warranty Documents' }] }, { title: '3.2.6 Projects Org Chart' }] },
        { title: '3.3 Resources Management', children: [{ title: '3.3.1 WORK DEPLOYMENT SCHEDULE' }, { title: '3.3.2 Project Namelist Submission' }, { title: '3.3.3 Project SIC update' }, { title: '3.3.4 Project Progress and Work done update' }, { title: '3.3.5 Internal & External Supply manpower update' }, { title: '3.3.6 Productivity Measures' }] },
        { title: '3.4 Technical', children: [{ title: '3.4.1 Product & Technical Information' }, { title: '3.4.2 Drawings' }, { title: '3.4.3 Design Calculation & Endorsement' }, { title: '3.4.4 Maintenance Manual' }] },
        { title: '3.5 Purchase Related', children: [{ title: '3.5.1 Supplier & Vendors Information/Register' }, { title: '3.5.2 Purchase Requisition' }, { title: '3.5.3 Purchase Order/ Blanket Order' }, { title: '3.5.4 Comparison' }] },
        { title: '3.6 Work & Delivery Order Related', children: [{ title: '3.6.1 Work Order Related' }, { title: '3.6.2 Delivery Order Related' }] },
        { title: '3.7 Letter Registration', children: [{ title: '3.7.1 Letters' }, { title: '3.7.2 Memo' }, { title: '3.7.3 Minutes of Meeting' }] },
        { title: '3.8 Client/Supplier/Vendor List' },
        { title: '3.9 Transportation Related' },
        { title: '3.10 Legal Action' },
        { title: '3.11 Additional Product & Services' },
        { title: '3.12 MET Management' }
    ]
  },
  {
    title: '4. Finance & Accounting',
    children: [
        { title: '4.1 Billing', children: [{ title: '4.1.1 Sales Invoice' }, { title: '4.1.2 Statement of Account (SOA)' }, { title: '4.1.3 Debit Note' }, { title: '4.1.4 Credit Note' }, { title: '4.1.5 Other In-come' }] },
        { title: '4.2 Expenses Management', children: [{ title: '4.2.0 Cost categories' }, { title: '4.2.1 General Expenses' }, { title: '4.2.2 Staff & Workers Expenses' }, { title: '4.2.3 Staff & Workers Salary', children: [{ title: '4.2.3.1 Staff & Workers CPF' }, { title: '4.2.3.2 Staff & Workers Levy' }] }, { title: '4.2.4 Project Purchasing (MET)' }, { title: '4.2.5 Sub-Contractors & Vendors' }, { title: '4.2.6 Transportation Expenses' }, { title: '4.2.7 Fine & Back Charges' }, { title: '4.2.8 Petty Cash' }, { title: '4.2.9 All Related Payout', children: [{ title: '4.2.9.1 Payment Voucher' }, { title: '4.2.9.2 Payment Register' }] }, { title: '4.2.10 Deposit Payment' }] },
        { title: '4.3 GST Filing' },
        { title: '4.4 Accounts Forecast' },
        { title: '4.5 AGM & Financial Statement' },
        { title: '4.6 Bank Account Information', children: [{ title: '4.6.1 Forms & Endorsement' }, { title: '4.6.2 Bank Statement' }] },
        { title: '4.7 P&L' },
        { title: '4.8 Tax Related' }
    ]
  },
  {
    title: '5. HSEQ (Health, Safety, Environment, Quality)',
    children: [
        { title: '5.1 SAFETY, QUALITY & ENVIRONMENT RELATED', children: [{ title: '5.1.1 SAFETY RELATED', children: [{ title: '5.1.1.1 DAILY TOOLBOX MEETING' }, { title: '5.1.1.2 PPE ISSUANCE RECORD' }] }, { title: '5.1.2 QUALITY RELATED' }, { title: '5.1.3 ENVIRONMENT RELATED' }, { title: '5.1.4 ALL SQE RELATED FORMS' }, { title: '5.1.5 AUDITING RELATED' }] }
    ]
  },
  {
    title: '6. Support & General',
    children: [
        { title: '6.1 Forms, Templates & Logos', children: [{ title: '6.1.1 All Related Forms' }, { title: '6.1.2 All Related Templates' }, { title: '6.1.3 All Related Logos' }, { title: '6.1.4 All Related Advertisement' }] },
        { title: '6.2 Email, ID & Password' },
        { title: '6.3 Letters & Memo', children: [{ title: '6.3.1 Letters' }, { title: '6.3.2 Memo' }, { title: '6.3.3 Minutes of Meeting' }] },
        { title: '6.4 Survey Related' },
        { title: '6.5 BCA Workhead' },
        { title: '6.6 Company Insurances', children: [{ title: '6.6.1 WICA' }, { title: '6.6.2 Project Insurance' }] },
        { title: '6.7 Information Sharing' }
    ]
  }
];

const FlowchartItem = ({ node, level = 0 }: { node: FlowchartNode, level?: number }) => {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      console.log(`File selected for ${node.title}:`, file.name);
      // TODO: Implement file upload to Firebase Storage or Firestore
    }
  };

  return (
    <div style={{ marginLeft: level * 16 }}>
      <div className="flex items-center justify-between mb-1 group">
        <p className={`text-sm ${level === 0 ? 'font-bold text-blue-500' : 'text-gray-300'}`}>
          {level > 0 && '• '} {node.title.toUpperCase()}
        </p>
        {!node.children && (
          <>
            <button
              className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-800 rounded transition-opacity"
              onClick={() => fileInputRef.current?.click()}
            >
              <FilePlus className="w-4 h-4 text-blue-400" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              style={{ display: 'none' }}
              onChange={handleFileChange}
            />
          </>
        )}
      </div>
      {node.children && node.children.map((child, i) => (
        <FlowchartItem key={i} node={child} level={level + 1} />
      ))}
    </div>
  );
};

export default function FlowchartPanel() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">OVERALL FLOW CHART</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {flowchartData.map((node, index) => (
          <div key={index} className="border border-gray-700 rounded-lg p-4 bg-[#111111]">
            <FlowchartItem node={node} />
          </div>
        ))}
      </div>
    </div>
  );
}
