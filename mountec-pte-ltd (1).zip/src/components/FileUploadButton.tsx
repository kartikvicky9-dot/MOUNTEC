import React, { useRef, useState } from 'react';
import { FilePlus } from 'lucide-react';

export default function FileUploadButton({ onUpload }: { onUpload: (file: File, displayName: string) => void }) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [displayName, setDisplayName] = useState('');
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setDisplayName(selectedFile.name);
    }
  };

  const handleUploadClick = () => {
    if (file && displayName) {
      onUpload(file, displayName);
      setFile(null);
      setDisplayName('');
    }
  };

  return (
    <div className="flex items-center gap-2">
      {file ? (
        <>
          <input
            type="text"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="text-sm p-1 bg-gray-800 text-white rounded border border-gray-600"
            placeholder="File name"
          />
          <button
            className="text-sm bg-blue-600 text-white px-2 py-1 rounded"
            onClick={handleUploadClick}
          >
            Upload
          </button>
        </>
      ) : (
        <>
          <button
            className="flex items-center gap-2 p-2 hover:bg-gray-700 rounded transition-colors text-blue-400"
            onClick={() => fileInputRef.current?.click()}
          >
            <FilePlus className="w-4 h-4" />
            <span className="text-sm">Upload</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: 'none' }}
            onChange={handleFileChange}
            accept=".xlsx, .xls, .csv"
          />
        </>
      )}
    </div>
  );
}
