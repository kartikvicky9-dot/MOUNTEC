/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { initAuth } from './lib/firebase';
import { AppProvider } from './context/AppContext';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [toast, setToast] = useState<{ message: string; visible: boolean }>({ message: '', visible: false });

  // Intercept window.alert to display a gorgeous non-blocking custom toast
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.alert = (message: any) => {
        setToast({ message: String(message), visible: true });
      };
      
      const handleCustomToast = (e: Event) => {
        const detail = (e as CustomEvent).detail;
        if (detail && detail.message) {
          setToast({ message: detail.message, visible: true });
        }
      };
      
      window.addEventListener('show-app-toast', handleCustomToast);
      return () => {
        window.removeEventListener('show-app-toast', handleCustomToast);
      };
    }
  }, []);

  useEffect(() => {
    // Check for custom Firestore session first with safety try-catch
    let customUserStr: string | null = null;
    try {
      customUserStr = localStorage.getItem('mountec_custom_user');
    } catch (e) {
      console.warn('Storage blocked:', e);
    }

    if (customUserStr) {
      try {
        const customUser = JSON.parse(customUserStr);
        setUser(customUser);
        setNeedsAuth(false);
        setLoading(false);
        return;
      } catch (e) {
        // ignore
      }
    }

    const unsubscribe = initAuth(
      (user, token) => {
        setUser(user);
        setNeedsAuth(false);
        setLoading(false);
      },
      () => {
        let hasCustomUser = false;
        try {
          hasCustomUser = !!localStorage.getItem('mountec_custom_user');
        } catch (e) {
          // ignore
        }
        if (!hasCustomUser) {
          setUser(null);
          setNeedsAuth(true);
        }
        setLoading(false);
      }
    );
    
    return () => unsubscribe();
  }, []);

  const [isDay, setIsDay] = useState(() => {
    const h = new Date().getHours();
    return h >= 7 && h < 19;
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const h = new Date().getHours();
      setIsDay(h >= 7 && h < 19);
    }, 60000); // Check every minute
    return () => clearInterval(timer);
  }, []);

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isDay ? 'bg-white' : 'bg-[#0A0A0A]'}`}>
        <Loader2 className={`w-10 h-10 ${isDay ? 'text-blue-600' : 'text-blue-500'} animate-spin`} />
      </div>
    );
  }

  return (
    <AppProvider user={user}>
      <div className={`uppercase transition-colors duration-500 ${isDay ? 'bg-white text-black' : 'bg-[#0A0A0A] text-white'}`}>
        {needsAuth ? <Login /> : <Dashboard isDay={isDay} />}
        
        {/* Universal Floating Toast (Replacing disruptive window.alert) */}
        {toast.visible && (
          <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-[9999] w-full max-w-sm px-4">
            <div className={`${isDay ? 'bg-gray-100 border-gray-300' : 'bg-[#141414] border-blue-500'} border text-${isDay ? 'black' : 'white'} rounded-xl shadow-2xl p-4 flex items-start gap-3 backdrop-blur-md animate-in slide-in-from-bottom-5 duration-300`}>
              <div className={`${isDay ? 'bg-blue-100 border-blue-300' : 'bg-blue-500/10 border-blue-500/20'} p-1.5 rounded-lg border shrink-0 mt-0.5`}>
                <Loader2 className="w-4 h-4 text-blue-500 rotate-45" />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-xs font-semibold ${isDay ? 'text-blue-700' : 'text-blue-400'} uppercase tracking-wider mb-1`}>Notification</p>
                <p className={`text-xs ${isDay ? 'text-gray-800' : 'text-[#ddd]'} leading-relaxed break-words font-medium`}>{toast.message}</p>
              </div>
              <button 
                onClick={() => setToast(prev => ({ ...prev, visible: false }))}
                className={`${isDay ? 'text-gray-500 hover:text-black' : 'text-[#666] hover:text-white'} text-xs font-bold uppercase tracking-wider shrink-0 px-2 py-1 rounded hover:bg-white/5 transition-colors`}
              >
                Dismiss
              </button>
            </div>
          </div>
        )}
      </div>
    </AppProvider>
  );
}
