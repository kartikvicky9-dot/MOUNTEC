import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Worker } from '../types';
import { defaultSheetData } from '../defaultData';
import { db } from '../lib/firebase';
import { doc, setDoc, onSnapshot, collection, query, where } from 'firebase/firestore';

interface AppPreferences {
  showTaskNotifications: boolean;
}

interface AppContextType {
  workers: Worker[];
  setWorkers: React.Dispatch<React.SetStateAction<Worker[]>>;
  rawData: string[][];
  setRawData: React.Dispatch<React.SetStateAction<string[][]>>;
  updateRawData: (newData: string[][], persistToFirestore?: boolean) => Promise<void>;
  syncWorkerToRawData: (worker: Worker, action: 'add' | 'update' | 'delete') => void;
  sheetId: string;
  setSheetId: (id: string) => void;
  sheetRange: string;
  setSheetRange: (range: string) => void;
  isViewOnly: boolean;
  isUserAdmin: boolean;
  isMasterAdmin: boolean;
  userRole: 'Master Admin' | 'Admin' | 'User' | null;
  accessiblePanels: string[];
  accessStatus: 'none' | 'pending' | 'approved';
  requestAccess: (name: string) => void;
  preferences: AppPreferences;
  updatePreferences: (newPrefs: Partial<AppPreferences>) => void;
  user: any;
  selectedEmployeeIdFor23?: string | null;
  setSelectedEmployeeIdFor23?: (id: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children, user }: { children: ReactNode, user?: any }) => {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [rawData, setRawData] = useState<string[][]>([]);
  const [sheetId, setSheetId] = useState('119iPntkH5hU0_i-7y1oF16m6z2s9-gA-Wb9EwT0r1OQ'); // A default if we want or just empty
  const [sheetRange, setSheetRange] = useState('Sheet1!A5:X100'); // Based on HTML, it's about A5 to X
  const [selectedEmployeeIdFor23, setSelectedEmployeeIdFor23] = useState<string | null>(null);
  
  const isPublicUrl = window.location.hostname.includes('ais-pre-') || window.location.hostname.includes('shared');
  const [accessStatus, setAccessStatus] = useState<'none' | 'pending' | 'approved'>('none');
  const [visitorId, setVisitorId] = useState<string>('');
  const [preferences, setPreferences] = useState<AppPreferences>(() => {
    try {
      const saved = localStorage.getItem('mountec_preferences');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Preferences storage blocked:', e);
    }
    return { showTaskNotifications: true };
  });

  const updatePreferences = (newPrefs: Partial<AppPreferences>) => {
    setPreferences(prev => {
      const updated = { ...prev, ...newPrefs };
      try {
        localStorage.setItem('mountec_preferences', JSON.stringify(updated));
      } catch (e) {
        console.warn('Preferences save blocked:', e);
      }
      return updated;
    });
  };

  useEffect(() => {
    let vid = '';
    try {
      vid = localStorage.getItem('mountec_visitor_id') || '';
    } catch (e) {
      console.warn('Visitor id read blocked:', e);
    }
    
    if (!vid) {
      vid = 'visitor-' + Math.random().toString(36).substr(2, 9);
      try {
        localStorage.setItem('mountec_visitor_id', vid);
      } catch (e) {
        console.warn('Visitor id save blocked:', e);
      }
    }
    setVisitorId(vid);

    const unsubscribe = onSnapshot(doc(db, 'accessRequests', vid), (docSnap) => {
      if (docSnap.exists()) {
        setAccessStatus(docSnap.data().status as any);
      }
    });

    return () => unsubscribe();
  }, []);

  const requestAccess = async (name: string) => {
    if (!visitorId) return;
    setAccessStatus('pending');
    await setDoc(doc(db, 'accessRequests', visitorId), {
      name,
      status: 'pending',
      timestamp: Date.now()
    });
  };

  const adminEmail = 'mountecstorage@gmail.com';
  const isMasterEmail = (email: string) => {
    const e = email.toLowerCase().trim();
    return e === 'mountecstorage@gmail.com' || e === 'kartikvicky9@gmail.com' || e === 'mountec21@gmail.com';
  };

  const [userRole, setUserRole] = useState<'Master Admin' | 'Admin' | 'User' | null>(null);
  const [accessiblePanels, setAccessiblePanels] = useState<string[]>(['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);

  useEffect(() => {
    if (!user || !user.email) {
      setUserRole(null);
      setAccessiblePanels(['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);
      return;
    }
    const q = query(collection(db, 'userCredentials'), where('email', '==', user.email.toLowerCase()));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      if (!snapshot.empty) {
        const userData = snapshot.docs[0].data();
        const docId = snapshot.docs[0].id;
        const isAdmin = isMasterEmail(user.email);
        
        if (isAdmin && (userData.role !== 'Master Admin' || !userData.accessiblePanels || !userData.accessiblePanels.includes('executive'))) {
          // Auto-promote/heal existing master email user to Master Admin with all panels in Firestore!
          const { updateDoc, doc: firestoreDoc } = await import('firebase/firestore');
          const allPanels = ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials'];
          updateDoc(firestoreDoc(db, 'userCredentials', docId), {
            role: 'Master Admin',
            accessiblePanels: allPanels
          }).catch(err => console.warn("Failed to auto-promote master user in Firestore:", err));
          
          setUserRole('Master Admin');
          setAccessiblePanels(allPanels);
        } else {
          setUserRole(userData.role || 'User');
          setAccessiblePanels(userData.accessiblePanels || ['executive', 'hr', 'ops', 'accounts', 'safety', 'general']);
        }
      } else {
        const isAdmin = isMasterEmail(user.email);
        const defaultPanels = isAdmin 
          ? ['flowchart', 'executive', 'hr', 'ops', 'accounts', 'safety', 'general', 'settings', 'access', 'credentials']
          : ['executive', 'hr', 'ops', 'accounts', 'safety', 'general'];
          
        setUserRole(isAdmin ? 'Master Admin' : 'User');
        setAccessiblePanels(defaultPanels);
        
        // Auto-register missing user
        try {
          const { addDoc } = await import('firebase/firestore');
          await addDoc(collection(db, 'userCredentials'), {
            email: user.email.toLowerCase(),
            password: '',
            name: user.displayName || user.email.split('@')[0],
            role: isAdmin ? 'Master Admin' : 'User',
            accessiblePanels: defaultPanels,
            createdAt: Date.now()
          });
        } catch (e) {
          console.error("Failed to auto-register user:", e);
        }
      }
    }, (err) => {
      console.error("Error listening to user credentials:", err);
    });
    return () => unsubscribe();
  }, [user]);

  const isMasterAdmin = user?.email ? (isMasterEmail(user.email) || userRole === 'Master Admin') : false;
  const isUserAdmin = isMasterAdmin || userRole === 'Admin' || userRole === 'Master Admin';
  const isViewOnly = !isUserAdmin && accessStatus !== 'approved';

  const updateRawData = async (newData: string[][], persistToFirestore = true) => {
    setRawData(newData);
    if (persistToFirestore) {
      try {
        await setDoc(doc(db, 'mountecSpreadsheet', 'currentData'), {
          rawData: JSON.stringify(newData),
          updatedAt: Date.now(),
          updatedBy: user?.email || 'System'
        });
      } catch (err) {
        console.warn("Failed to save sheet to Firestore:", err);
      }
    }
  };

  // Real-time synchronization of the master spreadsheet cache from Firestore
  useEffect(() => {
    const docRef = doc(db, 'mountecSpreadsheet', 'currentData');
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data().rawData;
        if (data) {
          try {
            const parsedData = JSON.parse(data);
            if (Array.isArray(parsedData) && parsedData.length > 0) {
              // Self-healing: Check if ME-001 Stint 1 is incorrectly marked as 'Live' and heal it to 'Cancelled'
              const headers = parsedData[0];
              if (Array.isArray(headers)) {
                const getIdx = (keywords: string[]) => headers.findIndex(h => keywords.some(k => String(h || '').toLowerCase().includes(k)));
                const empIdIdx = getIdx(['employee id', 'empid', 'id']);
                const sNoIdx = getIdx(['s/no', 'sno']);
                const passStatusIdx = getIdx(['pass status', 'status']);
                const exitDateIdx = getIdx(['exit date']);
                const durationIdx = getIdx(['work duration']);
                const nameIdx = getIdx(['name of worker', 'name']);
                const nationalityIdx = getIdx(['nationality']);
                const dateOfAppIdx = getIdx(['date of application']);
                const dateOfEmpIdx = getIdx(['date of employment']);
                const passIssuanceIdx = getIdx(['pass issuance', 'issuance date']);
                const dobIdx = getIdx(['date of birth', 'dob']);
                const finNoIdx = getIdx(['fin no', 'finno']);
                const passNoIdx = getIdx(['pass no', 'passno', 'wps pass no']);
                const passExpiryIdx = getIdx(['pass expiry', 'expiry date']);
                const passportNoIdx = getIdx(['passport no']);
                const passportExpiryIdx = getIdx(['passport expiry']);
                const passportCountryIdx = getIdx(['passport issuing']);

                let updated = false;
                parsedData.forEach((row, idx) => {
                  if (idx === 0 || !Array.isArray(row)) return;
                  const empId = empIdIdx >= 0 ? String(row[empIdIdx] || '').trim().toUpperCase() : '';
                  const sNo = sNoIdx >= 0 ? String(row[sNoIdx] || '').trim() : '';
                  
                  if (empId === 'ME-001' && sNo === '1') {
                    const currentStatus = passStatusIdx >= 0 ? String(row[passStatusIdx] || '').trim().toUpperCase() : '';
                    if (currentStatus === 'LIVE') {
                      console.log("Self-healing: Correcting ME-001 Stint 1 status to Cancelled in AppContext spreadsheet...");
                      if (passStatusIdx >= 0) row[passStatusIdx] = 'Cancelled';
                      if (exitDateIdx >= 0) row[exitDateIdx] = '07-Apr-2026';
                      if (durationIdx >= 0) row[durationIdx] = '3.81';
                      updated = true;
                    }
                  }

                  // General self-healing: Active workers (LIVE or PENDING) cannot have exit date or work duration month
                  const currentStatus = passStatusIdx >= 0 ? String(row[passStatusIdx] || '').trim().toUpperCase() : '';
                  const isRowActive = ['LIVE', 'PENDING ISSUANCE', 'PENDING ISSUANCE OF WP', 'PENDING ISSUANCE OF WP PASS'].includes(currentStatus);
                  if (isRowActive) {
                    const currentExitDate = exitDateIdx >= 0 ? String(row[exitDateIdx] || '').trim() : '';
                    const currentDuration = durationIdx >= 0 ? String(row[durationIdx] || '').trim() : '';
                    if (currentExitDate !== '' || currentDuration !== '') {
                      console.log(`Self-healing: Clearing exitDate/duration for active worker ${empId} in AppContext spreadsheet...`);
                      if (exitDateIdx >= 0) row[exitDateIdx] = '';
                      if (durationIdx >= 0) row[durationIdx] = '';
                      updated = true;
                    }
                  }
                });

                if (updated) {
                  setDoc(docRef, {
                    rawData: JSON.stringify(parsedData),
                    updatedAt: Date.now(),
                    updatedBy: 'System Auto-Healing'
                  }).catch(err => console.warn("Failed to auto-heal spreadsheet in Firestore:", err));
                }
              }

              setRawData(parsedData);
            }
          } catch (e) {
            console.error("Failed to parse spreadsheet data:", e);
          }
        }
      } else {
        // If the document does not exist, initialize it with the defaultSheetData so everyone is synced
        if (isMasterAdmin) {
          setDoc(docRef, {
            rawData: JSON.stringify(defaultSheetData),
            updatedAt: Date.now(),
            updatedBy: 'System Initialization'
          }).catch(err => console.warn("Failed to initialize spreadsheet in Firestore:", err));
        }
      }
    }, (err) => {
      console.error("Error listening to spreadsheet data:", err);
    });

    return () => unsubscribe();
  }, [isMasterAdmin]);

  // Derive and keep workers in sync with rawData dynamically
  useEffect(() => {
    if (rawData.length > 0) {
      const headers = rawData[0];
      const getIndex = (keywords: string[]) => {
        return headers.findIndex(h => keywords.some(k => h.toLowerCase().includes(k)));
      };

      const sNoIndex = getIndex(['s/no', 'sno']);
      const empIdIndex = getIndex(['employee id', 'empid', 'id']);
      const nameIndex = getIndex(['name of worker', 'name']);
      const nationalityIndex = getIndex(['nationality']);
      const dateOfAppIndex = getIndex(['date of application']);
      const dateOfEmpIndex = getIndex(['date of employment']);
      const passIssuanceIndex = getIndex(['pass issuance', 'issuance date']);
      const dobIndex = getIndex(['date of birth', 'dob']);
      const finNoIndex = getIndex(['fin no', 'finno']);
      const passNoIndex = getIndex(['pass no', 'passno', 'wps pass no']);
      const passExpiryIndex = getIndex(['pass expiry', 'expiry date']);
      const passportNoIndex = getIndex(['passport no']);
      const passportExpiryIndex = getIndex(['passport expiry']);
      const passportCountryIndex = getIndex(['passport issuing']);
      const passStatusIndex = getIndex(['pass status', 'status']);
      const bankAccIndex = getIndex(['bank account']);
      const bankNameIndex = getIndex(['bank name']);
      const mobileIndex = getIndex(['mobile']);
      const emailIndex = getIndex(['email']);
      const exitDateIndex = getIndex(['exit date']);
      const durationIndex = getIndex(['work duration']);

      const parsedWorkers: Worker[] = rawData.slice(1)
        .map((row, index) => {
          const empId = empIdIndex >= 0 ? row[empIdIndex] : '';
          const name = nameIndex >= 0 ? row[nameIndex] : row[0] || 'Unknown';
          const status = passStatusIndex >= 0 ? row[passStatusIndex] : 'Active';
          return {
            id: `w-${index}`,
            sNo: sNoIndex >= 0 ? row[sNoIndex] : '',
            employeeId: empId,
            nameOfWorker: name,
            name: name,
            nationality: nationalityIndex >= 0 ? row[nationalityIndex] : '',
            dateOfApplication: dateOfAppIndex >= 0 ? row[dateOfAppIndex] : '',
            dateOfEmployment: dateOfEmpIndex >= 0 ? row[dateOfEmpIndex] : '',
            wpsPassIssuanceDate: passIssuanceIndex >= 0 ? row[passIssuanceIndex] : '',
            dateOfBirth: dobIndex >= 0 ? row[dobIndex] : '',
            finNo: finNoIndex >= 0 ? row[finNoIndex] : '',
            wpsPassNo: passNoIndex >= 0 ? row[passNoIndex] : '',
            wpsPassExpiryDate: passExpiryIndex >= 0 ? row[passExpiryIndex] : '',
            passportNo: passportNoIndex >= 0 ? row[passportNoIndex] : '',
            passportExpiryDate: passportExpiryIndex >= 0 ? row[passportExpiryIndex] : '',
            passportIssuingCountry: passportCountryIndex >= 0 ? row[passportCountryIndex] : '',
            wpsPassStatus: (status || '').trim().toUpperCase() === 'PENDING ISSUANCE' ? 'PENDING ISSUANCE OF WP' : status,
            status: (status || '').trim().toUpperCase() === 'PENDING ISSUANCE' ? 'PENDING ISSUANCE OF WP' : status,
            bankAccountNo: bankAccIndex >= 0 ? row[bankAccIndex] : '',
            bankName: bankNameIndex >= 0 ? row[bankNameIndex] : '',
            mobileNumber: mobileIndex >= 0 ? row[mobileIndex] : '',
            emailId: emailIndex >= 0 ? row[emailIndex] : '',
            exitDate: exitDateIndex >= 0 ? row[exitDateIndex] : '',
            workDurationMonth: durationIndex >= 0 ? row[durationIndex] : '',
            role: 'Worker'
          };
        });
      
      setWorkers(parsedWorkers);
      try {
        localStorage.setItem('mountec_local_workers', JSON.stringify(parsedWorkers));
      } catch (e) {
        console.warn('Failed to save workers to local storage from AppContext:', e);
      }
    } else {
      // Load fallback default data on initial mount if rawData is still empty
      setRawData(defaultSheetData);
    }
  }, [rawData]);

  const syncWorkerToRawData = (worker: Worker, action: 'add' | 'update' | 'delete') => {
    if (rawData.length === 0) return;
    const headers = rawData[0];
    const getIndex = (keywords: string[]) => {
      return headers.findIndex(h => keywords.some(k => h.toLowerCase().includes(k)));
    };

    const sNoIndex = getIndex(['s/no', 'sno']);
    const empIdIndex = getIndex(['employee id', 'empid', 'id']);
    const nameIndex = getIndex(['name of worker', 'name']);
    const nationalityIndex = getIndex(['nationality']);
    const dateOfAppIndex = getIndex(['date of application']);
    const dateOfEmpIndex = getIndex(['date of employment']);
    const passIssuanceIndex = getIndex(['pass issuance', 'issuance date']);
    const dobIndex = getIndex(['date of birth', 'dob']);
    const finNoIndex = getIndex(['fin no', 'finno']);
    const passNoIndex = getIndex(['pass no', 'passno', 'wps pass no']);
    const passExpiryIndex = getIndex(['pass expiry', 'expiry date']);
    const passportNoIndex = getIndex(['passport no']);
    const passportExpiryIndex = getIndex(['passport expiry']);
    const passportCountryIndex = getIndex(['passport issuing']);
    const passStatusIndex = getIndex(['pass status', 'status']);
    const bankAccIndex = getIndex(['bank account']);
    const bankNameIndex = getIndex(['bank name']);
    const mobileIndex = getIndex(['mobile']);
    const emailIndex = getIndex(['email']);
    const exitDateIndex = getIndex(['exit date']);
    const durationIndex = getIndex(['work duration']);

    const newData = [...rawData];

    if (action === 'delete') {
      const rowIndex = newData.findIndex((row, idx) => {
        if (idx === 0) return false;
        const rowEmpId = empIdIndex >= 0 ? row[empIdIndex] : '';
        const rowName = nameIndex >= 0 ? row[nameIndex] : '';
        return (worker.employeeId && rowEmpId === worker.employeeId) || (worker.nameOfWorker && rowName === worker.nameOfWorker);
      });

      if (rowIndex >= 0) {
        newData.splice(rowIndex, 1);
        if (sNoIndex >= 0) {
          for (let i = 1; i < newData.length; i++) {
            newData[i][sNoIndex] = String(i);
          }
        }
        updateRawData(newData, true);
      }
    } else if (action === 'update') {
      let rowIndex = -1;
      
      const spreadsheetId = worker.spreadsheetId || (worker.id && worker.id.startsWith('w-') ? worker.id : null);
      
      // If the worker has a spreadsheet ID of form 'w-X', we can find the exact row directly and instantly!
      if (spreadsheetId && spreadsheetId.startsWith('w-')) {
        const idx = parseInt(spreadsheetId.replace('w-', ''), 10);
        if (!isNaN(idx) && idx >= 0 && idx < newData.length - 1) {
          rowIndex = idx + 1; // row 0 is header, so row X is index X + 1
        }
      }

      if (rowIndex === -1) {
        // Fallback search by Employee ID or Worker Name
        rowIndex = newData.findIndex((row, idx) => {
          if (idx === 0) return false;
          const rowEmpId = (empIdIndex >= 0 ? row[empIdIndex] : '').trim().toUpperCase();
          const rowName = (nameIndex >= 0 ? row[nameIndex] : '').trim().toUpperCase();
          const targetEmpId = (worker.employeeId || '').trim().toUpperCase();
          const targetName = (worker.nameOfWorker || '').trim().toUpperCase();
          return (targetEmpId && rowEmpId === targetEmpId) || (targetName && rowName === targetName);
        });
      }

      if (rowIndex >= 0) {
        newData[rowIndex] = [...newData[rowIndex]];
        if (empIdIndex >= 0) newData[rowIndex][empIdIndex] = worker.employeeId || '';
        if (nameIndex >= 0) newData[rowIndex][nameIndex] = worker.nameOfWorker || '';
        if (nationalityIndex >= 0) newData[rowIndex][nationalityIndex] = worker.nationality || '';
        if (dateOfAppIndex >= 0) newData[rowIndex][dateOfAppIndex] = worker.dateOfApplication || '';
        if (dateOfEmpIndex >= 0) newData[rowIndex][dateOfEmpIndex] = worker.dateOfEmployment || '';
        if (passIssuanceIndex >= 0) newData[rowIndex][passIssuanceIndex] = worker.wpsPassIssuanceDate || '';
        if (dobIndex >= 0) newData[rowIndex][dobIndex] = worker.dateOfBirth || '';
        if (finNoIndex >= 0) newData[rowIndex][finNoIndex] = worker.finNo || '';
        if (passNoIndex >= 0) newData[rowIndex][passNoIndex] = worker.wpsPassNo || '';
        if (passExpiryIndex >= 0) newData[rowIndex][passExpiryIndex] = worker.wpsPassExpiryDate || '';
        if (passportNoIndex >= 0) newData[rowIndex][passportNoIndex] = worker.passportNo || '';
        if (passportExpiryIndex >= 0) newData[rowIndex][passportExpiryIndex] = worker.passportExpiryDate || '';
        if (passportCountryIndex >= 0) newData[rowIndex][passportCountryIndex] = worker.passportIssuingCountry || '';
        if (passStatusIndex >= 0) newData[rowIndex][passStatusIndex] = worker.wpsPassStatus || '';
        if (bankAccIndex >= 0) newData[rowIndex][bankAccIndex] = worker.bankAccountNo || '';
        if (bankNameIndex >= 0) newData[rowIndex][bankNameIndex] = worker.bankName || '';
        if (mobileIndex >= 0) newData[rowIndex][mobileIndex] = worker.mobileNumber || '';
        if (emailIndex >= 0) newData[rowIndex][emailIndex] = worker.emailId || '';
        if (exitDateIndex >= 0) newData[rowIndex][exitDateIndex] = worker.exitDate || '';
        if (durationIndex >= 0) newData[rowIndex][durationIndex] = worker.workDurationMonth || '';
        
        updateRawData(newData, true);
      }
    } else if (action === 'add') {
      const newRow = new Array(headers.length).fill('');
      newRow[0] = String(newData.length + 5); 
      if (sNoIndex >= 0) newRow[sNoIndex] = String(newData.length);
      if (empIdIndex >= 0) newRow[empIdIndex] = worker.employeeId || '';
      if (nameIndex >= 0) newRow[nameIndex] = worker.nameOfWorker || '';
      if (nationalityIndex >= 0) newRow[nationalityIndex] = worker.nationality || '';
      if (dateOfAppIndex >= 0) newRow[dateOfAppIndex] = worker.dateOfApplication || '';
      if (dateOfEmpIndex >= 0) newRow[dateOfEmpIndex] = worker.dateOfEmployment || '';
      if (passIssuanceIndex >= 0) newRow[passIssuanceIndex] = worker.wpsPassIssuanceDate || '';
      if (dobIndex >= 0) newRow[dobIndex] = worker.dateOfBirth || '';
      if (finNoIndex >= 0) newRow[finNoIndex] = worker.finNo || '';
      if (passNoIndex >= 0) newRow[passNoIndex] = worker.wpsPassNo || '';
      if (passExpiryIndex >= 0) newRow[passExpiryIndex] = worker.wpsPassExpiryDate || '';
      if (passportNoIndex >= 0) newRow[passportNoIndex] = worker.passportNo || '';
      if (passportExpiryIndex >= 0) newRow[passportExpiryIndex] = worker.passportExpiryDate || '';
      if (passportCountryIndex >= 0) newRow[passportCountryIndex] = worker.passportIssuingCountry || '';
      if (passStatusIndex >= 0) newRow[passStatusIndex] = worker.wpsPassStatus || 'LIVE';
      if (bankAccIndex >= 0) newRow[bankAccIndex] = worker.bankAccountNo || '';
      if (bankNameIndex >= 0) newRow[bankNameIndex] = worker.bankName || '';
      if (mobileIndex >= 0) newRow[mobileIndex] = worker.mobileNumber || '';
      if (emailIndex >= 0) newRow[emailIndex] = worker.emailId || '';
      if (exitDateIndex >= 0) newRow[exitDateIndex] = worker.exitDate || '';
      if (durationIndex >= 0) newRow[durationIndex] = worker.workDurationMonth || '';

      newData.push(newRow);
      updateRawData(newData, true);
    }
  };

  return (
    <AppContext.Provider value={{ workers, setWorkers, rawData, setRawData, updateRawData, syncWorkerToRawData, sheetId, setSheetId, sheetRange, setSheetRange, isViewOnly, isUserAdmin, isMasterAdmin, userRole, accessiblePanels, accessStatus, requestAccess, preferences, updatePreferences, user, selectedEmployeeIdFor23, setSelectedEmployeeIdFor23 }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
