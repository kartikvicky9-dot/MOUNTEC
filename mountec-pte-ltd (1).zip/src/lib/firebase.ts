import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, initializeFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = (firebaseConfig as any).firestoreDatabaseId
  ? initializeFirestore(app, {}, (firebaseConfig as any).firestoreDatabaseId)
  : getFirestore(app);
export const storage = getStorage(app);

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.addScope('https://www.googleapis.com/auth/drive.readonly');

let isSigningIn = false;

const TOKEN_KEY = 'mountec_google_token';
const EXPIRY_KEY = 'mountec_google_token_expiry';
const EMAIL_KEY = 'mountec_google_token_email';

let cachedAccessToken: string | null = null;
let cachedEmail: string | null = null;
try {
  if (typeof sessionStorage !== 'undefined') {
    cachedAccessToken = sessionStorage.getItem(TOKEN_KEY);
    cachedEmail = sessionStorage.getItem(EMAIL_KEY);
    const expiry = sessionStorage.getItem(EXPIRY_KEY);
    if (expiry && Date.now() > parseInt(expiry, 10)) {
      cachedAccessToken = null;
      cachedEmail = null;
      sessionStorage.removeItem(TOKEN_KEY);
      sessionStorage.removeItem(EXPIRY_KEY);
      sessionStorage.removeItem(EMAIL_KEY);
    }
  }
} catch (e) {
  console.warn('Session storage not accessible:', e);
}

const setCachedToken = (token: string, email: string) => {
  cachedAccessToken = token;
  cachedEmail = email;
  try {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem(TOKEN_KEY, token);
      sessionStorage.setItem(EMAIL_KEY, email);
      sessionStorage.setItem(EXPIRY_KEY, (Date.now() + 55 * 60 * 1000).toString());
    }
  } catch (e) {}
};

export const clearCachedToken = () => {
  cachedAccessToken = null;
  cachedEmail = null;
  try {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem(TOKEN_KEY);
      sessionStorage.removeItem(EXPIRY_KEY);
      sessionStorage.removeItem(EMAIL_KEY);
    }
  } catch (e) {}
};

export const initAuth = (
  onAuthSuccess?: (user: User, token: string | null) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
    } else {
      clearCachedToken();
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (requireMountecStorage: boolean = false): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    
    const email = result.user.email || '';

    if (credential?.accessToken) {
        setCachedToken(credential.accessToken, email);
    }
    
    return { user: result.user, accessToken: cachedAccessToken || '' };
  } catch (error: any) {
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (requireMountecStorage: boolean = false): Promise<string | null> => {
  try {
    if (typeof sessionStorage !== 'undefined') {
      const expiryStr = sessionStorage.getItem(EXPIRY_KEY);
      if (expiryStr && Date.now() > parseInt(expiryStr, 10)) {
        clearCachedToken();
      }
    }
  } catch (e) {}
  return cachedAccessToken;
};

export const logout = async () => {
  await auth.signOut();
  clearCachedToken();
  localStorage.removeItem('mountec_custom_user');
  window.location.reload();
};
