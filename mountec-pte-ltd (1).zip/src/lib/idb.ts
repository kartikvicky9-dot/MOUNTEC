export const setMusicFile = async (file: File) => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('MountecMusicDB', 1);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('music')) {
        db.createObjectStore('music');
      }
    };
    request.onsuccess = (e: any) => {
      const db = e.target.result;
      const transaction = db.transaction('music', 'readwrite');
      const store = transaction.objectStore('music');
      store.put(file, 'selectedSong');
      transaction.oncomplete = () => resolve(true);
      transaction.onerror = () => reject(transaction.error);
    };
    request.onerror = () => reject(request.error);
  });
};

export const getMusicFile = async (): Promise<File | null> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('MountecMusicDB', 1);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('music')) {
        db.createObjectStore('music');
      }
    };
    request.onsuccess = (e: any) => {
      const db = e.target.result;
      const transaction = db.transaction('music', 'readonly');
      if (!db.objectStoreNames.contains('music')) {
         resolve(null);
         return;
      }
      const store = transaction.objectStore('music');
      const getReq = store.get('selectedSong');
      getReq.onsuccess = () => resolve(getReq.result || null);
      getReq.onerror = () => reject(getReq.error);
    };
    request.onerror = () => reject(request.error);
  });
};
