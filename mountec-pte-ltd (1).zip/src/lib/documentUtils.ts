import { db, storage } from './firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export const uploadDocument = async (category: string, file: File, displayName: string) => {
  // 1. Upload file to Storage
  const storageRef = ref(storage, `documents/${category}/${file.name}`);
  const snapshot = await uploadBytes(storageRef, file);
  const downloadURL = await getDownloadURL(snapshot.ref);
  
  // 2. Store document entry in Firestore
  await addDoc(collection(db, 'documents'), {
    category,
    originalName: file.name,
    displayName,
    downloadURL,
    version: 1, 
    updatedAt: serverTimestamp(),
  });
};

export const downloadFile = async (url: string, fileName: string) => {
  try {
    console.log('Attempting download for:', url);
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(blobUrl);
    console.log('Download successful');
  } catch (error) {
    console.error('Download failed, error:', error);
    alert('Download failed. Please try opening in a new tab to download manually.');
    // Fallback: If CORS blocks fetch, try direct link
    window.open(url, '_blank');
  }
};

export const previewFile = (url: string) => {
  console.log('Previewing:', url);
  window.open(url, '_blank');
};

export const shareFile = async (url: string, title: string) => {
  console.log('Sharing:', title, url);
  if (navigator.share) {
    try {
      await navigator.share({
        title: title,
        url: url
      });
      console.log('Share successful');
    } catch (err) {
      console.error('Error sharing:', err);
      await navigator.clipboard.writeText(url);
      alert('Share failed. Link copied to clipboard!');
    }
  } else {
    await navigator.clipboard.writeText(url);
    alert('Link copied to clipboard!');
  }
};

const documentUtils = {
  uploadDocument,
  downloadFile,
  previewFile,
  shareFile
};

export default documentUtils;
